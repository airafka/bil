# Реестр исследований и границы их применимости

Реестр подключает к библиотеке существующие исследования, не копируя их содержание. Он помогает понять, какой материал можно использовать как описание AS-IS, где внутри уже начинается проектирование TO-BE и какие выводы нужно перепроверить перед включением в ТЗ.

Состояние реестра проверено 11 сентября 2026 года по ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Работающее приложение, применённая БД и внешние системы не проверялись.

## Как читать статус

- **Частично сверено на текущем commit** — выборочные ключевые выводы повторно подтверждены исходниками, но всё исследование построчно не актуализировано.
- **Историческая база** — материал привязан к более старому commit или не содержит точного hash. Его нельзя загружать в GPT как безусловное описание текущего поведения.
- **TO-BE / рекомендация** — вариант изменения, а не реализованное поведение.

```mermaid
flowchart LR
    A[Задача аналитика] --> B{Предметная область}
    B --> C[КТК: затарка и растарка]
    B --> D[Порожний ЖД-вывоз]
    B --> E[Waybill и ЭТРАН]
    B --> I[Интеграционные контракты и ТЗ]
    C --> F[AS-IS исследование + текущие DTO/API/JPA]
    D --> F
    E --> F
    I --> F
    F --> G[Отделить подтверждённое от вопросов и TO-BE]
    G --> H[Формировать или проверять ТЗ]
```

## Карта материалов

| Исследование | Область | Исходная версия | Статус на `22fac945…` | Для чего использовать |
|---|---|---|---|---|
| [Затарка / растарка КТК](../../alis-container-stuffing-unstuffing-as-is.md) | Shipping/Receiving orders, КТК, клиент стока, остатки, WMS/TOS | 02.09.2026; commit в документе не указан | Историческая база; ключевые выводы частично сверены | Поиск существующих моделей ownership, reservation, movement и content перед проектированием операции |
| [Завершение ЖД-заявок без КТК](../../alis-empty-railway-shipping-order-event-analysis.md) | ShippingOrder, вагоны, `/datareon/event`, статусы и дедупликация | 31.08.2026; commit в документе не указан | Историческая база; основной дефект частично сверён | Анализ незавершения порожнего ЖД-вывоза и требований к входящему событию |
| [ЖД-модель вокруг Waybill](../../alis-waybill-railway-as-is.md) | Waybill/ЭТРАН, вагоны, КТК, ReceivingOrder и stockClient | `dev`, `3d8c8bb71a04fef2e9319d350ae7c0d1bfbaa318`, 04.09.2026 | Историческая база; текущий AS-IS актуализирован отдельно | Модель агрегата и ownership полей; варианты overlay использовать только как проектные рекомендации |

## Затарка / растарка КТК

### Что частично подтверждено сейчас

- `ContainerOwner` по-прежнему хранит связь `Client + Container`; полей status, receiving order и shipping order в entity нет.
- Production enum `EXPECTED / ON_TERMINAL / RESERVED_OUT / DEPARTED` в Java-исходниках не найден.
- Accept-validator каждой стороны ищет занятость КТК только среди заявок собственного типа: shipping отдельно от receiving. Это подтверждает описанный риск отсутствия единой cross-type серверной проверки.
- Все 51 локальная Markdown-ссылка исследования разрешается в текущем рабочем дереве.

Актуальные технические точки входа: [Container](../entities/catalog/entities/container/Container.md), [ContainerOwner](../entities/catalog/entities/containerowner/ContainerOwner.md), [ContainerRemain](../entities/catalog/entities/containerremain/ContainerRemain.md) и [правила заявок](../business-rules/orders.md).

### Где AS-IS, а где предложение

Разделы о существующих Shipping/Receiving orders, `Container`, `ContainerOwner`, остатках и маршрутизации WMS/TOS являются исследованием AS-IS. «Возможная точка для признака операции», «Точки расширения» и рекомендации о новом operation kind — проектные направления, а не реализованный контракт. Разделы о блокировке и содержимом КТК смешивают подтверждённые ограничения с будущими вариантами; каждое предлагаемое правило из них нужно оформлять как изменение.

### Что остаётся вопросом

- какой commit фактически исследовался 02.09.2026;
- должен ли TOS участвовать в stuffing/unstuffing и какое поле ожидает WMS;
- является ли `container_remain` authoritative состоянием или отчётным снимком;
- состояние feature flag и конкурентное поведение на работающей среде;
- применённые ограничения БД и фактическая взаимная блокировка заявок.

## Завершение порожнего ЖД-вывоза

### Что частично подтверждено сейчас

- Endpoint в текущем коде — `POST /datareon/event`; его декларативный контракт доступен в [каталоге API](../api/endpoints-generated.md#datareoncontroller).
- Shipping-ветка `CarriageArrivedAction` ставит `ShippingOrderRailwayCarriage.status = FINISHED`, но не вызывает проверку завершённости всей заявки. Receiving-ветка вызывает `tryMarkOrderDone()`.
- Само исследование не содержит кликабельных Markdown-ссылок: пути к исходникам перечислены текстом. В рамках этой сверки повторно проверены `DatareonController` и обе ветки `CarriageArrivedAction`, но не весь перечень файлов раздела 13.

Актуальные технические точки входа: [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md), [ShippingOrderRailwayCarriage](../entities/catalog/entities/shippingorderrailwaycarriage/ShippingOrderRailwayCarriage.md), [контракт endpoint](../api/endpoints-generated.md#datareoncontroller) и [правила вывоза](../business-rules/shipping-orders.md).

### Где AS-IS, а где предложение

Документ в основном описывает найденный AS-IS дефект, существующие механизмы `DONE`, идентификаторы и транзакции. Раздел «Что учитывать при будущей доработке» — перечень ограничений для проектирования, но не готовое решение и не реализованное правило.

### Что остаётся вопросом

- какой commit фактически исследовался 31.08.2026;
- актуальные строки `inbound_event_config` в нужной среде;
- какое событие TOS действительно отправляет при уходе порожнего вагона;
- допустима ли дедупликация только по `_id` и как соотносятся ID сообщения и ID wagon task;
- необходимые побочные эффекты при переводе заявки в `DONE`.

## ЖД-модель вокруг Waybill

**Актуальная замена AS-IS:** [Waybill и входящий ЭТРАН](../business-rules/waybill-etran-as-is.md) прослеживает текущий импорт, все пользовательские группы endpoints, DTO, справочники, связь с поставкой, ошибки, повторы и тесты на `22fac945…`. При подготовке ТЗ используйте её первой; старое исследование оставлено для расширенного контекста и исторических TO-BE-вариантов.

### Актуальность относительно текущего кода

Исследование выполнено на commit `3d8c8bb7…`, который является предком текущего `22fac945…`. После него `4e55d447…` изменил входные type/ISO поля и убрал старое вычисление классификации, а `42eee4ee` изменил фильтрацию/сортировку Waybill containers и railway carriages, включая `WaybillService`. Текущий серверный контур повторно прослежен в новом AS-IS; неперенесённые разделы старого исследования нельзя считать автоматически актуальными.

Само исследование не содержит кликабельных Markdown-ссылок: Java-файлы и строки указаны текстом. Поэтому разрешимость его source references автоматически не доказана; выборочно проверены существование ключевых файлов и Git-diff относительно исходного commit.

Актуальные технические точки входа: [Waybill](../entities/catalog/entities/waybill/Waybill.md), [WaybillRailwayCarriage](../entities/catalog/entities/waybillrailwaycarriage/WaybillRailwayCarriage.md), [WaybillContainer](../entities/catalog/entities/waybillcontainer/WaybillContainer.md), [WaybillIntegrationDto](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md) и [Waybill endpoints](../api/endpoints-generated.md#waybillcontroller).

### Где AS-IS, а где предложение

Описание агрегата, импортов, ownership, мутаций, TOS flow и обнаруженных дефектов — исследовательская часть AS-IS на старом commit. Уже в резюме присутствует архитектурная рекомендация варианта C. Разделы про создание overlay, lifecycle, outbound/inbound с overlay, будущую state machine, сравнение A/B/C и минимальный контракт — TO-BE без реализации. Их нельзя выдавать за существующие таблицы или endpoints.

### Что остаётся вопросом

- повторная проверка filter/sort/read-model после `42eee4ee`;
- состояние live schema, особенно аномалия `waybill_identifier` для manual Waybill;
- фактическое использование legacy endpoints отсутствующим frontend-репозиторием;
- production mapping `eventCode → actionCode`;
- согласование ownership `stockClient` и выбор варианта overlay владельцем процесса.

## Материалы `docs/integrations`

Ни один из шести Markdown-файлов каталога не содержит одновременно точную исходную дату и commit. Поэтому даже документы с подробными Java-ссылками являются входными исследованиями, а не автоматически актуальным слоем библиотеки.

| Материал | Классификация | Что подтверждено текущим репозиторием | Что нельзя считать реализованным |
|---|---|---|---|
| [Договоры и контрагенты 1С:ДО](../../integrations/1c-edo-contract-with-contractor-api.md) | Смешанный: частично устаревший AS-IS + проектный контракт | Оба действующих endpoint заново проверены: [Contractor](../business-rules/contractor-edo-datareon-as-is.md) и [Contract](../business-rules/contract-edo-datareon-as-is.md) | Успешный contractor update, идемпотентный contract create и применение внутренних DTO constraints не подтверждаются; `/contract-with-client`, единая транзакция и error contract не реализованы |
| [Draft ТЗ: договор с вложенным клиентом](../../integrations/tz-1c-edo-contract-with-client-api.md) | TO-BE, `document_type: Техническое задание`, `status: Draft`, 31.08.2026 | Использованные как основание текущие классы договоров/клиентов существуют | Все BR/TC, новый endpoint, миграции, идемпотентность, аутентификация и согласование с 1С/Datareon/ИБ |
| [Справочник вагонов ЭТРАН](../../integrations/etran-railway.md) | Неверсионированное исследование backend + внешнего преобразования | Backend актуализирован в [отдельном AS-IS](../business-rules/etran-reference-imports-as-is.md) | Алгоритм Datareon, production mapping типов, единицы измерения и фактические HTTP-ответы среды без внешнего источника/стенда |
| [Справочник контейнеров ЭТРАН](../../integrations/etran-container.md) | Неверсионированное исследование backend + внешнего преобразования | Backend актуализирован в [отдельном AS-IS](../business-rules/etran-reference-imports-as-is.md) | Скрипт Datareon, ISO-преобразование как deployed truth, единицы измерения и поведение среды |
| [Жизненный цикл КТК](../../integrations/ktk-lifecycle-as-is.md) | AS-IS срез от 25.08.2026, без commit | Текущие технические каталоги подтверждают отдельные модели `Container`, заявочных контейнеров, `ContainerRemain` и `ContainerOwner` | Полная актуальность всех flow после даты среза и фактическое состояние TOS/Datareon/БД |
| [Дефект загрузки Waybill](../../integrations/waybill-reference-lookup-bug.md) | Смешанный: исторический дефект + временное решение + TO-BE | `/datareon/waybill` по-прежнему создаёт/обновляет справочные вагоны и КТК | Старая причина классификации по `sort`/длине уже не соответствует коду; временное решение «только искать справочники» не реализовано |

### 1С:ДО — договор и клиент

Первый документ полезен для сравнения действующего раздельного приема договора/контрагента с предлагаемой объединённой операцией. Его разделы 1–2 и перечень Java-источников относятся к AS-IS; начиная с принципа отбора и нового URI документ преимущественно проектный. Второй файл — самостоятельный Draft ТЗ: его BR-01–BR-11, API, коды ошибок, миграции и TC-01–TC-17 являются требованиями, а не найденным поведением.

На `22fac945…` endpoint `/datareon/contract-with-client` в коде и generated-каталоге отсутствует. Не подтверждены правила отбора договоров в 1С:ДО, сетевой маршрут, authentication, `External-ID`, retry и очередь Datareon. Для текущей раздельной схемы использовать [Contractor AS-IS](../business-rules/contractor-edo-datareon-as-is.md) и [Contract AS-IS](../business-rules/contract-edo-datareon-as-is.md): первый выявил rollback update существующего `edoId`, второй — create-only без защиты от повторного insert и управляемой ошибки Currency. Зависимые [Company/Currency prerequisites](../business-rules/company-currency-contract-prerequisites-as-is.md) имеют только read endpoints; их production-источник наполнения в репозитории не установлен.

### ЭТРАН — справочники вагонов и КТК

Текущая Java-часть обоих потоков заново прослежена в [backend AS-IS справочников ЭТРАН](../business-rules/etran-reference-imports-as-is.md) на `22fac945…`. Используйте его для endpoint/DTO/upsert/ошибок/транзакции. Исходные два документа нужны для изучения предполагаемой внешней предобработки, которая не доказана backend-репозиторием.

Оба документа подробно описывают backend DTO, пакетный upsert, дубли, транзакцию и расхождения OpenAPI. Эти части сверены и уточнены: в частности, `null`-элемент container list может дать `500`, unknown ISO — `500`, update очищает optional-поля, а специализированных integration tests не найдено. Разделы «Предобработка Datareon» описывают код внешней шины, которого нет в backend-репозитории; их нельзя подтверждать одной Java-сверкой.

PlantUML-источники доступны рядом: [вагоны — activity](../../integrations/etran-railway-activity.puml), [вагоны — sequence](../../integrations/etran-railway-sequence.puml), [КТК — activity](../../integrations/etran-container-activity.puml), [КТК — sequence](../../integrations/etran-container-sequence.puml). Актуальные backend-точки: [Datareon endpoints](../api/endpoints-generated.md#datareoncontroller), [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) и [Container](../entities/catalog/entities/container/Container.md).

Открытыми остаются deployed-версия скриптов Datareon, коды справочников на стендах, единицы измерения, регистрозависимость, идемпотентность `MessageID` и фактический error mapping.

### Жизненный цикл КТК

Это наиболее чистый AS-IS материал каталога: он прямо исключает предложения. Однако commit среза не указан, а более новое исследование [затарки/растарки](../../alis-container-stuffing-unstuffing-as-is.md) частично перекрывает и уточняет его. Использовать документ как карту четырёх разных моделей — справочник, заявочный состав, остатки и ownership — после чего переходить к актуальным [JPA-паспортам](../entities/catalog/README.md) и endpoint-каталогу.

Текущий inbound и хранение остатков КТК/вагонов заново прослежены на `22fac945…` в [актуальном AS-IS остатков](../business-rules/remain-inbound-as-is.md). Он является приоритетным источником для `/datareon/*-remain`, DTO, ключей upsert, журналов, delete-and-reload, views и различия `container_remain`/`container_movement`; старый lifecycle остаётся обзорной картой соседних моделей.

### Дефект `/datareon/waybill`

Документ нельзя использовать как описание текущей причины инцидента. Commit `4e55d447eb554311d5d5e8dab8877011befccbfe` (`KIS-4590 remove value calculation from waybill integration`, 21.08.2026) уже изменил `WaybillIntegrationDto`, `WaybillDatareonService` и его integration test: текущий сервис получает `typeId`, `containerType` и ISO из входного DTO вместо описанной старой классификации вагона по `sort`/длине и КТК только по длине. Текущее поведение зафиксировано в [Waybill/ЭТРАН AS-IS](../business-rules/waybill-etran-as-is.md#изменения-после-исторического-исследования).

При этом текущий `/datareon/waybill` всё ещё выполняет `findOrCreate` и обновляет справочные объекты, поэтому предложенное временное решение «только найти существующие объекты» также не стало AS-IS. Записанный в документе путь `/api/datareon/waybill` содержит внешний `/api`-префикс, которого нет в controller mapping; source-каталог подтверждает `/datareon/waybill`, а gateway/reverse-proxy отдельно не проверялся.

Материал сохраняет ценность как история дефекта и набор требований/тестовых сценариев, но перед новым ТЗ его нужно актуализировать по [WaybillIntegrationDto](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md), [Waybill](../entities/catalog/entities/waybill/Waybill.md) и [текущему endpoint](../api/endpoints-generated.md#datareoncontroller).

## Краткий словарь

| Термин | Значение в этих материалах |
|---|---|
| КТК / `Container` | Физический крупнотоннажный контейнер из справочника `container` |
| `Cargo` | Грузовое место WMS; не является КТК, даже если в старом тексте названо контейнером |
| `ContainerOwner` | Текущая связь физического КТК с клиентом стока; не подтверждённая state machine местонахождения |
| `container_movement` / `ContainerRemains` | Движения физического КТК по событиям; не то же самое, что импортируемый снимок `container_remain` |
| Waybill | ЖД-накладная и её source-агрегат |
| WRC / `WaybillRailwayCarriage` | Вхождение вагона в конкретную Waybill |
| WC / `WaybillContainer` | Вхождение КТК в конкретный WRC/Waybill |
| ROC / `ReceivingOrderContainer` | Операционная строка КТК заявки поставки; не нейтральная копия WC |
| Overlay | Предлагаемый слой данных конкретной заявки поверх source-фактов Waybill; в описанном варианте C ещё не реализован |
| AS-IS | Поведение, найденное в исследованной версии кода; версия всё равно должна быть учтена |
| TO-BE | Предложение или целевой контракт, которого нельзя считать реализованным без кода/миграции |

## Как использовать в контексте GPT

Сначала загружайте этот реестр, затем только одно относящееся к задаче исследование и актуальные технические паспорта/API. В запросе явно указывайте текущий commit и просите модель разделять подтверждённый AS-IS, вывод исследования, открытый вопрос и TO-BE. Для окончательной проверки ТЗ ссылки исследования нужно сверять с текущим кодом, миграциями и доступными тестами.
