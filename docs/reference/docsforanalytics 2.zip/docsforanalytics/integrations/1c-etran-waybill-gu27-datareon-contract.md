# Контракт Datareon Etran27 для ЖД-накладной

Паспорт перенесён из `Etran27_22.09.2026_9-26-52.xlsx`. В книге один лист `Etran27`, 125 строк с заголовком и 7 колонок: наименование, тип, признак массива, разрешение `NULL`, проверка заполнения, внутренний идентификатор проверки и комментарий.

Связанный процесс: [ЖД-накладная 1С ЭТРАН → Datareon → ALIS](1c-etran-waybill-gu27-as-is.md). Контракт ALIS: [`WaybillIntegrationDto`](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md).

## Как читать обязательность

Выгрузка содержит 124 строки модели:

- 6 узлов-массивов;
- 116 строк с `Разрешить NULL = true`;
- 8 строк с `Разрешить NULL = false`;
- у всех 124 строк `Проверка заполнения = false`.

`NULL запрещён` в модели Datareon и `поле проверяется как заполненное` — разные признаки. В этой выгрузке запрет `NULL` установлен для `waybill`, шести массивов и `waybill_railway_carriage.railway_number`, но отдельная проверка заполнения не включена даже для них.

UUID из колонки `Проверка` — внутренние идентификаторы объектов Datareon. Они не являются полями JSON и здесь не повторяются.

## Корень сообщения

| JSON path | Тип Datareon | Массив | NULL |
|---|---|---:|---:|
| `waybill` | `waybill` | нет | запрещён |
| `Version` | `String [Max]` | нет | разрешён |
| `MessageId` | `String [Max]` | нет | разрешён |

Расхождение: ALIS ожидает `Version` как `Integer`, `MessageId` как UUID и также принимает alias `MessageID`.

## waybill

Все перечисленные scalar-поля допускают `NULL` в Datareon и не имеют проверки заполнения.

| Поле | Тип Datareon |
|---|---|
| `destination_route` | `String [Max]` |
| `departure_route` | `String [Max]` |
| `responsible_person` | `String [Max]` |
| `planned_wagons` | `String [50]` |
| `waybill_status` | `String [Max]` |
| `waybill_type` | `String [Max]` |
| `waybill_number` | `String [Max]` |
| `waybill_identifier` | `String [50]` |
| `shipment_type` | `String [Max]` |
| `shipment_speed` | `String [Max]` |
| `form_type` | `String [Max]` |
| `delivery_deadline` | `DateTime` |
| `waybill_created_at` | `DateTime` |
| `submitted_at` | `DateTime` |
| `approved_at` | `DateTime` |
| `accepted_at` | `DateTime` |
| `cargo_accepted_at` | `DateTime` |
| `departure_at` | `DateTime` |
| `departure_country` | `String [Max]` |
| `departure_station` | `String [Max]` |
| `departure_station_code` | `String [50]` |
| `destination_country` | `String [Max]` |
| `destination_station` | `String [Max]` |
| `destination_station_code` | `String [50]` |
| `shipper_name` | `String [Max]` |
| `shipper_address` | `String [Max]` |
| `shipper_tgnl` | `String [50]` |
| `shipper_okpo` | `String [50]` |
| `consignee_name` | `String [Max]` |
| `consignee_address` | `String [Max]` |
| `consignee_tgnl` | `String [50]` |
| `consignee_okpo` | `String [Max]` |
| `payer` | `String [Max]` |
| `payer_code` | `String [50]` |
| `payment_form` | `String [Max]` |
| `payment_place` | `String [Max]` |
| `wagon_ownership_type` | `String [Max]` |

## waybill_product

Узел `waybill_product` имеет тип `waybill_product`, является массивом и запрещает `NULL`. Все его поля допускают `NULL`.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `etsng_name` | `String [Max]` | да |
| `etsng_code` | `String [50]` | да |
| `gng_code` | `String [50]` | да |
| `cargo_full_name` | `String [Max]` | да |
| `additional` | `String [Max]` | да |
| `packaging_type` | `String [Max]` | да |
| `cargo_volume` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `cargo_weight` | `Decimal [15, 2]` | да |
| `weight_loaded` | `Decimal [15, 2]` | да |
| `cargo_weight_net` | `Decimal [15, 2]` | да |
| `cargo_weight_gross` | `Decimal [15, 2]` | да |
| `length` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `width` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `height` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `marks_stamps_shipper` | `String [Max]` | да |
| `sign_danger` | `String [Max]` | да |
| `packages_count` | `Int` | да |
| `places_count` | `Int` | да |
| `is_dangerous` | `String [Max]` | да |
| `emergency_card_number` | `String [Max]` | да |
| `customs_declaration_number` | `String [Max]` | да |
| `customs_declaration_product_number` | `String [50]` | да |
| `danger_identifier` | `String [50]` | **нет: ALIS ожидает `danger_product`** |

Word mapping и пример JSON используют `danger_product`, поэтому имя из Excel является прямым межсистемным расхождением.

## waybill_railway_carriage

Узел `waybill_railway_carriage` имеет одноимённый тип, является массивом и запрещает `NULL`. Поле `railway_number` также запрещает `NULL`; остальные поля допускают его.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `sort` | `String [Max]` | да |
| `railway_lifting_capacity` | `Decimal [15, 3]` | да, DTO ожидает строку |
| `railway_volume` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `axles_count` | `Int` | да, DTO ожидает строку |
| `ownership` | `String [Max]` | да |
| `renter` | `String [Max]` | да |
| `previously_transported` | `String [Max]` | да |
| `railway_weight_gross` | `String [50]` | да |
| `railway_weight_net` | `String [50]` | да |
| `place_count` | `Int` | да |
| `railway_length` | `Decimal [15, 2, Trim]` | да |
| `model` | `String [Max]` | да |
| `date_of_next_repair` | `DateTime` | да, DTO ожидает строку |
| `railway_weight` | `Int` | нет напрямую; Datareon пишет производное `weight` |
| `railway_number` | `String [50]` | да |
| `proxy_operator` | `String [Max]` | нет |
| `mileage_rate` | `String [50]` | нет напрямую |
| `mileage` | `String [50]` | нет напрямую |
| `noworking_parking` | `Int` | нет |
| `wagon_length` | `Decimal [15, 3]` | нет напрямую; участвует в расчёте `type_id` |
| `weight` | `Decimal [15, 3]` | да |
| `lifting_capacity` | `Decimal [15, 3]` | нет: ALIS читает `railway_lifting_capacity` |
| `sort_id` | `String [50]` | нет напрямую; участвует в расчёте `type_id` |
| `remaining_mileage` | `Decimal [15, 2]` | нет |
| `type_id` | `String [50]` | да |

Скрипт из Word создаёт `weight`, `lifting_capacity`, `remaining_mileage` и `type_id`. Из этих производных полей текущий ALIS DTO использует `weight` и `type_id`; `lifting_capacity` и `remaining_mileage` не читаются.

## waybill_container

Узел `waybill_container` имеет одноимённый тип, является массивом и запрещает `NULL`. Все его поля допускают `NULL`.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `container_number` | `String [Max]` | да |
| `lifting_capacity` | `Decimal [15, 3]` | да, DTO ожидает строку |
| `weight` | `Decimal [15, 3]` | да |
| `sending_request_number` | `String [Max]` | да |
| `supply_request_number` | `String [Max]` | да |
| `container_length` | `Decimal [15, 2]` | да, DTO ожидает строку |
| `owner` | `String [Max]` | да |
| `weight_gross` | `Decimal [15, 3]` | да |
| `weight_net` | `Decimal [15, 3]` | да |
| `carriage_number` | `String [50]` | да |
| `container_name` | `String [50]` | нет |
| `height` | `String [50]` | нет напрямую; участвует в расчёте ISO |
| `length` | `String [50]` | нет напрямую; участвует в классификации |
| `name_ISO` | `String [50]` | нет |
| `ISO` | `String [50]` | да |
| `code` | `String [50]` | нет; ALIS использует `container_number` |
| `container_type` | `String [50]` | да, enum `ContainerType` |
| `etran_container_type_id` | `String [50]` | нет напрямую; участвует в расчёте `container_type` |
| `etran_container_type_name` | `String [50]` | нет |
| `owner_name` | `String [50]` | нет |
| `renter_name` | `String [50]` | нет |
| `renter` | `String [50]` | нет |

## waybill_zpu

Узел `waybill_zpu` является массивом и запрещает `NULL`; поля допускают `NULL`.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `zpu` | `String [Max]` | да |
| `zpu_type` | `String [Max]` | да |
| `container_number_zpu` | `String [Max]` | да |

## waybill_special_marks

Узел `waybill_special_marks` является массивом и запрещает `NULL`; поля допускают `NULL`.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `info` | `String [Max]` | да |
| `mark` | `String [Max]` | да |

## waybill_tariff_marks

Узел `waybill_tariff_marks` является массивом и запрещает `NULL`; поля допускают `NULL`.

| Поле | Тип Datareon | ALIS читает |
|---|---|---:|
| `name` | `String [Max]` | да |
| `code` | `String [50]` | да, затем преобразуется в Integer |
| `note` | `String [Max]` | да |

## Сводка несовпадений типов

| Path | Datareon | ALIS DTO | Следствие |
|---|---|---|---|
| `Version` | String | Integer | Допустим только числовой текст/JSON number, если Jackson разрешает coercion |
| `planned_wagons` | String | Integer | Нечисловое значение не десериализуется |
| `waybill_product.cargo_volume/length/width/height` | Decimal | String | Требуется подтверждение сериализации числа в String |
| `waybill_product.danger_identifier` | String | отсутствует; ожидается `danger_product` | Поле не сопоставляется по имени |
| `railway_lifting_capacity`, `railway_volume`, `axles_count` | Decimal/Int | String | Поведение зависит от Jackson coercion |
| `date_of_next_repair` | DateTime | String | Формат должен подходить последующему ручному parse |
| `container.lifting_capacity`, `container_length` | Decimal | String | Поведение зависит от Jackson coercion |
| `container.container_type` | String | enum | Разрешены только значения `ContainerType` ALIS |

Данные Excel описывают тип внутри Datareon, но не доказывают точный JSON после алгоритма и блока отправки. Для закрытия таблицы нужен сохранённый outbound payload из `ALIS_ETRAN_OUT` и результат десериализации на текущем окружении ALIS.
