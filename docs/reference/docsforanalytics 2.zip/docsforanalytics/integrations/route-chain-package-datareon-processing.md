# Route chain package: обработка на стороне Datareon (внешний материал)

**Основание:** не source-level. Содержимое ниже — C#-скрипты трансформации (движок Datareon "SystemModels", `OwnList<>`), предоставленные аналитиком напрямую из среды Datareon, а не найденные в репозитории `backend`. Репозиторий `backend` содержит только отправляющую сторону — см. [route-chain-package-export-as-is.md](../business-rules/route-chain-package-export-as-is.md) и его раздел «Граница охвата: сторона Datareon не задокументирована», который этот документ частично закрывает. Датировки внутри скриптов (комментарии с ФИО и датой, от `22.05.2025` до `01.06.2026`) показывают, что это накопленная за долгое время, многократно правленная логика, а не единый снимок.

**Покрытие:** получены и разобраны три из четырёх пакетов — `receiving_auto` (= `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE`), `recievingCont` (= `RECEIVING_RAILWAY_ROUTE_CHAIN_PACKAGE`), `ship_cont_pack` (= `SHIPPING_ROUTE_CHAIN_PACKAGE`). `SERVICE_ORDER_CHAIN_PACKAGE` не предоставлен. Скрипт `ship_cont_pack` получен **не полностью** — «Блок алгоритм 2» обрывается на середине цикла группировки безномерных контейнеров; всё, что после обрыва, не задокументировано.

Схемное имя переменной пакета (`receiving_auto`/`recievingCont`/`ship_cont_pack`) — это контекстный объект Datareon с теми же корневыми ключами, что в JSON от ALIS (`Route`, `ReceivingOrder`, `WaybillContainer` и т.д., см. таблицы полей в [route-chain-package-export-as-is.md](../business-rules/route-chain-package-export-as-is.md)), но скрипт может как читать, так и **перезаписывать** эти поля на месте — то, что описано здесь, это финальная форма пакета уже после трансформации, не то, что реально отправил ALIS.

## `receiving_auto`: обогащение и группировка

1. **`Route.waybillContainerIds`** заполняется ID всех `ReceivingOrderContainer` пакета (с дедупликацией). Имя поля модели — «waybillContainerIds» — не соответствует содержимому (это ID контейнеров заявки на поставку, не `WaybillContainer`); похоже на скопированное из железнодорожного скрипта имя поля.
2. Каждый `ReceivingOrderContainer` получает `routeId`, `clientDriverId`, `clientVehicleId` — напрямую из `Route`.
3. Каждый `ReceivingOrderContainer` получает `clientId`, `number`, `planReceivingDateTime` из связанного `ReceivingOrder` по `receivingOrderId`. **Fallback:** если `receivingOrderId` контейнера не парсится/отсутствует, связь не ищется явно — код берёт **первый** `ReceivingOrder` пакета (`break` после первой итерации `foreach`, независимо от реального совпадения). При нескольких заявках на поставку на одном рейсе это может молча привязать контейнер не к той заявке.
4. Строится новый массив **`ReceivingOrderContainerZpu[]`**: один объект на контейнер, `receivingContainerId` = ID контейнера, `zpus[].zpu` = каждый элемент `sealNumbers` контейнера. После переноса **исходный `sealNumbers` очищается до `[]`** — то есть в финальной (пост-трансформированной) форме пакета пломбы существуют только в новом вложенном блоке, не в плоском поле.
5. **`ReceivingOrderContainerItem`** перегруппируется по `receivingOrderContainerId` в обёртку `{receivingOrderContainerId, items[]}`. **Найдено расхождение комментария и кода:** комментарий гласит «только etsngCodeId и weightNet», но код пишет `itemEntry1.weightGross = containerItem.weightGross` — то есть фактически переносится `weightGross`, а не `weightNet`. Если предполагалось именно `weightNet` — это дефект в скрипте Datareon, не в ALIS.
6. **Дефолтный ЕТСНГ-код** `defaultEtsngCodeId = "05510530-a4df-4e29"` — обратите внимание, это **не полный UUID** (не хватает двух сегментов до формата 8-4-4-4-12); либо это артефакт при копировании материала, либо в реальном скрипте значение действительно неполное/невалидное — не проверено, какой из вариантов верен.
   - Если у сгруппированного `ReceivingOrderContainerItem`-объекта (обёртки из п.5) собственный `etsngCodeId` — `null` (комментарий подтверждает: «в этом пакете приходит null», то есть так и задумано на стороне ALIS для этого уровня), он заменяется на дефолтный.
   - Для вложенных `items[]` с `etsngCodeId == null` — то же самое, плюс `subs.weightGross = weight` — переменная `weight` **не объявлена в показанном фрагменте** (внешняя/пайплайн-переменная Datareon), её происхождение и значение не установлены по этому материалу.
   - Если справочник `EtsngCode[]` пакета пуст — в него добавляется одна синтетическая запись: `id = code = defaultEtsngCodeId`, `name = "Не выбран"`, `active = true`. То есть при полном отсутствии товарных данных Datareon подставляет фиктивный «код-заглушку», а не оставляет справочник пустым.

## `recievingCont` (Receiving Railway): matching, дедупликация, фильтрация

1. **Временный workaround, явно помеченный в комментарии:** ID всех `WaybillContainer` пакета кладутся в **`Route.receivingOrderIds`** — старое поле, переиспользуемое как временное хранилище, «потому что `Route.waybillContainerIds` ещё не создан в модели». Это прямое подтверждение технического долга на стороне Datareon-модели, а не ALIS.
2. Для каждого `ReceivingOrder` пакета:
   - **`WaybillRailwayCarriage`** с совпадающим `receivingOrderId` получает `routeId`, `planReceivingDateTime`, `clientId`, `number`, `departureStationId`, `destinationStationId` из этого заказа.
   - **`WaybillContainer`** матчится на заказ **в два уровня**, с явным обоснованием в коде («Наличие Route или автомобиля не подтверждает связь с заявкой» — то есть примитивное сопоставление через `Route` намеренно отвергнуто):
     - если у контейнера задан `waybillRailwayCarriageId` — ищем `WaybillRailwayCarriage` с этим ID, берём **его** `receivingOrderId` и сверяем с текущим заказом;
     - если `waybillRailwayCarriageId` не задан — сверяем `waybillContainer.receivingOrderId` напрямую с текущим заказом.
   - Только при подтверждённом совпадении (`containerMatched`) контейнер получает `routeId`, `planReceivingDateTime`, `clientId`, `number`, `departureStationId`, `destinationStationId` из заказа.
   - `transportType` и `clientDriverId` контейнер получает от `Route` **всегда**, независимо от результата matching на заказ.
3. **Дефект/техдолг, явно датированный и подписанный в коде** («Садиков И.А. 18.05.2026»): заполнение `WaybillContainer.railwayCarriageId` (физический ID вагона):
   - ветка `RAILWAY` (есть `waybillRailwayCarriageId`, `Route.transportType == RAILWAY`): корректно берёт `railwayCarriageId` из найденного `WaybillRailwayCarriage`;
   - ветка `AUTO` (нет railway carriage-связи или транспорт не ЖД) — **«временная логика»**: в поле `railwayCarriageId` записывается **id первого `ClientVehicle`** пакета. То есть поле, названное для физического вагона, в авто-случае содержит ID автомобиля клиента — семантическое смешение, прямо признанное временным самим автором комментария.
4. **`WaybillProduct`** группируется по `waybillContainerId` в `products[]` (только `etsngCodeId` + `weight`). **Фильтрация «порожнего груза»** (тот же автор, та же дата): продукты с `etsngCodeId` из зашитого списка двух GUID (`8a35634c-c7c2-4115-aecf-dc805ff35647`, `419660d8-7a2c-4578-8e95-438161f9ed69`, помечены как «Порожний контейнер / КОНТЕЙН УН ПРИВ») **исключаются из пакета целиком**, а не просто помечаются. Список расширяем — в коде есть закомментированный шаблон для добавления новых кодов.
5. **`WaybillZpu`** группируется по `waybillContainerId` в `zpus[]` (только `zpu`).
6. **Нормализация дублей `WaybillRailwayCarriage`** (автор «Энгель», 22.05.2025) — по паре `(railwayCarriageId, receivingOrderId)`:
   - первая встреченная строка с такой парой становится «главной», последующие — дублями;
   - **защитная проверка перед удалением:** число `WaybillRailwayCarriage` и число `WaybillContainer` с этой же парой `(railwayCarriageId, receivingOrderId)` должны совпадать; если нет — дубль **не удаляется** (риск потери связи важнее компактности пакета);
   - при успешной проверке все `WaybillContainer.waybillRailwayCarriageId`, указывавшие на дубль, переключаются на ID «главной» строки, а сама строка-дубль исключается из `WaybillRailwayCarriage[]`.
7. **Обогащение имени контейнера** (автор «Энгель», 01.06.2026): `WaybillContainer.containerName` ← `Container.code` по совпадению `containerId`.

Ни в одном из показанных блоков `recievingCont` не упоминается `ownerContainerId` — скрипт его не трогает ни для чтения, ни для перезаписи (для ReceivingRailway это ожидаемо: на стороне ALIS поле и так корректно заполнено, см. [route-chain-package-export-as-is.md](../business-rules/route-chain-package-export-as-is.md)).

## `ship_cont_pack` (Shipping): группировка + два подозрительных поля (получено не полностью)

### Блок алгоритм 1

1. `Route` получает две новые (не переиспользованные, в отличие от `recievingCont`) выделенные коллекции: **`shippingOrderIds`** (все `ShippingOrder.id` пакета) и **`shippingOrderContainerIds`** (все `ShippingOrderContainer.id`), обе с дедупликацией.
2. Для каждого `ShippingOrderContainer`, матчащегося на `ShippingOrder` по `shippingOrderId`:
   - из заказа: `number`, `transportType`, `plannedShippingDateTime`, `clientId`;
   - из `Route`: `routeId`, `clientDriverId`. Строка `shippingOrderContainer.clientVehicleId = ship_cont_pack.Route.clientVehicleId;` **закомментирована** — то есть ID автомобиля клиента **намеренно не проставляется** сюда в текущей версии скрипта (в отличие от `clientDriverId` рядом, который проставляется).
3. **Поле `railwayClientVehicleId`** (единичное значение, не массив) — двухступенчатый fallback:
   - сначала пробуем `Route.clientVehicleId`;
   - если не задано — ищем `ShippingOrderRailwayCarriage` по `shippingOrderRailwayCarriageId` контейнера и записываем **его `railwayCarriageId`** (ID физического вагона!) в поле, названное `railwayClientVehicleId`. Как и `railwayCarriageId` в `recievingCont` выше, это ещё один случай смешения именования «вагон vs автомобиль» в одном поле — похоже на системный паттерн в этих скриптах, а не единичную опечатку.
4. Группировки по `shippingOrderId`/`shippingOrderContainerQtyId` (аналогично `recievingCont`, но без фильтрации по ЕТСНГ):
   - `ShippingOrderRailwayCarriageQty` → `railwayCarriageQtys[]` (`quantity`, `typeId`);
   - `ShippingOrderContainerQty` → `containerQtys[]` (`id`, `quantity`, `type`, `empty`);
   - `ShippingOrderEtsngCode` (по `shippingOrderContainerQtyId`) → `qtys[]` (`etsngCodeId`, `weight`).
5. `ShippingOrderContainer.code` ← `Container.code` по совпадению `containerId`.
6. Переменная `analize` = `fillingType` **только первого** `ShippingOrder` пакета (`ship_cont_pack.ShippingOrder[0]`), используется как управляющее значение для дальнейшего ветвления (какого — не видно в полученном материале). Если на одном рейсе есть заявки с разным `fillingType`, дальнейшая ветка ориентируется только на первую.

### Блок алгоритм 2 (обрыв материала)

Начинается группировка `ShippingOrderContainer` по `shippingOrderId` в `containerIds[]` (для «безномерных» контейнеров) с полями `id`, `containerId` и обогащением `type`/`code` из `Container` по `containerId` — на этом полученный текст обрывается. Что происходит дальше (остальные ветки по `fillingType`, обработка ЖД-вагонов, финальная сборка пакета) — неизвестно.

## Сопоставление с известной находкой ALIS-стороны

Ни в одном из трёх скриптов нет компенсирующей логики для `ownerContainerId` заявки на вывоз (`ShippingOrderContainer.ownerContainerId`) — в `ship_cont_pack` это поле вообще не упоминается ни в одном из показанных блоков. Это косвенно подтверждает (но не доказывает окончательно, так как «Блок алгоритм 2» неполон), что дефект «`ownerContainerId` всегда `null`» на ALIS-стороне (действовал 22.09–08.10.2026, закрыт KIS-4830 — см. [регистр остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830)) ничем не компенсировался дальше по цепочке — Datareon просто передаёт то, что получил. Пакеты, отправленные в этот период, у получателя остались без владельца.

## Открытые вопросы

1. Реальный ли `defaultEtsngCodeId = "05510530-a4df-4e29"` неполный, или это артефакт копирования материала.
2. Происхождение переменной `weight` в блоке подстановки дефолтного ЕТСНГ для `receiving_auto` (внешняя по отношению к показанному фрагменту).
3. Расхождение комментария/кода `weightNet` vs `weightGross` в группировке `ReceivingOrderContainerItem` — что должно быть на самом деле.
4. Полный текст «Блок алгоритм 2» `ship_cont_pack` и дальнейшая логика по `analize`/`fillingType`.
5. Скрипт для `SERVICE_ORDER_CHAIN_PACKAGE` не получен вовсе.
6. Оба случая семантического смешения «вагон vs автомобиль» в одном поле (`railwayCarriageId` в `recievingCont`, `railwayClientVehicleId` в `ship_cont_pack`) — уточнить у команды Datareon, действительно ли это временные решения (как явно помечено для первого случая) и есть ли план их развести.
7. Насколько эта версия скриптов актуальна на момент чтения — датировки внутри комментариев (22.05.2025…01.06.2026) не гарантируют отсутствие более поздних правок после получения этого материала.

## Связанные документы

- [Route chain package export: 4 пакета в Datareon AS-IS](../business-rules/route-chain-package-export-as-is.md) — отправляющая (ALIS) сторона с полным JSON-контрактом каждого пакета.
- [Регистр остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md)
- [Интеграционные контуры ALIS](README.md)
