# Импорт товаров заявки из Excel (Авто СК): AS-IS

> Сверено с backend `dev`, commit `729c9a17` (14.10.2026). Описывает состояние после `8ee1ab68` (13.10.2026, KIS-4841, «add batchUnknown»), который сменил шаблоны листа «Номенклатура» и добавил признак «Партия неизвестна». Это **source-level реконструкция** (`SOURCE_CONFIRMED`, если не указано иное); импорт на стенде и тесты парсеров не запускались — тестов парсеров в репозитории не найдено.

Документ покрывает загрузку товарных строк в существующую заявку склада (Авто СК) из Excel-шаблона. Правила товарной строки, которые применяются после разбора файла, описаны в [физической модели поставки](../database/receiving-order-good-as-is.md) и [вывоза](../database/shipping-order-good-as-is.md); проверка партии — в [валидации заявок](order-validation.md#партия-товарной-строки-уровень-3).

## HTTP-контур и шаблоны

| Действие | Endpoint | Право |
|---|---|---|
| Скачать шаблон | `GET /template/{uuid}/download?type=<TemplateReportType>` | `RECEIVING_ORDER:CREATE` или `SHIPPING_ORDER:CREATE` |
| Загрузить в поставку | `POST /template/receiving-order/upload` (multipart: `docType`, `id` заявки, `content`) | `RECEIVING_ORDER:WRITE` или `:CREATE` |
| Загрузить в вывоз | `POST /template/shipping-order/upload` | `SHIPPING_ORDER:CREATE` |

Источник: [`TemplateController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/template/TemplateController.java), [`ExcelTemplateCommonFileParsingService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/ExcelTemplateCommonFileParsingService.java). Заявка должна быть в `DRAFT` или `ON_REVIEW`, иначе `IllegalArgumentException`.

Затрагиваемые шаблоны (`TemplateReportType`, файлы в [`templates/`](../../../web-layer/src/main/resources/templates/)):

| `TemplateReportType` | Название | Листы с данными | Парсер |
|---|---|---|---|
| `RECEIVING_ORDER_AUTO_WAREHOUSE_NOMENCLATURE` | Заявка на поставку Авто СК по номенклатуре | «Номенклатура» | [`ReceivingOrderAutoWarehouseNomenclatureParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseNomenclatureParser.java) |
| `RECEIVING_ORDER_AUTO_WAREHOUSE_WITHOUT_DETAIL` | … без детализации | «Номенклатура» | [`ReceivingOrderAutoWarehouseWithoutDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseWithoutDetailParser.java) |
| `RECEIVING_ORDER_AUTO_WAREHOUSE_WITH_DETAIL` | … с детализацией | «Номенклатура», «Контейнеры» | [`ReceivingOrderAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseWithDetailParser.java) |
| `SHIPPING_ORDER_AUTO_WAREHOUSE_NOMENCLATURE` | Заявка на вывоз Авто СК по номенклатуре | «Номенклатура» | [`ShippingOrderAutoWarehouseNomenclatureParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ShippingOrderAutoWarehouseNomenclatureParser.java) |
| `SHIPPING_ORDER_AUTO_WAREHOUSE_WITH_DETAIL` | Заявка на вывоз Авто СК с детализацией | «Номенклатура», «Контейнеры» | [`ShippingOrderAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ShippingOrderAutoWarehouseWithDetailParser.java) |

Общая логика листа «Номенклатура» — [`NomenclatureParserSupport`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/NomenclatureParserSupport.java), «Контейнеры» — [`AbstractAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/AbstractAutoWarehouseWithDetailParser.java). Шаблоны «по контейнерам» (`*_AUTO_WAREHOUSE_CONTAINER`) этим документом не покрываются.

## Порядок обработки

1. Структура файла ([`ValidateUtil.excelFileStructureValidate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/ValidateUtil.java)): лист «Инструкция» с типом шаблона, наличие листов, заголовки строки 1. Каждый заголовок должен входить в список допустимых колонок листа, иначе `Column.<Лист>.NotFound` (например, `Column.Nomenclature.NotFound`). С 13.10.2026 (`8ee1ab68`, KIS-4841) заголовок сначала сравнивается целиком и только при промахе — после отрезания хвоста по regex `[,*].*$` (раньше — сразу после отрезания; поэтому «Количество всего, план» превращалось бы в «Количество всего» и не распознавалось). Наличие **обязательных** колонок отдельно не проверяется (см. риски).
2. `validate` собирает ошибки всех строк; при непустом списке — один `ValidationException` (HTTP 400) с кодами через запятую, нормализованными `ValidateUtil.normalize` (сегменты `UPPER_SNAKE` → `CamelCase`).
3. `save` (`@Transactional` на парсере) создаёт строки через обычный `ReceivingOrderGoodService.add`/`ShippingOrderGoodService.add`, поэтому срабатывают статусная проверка, `OrderGoodBatchValidator` и пересчёт totals. `totalPrice = price × plannedQuantity` считает парсер. Ошибка любой строки откатывает весь импорт.

## Две формы листа «Номенклатура»

Обе формы допустимы одновременно: список разрешённых колонок содержит старые и новые заголовки. **Новая форма включается наличием колонки «Номенклатура»**; без неё файл разбирается по старым правилам.

| | Старая форма (шаблоны до `8ee1ab68`) | Новая форма (шаблоны с `8ee1ab68`, KIS-4841) |
|---|---|---|
| Заголовки | `Артикул* \| Наименовании партии \| Дата партионного учета* \| Штрихкод партии \| Количество план* \| Цена за 1 ед. изм.*` | `№ \| Артикул \| Номенклатура \| Ед. изм. \| Партия \| Партия неизвестна \| Цена за 1 ед. изм. \| Количество всего, план` |
| Строка 2 | подсказки; парсер её пропускает | **пример данных** `1 \| 123456789 \| Химия \| шт \| Бытовая химия \| Нет \| 200 \| 200`; парсер её **не** пропускает |
| Выпадающие списки | «Артикул» `A3:A2000` из скрытого листа «Артикул», «Наименовании партии» `B3:…` из скрытого листа «Партия» | нет (скрытые листы «Артикул», «Партия» в шаблоне остались) |
| Поиск `ClientGood` | ячейка «Артикул» в формате `item_code` (`ParseUtil.getItem`) | `ClientGood.item` = «Артикул», `ClientGood.code` = «Номенклатура» |
| Обязательные колонки | Артикул, Количество план, Цена | Артикул, Номенклатура, Количество всего план (или «Количество план»), Цена |
| Колонка партии | «Наименовании партии» | «Партия» (при отсутствии — «Наименовании партии») |
| Партия не найдена | создаётся новая `Batch` (код, дата партионного учёта как дата производства **и** срок годности, штрихкод); без валидной даты — `DateBatchAccounting.NotValid` | ошибка `Batch.NotFound`, партия **не создаётся** |
| «Партия неизвестна» | колонки нет → всегда `false` | см. ниже |
| Номер строки в коде ошибки | порядковый номер строки данных после строки подсказок | порядковый номер строки данных, начиная с 1 (= строка 2 Excel) |

Общие для обеих форм (с 13.10.2026): полностью пустые строки пропускаются (раньше давали ошибки обязательных полей); `ClientGood` ищется среди активных номенклатур клиента заявки, `findFirst`; поиск без совпадений бросает `NotFoundException` «Client good not found» сразу, а не добавляет код в список. Номер строки считается по непустым физическим строкам листа (`getRowsBySheet` пропускает `null`-строки), а не по номеру строки Excel.

## Правила «Партия неизвестна» и партии (новая форма)

Партионный учёт в парсере = `ClientGood.batchAccountingType != NOT_USED`.

1. «Партия неизвестна» допускает пусто, `Да`, `Нет` (без учёта регистра); иное → `BatchUnknown.NotValid`.
2. `Да` у номенклатуры без партионного учёта → `BatchUnknown.NotValid`.
3. `Да` при заполненных «Партия»/«Наименовании партии», «Дата партионного учета» или «Штрихкод партии» → `<Колонка>.NotValid` для каждой заполненной.
4. Без учёта и не `Да` — партия не проверяется; заполненная «Партия» молча игнорируется (строка сохраняется без партии).
5. Учёт есть, не `Да`, «Партия» пуста → `Batch.IsEmpty`.
6. Учёт есть, «Партия» заполнена → поиск `Batch` по коду (`EXACTLY_MATCHES_IGNORE_CASE`) у этого `ClientGood` и клиента заявки; нет — `Batch.NotFound`.

Строка с `Да` сохраняется с `batch = null`, `batchUnknown = true`; дальше её партию проставит WMS-результат ([поставка](receiving-inbound-actions.md#wms_receiving_result), [вывоз](shipping-inbound-actions.md#wms_shipment_result)).

## Лист «Контейнеры» (шаблоны с детализацией)

Лист не менялся: `Контейнеры* | Артикул* | Наименовании партии | Упаковка | Количество упаковок`, строка 2 — подсказки (пропускается), обязательны «Контейнеры» и «Артикул». Строка связывается с товаром по ключу «Артикул» + «Наименовании партии» листа «Контейнеры», который должен совпасть с ключом листа «Номенклатура»: в новой форме это `<Артикул>_<Номенклатура>` + «Партия» (при пустом Артикуле — только Номенклатура), в старой — значение «Артикул» + «Наименовании партии». Несовпадение → `CONTAINERS.BatchName.NotValid.N` (после нормализации `Containers.BatchName.NotValid.N`).

**Несогласованность шаблона** (`SOURCE_CONFIRMED` по xlsx): подсказки листа «Контейнеры» по-прежнему ссылаются на «столбец А "Артикул"» и «столбец B "Наименование партии"» листа «Номенклатура», а выпадающий список `C3:C…` ссылается на `Номенклатура!$B3`, где теперь «Артикул». Пользователю нужно вручную ввести `Артикул_Номенклатура`, иначе связь не найдётся.

## Коды ошибок

Шаблоны до нормализации — `clientGoods.<КОЛОНКА>.<Тип>.<N>` ([`ConstantsMsg`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/ConstantsMsg.java)); в ответе сегмент колонки в `CamelCase`.

| Код (после нормализации) | Условие | Форма |
|---|---|---|
| `clientGoods.Article.IsEmpty.N`, `.Nomenclature.IsEmpty.N`, `.TotalCountPlan.IsEmpty.N` / `.CountPlan.IsEmpty.N`, `.PriceForOne.IsEmpty.N` | Пустое обязательное поле; число `0` тоже считается пустым | обе (Nomenclature — новая) |
| `clientGoods.BatchUnknown.NotValid.N` | Недопустимое значение «Партия неизвестна» или `Да` без партионного учёта | новая |
| `clientGoods.Batch.NotValid.N`, `.DateBatchAccounting.NotValid.N`, `.BatchBarcode.NotValid.N` | `Да` при заполненных данных партии | новая |
| `clientGoods.Batch.IsEmpty.N` / `clientGoods.BatchName.IsEmpty.N` | Учёт есть, партия не указана | новая / старая |
| `clientGoods.Batch.NotFound.N` | Партия не найдена | новая |
| `clientGoods.DateBatchAccounting.NotValid.N` | Партия не найдена и нет валидной даты для её создания | старая |
| `Column.<Лист>.NotFound` | Неизвестный заголовок колонки | обе |
| `OrderGood.*` | Срабатывание `OrderGoodBatchValidator` при сохранении (см. [каталог ошибок](order-errors.md)) | обе |

## Риски и вопросы

1. **Строка-пример импортируется.** В новых шаблонах строка 2 содержит данные примера и парсером не пропускается: если пользователь её не удалил, она проверяется как товар `123456789`/`Химия` (обычно `NotFoundException` «Client good not found», у клиента с такой номенклатурой — лишняя строка заявки).
2. **Новая форма не создаёт партии.** В отличие от старой формы, неизвестная партия — ошибка; завести партию нужно заранее (Datareon/WMS/справочник) или указать «Партия неизвестна».
3. **Несогласованный лист «Контейнеры»** — см. выше.
4. Отсутствие обязательной колонки (например, «Цена» в новой форме) структурной проверкой не ловится; ожидаемый итог — `NullPointerException` при `cells[columns.get(...)]` и HTTP 500 (`INFERENCE`).
5. Колонки «№» и «Ед. изм.» распознаются, но не читаются; единица измерения не сверяется с номенклатурой.
6. Импорт старых файлов продолжает работать, включая создание партий; срок поддержки старой формы не определён.
