# Группы пользователей и доступные клиенты AS-IS

Проверено по исходникам checkout `22fac945e8116d04972ccc87b06b2303acf7a561`. Это продолжение [модели ролей и разрешений](roles-permissions-as-is.md): method permission, роль в Keycloak/JWT и ограничение списка клиентов — три разные проверки. Документ описывает четыре ALIS group controllers и механизм `ClientUserGroup`; runtime Spring mappings, применённая схема, Keycloak и фактические grants не проверялись. Точный декларативный контракт параметров есть в [endpoint-каталоге](../api/endpoints-generated.md).

Как этим контуром пользуется интерфейс (состав запросов, права, дефект закрытия мастера) — в [UI-правилах администрирования](admin-ui-rules-as-is.md).

## HTTP, DTO и право метода

| Controller | Методы | Фактически используемые DTO и право |
|---|---|---|
| [`UserGroupController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/usergroup/UserGroupController.java) | `POST /usergroup/all`, `/page`, `/meta/{fieldName}`; `GET /usergroup/{groupId}`; `POST /usergroup/`; `PUT /usergroup/{groupId}` | Чтение [`KeycloakGroupFilter`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/usergroup/KeycloakGroupFilter.java) → [`UserGroupDto`](../dto/catalog/usergroup/UserGroupDto.md)/[`UserGroupDetailedDto`](../dto/catalog/usergroup/UserGroupDetailedDto.md); запись [`UserGroupCreationDto`](../dto/catalog/usergroup/UserGroupCreationDto.md)/[`UserGroupUpdateDto`](../dto/catalog/usergroup/UserGroupUpdateDto.md) → detailed. `UserGroup:READ/CREATE/WRITE`. |
| [`UserGroupRoleController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/usergroup/UserGroupRoleController.java) | `POST /usergroup/{groupId}/role/all`, `/page`, `/meta/{fieldName}`, `/set-user-roles` | [`GroupRoleFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/grouprole/GroupRoleFilter.java) → [`RoleDto`](../dto/catalog/wms/role/RoleDto.md)/[`UserRoleDto`](../dto/catalog/usergroup/UserRoleDto.md)/meta; set [`List<UserRoleUpdateDto>`](../dto/catalog/usergroup/UserRoleUpdateDto.md) → `void`. `/page`/meta требуют `UserGroup:READ`, set — `UserGroup:DELETE`; `/all` не имеет `@Secure` в Java method (но JWT authentication зависит от security chain). |
| [`UserGroupUserController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/usergroup/UserGroupUserController.java) | `POST /usergroup/{groupId}/user`, `DELETE /.../{userId}`, `POST /.../page` | Add [`UserUserGroupCreationDto`](../dto/catalog/usergroup/UserUserGroupCreationDto.md) → `void`, page [`GroupUserFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/groupuser/GroupUserFilter.java) → [`GroupUserDto`](../dto/catalog/usergroup/GroupUserDto.md); `UserGroup:CREATE/DELETE/READ`. |
| [`UserGroupClientController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/usergroup/UserGroupClientController.java) | `POST /usergroup/{groupId}/client`, `DELETE /.../{clientId}`, `POST /.../all`, `/page` | Add [`ClientUserGroupCreationDto`](../dto/catalog/clientusergroup/ClientUserGroupCreationDto.md) → `void`; read [`ClientUserGroupFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/clientusergroup/ClientUserGroupFilter.java) → `IdCodeDto` list/page; `UserGroup:CREATE/DELETE/READ`. |

`UserGroupCreationDto.name` — `@NotBlank`, а списки `clients`, `users`, `userRoles` имеют default empty и `@JsonSetter(nulls=SKIP)`; UUID внутри первых двух списков — `@NotNull`. [`UserRoleUpdateDto`](../dto/catalog/usergroup/UserRoleUpdateDto.md) требует `userId` и `roles` (`@NotNull`), но не проверяет существование каждой роли; пустой набор допустим. `UserGroupUpdateDto.id` — `@NotNull`. Отдельный add-users body требует `group @NotNull`, `users @NotEmpty`; add-clients — `group @NotNull`, `clients @NotEmpty`. Spring `@Valid` не означает автоматическую validation внутренних DTO, созданных самим service.

## Где живёт группа и что означает «роль группы»

[`UserGroupService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/usergroup/UserGroupService.java) и [`UserGroupMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/usergroup/UserGroupMapper.java) создают/читают/меняют Keycloak group и её user membership через [`WmsKeycloakFacade`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/keycloak/WmsKeycloakFacade.java). В ALIS не создаётся JPA `UserGroup` row. Таблица `client_user_group` хранит только пару Keycloak `group_id` + FK клиента, а не роль или пользователя; см. [JPA-паспорт](../entities/catalog/entities/clientusergroup/ClientUserGroup.md), [`1.24.0` migration](../../../db-layer/src/main/resources/db/changelog/v.1.24.0/v.1.24.0_20250807_KIS-1543_add_client_user_group_table.sql) и [rename в `1.28.0`](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250918_KIS-1623_RemoveClientTable_RenameLegalEntityTable.sql). Source migrations определяют PK, `group_id NOT NULL`, клиентский FK и `UNIQUE(group_id, client_id)` после rename; FK к Keycloak group быть не может. Применённую схему не проверяли.

Поле `userRoles` detailed response и `/role/all` — агрегация *прямых realm roles пользователей группы*, а не Keycloak group-level roles. `updateUserRoles(groupId, desiredUserRoles)` берёт `getGroupUsers`, для каждого user из body ищет desired role IDs в полном списке realm roles, затем сравнивает с `getUserRoles(userId)` и вызывает `addUserRoles`/`deleteUserRoles`. User группы, которых нет в body, пропускаются. Неизвестные role IDs молча не попадают в desired set. Если user указан с `roles=[]`, service снимает все найденные текущие realm roles этого пользователя, включая роли, полученные вне этой группы; controller требует `UserGroup:DELETE`. Это следует из set-difference в service; групповые Keycloak grants/runtime token отдельно не проверены.

Create выполняет по очереди `addGroup` → `addUsersToGroup` → `updateUserRoles` → `updateClientUserGroups` → `findById`; update — `updateGroup` → `updateUsersInGroup` → роли → клиентские связи → `findById`. [`ClientUserGroupService.updateClientUserGroups`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientusergroup/ClientUserGroupService.java) транзакционно удаляет отсутствующие в desired списке связи и добавляет новые. Весь [`UserGroupService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/usergroup/UserGroupService.java) не имеет общей транзакции с Keycloak; сбой после первого внешнего действия способен оставить частично изменённую группу/роли/клиентские связи. Обратная компенсация в source не найдена. `POST /.../client` вызывает **тот же replace-set method**, а не append-only: body `clients` становится полным целевым набором для body `group`.

Path/body consistency не обеспечена в трёх writes: `PUT /usergroup/{groupId}` вообще не принимает path `groupId` как Java-параметр и обновляет body `id`; add-user/add-client также передают service body `group`, игнорируя path `groupId`. Page/all user/client methods читают ID группы из body filter, не из path. Поэтому URL сам по себе не ограничивает выбранный объект; это source-level контракт и предметный риск для ТЗ, а не проведённый HTTP negative test. `POST /.../client/all` имеет optional body, но handler сразу вызывает `filter.getFilter()`; при реально отсутствующем body вероятен `NullPointerException` вместо пустого фильтра — runtime response не подтверждён.

```mermaid
flowchart TD
    R[UserGroupCreation/Update DTO] --> K[Keycloak group + membership]
    K --> U[UserRoleUpdateDto → direct realm roles каждого user]
    U --> D[CLIENT_USER_GROUP replace-set в ALIS БД]
    D --> G[GET detailed: group + users/roles + clients]
    K -. нет общей транзакции .-> D
```

## Ограничение клиента при чтении

[`ClientUserGroupService.getAvailableToUserIds`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientusergroup/ClientUserGroupService.java) обращается к Keycloak `getUserGroups(userId)`, берёт group UUID и находит соответствующие `client_user_group` rows; результат — объединение client UUID всех групп пользователя. Это не поиск по `GROUP_*` authority name из JWT. [`ResourceServerSecurity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) строит JWT authorities из `realm_access.roles` и claim `groups`, а [`SecurityUtils`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/utils/SecurityUtils.java) отдаёт current `sub` и `ROLE_*`. Текущая role permission проверка использует роли JWT; client restriction каждый раз запрашивает Keycloak membership/БД. Поэтому изменение группы может быть видно этим двум механизмам в разные моменты; фактическая задержка не измерялась.

[`FilterEnrichServiceImpl.addUserRestriction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java) добавляет ограничение **только если service передал filter, реализующий `ClientRestrictionFilter`**, и текущий user не admin. Admin определяется по имени admin role из Keycloak/`RoleService` в JWT, а не по client rows. Если JWT `sub` не UUID/отсутствует, метод возвращается без ограничения (для не-UUID `sub` `SecurityUtils.getUserId` может выбросить exception ещё до этого). Он объединяет доступные IDs всех зарегистрированных `UserRestriction`, затем [`RestrictionFilter.enrichFilter`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/restriction/RestrictionFilter.java) вписывает `ClientFilter.anyOfId` либо пересекает его с requested IDs. [`BaseService`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) вызывает enrichment в типовых list/page/meta reads; другие service paths делают это вручную. Прямой `getById` и произвольный endpoint не становятся row-level защищёнными только от наличия `@Secure`.

Граничная ошибка source-level: когда requested `anyOfId` задан, но **не пересекается** с доступными client IDs, `retainAll` оставляет пустой set. [`BaseIdentifierPredicate.prepareCommonPredicate`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/predicate/BaseIdentifierPredicate.java) добавляет SQL `id IN (...)` только при `CollectionUtils.isNotEmpty(anyOfId)`; пустой set игнорируется. Поэтому на read path, который использует этот predicate, непересекающийся фильтр снимает `anyOfId`-ограничение, оставляя прочие условия (или глобальный набор). При *пустом наборе доступных IDs* `enrichFilter` добавляет случайный UUID до установки `anyOfId`, но если requested ID другой, пересечение снова пусто. Это не доказанный production leak: нужны прямые security+SQL тесты конкретных endpoints, однако для ТЗ нельзя считать алгоритм безопасным deny-by-default. `ClientFilter.id` отдельно не пересекается с available IDs, но при непустом `anyOfId` оба условия применяются как `AND`; для него также важна именно ветка пустого пересечения.

[`UserInfoService.getDetailedUserInfo`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/userinfo/UserInfoService.java) показывает доступные clients, используя `getAvailableEntitiesForUser`; здесь нет admin bypass из list enrichment. Отображаемый client list, методное право и фактическая row-level выдача могут поэтому расходиться. Контур PDF/Excel owner-gap подробнее в [матрице прав отчётов](order-report-access-as-is.md).

```mermaid
flowchart TD
    J[JWT sub + ROLE_*] --> A{Admin по имени роли?}
    A -- да --> X[Нет client filter enrichment]
    A -- нет --> F{ClientRestrictionFilter передан?}
    F -- нет --> X
    F -- да --> K[Keycloak getUserGroups sub]
    K --> D[CLIENT_USER_GROUP → available client IDs]
    D --> I[requested anyOfId ∩ available IDs]
    I --> P{Непустой set?}
    P -- да --> Q[SQL id IN IDs]
    P -- нет --> O[BaseIdentifierPredicate игнорирует пустой set]
```

## Проверки, история и вопросы для ТЗ

[`UserGroupServiceTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/usergroup/UserGroupServiceTest.java) с mocks проверяет role-update и create/update calls; [`UserGroupControllerTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/controller/usergroup/UserGroupControllerTest.java) проверяет create/update и remove-client HTTP wiring. [`ClientUserGroupServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/clientusergroup/ClientUserGroupServiceIntegrationTest.java) описывает replace/remove пары client-group на изолированном контейнере. Тесты не запускались; прямой тест empty intersection/RLS leakage, mismatch path/body, `/role/all` без `@Secure`, Keycloak partial failure/JWT delay source-wide не найден.

| Commit | Подтверждённое влияние на описанный контур |
|---|---|
| `c037494a` (2025-03) | WMS `RestrictionFilter` с алгоритмом intersection и empty-set handling |
| `4f4cdc881` (2025-11) | Intersection requested IDs с available client IDs и `ClientRestrictionFilter` gate |
| `2d3d0f454` (2025-12) | Текущее RLS/user-info расположение и слияние restriction sets |
| `8397b6bf` (2026-08) | Meta/group-role read изменения |
| `6a17c5a2` (2026-08) | Keycloak group filter исправления |

Для ТЗ отдельно зафиксировать: что значит «роль группы» и допустимо ли снимать user roles из других контекстов; обязателен ли match path/body group ID; add-client — replace или append; атомарность Keycloak+БД и компенсация; безопасный deny при пустом intersection; client owner check для direct UUID/report paths; необходимость JWT refresh и фактические grants/развёрнутая схема. Описанное выше — исходники на указанном commit, не измеренное поведение рабочего стенда.
