# Права доступа к отчётам заявок AS-IS

Документ проверен на commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Scope: PDF, корневые и дочерние Excel-выгрузки `ReceivingOrder`/`ShippingOrder` в [ReportController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportController.java) и [ReportControllerV2](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportControllerV2.java), плюс `/report/all` и `/report/order/{id}/available`. Route, справочные и остаточные reports вне этой матрицы. Детали eligibility/templates/filter contracts уже описаны в [PDF](order-pdf-reports-as-is.md), [root Excel](order-excel-exports-as-is.md) и четырёх child Excel документах: [receiving 1](receiving-order-child-excel-exports-as-is.md), [receiving 2](receiving-order-child-excel-exports-part2-as-is.md), [shipping 1](shipping-order-child-excel-exports-as-is.md), [shipping 2](shipping-order-child-excel-exports-part2-as-is.md).

## Три независимых вопроса о доступе

1. **Аутентификация HTTP.** [ResourceServerSecurity](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) активируется при наличии `spring.security.oauth2.resourceserver.jwt.issuer-uri`; если конфигурация активна, `/report/**` и `/v2/report/**` попадают под `anyRequest().authenticated()`. JWT `realm_access.roles` превращаются в `ROLE_*`, группы — в `GROUP_*`. Фактические issuer/config/gateway на стенде не проверялись.
2. **Право на метод.** [`@Secure`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/aop/Secure.java)/[`@Secures`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/aop/Secures.java) проверяет [`PermissionAspectConfiguration`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/permission/PermissionAspectConfiguration.java) до handler body. Все методы в scope требуют `READ`, кроме `@Secures` availability, где достаточно *одного* из двух общих прав. Недостаток права приводит к `AccessDeniedException`, который [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) отображает в `403` для ALIS exception path.
3. **Доступ к строкам.** Permission aspect не получает order/client UUID и не проверяет принадлежность объекта. Row-level ограничение возможно только в конкретном service/filter flow. Корневые filter-выгрузки используют `ClientRestrictionFilter` при non-null filter; child filters и прямые PDF/path UUID flows не получают автоматического client scope. Это разные gates: право на endpoint не доказывает право на конкретную заявку.

```mermaid
flowchart TD
    H[HTTP] --> A{JWT security chain активна?}
    A -- да --> U[Authentication]
    A -- unknown runtime --> Q[Конфигурация стенда не проверена]
    U --> S[@Secure / @Secures: role permission READ]
    S -- нет --> F[AccessDeniedException → 403]
    S -- да --> C[Controller / collector]
    C --> R{Filter добавляет client IDs<br/>или проверяет owner UUID?}
    R -- да только в некоторых root flows --> L[Scoped rows]
    R -- нет --> G[Method gate без row ownership]
```

## Как вычисляется `READ`

[`PermissionCheckStrategy`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategy.java) берёт `SecurityUtils.getUserRoles()`, получает forest каждой роли из [`RolePermissionServiceImpl`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImpl.java) и сравнивает найденный уровень с `READ`. Уровни возрастают `NO_ACCESS < READ < WRITE < CREATE < DELETE` ([PermissionLevel](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/base/PermissionLevel.java)). Если ролей несколько, выбирается максимальный доступ. Дерево ищет последний существующий узел permission path ([Tree.findLastElement](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/Tree.java)); [`RolePermissionService.propagateInheritance`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionService.java) переносит уровень parent grant на дочерние узлы, а последующая более точная запись child path может его перекрыть. Нельзя выводить grants только из имени `@Secure`.

Для обычной роли forest начинается со всех `PermissionPath` на `NO_ACCESS` и перекрывается строками [`RolePermission`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/RolePermission.java). Специальный admin role ID из `config.admin-role.id` получает `DELETE` на все известные paths. Список ролей синхронизируется из Keycloak и cache обновляется/сбрасывается в сервисе; live роли и строки БД неизвестны. [`Permission`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/Permission.java) содержит path string; миграции добавляют сами paths, но не доказывают конкретные production role grants.

## PDF и служебные методы

| Метод | Method-level требование | Дополнительное поведение |
|---|---|---|
| `POST /report/all` | `Report:READ` | Возвращает весь enum `OrderReportType`, без ID/eligibility/row check. |
| `GET /report/order/{id}/available` | `ReceivingOrder.Report:READ` **или** `ShippingOrder.Report:READ` (`@Secures(requireAll=false)`) | [ReportService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ReportService.java) сначала ищет ShippingOrder, затем ReceivingOrder по UUID; после выбора направления collector `checkCanExport` проверяет узкое право и eligibility. Общий permission на выбранное направление отдельно не сверяется. |
| `POST /report/receivingorder/mx1/{id}/download` | `ReceivingOrder.Report.MX1:READ` | [MX-1 collector](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/Mx1ReportDataCollectorService.java) повторно проверяет узкое право и eligibility; общее `ReceivingOrder.Report` не требуется. |
| `POST /report/receivingorder/m7/{id}/download` | `ReceivingOrder.Report.M7:READ` | M-7 collector повторно проверяет узкое право/eligibility; общего права не требует. |
| `POST /report/shippingorder/mx3/{id}/download` | `ShippingOrder.Report.MX3:READ` | MX-3 collector повторно проверяет узкое право/eligibility; общего права не требует. |
| `POST /report/shippingorder/th/{id}/download` | `ShippingOrder.Report.TH:READ` | ContainerTN collector повторно проверяет узкое право/eligibility; общего права не требует. |
| `POST /report/shippingorder/packinglist/{id}/download` | `ShippingOrder.Report.PackingList:READ` | Packing List collector повторно проверяет узкое право/eligibility; общего права не требует. |

PDF availability и direct download не дают одинаковую permission-гарантию. Пользователь с узким правом без общего может вызвать direct download, но не availability. Пользователь с общим правом без узкого может вызвать availability, но соответствующий тип исчезнет из результата. `GET available` требует один из общих rights независимо от направления UUID. `BaseReportDataCollectorService.collectReportData` выбрасывает `IllegalArgumentException` при отрицательном `checkCanExport`; это попадает в catch-all `500`, а не в заявленный OpenAPI `400`. Ни availability, ни direct PDF path flows не добавляют `ClientRestrictionFilter` по конкретному order UUID. Повторные узкие проверки здесь относятся к типу/статусу/площадке, не к owner клиента.

```mermaid
flowchart TD
    A[GET available: одно из общих прав] --> O[Определить направление UUID]
    O --> T[Collector: узкое право + eligibility]
    T -- нет --> X[Тип не показывается]
    T -- да --> Y[Тип показывается]
    D[POST direct PDF: узкое право] --> V[Collector: то же узкое право + eligibility]
    V -- unavailable --> E[IllegalArgumentException → ожидаемый 500]
    V -- available --> P[PDF]
```

## Корневые Excel: V1/V2 permission-asymmetry

| Выгрузка | V1 | V2 | Row-scope AS-IS |
|---|---|---|---|
| Receiving orders | `POST /report/receiving-order/download` — `ReceivingOrder.Report:READ` | `POST /v2/report/receiving-order/download` — `ReceivingOrder:READ` | V1 создаёт non-null order filter и может добавить allowed client IDs; V2 `{}` делает то же для non-admin с user ID, но absent body оставляет filter null и пропускает enrichment. |
| Shipping orders | `POST /report/shipping-order/download` — `ShippingOrder.Report:READ` | `POST /v2/report/shipping-order/download` — `ShippingOrder:READ` | Та же развилка; право V2 на обычную заявку не означает client restriction при отсутствующем body. |

Прямого требования *обоих* прав для одной версии нет. Client enrichment у non-admin зависит от наличия UUID пользователя и доступных restriction IDs; [FilterEnrichServiceImpl](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java) при null user ID логирует предупреждение и не добавляет ограничение. Более подробные правила — в [root Excel AS-IS](order-excel-exports-as-is.md).

## Дочерние Excel: одинаковое право V1/V2

В следующей матрице `R` означает путь `ReceivingOrder`, `S` — `ShippingOrder`; все значения требуют `READ`. В каждой строке V1 `POST /report/{resource}/{orderId}/download` и V2 `POST /v2/report/{resource}/download` используют *одно и то же* method permission, без требования общего `*.Report`. Полные DTO/filter/collector/template связи — в четырёх child Excel документах выше.

| Направление | Resource suffix | Permission path | Особенность |
|---|---|---|---|
| R | `receiving-order-blackbox` | `ReceivingOrder.ReceivingOrderContainer` | Blackbox делит право с Container. |
| R | `receiving-order-cargo` | `ReceivingOrder.ReceivingOrderCargo` | Отдельное child право. |
| R | `receiving-order-container` | `ReceivingOrder.ReceivingOrderContainer` | Отдельный ресурс, общее право с Blackbox. |
| R | `receiving-order-container-item` | `ReceivingOrder.ReceivingOrderContainerItem` | Child право item. |
| R | `receiving-order-good` | `ReceivingOrder.ReceivingOrderGood` | Child право goods. |
| R | `receiving-order-requested-service` | `ReceivingOrder.ReceivingOrderRequestedService` | Child право service. |
| R | `receiving-order-etran-invoice` | `ReceivingOrder.EtranInvoice` | После KIS-3631 URI/permission legacy, данные — Waybill. |
| R | `receiving-order-railway-carriage` | `ReceivingOrder.RailwayCarriage` | Данные через WaybillRailwayCarriage. |
| S | `shipping-order-blackbox` | `ShippingOrder.ShippingOrderContainer` | Blackbox делит право с Container. |
| S | `shipping-order-cargo` | `ShippingOrder.ShippingOrderCargo` | Отдельное child право. |
| S | `shipping-order-container` | `ShippingOrder.ShippingOrderContainer` | Отдельный ресурс, общее право с Blackbox. |
| S | `shipping-order-container-item` | `ShippingOrder.ShippingOrderContainerItem` | Child право item. |
| S | `shipping-order-good` | `ShippingOrder.ShippingOrderGood` | Child право goods. |
| S | `shipping-order-requested-service` | `ShippingOrder.ShippingOrderRequestedService` | Child право service. |
| S | `shipping-order-etran-invoice` | `ShippingOrder.EtranInvoice` | Shipping сохраняет старые EtranInvoice entities. |
| S | `shipping-order-railway-carriage` | `ShippingOrder.RailwayCarriage` | ShippingCarriage/Etran model. |

V1 collector принудительно задаёт order ID и `deleted=false`, но не загружает корневую заявку для owner check. V2 body optional, а child filter не реализует `ClientRestrictionFilter`: absent body даёт глобальный набор включая deleted, `{}` — глобальный набор неудалённых строк, `deleted:null` снимает soft-delete condition. Receiving Waybill V2 absent body отличается: direct DAO путь ожидаемо падает на null filter, но `{}` всё равно не добавляет client/order scope. Child permission разрешает вызов ресурса, не гарантируя область выбранных строк.

```mermaid
flowchart TD
    P[Child permission READ] --> V{V1 / V2}
    V -- V1 --> I[Order UUID filter + deleted=false]
    V -- V2 --> B[Optional child filter]
    I --> C[Нет root owner check]
    B --> R[Нет автоматического ClientRestrictionFilter]
    C --> O[Строки выбранного UUID без client ownership gate]
    R --> G[Глобальная область при absent body / пустом filter]
```

## Миграции, тесты и неподтверждённое

Пути report rights добавлены миграциями: [`ReceivingOrder.Report`/`MX1`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240904_ALG-349_add_print_report_permissions.sql), [`ShippingOrder.Report`/`MX3`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240917_ALG-505_add_print_report_permissions.sql), [`TH`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240920_ALG-507_add_print_th_report_permissions.sql), [`M7`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250514_KIS-1089_add_permission.sql), [`PackingList`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250417_KIS-928_add_fields_for_shipping_order_cargo.sql) и [`Report`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250328_KIS-679_add_new_permission.sql). Child permission paths создавались с соответствующими моделями. Поиск миграций не нашёл статических role grants специально для `ReceivingOrder.Report*`/`ShippingOrder.Report*`; это не доказывает отсутствие grants в live БД, поскольку RolePermission изменяется через UI/service и роли приходят из Keycloak. JPA-модель также не заменяет проверку применённой схемы.

[`PermissionCheckStrategyTest`](../../../web-layer/src/test/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategyTest.java) проверяет уровни и role forest с mocks, [`RolePermissionServiceImplTest`](../../../web-layer/src/test/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImplTest.java) — часть role service. Прямых tests `ReportController` permission matrix, OR availability, разных V1/V2 grants и client ownership/global child exports source-wide поиск не нашёл. Тесты не запускались; runtime Spring context/JWT/gateway, реальные роли/role_permissions/live data не проверены.

История для ключевых частей: `b67b2971` (2024-09) — report paths, `c037494a` (2025-03) — WMS permission source, `cbf478f8` (2025-07) — auth, `905ef6e4` (2025-09) — V2 filters, `443ae69a` (2026-04) — receiving Waybill compatibility, `6611ec27` (2026-06) — availability endpoint, `0b120809` (2026-07) — OR permission availability. Состояние всегда сверять с указанным HEAD.

Для ТЗ нужна явная таблица «роль → method permission → допустимые client/order IDs»; отдельно решить правило для direct UUID, обязательный scope V2, soft-delete, отсутствие user ID, отличие availability от direct download и проверку streaming/403/500. Production role grants можно подтвердить только выгрузкой применённых `PermissionPath`/`RolePermission` и Keycloak roles с нужного стенда.
