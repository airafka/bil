# Входящие действия поставки

Документ фиксирует **AS-IS** receiving-веток `TOS_RECEIVING_RESULT`, `WMS_RECEIVING_RESULT`, `CARRIAGE_ARRIVED`, `STATUS_IN_WORK` и `STATUS_COMPLETED` на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 11.09.2026). Общий транспортный контракт, создание журнала, HTTP-результат и транзакционная граница описаны в [разборе Datareon-события](shipping-railway-empty-completion.md#транспортный-контракт).

## Сводная карта правил

| ID | Action | Минимальные данные после преобразования DTO | Изменяемые данные | Может поставить заявку в `DONE` |
|---|---|---|---|---|
| `BR-RO-IN-001` | `TOS_RECEIVING_RESULT` | `_order`, `_id`; непустой `cargoResult` или `addServicesResult` | контейнерная задача, услуги, `ContainerMovement`, владельцы КТК | Да, если завершены все контейнерные задачи обеих моделей и исходный статус — `ACCEPTED`/`IN_PROGRESS`. |
| `BR-RO-IN-002` | `WMS_RECEIVING_RESULT` | непустой `itemsResult` | товары, партии, фактические количества услуг, `GoodMovement` | Нет. |
| `BR-RO-IN-003` | `CARRIAGE_ARRIVED` | `_order`, `_id`, площадка события не `WAREHOUSE` | Waybill-задача вагона или КТК, `actualReceivingDateTime`, статус заявки | Да, только в вагонной ветке по отдельному условию «нет прямых контейнеров и все вагоны завершены». |
| `BR-RO-IN-004` | `STATUS_IN_WORK` | общие поля события | только `ReceivingOrder.orderStatus` | Нет: любой нетерминальный статус заменяется на `IN_PROGRESS`. |
| `BR-RO-IN-005` | `STATUS_COMPLETED` | общие поля события | только `ReceivingOrder.orderStatus` | Да: любой нетерминальный статус заменяется на `DONE` без проверки дочерних задач. |

Каждый action запускается только по найденной для `eventCode` строке `INBOUND_EVENT_CONFIG`. Production-mapping этих пяти receiving-actions в миграциях не найден; названия `REC_START`, `REC_FINISH`, `UNLOAD_FINISH` и `VH_ARRIVED` встречаются в тестовой конфигурации и не доказывают настройки применённой БД.

## DTO и идентификаторы

- Корневой request: [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md).
- Результат TOS: [CargoProcessingResultDto](../dto/catalog/datareon/inbound/CargoProcessingResultDto.md), вложенные [характеристики груза](../dto/catalog/datareon/inbound/CargoProcessingResultDto.CargoSpecResultDto.md) и [пломбы](../dto/catalog/datareon/inbound/CargoProcessingResultDto.SealResultDto.md).
- Результат WMS: [ItemsProcessingResultDto](../dto/catalog/datareon/inbound/ItemsProcessingResultDto.md) и [ItemsProcessingBatchDto](../dto/catalog/datareon/inbound/ItemsProcessingBatchDto.md).
- Фактические услуги: [AddServicesResultDto](../dto/catalog/datareon/inbound/AddServicesResultDto.md) и [ExtraOperationTypeDto](../dto/catalog/datareon/inbound/ExtraOperationTypeDto.md).

`_order` преобразуется в UUID заявки, `_id` — в UUID задачи. Вложенные `_item`, `_package` и `addServicesResult[].operationType._id` также разбираются до создания записи `InboundEvent`. Неверный UUID приводит к HTTP `500` без журнала события.

`InboundEventDto.eventCode` помечен `@NotBlank`: отсутствие или пустая строка дают HTTP `400` с кодом `NotBlank.inboundEventDto.eventCode`. Поле должно находиться на корневом уровне request, а не внутри `EventData`. Пример из интеграции с внешней оболочкой `MessageID + EventData[]` не является телом, которое непосредственно принимает этот endpoint, пока внешний преобразователь явно не развернул каждый элемент в плоский `InboundEventDto`.

У `itemsResult[].batch` нет Bean Validation-запрета на `null`, но converter разыменовывает `batch.getNumber()` без проверки. Такой WMS-request падает до создания журнала события.

## Модель контейнерных и вагонных задач

```mermaid
flowchart LR
    RO[ReceivingOrder]
    RO -->|CONTAINER + RAILWAY| WB[Waybill]
    WB --> WRC[WaybillRailwayCarriage]
    WRC --> WC[WaybillContainer]
    RO -->|CONTAINER + VEHICLE| ROC[ReceivingOrderContainer]
    CAR[Container] --- WC
    CAR --- ROC
```

Для ЖД-поставки `_id` может обозначать `WaybillRailwayCarriage` или `WaybillContainer`. Для автомобильной контейнерной поставки TOS использует `ReceivingOrderContainer`. После успешного экспорта ЖД route-chain-package вагоны и контейнеры Waybill получают `UPLOADED`; прямые контейнеры получают этот статус при экспорте cargo receiving task.

Сущности: [Waybill](../entities/catalog/entities/waybill/Waybill.md), [WaybillRailwayCarriage](../entities/catalog/entities/waybillrailwaycarriage/WaybillRailwayCarriage.md), [WaybillContainer](../entities/catalog/entities/waybillcontainer/WaybillContainer.md), [ReceivingOrderContainer](../entities/catalog/entities/receivingordercontainer/ReceivingOrderContainer.md).

## Общая последовательность

```mermaid
flowchart TD
    E[POST /datareon/event] --> CFG[Config rows по eventCode]
    CFG --> P0[Actions priority 0]
    P0 --> TOS[TOS_RECEIVING_RESULT]
    P0 --> WMS[WMS_RECEIVING_RESULT]
    P0 --> ARR[CARRIAGE_ARRIVED]
    TOS --> TC[Завершить WC или ROC; услуги и movements]
    TC --> TD{Все WC + ROC FINISHED и статус разрешён?}
    TD -->|да| TO[ReceivingOrder DONE; владельцы → клиент]
    TD -->|нет| KEEP[Статус не менять]
    WMS --> WG[Товары, партии, услуги и GoodMovement]
    ARR --> KIND{_id найден где?}
    KIND -->|WRC| WA[Вагон FINISHED; первое фактическое время; возможный DONE]
    KIND -->|WC| CA[КТК FINISHED; первое фактическое время]
    TO --> P1[Actions priority 1]
    KEEP --> P1
    WG --> P1
    WA --> P1
    CA --> P1
    P1 --> SIW[STATUS_IN_WORK]
    P1 --> SC[STATUS_COMPLETED]
    SIW -->|заявка нетерминальна| IP[IN_PROGRESS]
    SC -->|заявка нетерминальна| SD[DONE без проверки задач]
    SIW -->|уже DONE/REJECTED| RB[Ошибка и rollback набора actions]
    SC -->|уже DONE/REJECTED| RB
```

Первые три действия имеют priority `0`, оба status-action — priority `1`. Явного порядка между actions одного priority в DAO-запросе нет. Весь набор выполняется в одной транзакции `REQUIRES_NEW`: ошибка позднего action откатывает изменения ранних, затем журнал отдельно получает `INVALID` или `FAILED`; вызывающий обычно получает HTTP `200`.

## `TOS_RECEIVING_RESULT`

Action проверяет наличие `_order` и хотя бы одного результата груза или услуги. Затем требует `RECEIVING` в config, загружает заявку и сопоставляет её фактическую площадку и транспорт с config. Отсутствующая заявка или несовпадение фильтров дают `FAILED`.

Обработка всегда начинается с `_id` задачи, даже если событие содержит только услуги:

1. `_id` сначала ищется как `WaybillContainer`; найденная ЖД-задача получает `FINISHED`.
2. Иначе `_id` ищется как `ReceivingOrderContainer`; автомобильная задача получает `FINISHED` и `actualQuantity` из первого `cargoResult`.
3. У `WaybillContainer` поля `actualQuantity` нет: полученное количество только логируется и отбрасывается.
4. Переданные услуги блокируются по ID, после чего их `actualQuantity` заменяется значением события. ID, не найденные среди услуг, фактически игнорируются.
5. Для каждого `cargoResult` создаётся новый [ContainerMovement](../entities/catalog/entities/containermovement/ContainerMovement.md).

Для завершения заявки action объединяет все `WaybillContainer` и `ReceivingOrderContainer`, связанные с `_order`. Набор должен быть непустым и целиком иметь `FINISHED`; текущий статус должен входить в `ACCEPTED`/`IN_PROGRESS`, а переход в `DONE` — разрешаться `OrderStatus`. **Обновлено KIS-4661** (коммит `9a05f552` и последующие, 21 сентября 2026): только в этой ветке вызывается `ContainerStatusService.markReceived`, переводящий регистр [ContainerOwner](../entities/catalog/entities/containerowner/ContainerOwner.md) из статуса `EXPECTED` в `ON_TERMINAL` (владелец при этом **не меняется** — он уже был зафиксирован при `accept` заявки через `reserveForReceivingOrder`, см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md)). Прежнее описание «владельцы заменяются на клиента заявки» относилось к до-KIS-4661 версии кода без отдельного статуса remains.

Action не устанавливает `actualReceivingDateTime`. Он также не проверяет, что найденная по `_id` задача принадлежит `_order`: чужая задача может быть завершена, а решение о `DONE` принимается отдельно по задачам указанной заявки.

## `WMS_RECEIVING_RESULT`

Action требует непустой `itemsResult`, но не вызывает общую проверку `_order` и не применяет config-фильтры типа заявки, площадки или транспорта. При обычном HTTP-входе `_order` всё же ограничен Bean Validation корневого DTO; при прямом вызове сервиса отсутствие ID проявится позже.

Для каждого item среди неудалённых товаров заявки ищется ровно одна строка по `ClientGood.syncId` и совпадению `Batch.syncId` **или** `Batch.code`; с 13.10.2026 (`8ee1ab68`, KIS-4841) строка с `batchUnknown=true` совпадает с **любой** партией этого товара. Ноль совпадений — отсутствие строки; несколько совпадений с 13.10.2026 — `IllegalArgumentException` «Ambiguous order good for client good syncId: …», откат actions и `InboundEvent=INVALID` (раньше несколько совпадений тоже считались отсутствием строки и вели к созданию новой). Для найденной строки `actualQuantity` увеличивается на `qty`. Если строка `batchUnknown=true`, вызывается [`BaseWmsResultAction.resolveUnknownBatch`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseWmsResultAction.java): партия ищется **только** по WMS `syncId` (если она принадлежит другому `ClientGood` — ошибка «Actual batch belongs to another client good»), иначе создаётся активной; тип учёта берётся из `ClientGood`, код/даты/штрихкод — из WMS; партия ставится в строку, `batchUnknown=false`. Иначе, как раньше, `createOrUpdateBatch` (поиск по коду партии у товара) и прикрепление, если партии не было. Явного `update` после изменения существующей строки нет — сохранение зависит от JPA persistence context.

Следствие (`SOURCE_CONFIRMED` по коду, тестом не подтверждено): список строк читается один раз до цикла, поэтому после первого item строка «партия неизвестна» уже привязана к партии X; второй item того же товара с партией Y её не находит и при `deliveryType != BY_CARGO` создаёт новую строку с `plannedQuantity=0` (при `BY_CARGO` количество теряется). Если WMS прислал уже известный у товара код партии, но с новым `syncId`, `resolveUnknownBatch` (в отличие от `createOrUpdateBatch`) пойдёт в create и, по Liquibase-цепочке, упрётся в composite unique `(code, client_good_id)` [партии](batch-datareon-as-is.md#физические-ограничения) — вывод `INFERENCE`, ожидаемый итог — откат и `FAILED`; тестом не подтверждено. Остатки `GoodRemain` этой веткой не меняются.

Если совпадение не найдено и `deliveryType != BY_CARGO`, создаётся `ReceivingOrderGood` с `plannedQuantity=0`, фактическим количеством и ценой из `ClientGood`. Для каждого item безусловно добавляется новый [GoodMovement](../entities/catalog/entities/goodmovement/GoodMovement.md), а грузовое место ищется или создаётся по `cargoNumber`. Фактическое количество переданных услуг заменяется только у услуг, принадлежащих `_order`; неизвестные IDs игнорируются.

Action не меняет статус заявки, статус задач или `actualReceivingDateTime`.

## `CARRIAGE_ARRIVED`

Action требует `_order`, `_id` и отвергает `WAREHOUSE` в самом событии. Для receiving-ветки config должен разрешать `RECEIVING`, а найденная заявка обязана фактически быть `CONTAINER + RAILWAY` и пройти фильтры config. Отсутствующая заявка — тихий no-op; неподходящая — `FAILED`.

Перед dispatch задачи заявка переводится в `IN_PROGRESS`, если переход разрешён. Затем:

- `WaybillRailwayCarriage`: строка блокируется и получает `FINISHED`; для первого завершённого вагона `actualReceivingDateTime` устанавливается из `eventDateTime`; после этого проверяется `DONE`;
- `WaybillContainer`: строка блокируется и получает `FINISHED`; если фактическое время ещё не задано, оно устанавливается из события; `DONE` здесь не проверяется — комментарий кода делегирует завершение TOS-action;
- неизвестный `_id`: ошибка и `FAILED`.

### Подтверждённое расхождение условия `DONE`

Вагонная ветка считает, что у заявки «нет контейнеров», через `ReceivingOrderContainerDaoService.orderHasContainers`, то есть только по старой прямой таблице `receiving_order_container`. Контейнеры актуальной ЖД-модели находятся в `waybill_container` и этой проверкой не учитываются. Поэтому последний `WaybillRailwayCarriage` способен перевести ЖД-поставку в `DONE`, даже если связанные `WaybillContainer` ещё не завершены.

После такого перехода последующий `TOS_RECEIVING_RESULT` может завершить контейнерные задачи и добавить movements, но собственная ветка TOS уже не выполнит смену владельцев: её допустимые исходные статусы ограничены `ACCEPTED` и `IN_PROGRESS`. При этом ни вагонная ветка `CARRIAGE_ARRIVED`, ни status-action владельцев не меняют.

Отдельно `_id` вагона или контейнера не проверяется на принадлежность `_order`. Запрос `allRailwayCarriagesFinished` построен через `NOT EXISTS(status != FINISHED)`; для nullable `status` поведение SQL с `NULL` требует отдельной проверки на реальной БД.

## `STATUS_IN_WORK` и `STATUS_COMPLETED`

Оба action применяют config-фильтры order type, фактической площадки и транспорта, блокируют найденную заявку и отказывают для `DONE`/`REJECTED`. Отсутствующая заявка завершается тихим no-op.

Они не вызывают `OrderStatus.isStatusChangeAllowed` и не проверяют Waybill, контейнеры, вагоны, товары, услуги, владельцев или фактическое время:

- `STATUS_IN_WORK` заменяет любой нетерминальный `DRAFT`, `ON_REVIEW`, `ACCEPTED` или `IN_PROGRESS` на `IN_PROGRESS`;
- `STATUS_COMPLETED` заменяет любой такой статус на `DONE`.

Оба имеют одинаковый priority `1`, а порядок config-строк не определён. Если в одном событии присутствуют оба: порядок `IN_WORK → COMPLETED` заканчивается `DONE`, а `COMPLETED → IN_WORK` приводит к ошибке второго action и rollback всего набора.

## Кто изменяет итоговые признаки

| Action | Статус задачи | `actualReceivingDateTime` | `ReceivingOrder=DONE` | Смена владельца на клиента |
|---|---:|---:|---:|---:|
| `TOS_RECEIVING_RESULT` | WC или ROC → `FINISHED` | нет | по всем WC + ROC | только при собственном `DONE` |
| `WMS_RECEIVING_RESULT` | нет | нет | нет | нет |
| `CARRIAGE_ARRIVED`, WRC | WRC → `FINISHED` | первое завершение вагона | если «нет ROC» и все WRC завершены | нет |
| `CARRIAGE_ARRIVED`, WC | WC → `FINISHED` | первое событие по КТК | нет | нет |
| `STATUS_IN_WORK` | нет | нет | нет | нет |
| `STATUS_COMPLETED` | нет | нет | безусловно для нетерминальной заявки | нет |

## Конфликты config-строк одного события

| Сочетание | Результат AS-IS |
|---|---|
| `TOS_RECEIVING_RESULT` завершил заявку + status-action | `STATUS_IN_WORK` или `STATUS_COMPLETED` видит терминальный статус, выбрасывает ошибку и откатывает TOS-изменения. |
| Незавершивший заявку TOS + `STATUS_COMPLETED` | Контейнер/услуги/movements сохраняются, затем заявка получает `DONE` без условия полноты и без смены владельца. |
| `WMS_RECEIVING_RESULT` + `STATUS_COMPLETED` | Товарные результаты фиксируются, затем заявка получает `DONE` независимо от полноты приёмки. |
| Вагонный `CARRIAGE_ARRIVED` сам поставил `DONE` + status-action | Поздний status-action отвергает терминальную заявку; вагон, время и статус откатываются. |
| Незавершивший заявку `CARRIAGE_ARRIVED` + `STATUS_COMPLETED` | Waybill-задача завершается, затем заявка получает `DONE` без проверки остальных задач. |

## Повторы и конкурентность

| Action | Повтор | Блокировки / риск |
|---|---|---|
| `TOS_RECEIVING_RESULT` | Повторно создаёт `ContainerMovement`; статус задачи и количества услуг перезаписываются. | WC/ROC явно не блокируются; услуги блокируются; решение по всем контейнерам выполняется без общей блокировки агрегата. |
| `WMS_RECEIVING_RESULT` | Повторно прибавляет фактическое количество и создаёт новый `GoodMovement`. | Явных row locks для товарных строк нет; возможны lost updates. |
| `CARRIAGE_ARRIVED` | Уже завершённая задача даёт no-op и не переписывает фактическое время. | Конкретная WRC/WC блокируется, заявка явно не блокируется; два первых события могут конкурировать за время/статус. |
| Status-actions | Первый вызов меняет статус, повтор после терминального состояния получает `FAILED`. | Проверка статуса выполнена на объекте, прочитанном до `findAndLock`; явного reread после lock нет. |

Unique constraint журнала на message/task ID текущими исходниками не подтверждён; подробнее — [повторы и дедупликация](shipping-railway-empty-completion.md#повторы-и-дедупликация).

## Тестовая трассировка

- Активный `InboundEventDatareonServiceTest` проверяет TOS-обновление услуг, завершение одной из двух `WaybillContainer` без `DONE`, `ContainerMovement` и отсутствие поля фактического количества у WC.
- Тест полного TOS-завершения помечен `@Disabled` после удаления старой модели `ReceivingOrderRailwayCarriage`; актуальной проверки `DONE` и смены владельца для Waybill-модели нет.
- Блок integration test для `WMS_RECEIVING_RESULT` целиком закомментирован; активной предметной проверки WMS receiving в просмотренных тестах не найдено.
- Для `CARRIAGE_ARRIVED` активны проверки `WaybillRailwayCarriage.status=FINISHED`, журнала и первого `actualReceivingDateTime`, но не условия `DONE` при незавершённых `WaybillContainer`.
- Для `STATUS_IN_WORK` и `STATUS_COMPLETED` активны проверки смены статуса и failure на терминальной заявке; комментарий теста прямо отмечает отсутствие проверки вагонов у `STATUS_COMPLETED`.
- `ActionsProcessorTest` проверяет priority `0 → 1` и остановку на первой ошибке, но не определяет порядок двух actions одинакового priority.

Найденные тесты просмотрены, но не запускались. Ключевые реализации: [TosReceivingResultAction](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosReceivingResultAction.java), [WmsReceivingResultAction](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsReceivingResultAction.java), [CarriageArrivedAction](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java), [BaseChangeStatusResultAction](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseChangeStatusResultAction.java), [integration tests](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonServiceTest.java), [priority tests](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessorTest.java).

## Повлиявшие изменения Git

| Commit | Подтверждённое влияние |
|---|---|
| `b2dd03a4` | Добавил receiving-завершение после прибытия всех вагонов при отсутствии контейнеров — изначально для старой прямой контейнерной модели. |
| `3a1f0027` (`KIS-3355`, 11.03.2026) | Перенёс переход в `IN_PROGRESS` в `CARRIAGE_ARRIVED` и удалил config `VH_ARRIVED + STATUS_IN_WORK`. |
| `8b6244e6` (27.04.2026) | Добавил dispatch `CARRIAGE_ARRIVED` на `WaybillContainer`, не расширив проверку наличия контейнеров перед вагонным `DONE`. |
| `00629653` (05.05.2026) | Перевёл TOS receiving на dispatch между `WaybillContainer` и `ReceivingOrderContainer` и объединил обе модели в проверке завершения. |
| `ef43207b` (`KIS-4269`, 14.07.2026) | Добавил смену владельца КТК на клиента при собственном TOS-переходе в `DONE`. |

Короткие hash приведены только как идентификаторы уже существующих commits; анализ выполнен по текущему полному commit документа.

## Неподтверждённое

Не проверены production-строки `INBOUND_EVENT_CONFIG`, внешний envelope/transform Datareon, применённая схема и SQL-поведение nullable task status, runtime security/gateway, фактическое состояние TOS/WMS и порядок config-строк одинакового priority. Документ не предлагает TO-BE и не объявляет найденные риски исправленными.
