# Остатки товаров: inbound AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026): публичный `POST /datareon/remain`, ручную полную синхронизацию, хранение, чтение и Excel-выгрузку остатков номенклатуры. Бизнес-код, конфигурация и миграции не изменялись; внешняя WMS/Datareon и применённая схема БД не проверялись.

Предварительный Datareon create/update справочника Batch описан отдельно в [AS-IS партий](batch-datareon-as-is.md).

Остаток [GoodRemain](../entities/catalog/entities/goodremains/GoodRemain.md) — снимок количества товара. Он не является [GoodMovement](../entities/catalog/entities/goodmovement/GoodMovement.md): этот inbound не создаёт движение и не связывается с конкретной заявкой.

## Карта потока

```mermaid
flowchart LR
    DR[Datareon / WMS] -->|POST /datareon/remain| INC[Инкрементальный upsert]
    UI[Пользователь] -->|POST /remain/updating/synchronize| ASYNC[Async full sync]
    ASYNC --> DEL[Удалить весь good_remain]
    DEL --> GET[Внешний GET с Basic auth]
    GET --> LOAD[Собрать и сохранить снимок]
    INC --> GR[(good_remain)]
    LOAD --> GR
    GR --> VIEW[analytics.good_remain_view<br/>quantity &gt; 0 and active]
    VIEW --> API[/remain/good/view и view-all]
    VIEW --> XLS[/report/goodremains/download]
```

## Endpoints контура

| Метод и путь | Request / response | Серверная логика |
|---|---|---|
| `POST /datareon/remain` | [GoodRemainSyncDto](../dto/catalog/goodremain/GoodRemainSyncDto.md); `200` без тела | Мониторинг `MessageID`, затем инкрементальный parallel upsert с построчным журналом. |
| `POST /remain/updating/synchronize` | Без body; строка | Сразу отвечает «запущена», а `@Async` выполняет delete-and-reload из настроенного внешнего GET. |
| `GET /remain/updating/status` | Boolean | Проверяет наличие журнала со статусом `active`, а не состояние async future. |
| `POST /remain/updating/force-complete-logs` | Hidden; строка | Переводит все active logs в completed; данные не пересчитывает и не восстанавливает. |
| `POST /remain/good/view` | `FilterWithPaging<GoodRemainViewFilter>` → Page | Читает analytics view с фильтрами и client restriction. |
| `GET /remain/good/view-all` | Page с практически неограниченным размером | Создаёт пустой фильтр, но query service всё равно добавляет client restriction. |
| `POST /report/goodremains/download` | Без body; XLSX stream | Читает ту же view через тот же restricted query service, сортирует по коду номенклатуры. |

`/datareon/**` разрешён без аутентификации текущей security-конфигурацией. Остальные endpoints попадают под общее `authenticated()` и не имеют собственных `@Secure`; конкретные роли, gateway и runtime mappings не проверялись.

## DTO и фактическая обязательность

`POST /datareon/remain` принимает [GoodRemainSyncDto](../dto/catalog/goodremain/GoodRemainSyncDto.md), строка описана в [GoodRemainSyncDto.Leftover](../dto/catalog/goodremain/GoodRemainSyncDto.Leftover.md). Ни корень, ни nested-класс не содержат Bean Validation. Поэтому `@Valid` на controller body не делает обязательными `MessageID`, `leftovers` и поля элементов.

| JSON | Java-тип | Фактическое использование AS-IS |
|---|---|---|
| `MessageID` | String | Только best-effort вызов мониторинга; не сохраняется и не дедуплицируется. |
| `leftovers` | array | Обрабатывается через `parallelStream`; `null` вызывает общую runtime-ошибку. |
| `number` | Integer | Не используется. |
| `event_code` | String | Сохраняется; фактически обязателен из-за DB `NOT NULL`. |
| `item` | UUID | Ищет [ClientGood](../entities/catalog/entities/clientgood/ClientGood.md) по `syncId`; фактически обязателен. |
| `packageId` | UUID | **Игнорируется**. Упаковка ищется по найденному ClientGood, без использования входного UUID. |
| `batch` | UUID | Ищет [Batch](../entities/catalog/entities/batch/Batch.md) по `syncId`; `null`/unknown даёт row error, хотя DB допускает nullable `batch_id`. |
| `good_status` | String | Часть upsert key и поле таблицы; фактически обязателен из-за DB `NOT NULL`. |
| `cargo_number` | String | Exact lookup [Cargo](../entities/catalog/entities/cargo/Cargo.md) по code; отсутствующий code создаёт новый Cargo. Blank/null возвращает `null`, но DB `cargo_id NOT NULL` отклоняет остаток. |
| `actual_quantity` | BigDecimal | Сохраняется без пересчёта; DB `NUMERIC(16,3) NOT NULL`, DTO не имеет sign/precision ограничений. |
| `active` | Boolean | Сохраняется; фактически обязателен из-за DB `NOT NULL`. |
| `client` | UUID | **Игнорируется**; клиент берётся из `ClientGood.client`. |
| `zone` | String | Exact key [ZoneStatusCatalog](../entities/catalog/entities/goodremains/ZoneStatusCatalog.md); blank/unknown — row error, новая zone не создаётся. |
| `timestamp` | String | **Игнорируется**; порядок/актуальность события по времени не проверяются. |

`GoodPackage` ищется только по ClientGood. В коде нет выбора по `packageId`, уровня упаковки или явного порядка при нескольких подходящих строках. Площадка также не берётся из payload: всегда ищется [TerminalArea](../entities/catalog/entities/terminalarea/TerminalArea.md) с точным именем `Складской комплекс 4.2.8`. Если справочник не найден, поле остаётся `null`, а DB `terminal_area_catalog_id NOT NULL` отклоняет сохранение.

Единица измерения не приходит в DTO и не преобразуется сервисом. View показывает `ClientGood.unitOfMeasure.code`; следовательно, смысл `actual_quantity` зависит от номенклатуры и внешнего контракта, который backend не подтверждает.

## Инкрементальный Datareon upsert

```mermaid
flowchart TD
    A[JSON десериализован] --> MON[Best-effort monitoring по MessageID]
    MON --> LOG[Создать active GoodRemainLog]
    LOG --> PAR[parallelStream leftovers]
    PAR --> REF[Zone + ClientGood + package + Batch]
    REF --> CARGO{Cargo code найден?}
    CARGO -->|нет| NEWC[Создать Cargo]
    CARGO -->|да| KEY[Собрать entity]
    NEWC --> KEY
    KEY --> FIND[find by ClientGood + package + batch + goodStatus + cargo]
    FIND --> UPS{Найден?}
    UPS -->|да| UPDATE[Полностью обновить поля; processed=true]
    UPS -->|нет| CREATE[Создать; createdBy/updatedBy=API; processed=true]
    UPDATE --> STAT[success++]
    CREATE --> STAT
    REF -->|ошибка строки| ERR[GoodRemainLogDetails; failure++]
    ERR --> NEXT[Продолжить остальные строки]
    STAT --> DONE[Завершить log; HTTP 200]
    NEXT --> DONE
```

Ключ поиска: `(clientGood, goodPackage, batch, goodStatus, cargo)`. `client`, zone и terminal area в него не входят, поэтому более новое событие того же ключа переносит остаток между клиентом/zone/площадкой и перезаписывает quantity, active и eventCode. Timestamp не участвует: поздно доставленное старое сообщение может победить новое.

При update сервер перезаписывает client, ClientGood, zone, terminal area, package, batch, goodStatus, cargo, actualQuantity, active и eventCode; `processed=true`. При create также ставит `createdBy=API`, `updatedBy=API` — отдельной метки `DATAREON` этот путь не использует. Отсутствующие в пакете строки не удаляются и не обнуляются.

Repository содержит методы `resetAllProcessedFlags()` и `resetActualQuantityForUnprocessed()`, но вызовов этих методов в текущих Java-исходниках не найдено. Поэтому поле `processed` не реализует в данном flow алгоритм «не пришло → quantity=0».

По замыслу ошибка строки записывается в [GoodRemainLogDetails](../entities/catalog/entities/goodremains/GoodRemainLogDetails.md), увеличивает failure и не меняет HTTP `200`. `OpenAPI` заявляет только `200`/`400`, но caller не получает детализацию partial success в response body и должен обращаться к журналам/наблюдаемости.

Строки выполняются в `parallelStream`. Транзакция `updateRemainsFromDto` привязана к HTTP-потоку и не переносится автоматически в worker threads; package-wide atomicity не гарантирована. Дубли ключа не схлопываются: параллельный create может конфликтовать на DB unique, а update одного остатка работает без row lock/`@Version` по принципу last-commit-wins. Создание Cargo также имеет гонку по `cargo.code UNIQUE`.

Есть дополнительный code-level риск error logging: active `GoodRemainLog` создаётся внутри основной HTTP-транзакции, а worker сохраняет detail в своей repository-транзакции с FK на ещё не закоммиченный log. Основной поток одновременно ждёт завершения `parallelStream`. В зависимости от того, на каком потоке возникла ошибка, это может привести к ожиданию/ошибке FK вместо штатного partial `200`. Работающая БД и timeout этого сценария не проверялись.

`leftovers=null` падает до row-level catch. `null`-элемент либо ошибка с `item=null` может повторно сломать формирование/сохранение error detail. В таких случаях возможен HTTP `500` и незавершённый active log, поскольку завершение не находится в `finally`.

## Полная ручная синхронизация

`POST /remain/updating/synchronize` вызывает public `@Async`-метод и немедленно возвращает `200`. В worker thread выполняется:

1. проверка существующего active log;
2. загрузка caches zones, ClientGood и GoodPackage;
3. создание active log;
4. транзакционное удаление всех `good_remain`;
5. внешний GET через отдельный WebClient с Basic auth;
6. Jackson parse в тот же DTO;
7. параллельная сборка уникального map, сохранение errors и нового снимка;
8. завершение log в `finally`.

Это не атомарная замена: delete коммитится до GET/parse/save. Ошибка источника или сохранения оставляет таблицу пустой либо частично заполненной. Созданные во время обработки Cargo могут сохраниться отдельно, даже если итоговый `saveAll(good_remain)` завершился ошибкой.

Full sync схлопывает строки по строковому ключу `ClientGood.id + derived package.id + входной batch UUID + goodStatus + cargo_number`. При дубле обновляется **только** `actualQuantity`; zone, active, eventCode и остальные поля остаются от строки, первой создавшей объект. Из-за parallel execution итоговая quantity и набор прочих полей не имеют детерминированного «последнего входного элемента». Статистика success считается по входным строкам, а не по числу сохранённых уникальных остатков.

В full sync row error дополнительно отправляет incident `REMAINS_UPDATING_ERROR/MEDIUM`; мониторинг перехватывает собственные HTTP-ошибки. Ошибочные строки пропускаются, валидные сохраняются. Ошибка уровня списка или финального `saveAll` записывается как общая detail, после чего log завершается.

Active-check выполняется уже в async thread, поэтому инициатор всё равно получает `200`, если процесс был запущен ранее. Check-then-create log не защищён блокировкой или unique constraint; одновременные старты и параллельный Datareon upsert не координируются.

## Хранение, unique и nullable

Начальная миграция создаёт `good_remain` со следующими существенными условиями:

- `zone_id`, terminal area, `good_status`, `cargo_id`, `actual_quantity`, `active`, `event_code` — `NOT NULL`;
- `client_id`, `good_id`, `package_id`, `batch_id` — nullable в SQL, хотя JPA требует ClientGood/zone и наследует дополнительные правила только на уровне модели;
- unique constraint `(good_id, package_id, batch_id, good_status, cargo_id)`;
- `processed BOOLEAN NOT NULL DEFAULT FALSE` добавлен отдельной миграцией.

PostgreSQL unique допускает несколько строк, когда хотя бы один компонент `NULL`. Успешный текущий flow фактически требует batch/cargo, но package может быть `null`; в этом случае DB constraint не обеспечивает уникальность. Кроме того, repository query использует обычное `goodPackage = :goodPackage`, а не null-safe условие, поэтому `package=null` не находит прежнюю строку и создаёт повтор.

`GoodRemainLogDetails.goodId` nullable в исходной SQL, но JPA помечает колонку `nullable=false`; live schema и Hibernate runtime check не проверялись. Таблица `good_remain_barcodes` существует в миграциях, но Java-модель/обработка barcode в текущем inbound-контуре не найдена.

Источники: [создание таблиц](../../../db-layer/src/main/resources/db/changelog/v.1.23.0/v1.0.0_KIS-1410_add_table_good_remain.sql), [processed](../../../db-layer/src/main/resources/db/changelog/v.1.23.0/v.1.23.0_20250807_KIS-1515_Added_new_column_for_good_remain_table.sql), [terminal area UUID/FK](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20251111_KIS-1422_edit_terminal_area_catalog_entity.sql), [rerunnable view](../../../db-layer/src/main/resources/db/changelog/rerunnable/V1.0.0_KIS-1410_add_view_good_remain.sql), [barcodes](../../../db-layer/src/main/resources/db/changelog/v.1.26.0/v.1.26.0_20250828_KIS-1517_Added_new_table_good_remain_barcodes.sql).

## Read model и client restriction

`analytics.good_remain_view` берёт только строки `actual_quantity > 0 AND active=true`. Нулевые, отрицательные и неактивные остатки сохраняются в `good_remain`, но через view/API/report не видны.

View связывает ClientGood, UOM, Batch, Cargo, TerminalArea, GoodPackage и ZoneStatusCatalog. В текущем SQL есть важная проекция:

- `good_status` выводится как `zone_status_catalog.status`, а не `good_remain.good_status`;
- `zone` также выводится как `zone_status_catalog.status`, а не исходный `zone_id`.

В результате API не показывает исходные `good_status` и zone key раздельно; оба поля могут содержать одинаковый статус зоны. Фильтры `zone` и отображаемый goodStatus относятся к этой проекции.

Код клиента — `COALESCE(ClientGood.client.code, ReceivingOrder.client.code через Cargo/blackbox)`, но `client_id` берётся только из `ClientGood.client`. Query service вызывает `FilterEnrichService`; для не-admin с определённым user id запрошенный client filter пересекается с доступными client ids, а пустой набор подменяется случайным UUID. Для admin ограничение не добавляется. Если security context не содержит user id, сервис лишь пишет warning и restriction не добавляет — это отдельная runtime-граница доступа.

## Ошибки и повторы

| Ситуация | Результат AS-IS |
|---|---|
| Некорректный JSON или формат UUID | Jackson error → HTTP `400`. |
| Unknown/blank zone, unknown ClientGood/Batch | По замыслу row error → detail и продолжение; cross-thread detail/FK может нарушить этот partial `200`. |
| Blank cargo, missing fixed TerminalArea, null required DB value | DB/integrity row error; partial `200` только при успешном error logging. |
| Duplicate Cargo/good remain DB key | Row error; HTTP `200` не гарантирован из-за описанного logging/FK риска. |
| `leftovers=null`, null element/error-detail failure | Общая runtime error → HTTP `500`; active log может остаться. |
| Повтор `MessageID` | Полный новый проход; дедупликации нет. |
| Повтор бизнес-ключа в следующем пакете | Полный update независимо от timestamp. |
| Ключ отсутствует в Datareon-пакете | Остаётся без изменений; только full sync предварительно удаляет всё. |
| Full sync fetch/parse/save error | HTTP инициатора уже `200`; log фиксирует ошибку, snapshot может остаться пустым. |

Глобальный формат HTTP-ошибок задаёт [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java). Однако большинство содержательных ошибок перехватываются внутри row loop и не доходят до advice.

## Влияющие commits

| Commit | Влияние на текущее поведение |
|---|---|
| `3699292728f15d4f953cee1c732f02eb0c1267e9`, 21.07.2025, `KIS-1410 migration with remains moved to release folder...` | Добавил исходную модель, таблицы, view, controllers, DTO и full-sync service. |
| `ab6480834c7bf6ee2bdf7ab8fc70a1c1ba578a80`, 24.07.2025, `KIS-1410 uploading remains from datareon and api` | Добавил Datareon-вход и разделил источники запуска. |
| `bd0669045e469c1735ca65ee248cc23e62b011bf`, 21.08.2025, `KIS-1556 Added processing of batch...` | Сформировал текущие transaction/cache/synchronization services и сделал Batch внешним обязательным справочником. |
| `819c0f2a7441cac668985ae9dff5d38db16ac916`, 28.10.2025, `KIS-1831 Removed transaction from remain saving` | Явно снял транзакцию с full-sync `processAndSaveRemains`. |
| `5a162c8ca43be1646f7380f3a449b816bdc9d459`, 18.11.2025, `KIS-1869 Change remains view tables...` | Изменил поля/фильтры current read view. |
| `9555187618055d77837b34106f34c69d90fd9a1d`, 29.12.2025, `KIS-2434 add restriction by user for good remains /view-all request` | Добавил действующий ClientRestrictionFilter и его применение к view/view-all/report. |
| `2005834e7d7189c8058d69a84c3034cfe96eff35`, 07.04.2026, `KIS-3544 add namebased dao service and repository` | Перевёл фиксированную площадку остатков на поиск по русскому имени. |

## Тесты и граница доверия

Прямых unit/integration tests для `GoodRemainTransactionService`, `GoodRemainSynchronizationService`, трёх controllers, DTO, unique/null cases, client restriction view и Excel-выгрузки в текущих test source sets не найдено. Тесты на подэтапе не запускались.

Для ТЗ нельзя без отдельного решения считать `MessageID` idempotency key, timestamp критерием свежести, `packageId` реально применяемым полем, Datareon-пакет полным снимком, пакетную запись атомарной, view отражающей raw zone/goodStatus или отрицательный/нулевой остаток. Эти гарантии отсутствуют в текущем backend AS-IS.
