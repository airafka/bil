# Валидация заявок и обязательность полей

> Сверено с checkout `22fac945e8116d04972ccc87b06b2303acf7a561` 18.09.2026 в рамках повторного аудита базовых документов этапа 3. Строки, относящиеся к вывозу, перепроверены по деталям физических моделей частей 16–23; строки поставки — без повторного построчного прохода.

Этот документ разделяет проверки HTTP-запроса и проверки сохранённого агрегата. Они выполняются в разные моменты и используют разные источники данных.

## Уровни валидации

| Уровень | Когда | Что проверяется | Источник правил |
|---|---|---|---|
| 0. UI (frontend) | В браузере до отправки запроса | Обязательность и формат полей формы, зависимости полей, доступность кнопок по статусу и праву | zod-схемы и конфиги форм; см. [UI-правила заявок](order-ui-rules-as-is.md) |
| 1. JSON binding | До входа в метод контроллера | Синтаксис JSON, UUID, ISO-8601 даты, имена enum | Jackson и типы полей request DTO |
| 2. Bean Validation | До входа в метод контроллера | `@NotNull`, `@PositiveOrZero`, вложенные объекты под `@Valid`, class-level `@AssertTrue` | Конкретный request DTO |
| 3. Создание/изменение модели | В сервисе create/update | Существование ссылочных записей, допустимость редактирования, сочетание площадки/транспорта/типов, нормализация | mapper, DAO, `OrderCombinationValidator`, сервис заявки |
| 4. Переход статуса | В начале review/accept | Разрешён ли переход из текущего статуса | `OrderStatus.isStatusChangeAllowed` |
| 5. Review/accept | После проверки перехода, над сохранённым агрегатом | Полнота корня, транспорт, товары, грузы, КТК, вагоны и документы | `ReceivingOrderAcceptValidator` или `ShippingOrderAcceptValidator` |

Уровень 0 действует только для запросов из штатного UI и может быть как строже, так и мягче сервера — расхождения сведены в [реестр UI ↔ backend](order-ui-rules-as-is.md#реестр-расхождений-ui--backend). Ошибка на одном уровне не означает, что последующие уровни пройдены. Например, поле `currency` разрешено не передавать при создании `DRAFT`, но без валюты заявка не пройдёт review/accept.

## Как читать обязательность

- **В request** — поле обязано присутствовать уже в JSON из-за Bean Validation.
- **Условно в request** — поле проверяется только при заданной комбинации других полей.
- **Перед review/accept** — поле может отсутствовать в create/update, но должно быть заполнено в сохранённом агрегате к моменту перехода статуса.
- **Серверное** — клиент не задаёт итоговое значение; его генерирует или переопределяет сервер.

`@NotNull` запрещает `null`, но для строки не запрещает `""`. `@NotBlank` запрещает `null`, пустую строку и строку из пробелов. В корневых DTO заявок используются преимущественно `@NotNull`.

## Поставка: корневой request

Конкретные контракты: [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md) и [ReceivingOrderUpdateDto](../dto/receiving-order/ReceivingOrderUpdateDto.md); общие поля обоих запросов вынесены в [ReceivingOrderBaseDto](../dto/receiving-order/ReceivingOrderBaseDto.md).

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | Update ищет заявку по `body.id`; path-параметр контроллером не используется |
| `client` | обязательно | обязательно | Вложенный `id` валидируется; после создания клиент не меняется |
| `contract` | обязательно | обязательно | Ссылка разыменовывается через DAO |
| `terminalArea` | обязательно | обязательно | Значимый `code`; после создания поле не меняется |
| `transportType` | обязательно | обязательно | После создания поле не меняется |
| `orderStatus` | обязательно | обязательно | При create переданное значение заменяется на `DRAFT` |
| `storagePeriod` | нет | нет | Если задан, значение должно быть `>= 0` |
| `deliveryType` | условно | условно | Обязателен для `WAREHOUSE + VEHICLE`; вне этой комбинации при create сбрасывается в `null` |
| `payerId` | условно | отсутствует | Для `CONTAINER + RAILWAY`, только если `RAILWAY_FIELDS_REQUIRED=true` |
| `departureStationId` | условно | отсутствует | То же условие |
| `destinationStationId` | условно | отсутствует | То же условие |
| `currency` | нет | нет по DTO | Обязательна перед review/accept; текущий update-код разыменовывает `currency.id`, поэтому `null` небезопасен |
| `planReceivingDateTime` | нет | нет | Обязательна перед review/accept |
| `shipper` | нет | нет | Обязателен перед review/accept при `terminalArea.code=CONTAINER` |
| `contact`, `comment`, `needTransport`, `route`, `waybill` | нет | нет | Применяются правила изменения из документа поставки |
| `carrier` | нет | нет | Deprecated и игнорируется mapper-ом; использовать `shipper` |

`payerId`, `departureStationId` и `destinationStationId` принадлежат только create DTO. `ReceivingOrderUpdateDto` их не наследует и изменить их общим update endpoint нельзя.

## Вывоз: корневой request

Конкретные контракты: [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md) и [ShippingOrderUpdateDto](../dto/shipping-order/ShippingOrderUpdateDto.md). Update DTO наследует все поля creation DTO и добавляет `id`.

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | Update ищет заявку по `body.id`; path-параметр контроллером не используется |
| `client` | обязательно | обязательно | Вложенный `id` валидируется; после создания клиент не меняется |
| `contract` | обязательно | обязательно | Ссылка разыменовывается через DAO |
| `terminalArea` | обязательно | обязательно | Значимый `code`; после создания поле не меняется |
| `transportType` | обязательно | обязательно | После создания поле не меняется |
| `orderStatus` | обязательно | обязательно | При create переданное значение заменяется на `DRAFT` |
| `deliveryType` | условно | условно | Обязателен для `WAREHOUSE + VEHICLE`; вне этой комбинации при create сбрасывается в `null` |
| `fillingType` | нет | нет | `NONE_CONTAINER` разрешён только для `CONTAINER + VEHICLE`; для `CONTAINER + RAILWAY` отсутствие нормализуется в `ALL` |
| `currency` | нет | нет по DTO | Обязательна перед review/accept; текущий update-код разыменовывает `currency.id`, поэтому `null` небезопасен |
| `plannedShippingDateTime` | нет | нет | Обязательна перед review/accept |
| `consignee` | нет | нет | Обязателен перед review/accept для `CONTAINER`; при записи проверяются роль и принадлежность клиенту |
| `contact`, `comment`, `route`, `needTransport`, `consigneeAddress` | нет | нет | `consigneeAddress` при записи грузополучателя заменяется его фактическим адресом |

**Дублирующийся `consignee` на transport.** У `ShippingOrderTransport` есть собственные физические колонки `consignee`/`consigneeAddress` (отдельная таблица `shipping_order_transport`, не `shipping_order`), заполняемые через `POST/PUT /shippingordertransport/*` **без** проверки роли/принадлежности клиенту и без подстановки `addressFact` — в отличие от одноимённых root-полей выше. Ни один найденный потребитель (TN-отчёт, копирование в рейс, outbound manifest) не читает transport-версию этих полей. Подробности — в [физической модели транспорта](../database/shipping-order-transport-as-is.md#дублирующийся-грузополучатель-root-и-transport--разные-правила).

## Заявка на услугу: корневой request

Конкретные контракты: [ServiceOrderCreationDto](../dto/service-order/ServiceOrderCreationDto.md) и [ServiceOrderUpdateDto](../dto/service-order/ServiceOrderUpdateDto.md).

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | Основной идентификатор update передаётся также в path |
| `client` | обязательно | отсутствует | После создания этим endpoint не меняется |
| `service` | обязательно | обязательно | Реализовано только значение `CHANGE_OWNER` |
| `comment` | нет | нет | Может быть заменён или очищен |

Create устанавливает `status=DRAFT`. Update разрешён только в `DRAFT`. Accept не имеет request body и проверяет минимум одну сохранённую связь с контейнером.

## Межполевая проверка create/update

После преобразования DTO в модель выполняется `OrderCombinationValidator`:

1. Если `transportType=RAILWAY`, `terminalArea.code` должен быть `CONTAINER`.
2. Для `WAREHOUSE + VEHICLE` поле `deliveryType` обязательно.
3. Для вывоза `fillingType=NONE_CONTAINER` разрешён только при `CONTAINER + VEHICLE`.
4. При create поставки/вывоза `deliveryType` вне `WAREHOUSE + VEHICLE` сбрасывается в `null`.
5. При create вывоза `CONTAINER + RAILWAY` и пустом `fillingType` устанавливается `ALL`.

Проверка использует `terminalArea.code`, полученный после mapping. Наличие объекта `terminalArea` в JSON само по себе не подтверждает допустимость его кода или существование справочной записи.

## Review и accept проверяют агрегат, а не request DTO

`PUT /receivingorder/{id}/review` и `PUT /shippingorder/{id}/review` не принимают тело. Сервис блокирует заявку, проверяет переход в `ON_REVIEW`, затем запускает accept-валидатор с ослабленным флагом.

Accept реализован сервисными методами, но публичные endpoints для транспортных заявок в соответствующих контроллерах отсутствуют. Сервисный accept блокирует заявку, проверяет переход в `ACCEPTED`, запускает полный валидатор и только после успеха меняет статус и формирует outbound-данные.

Порядок агрегатной проверки:

1. Для поставки при accept отдельно проверяется неопределённый тип вагона; эта ошибка выбрасывается сразу.
2. Собираются ошибки общих полей корня: валюта, плановая дата, `shipper`/`consignee` для контейнерной площадки.
3. По паре `terminalArea.code + transportType` выбирается набор валидаторов дочерних частей.
4. Только при accept для `CONTAINER + VEHICLE` проверяется `ktkNumberUnknown`.
5. Накопленные коды объединяются через `", "` и возвращаются одной `ValidationException`.

Полная матрица дочерних проверок находится в правилах [поставки](receiving-orders.md#матрица-содержательной-валидации) и [вывоза](shipping-orders.md#матрица-содержательной-валидации), а расшифровка кодов — в [каталоге ошибок](order-errors.md).

## DTO дочерних частей агрегата

Корневые create/update DTO не содержат товары, транспорт, КТК, вагоны и документы. Они сохраняются отдельными endpoints до review/accept. Ниже указаны конкретные request DTO, данные которых затем читает агрегатный валидатор.

| Часть агрегата | Поставка | Вывоз |
|---|---|---|
| Транспорт | *(изменено KIS-4093, коммит `d30d77ad`, 24 сентября 2026)* Отдельных `ReceivingOrderTransport*Dto` больше нет; аккаунт-проверка при accept — `shippingOrder.getRoute() != null` / аналогично для поставки, через связанный [`Route`](../entities/catalog/entities/route/Route.md) и `RouteController` (`POST /route/{id}/assign` и т.п.), а не через отдельный transport-DTO заявки | То же — прежние `ShippingOrderTransportCreationDto`/`UpdateDto` удалены, проверка `MISSING_TRANSPORT` теперь требует `shippingOrder.route != null` (`ShippingOrderAcceptValidator.transportChecks`) |
| Товар | [`ReceivingOrderGoodCreationDto`](../dto/catalog/receivingordergood/ReceivingOrderGoodCreationDto.md), [`ReceivingOrderGoodUpdateDto`](../dto/catalog/receivingordergood/ReceivingOrderGoodUpdateDto.md) | [`ShippingOrderGoodCreationDto`](../dto/catalog/shippingordergood/ShippingOrderGoodCreationDto.md), [`ShippingOrderGoodUpdateDto`](../dto/catalog/shippingordergood/ShippingOrderGoodUpdateDto.md) |
| Детальное грузовое место | [`ReceivingOrderCargoCreationDto`](../dto/catalog/receivingordercargo/ReceivingOrderCargoCreationDto.md), [`ReceivingOrderCargoUpdateDto`](../dto/catalog/receivingordercargo/ReceivingOrderCargoUpdateDto.md) | [`ShippingOrderCargoCreationDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoCreationDto.md), [`ShippingOrderCargoUpdateDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoUpdateDto.md) |
| Blackbox | [`ReceivingOrderBlackboxCreationDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxCreationDto.md), [`ReceivingOrderBlackboxUpdateDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxUpdateDto.md) | [`ShippingOrderBlackboxCreationDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxCreationDto.md), [`ShippingOrderBlackboxUpdateDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxUpdateDto.md) |
| Контейнер | [`ReceivingOrderContainerCreationDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerCreationDto.md), [`ReceivingOrderContainerUpdateDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerUpdateDto.md) | [`ShippingOrderContainerCreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerCreationDto.md), [`ShippingOrderContainerUpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerUpdateDto.md) |
| Содержимое контейнера | [`ReceivingOrderContainerItemCreationDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemCreationDto.md), [`ReceivingOrderContainerItemUpdateDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemUpdateDto.md) | [`ShippingOrderContainerItemCreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemCreationDto.md), [`ShippingOrderContainerItemUpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemUpdateDto.md) |
| Безномерные контейнеры | — | [`ShippingOrderContainerQtyCreationDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyCreationDto.md), [`ShippingOrderContainerQtyUpdateDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyUpdateDto.md) |
| Конкретные вагоны | Через `WaybillRailwayCarriage` в агрегате накладной | [`ShippingOrderRailwayCarriageCreationDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageCreationDto.md), [`ShippingOrderRailwayCarriageUpdateDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageUpdateDto.md) |
| Безномерные вагоны | — | [`ShippingOrderRailwayCarriageQtyCreationDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyCreationDto.md), [`ShippingOrderRailwayCarriageQtyUpdateDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyUpdateDto.md) |
| ЭТРАН | Через `Waybill` в агрегате накладной | [`ShippingOrderEtranInvoiceCreationDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceCreationDto.md), [`ShippingOrderEtranInvoiceUpdateDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceUpdateDto.md) |

### Партия товарной строки (уровень 3)

С 13.10.2026 (`8ee1ab68`, KIS-4841) при add/update товарной строки поставки и вывоза (`prepareModelToAdd`/`prepareModelToUpdate`, включая `multipleaddition`/`multipleupdate`, `applyBatch` и копирование заявки) сервис вызывает [`OrderGoodBatchValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/ordergood/validation/OrderGoodBatchValidator.java) (`SOURCE_CONFIRMED`). «Учёт включён» = `ClientGood.batchAccountingType` равен `MANUFACTURE_DATE` или `EXPIRATION_DATE`. Правила проверяются по порядку, первая ошибка — `ValidationException` → HTTP 400:

| Условие | Код |
|---|---|
| `batchUnknown=true`, учёт не включён | `OrderGood.BatchUnknownNotAllowed` |
| `batchUnknown=true` и передана `batch` | `OrderGood.BatchUnknownWithBatch` |
| учёт включён, `batchUnknown=false`, `batch=null` | `OrderGood.MissingBatch` |

До коммита сервер партию не требовал (правило было только в UI). Review/accept партию по-прежнему не проверяет; строки, создаваемые WMS-результатом, валидатор не проходят. Принадлежность `batch` выбранному `ClientGood` валидатор не проверяет.

Для заявки на услугу контейнеры задаются отдельным [`ServiceOrderContainerSaveDto`](../dto/catalog/serviceordercontainer/ServiceOrderContainerSaveDto.md): должен быть указан хотя бы один из `id` или `containerOwnerId`. Accept затем требует, чтобы в БД была минимум одна связь `ServiceOrderContainer`.

Ссылки ведут в generated-паспорта с полями и Bean Validation. Для DTO без ручного паспорта бизнес-смысл следует подтверждать сервисной логикой; review/accept повторно проверяет только явно перечисленные бизнес-инварианты агрегата.
