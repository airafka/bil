# Регистр остатков и владельца КТК: `ContainerOwner`/`ContainerOwnerHistory` AS-IS

Проверено по checkout `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026): Java entity/service/validator source. Это **source-level реконструкция**, а не проверка применённой БД или прогон тестов. Вся описанная ниже машина статусов (`ContainerStatusService`, 427 строк) — новый код этого периода (KIS-4661, «KTK remains», первый коммит `9a05f552` от 21 сентября 2026); модель владельца (`ContainerOwner`/`ContainerOwnerHistory`) существовала раньше, но получила поле `status` и связи с заявками той же серией коммитов, плюс замену типа `owner`-полей с `ClientRelatedEntity` на `Client` в KIS-4716 (24–25 сентября 2026).

> **Актуализация 14.10.2026 (`729c9a17`, KIS-4830, коммиты `401bbea3`, `143d3a43`, `a1238ba1`).** Изменились: отмена поставки больше не удаляет строку `ContainerOwner`; при отмене поставки/вывоза ссылка `receivingOrder`/`shippingOrder` возвращается на предыдущую заявку, а не обнуляется; `ShippingOrderContainer.ownerContainer` переведён на `Client` и заполняется снимком из registry — дефект `ownerContainerId = null` в route chain package закрыт; API истории владельцев показывает только записи выполненных заявок с переходом в `ON_TERMINAL`/`DEPARTED` и отдаёт `newClient` вместо `orderClient`. Ниже текст обновлён по этим коммитам.

## Модель: один регистр на КТК, а не поле на заявке

[`ContainerOwner`](../entities/catalog/entities/containerowner/ContainerOwner.md) — `@OneToOne` с `Container` (до KIS-4661 было `@ManyToOne`, то есть раньше формально допускалось несколько owner-строк на один физический контейнер; сейчас на уровне JPA/PK — ровно одна текущая строка на контейнер). Строка хранит:

- `client` — текущий владелец;
- `status` — [`ContainerStatus`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/container/ContainerStatus.java): `EXPECTED` (ожидает поставки) / `ON_TERMINAL` (в остатках) / `RESERVED_OUT` (ожидает вывоза) / `DEPARTED` (нет в остатках);
- `receivingOrder`/`shippingOrder` — какая заявка определила текущее состояние.

[`ContainerOwnerHistory`](../entities/catalog/entities/containerownerhistory/ContainerOwnerHistory.md) — append-only лог: `oldClient/newClient`, `oldStatus/newStatus`, `container`, полиморфная `order` (`@Any` на `ReceivingOrder`/`ShippingOrder`/`ServiceOrder` через `order_type` discriminator). Пишется **только** при фактическом изменении client или status (`ContainerStatusService.transition`, сравнение `sameClient`/`oldStatus != newStatus`).

Миграция [`v.1.35.0_..._KIS-4661_add_container_owner_status.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260915_KIS-4661_add_container_owner_status.sql) при накатке проставила всем существующим строкам `status='ON_TERMINAL'` — то есть все ранее созданные `container_owner` считаются «в остатках» по умолчанию, задним числом, без реальной истории EXPECTED/RESERVED_OUT для них.

## Состояния и переходы (`ContainerStatusService`)

```mermaid
stateDiagram-v2
    [*] --> EXPECTED: reserveForReceivingOrder (accept поставки)
    EXPECTED --> ON_TERMINAL: markReceived (TOS receiving result)
    EXPECTED --> DEPARTED: cancelReceivingOrder (reject/cancel поставки)
    ON_TERMINAL --> RESERVED_OUT: reserveForShippingOrder (accept вывоза)
    ON_TERMINAL --> DEPARTED: cancelReceivingOrder (отмена DONE-поставки, см. риск ниже)
    RESERVED_OUT --> DEPARTED: markShipped (TOS shipment result)
    RESERVED_OUT --> ON_TERMINAL: cancelShippingOrder (reject/cancel вывоза)
    DEPARTED --> EXPECTED: reserveForReceivingOrder (повторная поставка того же КТК)
```

| Метод | Вызывается из | Что делает | Ключевые проверки (иначе `ValidationException`, коды `ContainerStatus.*`) |
|---|---|---|---|
| `reserveForReceivingOrder` | [`ReceivingOrderService.accept`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java) | Владелец для каждого КТК заявки — из `ReceivingOrderContainer.ownerContainer` **и** связанных `WaybillContainer.ownerContainer`; переход в `EXPECTED` | Владелец обязателен и должен совпадать между строками одного КТК (`ContainerStatus.ReceivingAlreadyReserved/InRemains/InShipping`, если КТК уже трекается в другом статусе, кроме `DEPARTED`) |
| `markReceived` | [`TosReceivingResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosReceivingResultAction.java) (inbound TOS-событие) | `EXPECTED → ON_TERMINAL`, владелец не меняется | Не проверяет входной статус явно — просто перезаписывает |
| `cancelReceivingOrder` | `ReceivingOrderService.reject` | Не выполняется для `DRAFT`/`ON_REVIEW` (там ещё не было `reserveForReceivingOrder`). Для остальных статусов: если предыдущий статус был `DONE`, требует `ON_TERMINAL` именно от этой заявки, иначе — восстановление предыдущего владельца (см. ниже) | `CancelReceivingInShipping/Departed/ReservedLater`, если КТК уже не в ожидаемом состоянии |
| `reserveForShippingOrder` | `ShippingOrderService.accept` | Требует `owner != null && status == ON_TERMINAL`; переход в `RESERVED_OUT`, владелец **не выбирается заново** — берётся из текущей строки registry | `ShippingMissingInRemains` (нет владельца/уже `DEPARTED`), `ShippingNotReceived` (ещё `EXPECTED`), `ShippingAlreadyReserved` (уже `RESERVED_OUT`) |
| `markShipped` | [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) | `RESERVED_OUT → DEPARTED` | — |
| `cancelShippingOrder` | `ShippingOrderService.reject`/отмена | Не выполняется для `DRAFT`/`ON_REVIEW`. Для `DONE` требует, чтобы КТК сейчас был `DEPARTED` именно от этой заявки; иначе `CancelShippingExpected/Received/ReservedLater`. Возврат в `ON_TERMINAL`, владелец не меняется; `shippingOrder` с 08.10.2026 (KIS-4830) — предыдущая неотклонённая заявка на вывоз этого КТК по истории (`findPreviousShippingOrder`: запись истории раньше первой записи отменяемой заявки, статус заявки ≠ `REJECTED`), если её нет — `null` (до KIS-4830 всегда `null`) | — |

## Риск: восстановление владельца при отмене поставки всегда даёт `DEPARTED`, а не прежний статус

`cancelReceivingOrder` → `restorePreviousOwner` ищет в `ContainerOwnerHistory` запись `findReceivingReservation(containerId, orderId)` и берёт из неё `oldClient` (владельца **до** этой поставки). Дальше:

- если `oldClient == null` (у контейнера не было владельца до этой поставки, то есть это была первая регистрация) — с 08.10.2026 (KIS-4830, `401bbea3`) строка `ContainerOwner` **сохраняется**: статус `DEPARTED`, владелец остаётся тем, кого указала отменённая поставка; в историю пишется запись `oldClient = newClient =` этот владелец, меняется только статус. До KIS-4830 строка удалялась целиком (`containerOwnerDaoService.remove`) и КТК выходил из регистра;
- если `oldClient` есть — строка обновляется: `client = oldClient`, но **статус жёстко ставится `DEPARTED`**, а не восстанавливается прежний статус до этой поставки;
- в обоих случаях `receivingOrder` с KIS-4830 указывает на предыдущую неотклонённую поставку этого КТК по истории (`findPreviousReceivingOrder`), а при её отсутствии — `null` (до KIS-4830 всегда `null`).

То есть отмена/reject поставки, у которой КТК уже был `ON_TERMINAL` (реально принят складом, затем заявку отменили как `DONE`), не возвращает КТК в `ON_TERMINAL` под старым владельцем — он помечается как выбывший (`DEPARTED`) вне зависимости от того, был ли он физически кем-то вывезен. Отдельно физическое перемещение (`good_movement`/warehouse) этим методом не проверяется и не корректируется. **Вопрос для ТЗ:** осознанное упрощение (отмена = импорт-исправление, а не физическое движение) или дефект.

## Два уровня «владельца» и их рассинхронизация (KIS-4716)

До KIS-4716 поле-владелец на строке заявки (`ReceivingOrderContainer.ownerContainer`, `ShippingOrderContainer.ownerContainer`/`ownerRailwayCarriage`, `WaybillContainer.ownerContainer`) было типизировано как `ClientRelatedEntity`. Миграции [`add_owner_client_columns.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_add_owner_client_columns.sql) + [`migrate_owner_client_data.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_migrate_owner_client_data.sql) переводят это на прямую ссылку на `Client` — но **не единообразно**:

| Сущность | Поле | Колонка | Тип на 14.10.2026 |
|---|---|---|---|
| `ReceivingOrderContainer` | `ownerContainer` | `owner_container_id_new` | `Client` (мигрировано KIS-4716) |
| `WaybillContainer` | `ownerContainer` | `owner_container_id` | `Client` (мигрировано KIS-4716) |
| `ShippingOrderContainer` | `ownerContainer` | `owner_container_id` | `Client` — мигрировано **KIS-4830** (08.10.2026), заполняется сервером снимком из registry, см. [раздел ниже](#владелец-на-строке-вывоза-kis-4830). С 22.09 по 08.10.2026 было `ClientRelatedEntity` и всегда `null` у новых строк |
| `ShippingOrderContainer` | `ownerRailwayCarriage` | `owner_railway_carriage_id` | **`ClientRelatedEntity`** (НЕ мигрировано) |

Старая колонка `owner_container_id_new` на `receiving_order_container` называется «`_new`» потому, что попытка убрать старое поле и колонку тем же днём была сделана и тут же отменена (коммит `e8eed7fe` «KIS-4716 drop old owner container field», следом `1eef7cd9` «Revert»); соответствующий migration-файл `cleanup_receiving_order_container_owner.sql` в текущем `dev` не существует (не подтверждено, был ли он удалён или так и не попал в cumulative.yml). Итоговое имя колонки `owner_container_id_new` осталось «временным» именем в постоянном использовании — стоит уточнить у разработчиков, планируется ли переименование.

С 22.09 по 08.10.2026 мапперы `/list`-, detail- и merge-эндпоинтов вывоза (коммиты `7c7d4ec9`…`156bcd48`: `toDto`, `toDetailedDto`, `mapToContainerDto`, `mapToUnnumberedOrderContainerMergeDto` в [`ShippingOrderContainerMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java)) заполняли `ownerContainer` из `container.containerOwner.client` (live-registry), минуя поле строки. KIS-4830 убрал эти `@Mapping` — теперь они отдают поле строки (снимок); live-значение registry осталось только в `toContainerDto` (DTO самого КТК). В период KIS-4716 из [`ShippingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) убрана проверка `container.getOwnerContainer() == null → MISSING_OWNER_CONTAINER` — на вывозе владелец больше не выбирается и не валидируется на уровне строки заявки, единственная проверка владельца при accept вывоза теперь происходит через `ContainerStatusService.reserveForShippingOrder` (требование `status == ON_TERMINAL`, владелец берётся из registry).

### Владелец на строке вывоза (KIS-4830)

Коммит `401bbea3` (08.10.2026):

- **Схема.** Миграция [`v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql) переводит FK `shipping_order_container.owner_container_id` с `client_related_entity` на `client`. Значения перемаплены по таблице соответствия из KIS-4716 (`3bcf0113`); значения, которых нет в таблице, становятся `NULL`.
- **Заполнение.** Значение из DTO игнорируется (`modelCreation` и `modelUpdate` — `ignore = true`). [`ShippingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) записывает в строку текущего владельца из registry (`container.containerOwner.client`) при создании строки и при смене КТК в `PUT`; [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) делает то же для строк, которые создаёт или перепривязывает по результату отгрузки из TOS. Без КТК или без строки registry — `NULL`.
- **Чтение.** `toDto`/`toDetailedDto`/merge-DTO и route chain package (`toChainPackageDto` → `ShippingRouteChainPackageExportService`, `.ownerContainerId(id(shippingOrderContainer.getOwnerContainer()))`) читают **одно и то же** поле строки. Дефект «`ownerContainerId` в пакете вывоза всегда `null`» (22.09–08.10.2026) этим закрыт.
- **Excel-загрузка вывоза.** Из трёх шаблонов загрузки (`templates/shipping_order_auto_container_yard.xlsx`, `shipping_order_railway_carriage.xlsx`, `shipping_order_railway_carriage_filling_type_container.xlsx`) удалена колонка «Собственник КТК*» вместе с выпадающим списком на лист «Контрагенты»; остальные колонки сдвинулись на одну влево. Парсеры (`ShippingOrderAutoContainerYardParser`, `ShippingOrderRailwayCarriageParser`, `ShippingOrderRailwayCarriageFillingTypeContainerParser`) владельца не читают и не проверяют — пропала ошибка `Container.KtkOwner.IsEmpty.N`. Файл **старого образца** с этой колонкой отклоняется проверкой структуры (`ValidateUtil.validateColumn`, ошибка `Column.<Лист>.NotFound`). Для поставки проверка колонки сохранена (`KtkParserSupport` проверяет её только при наличии).
- **Собственник вагона в ЖД-шаблоне вывоза.** До KIS-4830 `AbstractRailwayCarriageParser` записывал в `ownerRailwayCarriage` значение колонки «Собственник КТК», а колонку «Собственник вагона» игнорировал. Теперь для вывоза берётся «Собственник вагона» (поиск по `ClientRelatedEntity` клиента заявки, при отсутствии — `NotFoundException`).
- **Выпуск шаблонов.** В ЖД-шаблоне вывоза лист «Грузополучатель» теперь заполняется `ClientRelatedEntity` клиента заявки с признаком грузополучателя (раньше — все активные `Client`), то есть ровно тем, что ищет импорт. В авто-шаблоне поставки (`ReceivingOrderAutoContainerYardTemplateDataCollector`) лист «Контрагенты» теперь заполняется всеми активными `Client` (раньше — `ClientRelatedEntity` клиента), в соответствии с поиском владельца при импорте поставки.
- **Фильтр/сортировка.** `ShippingOrderContainerFilter.ownerContainer` стал `ClientFilter` (было `ClientRelatedEntityFilter`); сортировка и общий поиск по владельцу идут по `client.code`.

Ограничения (вывод по исходному коду, `SOURCE_CONFIRMED`): значение — **снимок** на момент добавления КТК в заявку или смены КТК в строке; если владелец в registry сменился позже (например, заявкой на услугу), строка вывоза и пакет в Datareon покажут прежнего владельца. Строки, созданные 22.09–08.10.2026, миграция не дозаполняет — у них `NULL`, пока в строке не сменят КТК.

**Расхождение с каталогом ошибок:** [`order-errors.md`](order-errors.md) по-прежнему перечисляет `XContainer.MissingOwnerContainer` как общий для поставки и вывоза код («У известного КТК нет владельца», «контейнерная площадка»). На 29 сентября 2026 это верно только для [`ReceivingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/validation/ReceivingOrderAcceptValidator.java) (`ReceivingOrderContainer.MissingOwnerContainer` активен); для вывоза этот код с 25 сентября 2026 не выбрасывается. `order-errors.md` эту строку не разделяет — нужна правка (отдельный источник правды, здесь не изменяю таблицу ошибок, чтобы не потерять остальную сверку той страницы).

## Связь с приёмкой заявки (WaybillContainer как альтернативный источник владельца)

`ContainerStatusService.getContainers(ReceivingOrder)` объединяет КТК из **двух** источников: собственных `ReceivingOrderContainer` заявки **и** `WaybillContainer`, связанных через `receivingOrderId` (то есть КТК, пришедшие по железнодорожной накладной и привязанные к этой поставке). `getRequiredReceivingOwners` требует владельца от **обоих** источников и явно проверяет, что они не противоречат друг другу (`Для КТК указаны разные собственники`, если `ReceivingOrderContainer.ownerContainer` и `WaybillContainer.ownerContainer` для одного физического КТК различаются). Это означает, что для КТК на железнодорожной площадке владелец фактически должен быть выставлен дважды (на уровне заявки и на уровне накладной) и синхронизирован вручную/UI — расхождение блокирует `accept`.

## API истории владельцев (`/container/{id}/owner-history`)

[`ContainerOwnerHistoryService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerownerhistory/ContainerOwnerHistoryService.java) для `POST /page` и `POST /meta/{fieldName}` принудительно добавляет к фильтру клиента (с 08.10.2026, KIS-4830, `401bbea3` и `143d3a43`):

- `orderStatus IN (DONE)` — только записи по выполненным заявкам (поставка/вывоз — `orderStatus`, услуга — `status`);
- `newStatus IN (ON_TERMINAL, DEPARTED)` — только переходы «принят на терминал» и «выбыл»; записи `EXPECTED`/`RESERVED_OUT` и смены владельца без смены статуса в эти значения не показываются.

Физически `ContainerOwnerHistory` по-прежнему пишет все переходы — ограничение только на чтение через API.

С 12.10.2026 (`a1238ba1`) в [`ContainerOwnerHistoryDto`](../dto/catalog/containerownerhistory/ContainerOwnerHistoryDto.md) поле `orderClient` («Клиент заявки», клиент заявки) **заменено** на `newClient` («Новый владелец КТК», `history.newClient`). Из фильтра удалён `orderClient` (поиск по коду клиента заявки); meta по `newClient` отдаёт значения `newClient.code`. Для клиентов API это несовместимое изменение контракта.

## Передача владельца во внешние системы

Куда и в каком виде `ownerContainerId` уходит в исходящих пакетах Datareon (по сценариям поставки/вывоза, включая закрытый KIS-4830 дефект на вывозе) — сведено отдельно, как справка для аналитика 1С: [container-owner-outbound-contract.md](../integrations/container-owner-outbound-contract.md).

## Открытые вопросы

1. Осознанность DEPARTED-заглушки при отмене принятой поставки (см. раздел про восстановление владельца) — нужен ответ разработчика/продукта, не source-level вопрос.
2. Судьба «временного» имени `owner_container_id_new` и планов по унификации типа `ownerRailwayCarriage` на `ShippingOrderContainer` с `Client` (`ownerContainer` переведён KIS-4830).
3. `order-errors.md` требует разделения строки `MissingOwnerContainer` на поставку/вывоз отдельно от этой сверки.
4. Тесты в этом периоде (`ContainerStatusServiceIntegrationTest`) не прогонялись в рамках этой сверки; поведение на реальной БД (constraint `chk_container_owner_status`, параллельные accept двух заявок на один КТК через `findAndLock`) не проверено сверх чтения source.
5. ~~`ownerContainerId` в outbound route chain package для вывоза с 22.09.2026 всегда `null`~~ — **закрыто KIS-4830** (`401bbea3`, 08.10.2026). Новые вопросы: (а) нужно ли дозаполнить `owner_container_id` у строк вывоза, созданных 22.09–08.10.2026; (б) должен ли снимок владельца в строке вывоза обновляться при смене владельца в registry до отгрузки.
6. После KIS-4830 отмена первой поставки КТК оставляет в registry строку `DEPARTED` с владельцем из отменённой заявки (раньше строка удалялась). Подтвердить, что это ожидаемо: такой КТК в справочнике выглядит «выбывшим» с владельцем, хотя на терминал фактически не поступал.
7. История владельцев в UI скрывает переходы `EXPECTED`/`RESERVED_OUT` и записи невыполненных заявок — подтвердить, что аналитикам и пользователям не нужна полная история (в БД она есть).
8. `ShippingOrderContainerMergeDto.ShippingOrderContainerDto.ownerContainer` по-прежнему помечен `@NotNull`, хотя сервер значение игнорирует: клиент `PUT /merge` обязан прислать владельца, который ни на что не влияет. Уточнить у разработчиков, нужно ли снять ограничение.
