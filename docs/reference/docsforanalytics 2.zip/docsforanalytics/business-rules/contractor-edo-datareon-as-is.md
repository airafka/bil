# Контрагенты ЭДО и Datareon: AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026): `POST /datareon/contractor` от [ContractorEdoDatareonDto](../dto/catalog/datareon/ContractorEdoDatareonDto.md) до [Client](../entities/catalog/entities/client/Client.md), повторную обработку, транзакцию, исходящий эффект, ошибки, пользовательские endpoints и тестовую доказательность. Бизнес-код, runtime-конфигурация и миграции не изменялись; работающие ALIS/Datareon, production payload и применённая схема БД не проверялись.

## Терминология и HTTP-контракт

Внешний `contractor` не сохраняется в отдельную сущность Contractor. В текущей модели он преобразуется в ALIS `Client`. Исторически поток создавал старые `client` и `legal_entity`; после объединения Java-моделей и DB-переименования актуальная physical таблица — `client`, бывшая `legal_entity`.

| Метод и путь | Request | Response | Доступ AS-IS |
|---|---|---|---|
| `POST /datareon/contractor` | [ContractorEdoDatareonDto](../dto/catalog/datareon/ContractorEdoDatareonDto.md), обязательный body с `@Valid` | `200` без тела только при успешном завершении | `/datareon/**` разрешён security-конфигурацией без аутентификации |

Endpoint находится в [DatareonController](../api/endpoints-generated.md#datareoncontroller). Сначала выполняется best-effort мониторинг по входному `_id`, затем вызывается [ContractorEdoDatareonService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/ContractorEdoDatareonService.java). Ошибка мониторинга логируется и не отменяет предметную обработку; `_id` не становится idempotency key мониторинга или БД.

## Входной DTO и фактическая обязательность

На внешнем DTO есть только четыре `@NotNull`. Они запрещают отсутствующее поле/JSON `null`, но разрешают `""` и строки из пробелов. Ограничения [ClientCreationDto](../dto/catalog/client/ClientCreationDto.md) и [ClientUpdateDto](../dto/catalog/client/ClientUpdateDto.md) не применяются: эти DTO создаются внутри сервиса и не проходят через `@Valid` controller method или method validation.

| JSON | Внешняя проверка | Create в Client | Existing Client / update AS-IS |
|---|---|---|---|
| `_id` | `@NotNull` | `edoId`; также ключ lookup | Lookup без учёта регистра, но в update DTO не переносится |
| `name` | `@NotNull` | `code` | В update DTO не переносится; `code` становится `null` |
| `fullName` | нет | `name` | Полностью заменяет `name` |
| `INN` | `@NotNull` | `inn` | Полностью заменяет `inn` |
| `KPP` | `@NotNull` | `kpp` | Полностью заменяет `kpp` |
| `OKPO` | нет | `okpo` | Полностью заменяет, включая `null` |
| `OGRN` | нет | `ogrn` | Полностью заменяет, включая `null` |
| `addressLegal` | нет | `addressLegal` | Не переносится; update model содержит `null` |
| `addressFact` | нет | `addressFact` | Полностью заменяет, включая `null` |
| `signatoryName` | нет | `signatoryName` | Не переносится; update model содержит `null` |
| `signatoryPosition` | нет | `signatoryPosition` | Не переносится; update model содержит `null` |
| `isClient` | нет | Игнорируется | Игнорируется |

При create сервер дополнительно задаёт `active=true`; `ClientService` генерирует UUID entity и, поскольку входной `syncId` отсутствует, задаёт `syncId = Client.id`. `email` и `phoneNumber` входной контракт не содержит.

Фактически для успешного create также нужны `fullName != null`, `name` длиной не более 100, `_id` длиной не более 46 и значения, помещающиеся в physical колонки. Blank-строки и нецифровые ИНН/КПП проходят внешний DTO; regex из `ClientCreationDto` здесь не исполняется.

## Lookup и серверный алгоритм

```mermaid
flowchart TD
    A[POST /datareon/contractor] --> V[Bean Validation внешнего DTO]
    V -->|null в _id/name/INN/KPP| E400[HTTP 400]
    V --> M[Best-effort monitor по _id]
    M --> F[ClientFilter: edoId<br/>EXACTLY_MATCHES_IGNORE_CASE]
    F --> Q[findFirst, без lock]
    Q -->|не найден| C[Собрать ClientCreationDto]
    C --> CTX[ClientService.add transaction]
    CTX --> G[UUID id; syncId=id; active=true]
    G --> INS[INSERT Client + OutboundData]
    INS --> OK[HTTP 200 без тела]
    Q -->|найден| U[Собрать неполный ClientUpdateDto]
    U --> UTX[ClientService.update transaction]
    UTX --> COPY[Перенести все Client fields;<br/>code/edoId/legal/signatory/email/phone = null]
    COPY --> DBERR[Physical code NOT NULL → rollback]
    DBERR --> E500[HTTP 500]
```

Lookup использует точное совпадение `edoId` без учёта регистра. В Liquibase нет unique для `edo_id`; при дублях `findFirst` выбирает одну строку без явно заданной сортировки. Если `_id` пустой или состоит из пробелов, `SearchString.isNotBlank` исключает условие `edoId` из predicate: при непустой таблице выбирается первый произвольный Client, при пустой — выполняется create с blank `edoId`.

Поиск выполняется в отдельной read-only транзакции, а `ClientService.add/update` — в следующей транзакции. Между lookup и insert нет lock или DB uniqueness по `edo_id`.

## Критический дефект update на текущем commit

С `ef2ea5afa102aa2b77f3f7cfc50a4181becadf05` create и update используют разные mappings. `mapToClientUpdateDto` не задаёт `code`, `edoId`, `addressLegal`, `signatoryName`, `signatoryPosition`, `email` и `phoneNumber`. Это не patch-семантика: [ClientService.prepareModelToUpdate](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/client/ClientService.java) явно копирует каждое из этих полей из update model в existing entity, включая `null`.

В актуальной Liquibase-цепочке `client.code` имеет `NOT NULL`. Поэтому обычный повтор уже существующего `_id` приводит к попытке записать `code=null`, откату транзакции и HTTP `500`, а не к успешному обновлению. Изменения `fullName`, реквизитов и адреса также откатываются.

Если применённая схема отличается и допускает null code, такой update очистил бы сам `edoId` и перечисленные optional-поля. Тогда следующий такой же `_id` перестал бы находить строку и пошёл бы в create. Это условный риск расхождения live schema, а не утверждение о штатной Liquibase-схеме.

`ClientUpdateDto` наследует `@NotBlank code/name/addressFact/inn/kpp/addressLegal` и regex реквизитов, но внутренний вызов `clientService.update(updateDto)` эту Bean Validation не запускает. Наличие аннотаций не предотвращает описанный DB rollback.

## Create, уникальность и повторы

| Ситуация | Результат AS-IS |
|---|---|
| Первый валидный `_id` | Создаётся Client; `edoId=_id`, `code=name`, `name=fullName`, `syncId=id`, `active=true`. |
| Точный повтор существующего `_id` | На текущей physical схеме update откатывается из-за `code=null`; HTTP `500`. |
| Тот же `_id` в другом регистре | Та же update-ветка и тот же rollback. |
| Новый `_id`, уже существующая пара INN/KPP | Partial unique index БД не допускает create; duplicate обычно преобразуется в `409`. |
| Новый `_id` и новая пара INN/KPP | Создаётся новый Client, даже если code/name совпадают. |
| Два параллельных запроса одного нового `_id` | Оба могут не найти строку; unique по `edo_id` нет. Одинаковая INN/KPP обычно остановит один insert, разная может создать два Client. |
| Несколько уже существующих строк с одним `edoId` | Обновляется выбранный `findFirst`; выбор не детерминирован явной сортировкой. |

При update `ClientService` проверяет новую пару INN/KPP только если INN/KPP меняются и новый INN не null. Проверка считает все строки с новой парой и не имеет параметра исключения текущего ID. DB partial unique index остаётся окончательной защитой. При create прикладная `checkInnKppUniqueness` не вызывается.

Delete/deactivate логики в этом endpoint нет: `active` всегда устанавливается в `true`, а `isClient=false` игнорируется.

## Транзакция и исходящий эффект

Create одного Client и создание связанных строк `OutboundData` выполняются внутри одной транзакции `ClientService.add`. Миграция включает active `OutboundConfig` для `EntityType.CLIENT + MessageType.CONTRACTOR`, поэтому успешный inbound create ставит этого же Client в исходящую очередь.

```mermaid
flowchart LR
    IN[POST /datareon/contractor<br/>_id = внешний EDO id] --> CL[(Client<br/>edoId = внешний id<br/>syncId = ALIS id)]
    CL --> OD[(OutboundData<br/>CONTRACTOR)]
    OD --> SCH[ScheduledContractorExportService]
    SCH --> OUT[POST Datareon /contractor<br/>_id = Client.syncId]
```

[ContractorExportService](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/contractor/ContractorExportService.java) для Client строит исходный payload только из `_id=syncId`, `name=code`, `fullName=name`, `isClient=true`; ИНН/КПП/адреса/подписант не включаются. `_id` исходящего сообщения отличается по смыслу от входного: это сгенерированный UUID ALIS, а не сохранённый `edoId` 1С. Поведение внешнего получателя и возможность обратного эха репозиторием не подтверждены.

Планировщик отправляет сообщения на `${datareon.base.url}/contractor` с Basic Auth, группирует строки одного root/message, использует `SKIP LOCKED`, до пяти попыток с интервалом и считает успехом только response body, разбираемый как UUID. Этот outbound lifecycle приведён как непосредственный side effect создания, а не как часть входного HTTP-ответа.

## Physical Client

Текущая таблица `client` образована переименованием бывшей `legal_entity`, а старая таблица `client` была удалена. По Liquibase chain значимы:

- `id UUID PRIMARY KEY`, `code VARCHAR(100) NOT NULL`, `name VARCHAR(255) NOT NULL`, `active BOOLEAN NOT NULL`;
- `sync_id UUID NOT NULL`, но отдельный unique в просмотренной цепочке не найден;
- `inn VARCHAR(12)`, `kpp VARCHAR(9)`, `okpo VARCHAR(10)`, `ogrn VARCHAR(15)` nullable;
- `edo_id VARCHAR(46)`, `address_legal/address_fact VARCHAR(1000)`, `signatory_name/signatory_position VARCHAR(50)`, `email VARCHAR(150)`, `phone_number VARCHAR(50)` nullable;
- partial unique index `(inn, kpp) WHERE inn IS NOT NULL`; unique/check для `edo_id`, code, syncId и форматов реквизитов в просмотренных миграциях нет;
- `created_at/created_by NOT NULL`, update audit nullable.

JPA-аннотация inherited `BaseIdCode.code` содержит `unique=true`, но Liquibase текущей renamed table такого unique не задаёт. Для physical AS-IS документ опирается на цепочку миграций, а не на schema-generation предположение.

Источники: [исходная legal_entity](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_ALG-45_add_table_legal_entity.sql), [unique INN/KPP](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240702_ALG-234_add_legal_entity_inn_kpp_unique_index.sql), [syncId NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240822_ALG-784_make_sync_id_columns_not_null.sql), [объединение связей](../../../db-layer/src/main/resources/db/changelog/v.1.24.0/v1.24.0_KIS-1397_add-field-tables-legal_entity_id.sql), [rename в client](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250918_KIS-1623_RemoveClientTable_RenameLegalEntityTable.sql), [OGRN до 15](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260605_KIS-3994_add_client_requisites_constraints.sql).

## Пользовательские endpoints Client

Соседний [ClientController](../api/endpoints-generated.md#clientcontroller) предоставляет `/client/all`, `/page`, `/meta/{fieldName}`, `GET /{id}`, create, update и `/synchronize`; DTO/валидация и серверный CRUD подробно связаны в [API клиентов и договоров](../api/client-contract-api.md#1-клиенты-client).

Это другой validation boundary: HTTP `POST /client/` и `PUT /client/{id}` запускают ограничения Client DTO, тогда как Datareon handler валидирует только Contractor DTO. Page/get/create/update защищены `CLIENT` permissions согласно controller; `/client/all` и `/client/synchronize` не имеют method-level `@Secure`, но глобальная security требует аутентификацию для путей вне `/datareon/**`.

`POST /client/synchronize` — отдельный WMS import по `syncId`; он не ищет `edoId`, не обновляет существующие строки и не заменяет Datareon contractor flow.

## Ошибки и расхождения документов

| Условие | Внешний результат AS-IS |
|---|---|
| Нет body / невалидный JSON / null в `_id`, `name`, `INN`, `KPP` | HTTP `400`. |
| Blank обязательное внешнее поле | DTO пропускает; дальнейший результат зависит от empty lookup и DB. |
| Create без `fullName`, слишком длинные значения, DB NOT NULL/length | HTTP `500` для non-duplicate integrity/runtime ошибки. |
| Duplicate INN/KPP | HTTP `409` по текущему `ExceptionAdvice`. |
| Повтор существующего `_id` | Update rollback из-за `code=null`, HTTP `500`. |
| ~~Ошибка мониторинга~~ | **Удалено** (коммит `a5a40f94` «remove datareon monitoring», 17 сентября 2026): `MonitorClient.logInboundPacket` на `DatareonController` и вся инфраструктура мониторинга (`IncidentDto`/`IncidentType`/`IncidentSeverity`, feature flag `datareonMonitoringEnabled`) удалены без замены; строка описывала поведение до этой даты. |

OpenAPI заявляет `406 Unique violation problems`, но актуальный [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) возвращает `409` для duplicate и `500` для прочих integrity errors.

Входной материал [«Интеграция договоров и контрагентов из 1С:ДО»](../../integrations/1c-edo-contract-with-contractor-api.md) правильно связывает `contractor` с Client и отмечает ignored `isClient`, но его вывод об успешном update и фактическом применении Client DTO regex/`@NotBlank` не соответствует текущему вызову. Для backend AS-IS этого endpoint источником является данный документ; предложенный `/datareon/contract-with-client` остаётся TO-BE и в коде отсутствует.

## Влияющие commits

| Commit | Влияние на текущий AS-IS |
|---|---|
| `b67b2971707c0a1d8e296b8b50071776376722ac` (10.09.2024) | Добавил Datareon contractor DTO/controller/service и `edoId`. |
| `5de66acd108609c94e123e3e2639a2ee025f613c` (16.09.2024) | Перевёл lookup на case-insensitive `findFirst` и создание/обновление через web services. |
| `4212247da70d3ca69e7b3acd6a51f4a7f2bd68ef` (`KIS-1397`, 30.07.2025) | Объединил Java Client и LegalEntity; contractor перестал создавать две сущности. |
| `a90b9076f153c8f9021b30e264bae782850505f1` (`KIS-1623`, 29.09.2025) | Удалил старую physical client и переименовал legal_entity в client со связями. |
| `ef2ea5afa102aa2b77f3f7cfc50a4181becadf05` (`KIS-3994`, 04.06.2026) | Разделил create/update mappings; текущий update mapping перестал задавать code/edoId/legal/signatory fields. |
| `22433aa6a97a944b2430122bbd79938ad8f73f3e` (`KIS-3994`, 11.06.2026) | Усилил Client HTTP DTO `@NotBlank`/regex; Datareon внутренний mapping эту validation не запускает. |
| `d3e370db11453f73e21ebead0eabcb89b9dd584a` / `5b45baf1941eff3349f5203c0c4c4b67681e50f8` (03–11.09.2025) | Добавили и адаптировали best-effort мониторинг Datareon. |
| `84204c4bb53ca9567beccfccee3797cee8559d2d` (15.07.2026) | Удалил неэффективную class-level method validation; фактический Contractor DTO controller validation сохранился. |

## Тестовая доказательность и границы

Прямых unit/integration тестов `ContractorEdoDatareonService`, `POST /datareon/contractor`, его create/update mappings, повторов, outbound echo и DB edge cases поиском не найдено. `ClientDaoServiceTest` проверяет лишь общий add/find/page/update DAO и не использует `edoId`/реквизиты/Datareon. Соседний `ContractEdoDatareonServiceTest` относится к договору, не контрагенту. Тесты не запускались.

Не подтверждены production payload, правила отбора 1С:ДО, gateway/auth вне source security, external retry/order, поведение Datareon `/contractor`, runtime outbound config и live schema. Для нового ТЗ необходимо явно определить create/update/patch semantics, валидацию реквизитов, уникальный внешний ID, ответ, идемпотентность, конкурентность и запрет/допустимость обратного outbound после inbound.

Зависимый следующий шаг загрузки договора через отдельный `POST /datareon/contract`, включая lookup этого Client по `edoId`, описан в [Договоры ЭДО и Datareon](contract-edo-datareon-as-is.md).
