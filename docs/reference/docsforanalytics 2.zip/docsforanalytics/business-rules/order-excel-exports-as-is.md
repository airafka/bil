# Корневые Excel-выгрузки заявок V1/V2 AS-IS

Документ фиксирует четыре выгрузки реестра заявок на commit `22fac945e8116d04972ccc87b06b2303acf7a561`: V1 без пользовательского фильтра и V2 с optional filter body. Дочерние выгрузки грузов, КТК, товаров, услуг, накладных и вагонов сюда не входят.

Базовые правила агрегатов описаны в документах [поставки](receiving-orders.md), [вывоза](shipping-orders.md) и [валидации заявок](order-validation.md). Декларативные mappings также доступны в [generated endpoint-каталоге](../api/endpoints-generated.md#reportcontroller) и его секции [ReportControllerV2](../api/endpoints-generated.md#reportcontrollerv2).

## HTTP-контур

| Версия | Endpoint | Request body | Permission | Report type / результат |
|---|---|---|---|---|
| V1 | `POST /report/receiving-order/download` | Нет | `RECEIVING_ORDER_REPORT:READ` | `RECEIVING_ORDER_EXPORT` / `receiving_order.xlsx` |
| V1 | `POST /report/shipping-order/download` | Нет | `SHIPPING_ORDER_REPORT:READ` | `SHIPPING_ORDER_EXPORT` / `shipping_order.xlsx` |
| V2 | `POST /v2/report/receiving-order/download` | Optional [`ReceivingOrderFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingorder/ReceivingOrderFilter.java) | `RECEIVING_ORDER:READ` | `RECEIVING_ORDER_EXPORT` / `receiving_order.xlsx` |
| V2 | `POST /v2/report/shipping-order/download` | Optional [`ShippingOrderFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingorder/ShippingOrderFilter.java) | `SHIPPING_ORDER:READ` | `SHIPPING_ORDER_EXPORT` / `shipping_order.xlsx` |

Точные пути V2 начинаются с `/v2/report`; вариант `/report/v2/...` в текущем контроллере отсутствует. Все четыре метода возвращают `StreamingResponseBody` с declared `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`. V1 наследует class-level `consumes = application/json`, хотя body у его двух методов нет. У V2 `consumes` не задан.

Имена файлов заданы в [`PageReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java), но контроллеры не устанавливают `Content-Disposition`. Поэтому эти имена используются генератором в диагностике, но не гарантированы как имя скачанного HTTP-файла.

V1 OpenAPI перечисляет `200` и `400 Validation problems`, не задавая response schema. У V2 явных `@ApiResponse` нет. Ни одна версия не возвращает JSON DTO при успехе: контрактом является XLSX-поток.

```mermaid
flowchart LR
    V1[ReportController V1<br/>без body] --> RS[ReportService]
    V2[ReportControllerV2<br/>optional filter] --> RS2[ReportServiceV2]
    RS --> C[OrderReportDataCollectorService<br/>strategy by PageReportType]
    RS2 --> C
    C --> RC[ReceivingOrder export collector]
    C --> SC[ShippingOrder export collector]
    RC --> J[JxlsReportGenerator]
    SC --> J
    J --> X[XLSX HTTP stream]
```

## Главное различие V1 и V2

V1 всегда создаёт серверный filter и не принимает условия от клиента. V2 передаёт optional request body в тот же collector через `getReportDataWithFilter`.

| Поведение | V1 | V2 |
|---|---|---|
| Условия клиента | Не принимаются | Принимается корневой order filter |
| Pagination из запроса | Нет | Нет: body — filter, а не `FilterWithPaging` |
| Фактический page size | `Integer.MAX_VALUE` | `Integer.MAX_VALUE` |
| Receiving sort | DAO numeric `number DESC` | После mapping принудительно String `number DESC` |
| Shipping sort | После mapping `number DESC` | После mapping `number DESC` |
| Право | Специальное report permission | Обычное root-order read permission |
| Client restriction | Filter всегда non-null | Зависит от того, передан ли хотя бы `{}` |

V2 не является надмножеством V1 по security: она проверяет другое право. Пользователь может иметь обычное чтение заявок, но не report permission, либо наоборот; доступность версий тогда различается.

## Фильтры V2

Body передаётся непосредственно как `ReceivingOrderFilter` или `ShippingOrderFilter`. Полей `page`, `size` и wrapper `filter` в этом контракте нет. Оба класса наследуют технические поля `id`, `anyOfId`, created/updated audit filters и sorting fields из WMS base filters.

### Поставка

Собственные поля `ReceivingOrderFilter`:

| Поле | Назначение AS-IS |
|---|---|
| `client`, `contract` | Вложенные фильтры клиента и договора |
| `orderStatus` | Enum-search по статусу |
| `number`, `totalCargoQuantity` | Числовой поиск |
| `terminalArea` | Вложенный фильтр площадки |
| `transportType` | Фактически exact `TransportType.valueOf(content)` |
| `clientDriver`, `vehicleBrand`, `clientVehicle` | Вложенные фильтры транспорта |
| `planDateTime` | Фильтр по `planReceivingDateTime`; alias JSON — `planReceivingDateTime` |
| `comment`, `documentConfirmed` | Фильтры комментария и подтверждения документов |
| `search` | Общий поиск по номеру, клиенту, плановой дате, площадке, транспорту, созданию, комментарию, статусу, подтверждению документов и номеру рейса |
| `route`, `ktkNumberUnknown` | Рейс и признак неизвестного номера КТК |
| `includeRejectedRouteId` | Добавляет к status-условию OR-ветку `route.id = value AND orderStatus = REJECTED` |
| `planReceivingDate`, `planReceivingTime` | Используются как custom sorting columns, но не добавляют predicate-условие |

### Вывоз

`ShippingOrderFilter` имеет аналогичные `client`, status, terminal, transport, contract, driver/vehicle, `number`, `comment`, `search`, `route`, `ktkNumberUnknown` и `includeRejectedRouteId`. Отличия:

- `planDateTime` фильтрует `plannedShippingDateTime`; JSON alias — `plannedShippingDateTime`;
- `fillingType` ограничивает результат набором `ShippingOrderFillingType`;
- общий поиск не включает `documentConfirmed`, но включает номер, клиента, плановое время, площадку, транспорт, дату создания, рейс, комментарий и статус;
- `planShippingDate` и `planShippingTime` используются как custom sorting columns, но не как predicate;
- `comment.byOr=true` добавляет comment condition в OR-часть составного predicate, тогда как receiving comment всегда добавляется через AND.

`transportType` в обоих predicates не использует заявленный оператор `SearchString`: сервер берёт только `content` и вызывает `TransportType.valueOf`. Значение должно точно совпасть с Java enum name; иначе ожидаемо `IllegalArgumentException` и `500`, а `type`/`byOr` этого поля не влияют на сравнение.

Для `planDateTime` значение `BETWEEN` с одинаковыми `start` и `end` превращается в полуинтервал одних суток `[start, start + 1 day)`. Shipping дополнительно поддерживает односторонний BETWEEN; receiving для остальных вариантов делегирует поведение базовому `SearchDate`.

На полях этих двух filter-классов нет собственных Bean Validation constraints, а вложенные filters не помечены `@Valid`. Поэтому controller-level `@Valid` не задаёт обязательных бизнес-полей. Некорректный JSON или enum может завершиться `400` на deserialization, но семантические ошибки predicate могут возникнуть позднее.

## Client scope: `null` и `{}` не эквивалентны

[`BaseService.getAllEntities`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) перед чтением вызывает [`FilterEnrichServiceImpl.addUserRestriction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java). Оба order filters реализуют `ClientRestrictionFilter`, но обогащение выполняется только для non-null объекта.

```mermaid
flowchart TD
    A[POST V2 download] --> B{Body передан?}
    B -- нет --> N[filter = null]
    B -- пустой объект --> E[Создан order filter<br/>client = new ClientFilter]
    B -- условия --> F[Создан order filter с условиями]
    N --> NR[addUserRestriction ничего не делает]
    E --> R{Пользователь admin?}
    F --> R
    R -- да --> AR[Client restriction не добавляется]
    R -- нет, userId есть --> IR[Пересечение client IDs<br/>с разрешёнными]
    R -- нет, userId отсутствует --> WR[Warning и restriction не добавляется]
    NR --> ALL[Predicate без client scope]
    AR --> Q[Запрос]
    IR --> Q
    WR --> Q
    ALL --> Q
```

Следствия текущего кода:

- V1 всегда создаёт non-null filter, поэтому для не-администратора с user ID client restriction применяется;
- V2 без body получает `null`: enrichment пропускается, а `PredicateBuilder.validateAndPreparePredicate(null)` создаёт пустой predicate — выбираются все заявки, доступные запросу без client-условия;
- V2 с body `{}` создаёт filter с default `ClientFilter`, поэтому client restriction применяется;
- V2 с явным `"client": null` для non-admin доходит до `enrichFilter(null, ...)` и способен завершиться `NullPointerException`/`500`;
- explicit client IDs пересекаются с разрешёнными; пустой набор разрешений принудительно превращается в условие с случайным UUID, чтобы вернуть пустой результат;
- для администратора client restriction намеренно не добавляется; при отсутствующем user ID сервис пишет warning и также не ограничивает выборку.

Различие между отсутствующим body и `{}` является подтверждённым source-level security gap. Фактические runtime-роли и reverse-proxy ограничения не проверялись.

## Сбор данных, объём и транзакция

[`BaseReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) собирает данные в транзакции `REPEATABLE_READ`. V1 использует `collectReportData(id=null)`, V2 — `collectReportDataWithFilter(filter)`. Default `checkCanExport` возвращает available; у этих двух collectors нет дополнительных eligibility-проверок по статусу, площадке или заполненности заявки.

Обе реализации создают `PageInfo(page=0, size=Integer.MAX_VALUE)`. [`BaseDaoService.getPage`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseDaoService.java) выполняет data query и отдельный count query. Затем весь список entities преобразуется через `parallelStream` в DTO, а XLSX формируется после возврата из collector transaction.

```mermaid
flowchart TD
    A[Filter V1/V2] --> R[Добавить client restriction<br/>если filter non-null]
    R --> P[Page 0, size Integer.MAX_VALUE]
    P --> D[Query данных + count query]
    D --> L[Полный List entities в памяти]
    L --> M[parallelStream mapping в report DTO]
    M --> S[Сортировка number DESC]
    S --> T[Завершение REPEATABLE_READ transaction]
    T --> J[JXLS fill template]
    J --> O[Запись XLSX в HTTP output stream]
```

Клиент не может уменьшить или увеличить страницу: collector всегда выгружает весь отфильтрованный набор. `sheetStreaming="true"` в шаблонах относится к записи листа JXLS, но entities и DTO к этому моменту уже полностью загружены в память. Поэтому большие выборки создают риск длительного запроса и расхода памяти; server-side max rows отсутствует.

Mapping выполняется parallel stream внутри транзакционного метода. Это создаёт технический риск работы JPA entities/lazy associations из потоков common pool, тогда как persistence context привязан к исходному потоку; наличие фактического сбоя зависит от загрузки связей и runtime и не подтверждено тестом.

## Выходные строки и шаблоны

Оба направления используют [`ExcelReportDtoMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/client/ExcelReportDtoMapper.java).

### Поставка

Шаблон [`receiving_order.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order.xlsx) получает параметр `receivingOrders` и повторяет область `A1:I2`. Каждая строка — [`ReceivingOrderReportDto`](../dto/catalog/receivingorder/ReceivingOrderReportDto.md):

| Колонка | Источник / преобразование |
|---|---|
| Номер | `ReceivingOrder.number` → String |
| Клиент | `client.code` |
| Статус | `orderStatus.translation` |
| Площадка | `terminalArea.name` |
| Транспорт | Форматированное имя типа транспорта |
| Дата исполнения | Дата `planReceivingDateTime` |
| Время исполнения | Время в JVM system zone; заголовок шаблона указывает МСК |
| Дата создания | Дата `createdAt` |
| Статус документов | Условное вычисление ниже |

Статус документов вычисляется только для `transportType = VEHICLE` и площадки, чей code не равен `WAREHOUSE`: `true` → `Подтверждены`, `false` → `Не подтверждены`, `null` → `Не обработаны`. Для остальных заявок выводится `-`. `terminalArea` разыменовывается и её code преобразуется через `TerminalAreaEnum.valueOf`; null или неизвестный code способен прервать mapping с `500`.

### Вывоз

Шаблон [`shipping_order.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order.xlsx) получает `shippingOrders`, область `A1:I2`, и использует восемь полей [`ShippingOrderReportDto`](../dto/catalog/shippingorder/ShippingOrderReportDto.md): номер, `client.code`, перевод статуса, плановые дата/время, имя площадки, форматированный тип транспорта и дату создания.

Во всех четырёх выгрузках итоговый порядок заявлен кодом как номер по убыванию. V2 игнорирует переданную сортировку в финальном workbook, потому что после DAO выполняется новая сортировка DTO. Для V1 receiving и обеих shipping-веток это числовая сортировка. У V2 receiving поле DTO имеет тип String, поэтому comparator лексикографический: например, `"99"` будет выше `"100"`. Это фактическое отличие от V1.

## Ошибки и streaming

| Случай | AS-IS до начала передачи response |
|---|---|
| Нет controller permission | Ожидаемо `403` |
| Malformed JSON / неизвестный enum при deserialization V2 | `HttpMessageNotReadableException` → `400` |
| Некорректный `transportType.content`, null/unknown terminal, mapping failure | Catch-all → `500` |
| Ошибка чтения шаблона, expression или записи XLSX | `JxlsReportProcessingException` → catch-all `500` |
| Ошибка после начала `StreamingResponseBody` | Возможны частичный XLSX и уже зафиксированный status; JSON `ApiErrorDto` не гарантирован |

Текущий [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) имеет явный `400` для unreadable body/validation, но не имеет отдельного handler для локального `JxlsReportProcessingException`; он попадает в общий `Exception` → `500`. Отдельный handler импортирован для одноимённого WMS Jasper exception, а не для JXLS exception этого модуля.

JXLS настроен с exception thrower и ограничением JEXL packages `ru.korusconsulting.alis.*`/`ru.korusconsulting.wms.*`. Ошибка шаблона не подавляется, а оборачивается с result filename.

## Тестовое покрытие

В `web-layer/src/test` и `web-layer/src/integrationTest` не найдены прямые тесты четырёх controller mappings, двух root export collectors, `RECEIVING_ORDER_EXPORT`/`SHIPPING_ORDER_EXPORT` или содержимого этих XLSX. [`ReportServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/report/ReportServiceIntegrationTest.java) вызывает V1 `getExcelReport` для других page reports, но не для двух корневых типов.

Отдельный [`FilterEnrichServiceImplIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/FilterEnrichServiceImplIntegrationTest.java) проверяет общую механику client restrictions, но не различие `null`/`{}` через V2 report endpoint.

Не покрыты автоматически:

- V1/V2 permissions и различие их permission namespaces;
- V2 body absent против `{}` и client-scope leak;
- все filter fields, aliases, rejected-route OR и ignored date/time filter fields;
- принудительная сортировка, unbounded row count и большой набор данных;
- XLSX headers/values, document status, timezone и unknown terminal code;
- content type, `Content-Disposition`, controller status и сбой после начала stream.

Тесты при документировании не запускались.

## История изменений

| Commit | Влияние на текущий AS-IS |
|---|---|
| `7e50a680` (2025-08-13, KIS-47) | Добавил V1 endpoints, root collectors, DTO/template wiring и исходные XLSX-выгрузки |
| `576e8787` / `bd4ec3d3` (2025-08-18, KIS-47) | Доработали export permissions и реализацию выгрузок |
| `905ef6e4` (2025-09-08, KIS-1336) | Добавил `ReportControllerV2`, optional filters и обычные order read permissions |
| `969e2059` (2025-09-11, KIS-1673) | Исправил ошибки Excel-выгрузок и шаблоны |
| `14d6f159` / `d2c385b6` (2025-12-01/11, KIS-1966) | Исправил report errors, включая JXLS/template path |
| `3256b8f0` (2026-06-18) | Перевёл collectors на новый `PageInfo`, сохранив unbounded page 0 |
| `84204c4b` (2026-07-15) | Удалил неиспользуемые controller validation/logging annotations; endpoint contracts сохранились |

Поздние изменения самих order filters автоматически влияют на V2 export, потому что отдельного export filter нет. В частности, `9791c676` (2026-05-19, KIS-3873) добавил `includeRejectedRouteId`, а August 2026 commits расширили meta/search-состав order filters. Это coupling следует учитывать при изменении list API: новое filter field может без отдельной правки отчёта стать доступно выгрузке.

## Чек-лист для ТЗ

Для изменения корневой Excel-выгрузки следует явно зафиксировать:

1. точную версию endpoint и request body, включая различие отсутствующего body и `{}`;
2. report permission или root-order permission;
3. обязательный client scope для admin/non-admin и пользователя без ID;
4. supported filter fields, aliases, операторы и semantics OR;
5. максимальное число строк, pagination/async generation и timeout;
6. итоговую сортировку независимо от list-screen sorting;
7. поля, timezone, локаль и преобразования report DTO;
8. `Content-Type`, `Content-Disposition` и имя файла;
9. формат ошибки до и после начала stream;
10. контрольные HTTP, RLS, filter и XLSX content tests.
