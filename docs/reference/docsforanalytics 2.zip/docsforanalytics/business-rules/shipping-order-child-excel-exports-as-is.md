# Дочерние Excel-выгрузки отгрузки, часть 1 AS-IS

Проверено относительно commit `22fac945e8116d04972ccc87b06b2303acf7a561`: восемь V1/V2 методов для blackbox, cargo, КТК и содержимого КТК. Это описание реализованного исходниками поведения, не контракт работающего стенда. Корневые выгрузки описаны [отдельно](order-excel-exports-as-is.md); декларативный список методов — [ReportController](../api/endpoints-generated.md#reportcontroller) и [ReportControllerV2](../api/endpoints-generated.md#reportcontrollerv2).

## HTTP и связи с DTO

| Ресурс | V1 `POST /report/...` | V2 `POST /v2/report/...` | `Permission:READ` | Filter V2 / result DTO / XLSX |
|---|---|---|---|---|
| Blackbox | `/shipping-order-blackbox/{shippingOrderId}/download` | `/shipping-order-blackbox/download` | `SHIPPING_ORDER_SHIPPING_ORDER_CONTAINER` | [`ShippingOrderBlackboxFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingorderblackbox/ShippingOrderBlackboxFilter.java) / [`ShippingOrderBlackboxDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxDto.md) / [`shipping_order_blackbox.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_blackbox.xlsx) |
| Cargo | `/shipping-order-cargo/{shippingOrderId}/download` | `/shipping-order-cargo/download` | `SHIPPING_ORDER_SHIPPING_ORDER_CARGO` | [`ShippingOrderCargoFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordercargo/ShippingOrderCargoFilter.java) / [`ShippingOrderCargoDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoDto.md) / [`shipping_order_cargo.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_cargo.xlsx) |
| Container | `/shipping-order-container/{shippingOrderId}/download` | `/shipping-order-container/download` | `SHIPPING_ORDER_SHIPPING_ORDER_CONTAINER` | [`ShippingOrderContainerFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordercontainer/ShippingOrderContainerFilter.java) / [`ShippingOrderContainerDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerDto.md) / [`shipping_order_container.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_container.xlsx) |
| Container item | `/shipping-order-container-item/{shippingOrderId}/download` | `/shipping-order-container-item/download` | `SHIPPING_ORDER_SHIPPING_ORDER_CONTAINER_ITEM` | [`ShippingOrderContainerItemFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordercontainer/ShippingOrderContainerItemFilter.java) / [`ShippingOrderContainerItemDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemDto.md) / [`shipping_order_container_item.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_container_item.xlsx) |

Blackbox использует permission КТК, хотя имеет отдельные entity/filter/DTO. [V1 controller](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportController.java) требует UUID в path, body не принимает, method-level `consumes=*/*`, `produces` XLSX и декларирует OpenAPI `200`/`400` без response schema. [V2 controller](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportControllerV2.java) принимает `@Valid @RequestBody(required=false)` сам filter (не `FilterWithPaging`), не указывает explicit response schema. Оба возвращают `StreamingResponseBody`; server-side `Content-Disposition` не установлен. Имена файлов определяет [`PageReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java), но имя из enum не означает автоматически отправленный filename header.

```mermaid
flowchart LR
    P[V1 path shippingOrderId] --> R[ReportService]
    F[V2 optional child filter] --> R2[ReportServiceV2]
    R --> C[Collector registry]
    R2 --> C
    C --> B[Blackbox / Cargo / Container / Item collectors]
    B --> D[Entity list → parallel DTO mapping]
    D --> J[JXLS template → XLSX stream]
```

## Выборка, область доступа и удалённые строки

Все четыре [collectors](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderBlackboxExportReportDataCollectorService.java) имеют одинаковую развилку: V1 строит `shippingOrder=ShippingOrderFilter.byId(path UUID)` и `deleted=false`, V2 приводит nullable `BaseFilter` к своему типу, не добавляя серверного ID заявки. Аналогичные реализации: [Cargo](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderCargoExportReportDataCollectorService.java), [Container](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderContainerExportReportDataCollectorService.java), [Item](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderContainerItemExportReportDataCollectorService.java).

| Вход | Source-level результат до вычисления XLSX expressions |
|---|---|
| V1 неизвестный UUID | Нет root existence check/`404`: дочерняя выборка пуста |
| V1 UUID другого клиента | Корневой объект не загружается для ownership check; требуется только child permission |
| V2 body отсутствует | Null filter даёт predicate без ограничений: все строки данного вида, включая soft-deleted |
| V2 `{}` | Default `deleted=false`: все неудалённые строки вида, без привязки к заявке |
| V2 `{"deleted":null}` | Условие soft-delete отсутствует: удалённые и неудалённые строки |
| V2 с nested `shippingOrder` | Условие заявки применяется, но разрешённые клиентские IDs сервером не добавляются |

Четыре child filters наследуют `BaseEditableFilter`, а не реализуют `ClientRestrictionFilter`. `BaseService.getAllEntities` вызывает [FilterEnrichServiceImpl](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java), который добавляет ограничения лишь root filter типа `ClientRestrictionFilter`; вложенный `ShippingOrderFilter` не обогащается отдельно. Это source-level пробел client RLS; deployed security/gateway и фактические роли не проверены.

```mermaid
flowchart TD
    A[Request] --> V{V1 / V2}
    V -- V1 --> I[shippingOrder.id + deleted=false]
    V -- V2 --> F{Body}
    F -- absent --> N[null filter: no predicate]
    F -- object --> O[child filter: default deleted=false]
    I --> Q[BaseService + root enrichment]
    N --> Q
    O --> Q
    Q --> X{ClientRestrictionFilter?}
    X -- no for all four --> L[Client IDs не добавлены]
    L --> P[Page 0 / Integer.MAX_VALUE]
```

## Фильтры V2: конкретные условия

- Blackbox: `shippingOrder`, `cargo` с JSON alias `container`, `deleted=false`; [predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingorderblackbox/ShippingOrderBlackboxPredicate.java) объединяет собственные условия через AND.
- Cargo: `shippingOrder`, `shippingOrderGood`, `goodPackage`, `cargo`, `cargoIsNull`, `cargoNumber`, `item` (`article`), `clientGoodName` (`name`/`nomenclature`), `unitOfMeasure`, `batch`, `packageQuantity`, `totalQuantity` (`plannedQuantity`), `search`, `deleted=false`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingordercargo/ShippingOrderCargoPredicate.java) переносит `cargoNumber`, `item`, `clientGoodName`, `unitOfMeasure`, `batch`, `packageQuantity`, `totalQuantity` в общую OR-часть при `byOr`; остальные условия — AND. `search` ищет номер cargo, item/name/uom, batch, quantities; `cargoIsNull=true/false` добавляет `IS NULL`/`IS NOT NULL`.
- Container: `shippingOrder`, `container`, `shippingOrderRailwayCarriage`, `hasShippingOrderRailwayCarriage`, `anyOfStatus`, `deleted=false`, `empty`, `random`, `customsClearance`, `dangerClass`, `ownerContainer`, `weight`, `containerType`, `standardSize` (`size`), `tareWeight`, `liftingCapacity`, `sealType`, `sealNumbers`, `sealNumbersSearch`, `ktkNumberUnknown`, `dataTimeKrugloyePole`, nested-item `etsngCode`/`description`/`price`/`wightGross`/`wightNet`/`quantityPlace`, `search`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingordercontainer/ShippingOrderContainerPredicate.java) применяет основные условия через AND, для item conditions требует существования *неудалённого* item. `sealNumbers` — либо массив для PostgreSQL `array_overlaps`, либо SearchString object для `array_to_string`; одинаковые границы date `BETWEEN` расширяются до суток. Параметры `empty` и sealNumbers учитываются в root predicate; filter `isNotEmpty()` не включает `empty`, что важно при вложенном использовании.
- Container item: `shippingOrder`, nested `shippingOrderContainer`, `container`, `containerType`, `etsngCode`, `description`, `price`, `wightGross`, `wightNet`, `grossWeight`, `netWeight`, `quantityPlace`, `search`, `deleted=false`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingordercontainer/ShippingOrderContainerItemPredicate.java) поддерживает `description.byOr`; остальное AND. `grossWeight` использует вес КТК, `netWeight` — вес КТК минус tara физического контейнера, а не одноимённые `wight*` поля item. Nested `shippingOrderContainer` может задавать собственный deleted condition; он не добавляется автоматически самим item collector.

Специальная орфография `wightGross`/`wightNet` — текущий JSON/Java contract. Собственной Bean Validation обязательности в четырёх filters нет; `@Valid` на request не делает nested поля обязательными. Malformed JSON/enum/UUID ожидаемо отклоняется при десериализации, но runtime response не проверялся.

## DTO, mapper и XLSX: фактические expression

Каждый collector использует обычный API `toDto`, не отдельный report DTO: [Blackbox mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderblackbox/ShippingOrderBlackboxMapper.java), [Cargo mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercargo/ShippingOrderCargoMapper.java), [Container mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java), [Item mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerItemMapper.java). Шаблоны проанализированы как ZIP/XML, а не запущены в приложении.

| Вид | JXLS parameter / area | Заполненные поля и проверка DTO |
|---|---|---|
| Blackbox | `shippingOrderBlackboxes`; `A1:H2`, each до `D2` | Template обращается к `cargo.code`, который есть в `ShippingOrderBlackboxDto`; nested null может дать expression error. У `jx:area` стоит нетипичное `sheetStreaming="D2"`, а не boolean `true`: фактический эффект требует исполнения JXLS. |
| Cargo | `shippingOrderCargos`; `A1:L2` | `cargo.code`, `shippingOrderGood.name`, `shippingOrderGood.batch.code`, `goodPackage.code`, `packageQuantity`. Mapper заполняет `shippingOrderGood.name` из `clientGood.name`; null nested links могут сломать expression. |
| Container | `shippingOrderContainers`; area/each до `Q2` | `container.code`, `empty`, `container.liftingCapacity`, `customsClearance`, `dangerClass.code`, `random`, `shippingOrderRailwayCarriage.code`, `sealNumbers`, `sealType.code`, `container.standardSize.code`, `container.weight`, `weight`, `ownerContainer.code` и тип контейнера. С 08.10.2026 (KIS-4830) `ownerContainer.code` — код `Client` из снимка на строке заявки, а не из registry `ContainerOwner`; у строк, созданных 22.09–08.10.2026, и у строк без КТК в registry значение пустое. Expression `s.getDangerousCargo()` и `s.getRefrigerator()` обращаются к отсутствующим getters `ShippingOrderContainerDto`: непустая выборка ожидаемо завершится ошибкой JXLS. Template также не защищает все nullable nested references. |
| Container item | `shippingOrderContainerItems`; `A1:G2` | `shippingOrderContainer.code`, `etsngCode`, `description`, `price`, `wightGross`, `wightNet`, `quantityPlace`. ЕТСНГ expression содержит `s.getEtsngCode().getCode() += ' ' += s.getEtsngCode().getName()` — compound assignment вместо простой конкатенации; результат/ошибка без запуска JXLS не подтверждены. При `wightGross` стоит `!= null || != 0`, тогда как у net/places `&&`: ветка для gross не работает как обычная проверка non-null/non-zero. |

У Container report это не расхождение с creation DTO: collector передаёт именно `ShippingOrderContainerDto`, в котором getters `getDangerousCargo` и `getRefrigerator` отсутствуют. Нельзя считать объявленную area или наличие XLSX гарантией успешного HTTP `200` на непустом наборе.

```mermaid
flowchart TD
    E[Collector] --> D[ShippingOrderContainerDto list]
    D --> X[shipping_order_container.xlsx]
    X --> C{Template getter существует?}
    C -- getDangerousCargo/getRefrigerator: нет --> J[Ожидаемая JXLS ошибка]
    I[Item DTO list] --> T[container_item.xlsx]
    T --> U[ЕТСНГ compound assignment: runtime не подтверждён]
```

## Объём, ошибки, история и проверки

[BaseReportDataCollectorService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) собирает данные в `REPEATABLE_READ`; все четыре collectors задают `PageInfo(page=0,size=Integer.MAX_VALUE)`, читают страницу с count/data queries, хранят полный entity list и DTO list (`parallelStream`) перед JXLS render после возврата из collector transaction. V1 использует default сортировку по ID, V2 — sorting из filter, если задан. Нет server max rows; parallel mapping lazy associations создаёт риск внепоточного обращения к JPA. При ошибке после начала streaming частичный XLSX/HTTP status возможен; JSON error не гарантирован.

Permission denial ожидаемо `403`; malformed path/body — `400`. Ошибки mapper/JXLS, включая несовместимые getters Container, проходят по общему exception path с ожидаемым `500`; фактический HTTP не воспроизводился. Доступность ресурса и security reverse proxy не подтверждены. Source-wide test search не нашёл прямых tests восьми mappings, четырёх collectors и фактического XLSX output; тесты не запускались.

| Commit | Влияние |
|---|---|
| `7e50a680`, `576e8787` (2025-08, KIS-47) | Исходные shipping child exports |
| `4d870bdd`, `1b0c4917` (2025-08, KIS-47) | Рефакторинг и исправления шаблонов |
| `905ef6e4` (2025-09, KIS-1336) | V2 optional-filter методы |
| `969e2059` (2025-09, KIS-1673) | Изменения Excel-шаблонов |
| `14d6f159`, `d2c385b6` (2025-12, KIS-1966) | Последующие изменения отчётов |
| `de31b4fb`, `29283833` (2026-04) | Комментарий вместо имени груза; текущая ЕТСНГ expression |
| `3256b8f0` (2026-06) | PageInfo/неограниченная страница collectors |

Для ТЗ отдельно согласовать client/ownership scope V1/V2, absent body/soft-delete, фильтры и `byOr`, максимальное число строк, null-policy вложенных справочников, реальные шаблоны и их expressions, filename header и тесты восьми HTTP/permission/filter/content вариантов. Runtime-роли, production payload и фактическая генерация XLSX остаются неподтверждёнными.
