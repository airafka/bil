# Бизнес-правила ALIS

Правила организованы от общего к частному. Специализированный документ наследует базовые правила ссылкой и описывает только отличия.

Определения бизнес-объектов, владельцы, цели процессов и общий словарь формируются в [глобальном бизнес-слое](../business/README.md). Этот каталог остаётся детальным source-level описанием реализованных проверок, переходов, вычислений и эффектов. Поэтому бизнес-смысл читается сверху вниз из `business/`, а точное поведение реализации — из `business-rules/`, API, DTO и модели данных.

## Заявки

1. [Карта правил](orders.md)
2. [Типы заявок](order-types.md)
3. [Валидация и обязательность полей](order-validation.md)
4. [Статусы](order-statuses.md)
5. [Поставка](receiving-orders.md)
6. [Вывоз](shipping-orders.md)
7. [Заявка на услугу](service-orders.md)
8. [Копирование](order-copying.md)
9. [Интеграции](order-integrations.md)
10. [Каталог бизнес-ошибок](order-errors.md)
11. [Модель ошибок HTTP API: `AlisException` AS-IS](error-model-as-is.md)
12. [Завершение порожнего ЖД-вывоза без КТК](shipping-railway-empty-completion.md)
13. [Входящие действия завершения вывоза](shipping-inbound-actions.md)
14. [Входящие действия поставки](receiving-inbound-actions.md)
15. [Полный lifecycle заявки на услугу](service-order-lifecycle.md)
16. [Waybill и входящий ЭТРАН: актуальный AS-IS](waybill-etran-as-is.md)
17. [Справочники ЭТРАН: вагоны и КТК](etran-reference-imports-as-is.md)
18. [Остатки КТК и вагонов: inbound AS-IS](remain-inbound-as-is.md)
19. [Регистр остатков и владельца КТК: `ContainerOwner` AS-IS](container-remains-and-owner-as-is.md)
20. [Остатки товаров: inbound AS-IS](good-remain-inbound-as-is.md)
21. [Партии товаров и Datareon: AS-IS](batch-datareon-as-is.md)
22. [Занятость складских ячеек и Datareon: AS-IS](cell-occupancy-datareon-as-is.md)
23. [Контрагенты ЭДО и Datareon: AS-IS](contractor-edo-datareon-as-is.md)
24. [Договоры ЭДО и Datareon: AS-IS](contract-edo-datareon-as-is.md)
25. [Company и Currency для договоров: AS-IS справочников](company-currency-contract-prerequisites-as-is.md)
26. [Рейсы: основной lifecycle AS-IS](route-lifecycle-as-is.md)
27. [Route chain package export: 4 пакета в Datareon AS-IS](route-chain-package-export-as-is.md)
28. [Рейс: план, факт и meta по заявкам на вывоз](route-shipping-plan-fact-as-is.md)
29. [Рейсы: PDF/Excel-отчёты AS-IS](route-reports-as-is.md)
30. [PDF-отчёты заявок: availability и download AS-IS](order-pdf-reports-as-is.md)
31. [Корневые Excel-выгрузки заявок V1/V2 AS-IS](order-excel-exports-as-is.md)
32. [Дочерние Excel-выгрузки поставки, часть 1 AS-IS](receiving-order-child-excel-exports-as-is.md)
33. [Дочерние Excel-выгрузки поставки, часть 2 AS-IS](receiving-order-child-excel-exports-part2-as-is.md)
34. [Дочерние Excel-выгрузки вывоза, часть 1 AS-IS](shipping-order-child-excel-exports-as-is.md)
35. [Дочерние Excel-выгрузки вывоза, часть 2 AS-IS](shipping-order-child-excel-exports-part2-as-is.md)
36. [Права доступа к PDF и Excel-отчётам заявок AS-IS](order-report-access-as-is.md)
37. [Роли и разрешения, часть 1 AS-IS](roles-permissions-as-is.md)
38. [Группы пользователей и доступные клиенты, часть 2 AS-IS](user-groups-client-restriction-as-is.md)
39. [Настройки пользователя AS-IS](user-settings-as-is.md)
40. [Профиль пользователя и сводка прав AS-IS](user-profile-permissions-as-is.md)
41. [Реестр входящих событий Datareon: eventCode → action AS-IS](inbound-event-registry-as-is.md)
42. [UI-правила заявок: frontend AS-IS](order-ui-rules-as-is.md) — вкладки, обязательность полей в форме, кнопки по статусу и праву, реестр расхождений UI ↔ backend
43. [UI-правила рейсов: frontend AS-IS](route-ui-rules-as-is.md) — назначение заявок, отправка и отмена рейса, вкладки и права в UI
44. [UI-правила справочников: frontend AS-IS](dictionary-ui-rules-as-is.md) — клиенты и договоры, контрагенты, водители, ТС, номенклатура, КТК и вагоны в UI
45. [UI-правила администрирования: frontend AS-IS](admin-ui-rules-as-is.md) — пользователи, группы и роли в UI, расхождения прав и состава группы с backend
46. [UI-правила накладных ЭТРАН: frontend AS-IS](waybill-ui-rules-as-is.md) — реестры входящих/исходящих/архива, карточка накладной, привязка к ЖД-поставке
47. [Импорт товаров заявки из Excel (Авто СК) AS-IS](order-goods-excel-import-as-is.md) — две формы листа «Номенклатура», «Партия неизвестна», коды ошибок, лист «Контейнеры» (KIS-4841)

Внешнее формирование и преобразование ЖД-накладной до вызова ALIS вынесено в [интеграционный контур 1С ЭТРАН → Datareon → ALIS](../integrations/1c-etran-waybill-gu27-as-is.md). Названия «ГУ-27», «накладная ЭТРАН», «ЖДН» и «СМГС 2015» зафиксированы там как бизнес-синонимы одного процесса, а не как отдельные backend-сущности.

HTTP-методы, пути, request/response DTO и серверные сценарии собраны в [API заявок](../api/order-api.md). Полный технический inventory всех контроллеров доступен в [каталоге endpoints](../api/endpoints-generated.md).

Идентификаторы правил стабильны для ссылок из ТЗ: `BR-ORDER-*` — общий уровень, `BR-RO-*` — поставка, `BR-SO-*` — вывоз, `BR-SRV-*` — заявка на услугу.

## Принцип переиспользования

Новые документы не копируют общую статусную таблицу или матрицу типов. Они ссылаются на базовое правило и фиксируют специализацию, исключение либо новый вариант. Трассировка требования строится как:

```text
REQ → BR → тип заявки → DTO → Entity.field → DB column → integration → test
```

Для новой предметной области используется [шаблон правила](../templates/business-rule.md).
