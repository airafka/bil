# Дочерние Excel-выгрузки вывоза, часть 2 AS-IS

Документ проверен относительно commit `22fac945e8116d04972ccc87b06b2303acf7a561` и описывает оставшиеся восемь V1/V2 Excel methods: товары, заказанные услуги, связанные накладные ЭТРАН и вагоны. Blackbox, cargo, КТК и содержимое КТК — в [первой части](shipping-order-child-excel-exports-as-is.md). Список controller mappings: [ReportController](../api/endpoints-generated.md#reportcontroller), [ReportControllerV2](../api/endpoints-generated.md#reportcontrollerv2).

## HTTP-контур и используемые DTO

| Ресурс | V1 endpoint | V2 endpoint | Permission `:READ` | V2 filter / result DTO |
|---|---|---|---|---|
| Товары | `POST /report/shipping-order-good/{shippingOrderId}/download` | `POST /v2/report/shipping-order-good/download` | `SHIPPING_ORDER_SHIPPING_ORDER_GOOD` | [`ShippingOrderGoodFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordergood/ShippingOrderGoodFilter.java) / [`ShippingOrderGoodDto`](../dto/catalog/shippingordergood/ShippingOrderGoodDto.md) |
| Услуги | `POST /report/shipping-order-requested-service/{shippingOrderId}/download` | `POST /v2/report/shipping-order-requested-service/download` | `SHIPPING_ORDER_SHIPPING_ORDER_REQUESTED_SERVICE` | [`ShippingOrderRequestedServiceFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingorderrequestedservice/ShippingOrderRequestedServiceFilter.java) / [`ShippingOrderRequestedServiceDto`](../dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceDto.md) |
| ЭТРАН | `POST /report/shipping-order-etran-invoice/{shippingOrderId}/download` | `POST /v2/report/shipping-order-etran-invoice/download` | `SHIPPING_ORDER_ETRAN_INVOICE` | [`ShippingOrderEtranInvoiceFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingorderetraninvoice/ShippingOrderEtranInvoiceFilter.java) / [`ShippingOrderEtranInvoiceDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceDto.md) |
| Вагоны | `POST /report/shipping-order-railway-carriage/{shippingOrderId}/download` | `POST /v2/report/shipping-order-railway-carriage/download` | `SHIPPING_ORDER_RAILWAY_CARRIAGE` | [`ShippingOrderRailwayCarriageFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageFilter.java) / [`ShippingOrderRailwayCarriageDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageDto.md) |

[V1](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportController.java) принимает обязательный UUID в path и не принимает body; каждый method-level `consumes=*/*`, `produces` XLSX, OpenAPI `200`/`400` без schema. [V2](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportControllerV2.java) принимает optional `@Valid @RequestBody(required=false)` сам filter, без клиентского `FilterWithPaging`, и не задаёт explicit response schema. Оба возвращают `StreamingResponseBody`; filename хранится в [`PageReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java), но контроллер не ставит `Content-Disposition`.

### Не смешивать ЭТРАН с Waybill поставки

В отличие от [receiving legacy URI](receiving-order-child-excel-exports-part2-as-is.md#waybill-под-legacy-uri-этран), shipping endpoint реально использует старые [`ShippingOrderEtranInvoice`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingorderetraninvoice/ShippingOrderEtranInvoice.java) и [`EtranInvoice`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/etran/EtranInvoice.java), а не `Waybill`. Это подтверждают [`ShippingOrderEtranInvoiceExportReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderEtranInvoiceExportReportDataCollectorService.java), его filter/mapper и текущий template. KIS-3631 заменил receiving export model, но в этом shipping export flow такой замены нет. Данные deployed ЭТРАН/Waybill не проверялись.

```mermaid
flowchart LR
    V1[V1 path shippingOrderId] --> R[ReportService]
    V2[V2 optional filter] --> R2[ReportServiceV2]
    R --> C[Collector registry]
    R2 --> C
    C --> G[Good collector]
    C --> S[Service collector]
    C --> E[Shipping Etran collector]
    C --> W[Shipping carriage collector]
    G --> J[JXLS]
    S --> J
    E --> J
    W --> J
```

## Выборка, soft-delete и права на данные

Все четыре collectors имеют две реализации. V1 строит child filter по `shippingOrder=ShippingOrderFilter.byId(path UUID)`. Good, Etran и Carriage явно добавляют `deleted=false`; Service получает default `deleted=false` из builder. V2 передаёт nullable child filter как есть, не добавляя серверный ID заявки: [Good collector](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderGoodExportReportDataCollectorService.java), [Service collector](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderRequestedServiceExportReportDataCollectorService.java), [Carriage collector](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ShippingOrderRailwayCarriageExportReportDataCollectorService.java).

| Случай | Source-level выборка до вычисления XLSX expressions |
|---|---|
| V1 неизвестный UUID | Дочерний набор пуст; отдельного root lookup/`404` нет |
| V1 UUID другого клиента | Root ownership не проверяется; нужен только соответствующий child permission |
| V2 body отсутствует | Null filter даёт пустой predicate: все строки данного вида, включая deleted |
| V2 `{}` | Default `deleted=false`: глобальный набор неудалённых строк данного вида |
| V2 `{"deleted":null}` | Нет deleted predicate: активные и soft-deleted строки |
| V2 nested `shippingOrder` | Условие заявки применяется, но сервер не пересекает её client с разрешёнными IDs |

Ни один из четырёх child filters не реализует `ClientRestrictionFilter`. Их `BaseService.getAllEntities` вызывает [FilterEnrichServiceImpl](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java), но тот добавляет client restriction только root filter нужного interface-типа; nested `ShippingOrderFilter` отдельно не обогащается. Это source-level пробел client RLS. Runtime role grants, gateway и фактический доступ на стенде неизвестны.

```mermaid
flowchart TD
    A[Download] --> B{V1 / V2}
    B -- V1 --> I[shippingOrder.id + deleted=false]
    B -- V2 --> F{Body}
    F -- absent --> N[null: все строки включая deleted]
    F -- object --> O[child filter: default deleted=false]
    I --> E[BaseService enrichment]
    N --> E
    O --> E
    E --> C{Root ClientRestrictionFilter?}
    C -- no for all four --> Q[Client IDs не добавлены]
    Q --> P[Page 0 / MAX_VALUE]
```

## Контракты фильтров V2

Фильтры наследуют базовые ID/sorting/audit условия; в собственных полях нет Bean Validation обязательности. `@Valid` не добавляет отсутствующий `shippingOrder` и не валидирует автоматически все nested объекты.

| Filter | Собственные условия и реализация |
|---|---|
| Good | `shippingOrder`, `clientGood`, `item` (`article`), `clientGoodName` (`name`/`nomenclature`), `unitOfMeasure`, `batch`, `price`, `plannedQuantity`, `search`, `deleted=false`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingordergood/ShippingOrderGoodPredicate.java) допускает `byOr` для item/name/uom/batch/price/plannedQuantity; общий `search` охватывает item/name/uom/batch/price/plannedQuantity. `actualQuantity` и `totalPrice` не фильтруются собственными полями. |
| Requested Service | Только `shippingOrder`, `termOfRequestedService`, `deleted=false`; [predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingorderrequestedservice/ShippingOrderRequestedServicePredicate.java) объединяет через AND. Фильтров количества/тарифа/цены здесь нет. |
| Etran Invoice | `etranInvoice`, `shippingOrder`, `number`, `transportationType` (`shipmentType`), `shipper`, `consignee` (`consigneeClient`/`finalConsignee`), departure/destination station, `search`, `deleted=false`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingorderetraninvoice/ShippingOrderEtranInvoicePredicate.java) переносит шесть отдельных строковых условий в OR при `byOr`, общий `search` охватывает номер, вид отправки, стороны и станции. |
| Railway Carriage | `etranInvoice`, `railwayCarriage`, `shippingOrder`, `anyOfStatus`, `dataTimeKrugloyePole`, `dateDepotRepair`, carriage type/sort/model, lifting capacity, customer service/owner, nested `container`, `etsngCode`, `wightGross`, `wightNet`, `search`, `deleted=false`. [Predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingorderrailwaycarriage/ShippingOrderRailwayCarriagePredicate.java) использует AND для базовых условий; type/sort/model поддерживают `byOr`. Container/nested-item conditions реализованы через `EXISTS` с `deleted=false` для связанных КТК/items. Same-day date `BETWEEN` расширяется до суток `[start,start+1day)`. |

Орфография `wightGross`/`wightNet` — фактический контракт. Некорректный UUID/path JSON/enum ожидаемо отклоняется при десериализации (`400`), но конкретный runtime response не проверялся.

## XLSX и конкретные getters

Все collectors передают обычные API response DTO после `mapper::toDto`, а не отдельные report DTO: [Good mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordergood/ShippingOrderGoodMapper.java), [Service mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderrequestedservice/ShippingOrderRequestedServiceMapper.java), [Etran mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderetraninvoice/ShippingOrderEtranInvoiceMapper.java), [Carriage mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageMapper.java). Четыре XLSX проверены как ZIP/XML; endpoint/JXLS runtime не запускался.

| Шаблон / result filename | JXLS key / area | Фактические поля |
|---|---|---|
| [`shipping_order_good.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_good.xlsx) | `shippingOrderGoods`; `A1:L2` | `clientGood.item/name/unitOfMeasure.code`, `batch.code`, `plannedQuantity`, `price`, `totalPrice`, `actualQuantity`; A–H заполнены, I–L пусты. Null `clientGood`/`batch`/UoM может сломать expression. |
| [`shipping_order_requested_service.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_requested_service.xlsx) | `shippingOrderRequestedServices`; `A1:G2` | `termOfRequestedService.code` (mapper берёт `service.code`), `serviceOfMeasure.displayName`, `plannedQuantity`, `rate`, `priceWithoutVAT`, `priceWithVAT`, `actualQuantity`. Getter expressions сейчас согласованы с DTO, в отличие от [receiving Service template](receiving-order-child-excel-exports-part2-as-is.md#заказанные-услуги); nullable nested service/UoM остаются риском. |
| [`shipping_order_etran_invoice.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_etran_invoice.xlsx) | `shippingOrderEtranInvoices`; `A1:F2` | `etranInvoice.code`, `transportationType.description`, `shipper.code`, `consigneeClient.code`, `departureStation.name`, `destinationStation.name`. Это [`EtranInvoiceDto`](../dto/catalog/etran/EtranInvoiceDto.md), вложенный в `ShippingOrderEtranInvoiceDto`; nullable станции/стороны могут дать JXLS error. За пределами JXLS area остались заголовки G1 «Класс опасности» и H1 «Активный» без data expressions. |
| [`shipping_order_railway_carriage.xlsx`](../../../web-layer/src/main/resources/reports/shipping_order_railway_carriage.xlsx) | `shippingOrderRailwayCarriages`; `A1:F2` | `shippingOrderEtranInvoice.code` (mapper берёт `etranInvoice.code`), `railwayCarriage.code/type.code/model.code/liftingCapacity`; F не содержит expression. H1 «Активный» лежит вне area и также не имеет data expression. Nullable накладная/вагон/type/model могут дать JXLS error. |

Все четыре template parameter keys совпадают с параметрами collectors. Наличие template и согласованных getters не доказывает успешную генерацию всех записей: вложенные reference могут быть null, mapper/JXLS исполняются отдельно.

```mermaid
flowchart LR
    E[ShippingOrderEtranInvoice entity] --> M[Etran mapper]
    M --> D[ShippingOrderEtranInvoiceDto<br/>nested EtranInvoiceDto]
    D --> T[shipping_order_etran_invoice.xlsx]
    W[Waybill receiving model] -. другой collector и template .-> X[Не часть shipping export]
```

## Транзакции, объём, ошибки и тесты

[BaseReportDataCollectorService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) собирает параметры в `REPEATABLE_READ`. Каждый collector запрашивает `PageInfo(page=0,size=Integer.MAX_VALUE)`: data+count queries, полный entity list, затем полный DTO list через `parallelStream` и JXLS render после выхода из collector transaction. Server max rows нет. V1 использует default sort ID ASC, V2 сохраняет request sorting, если задан; JXLS отдельной сортировки не делает. Доступ к lazy JPA association из parallel mapping/common pool и память на больших выборках — риски, а не подтверждённые production failures.

Нет permission — ожидаемо `403`; malformed path/body — `400`; mapping/JXLS exception — ожидаемо `500` по общему exception path. После начала stream JSON error/status не гарантированы, возможен частичный XLSX. Прямых tests восьми mappings, четырёх collectors и content XLSX source-wide поиск не нашёл; тесты не запускались.

| Commit | Влияние на AS-IS |
|---|---|
| `7e50a680`, `576e8787` (2025-08, KIS-47) | Исходные shipping child exports |
| `c2d41a09` (2025-08, KIS-47) | Рефакторинг шаблонов/collectors |
| `905ef6e4` (2025-09, KIS-1336) | V2 optional-filter методы |
| `969e2059` (2025-09, KIS-1673) | Правки XLSX |
| `14d6f159`, `1e0b0443`, `d2c385b6`, `fd8aa53e` (2025-12, KIS-1966) | Исправления отчётов, включая текущие service/ЭТРАН expressions |
| `443ae69a` (2026-04, KIS-3631) | Receiving миграция на Waybill; shipping Etran export сохраняет старую модель |
| `3256b8f0` (2026-06) | Paged collectors с `Integer.MAX_VALUE` |

Для ТЗ отдельно определить client/ownership scope, absent body и deleted-политику, допустимый объём/async режим, сортировку и filename header, null-policy связанных справочников, совместное существование shipping ЭТРАН и receiving Waybill, а также HTTP/permission/filter/template/content tests. Runtime-роли, live schema, внешний ЭТРАН и фактическая генерация XLSX не подтверждены.
