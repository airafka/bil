# Бизнес-правила заявки на услугу

`ServiceOrder` наследует идентификатор, audit-поля, номер и клиента от `Order`, но не наследует `TransportOrder`: у неё нет площадки, транспорта и `OrderStatus`.

## Контракты и модель

- Сущность: [ServiceOrder](../entities/catalog/entities/serviceorder/ServiceOrder.md)
- Связь с КТК: [ServiceOrderContainer](../entities/catalog/entities/serviceordercontainer/ServiceOrderContainer.md)
- DTO: [create](../dto/service-order/ServiceOrderCreationDto.md), [update](../dto/service-order/ServiceOrderUpdateDto.md), [response](../dto/service-order/ServiceOrderDto.md)
- Общая классификация: [типы заявок](order-types.md#7-тип-сервисной-заявки-serviceordertype)
- Обязательные поля и порядок проверок: [карта валидации сервисной заявки](order-validation.md#заявка-на-услугу-корневой-request)
- Полный процесс и все endpoints: [lifecycle заявки на услугу](service-order-lifecycle.md)

## Правила

Create использует [ServiceOrderCreationDto](../dto/service-order/ServiceOrderCreationDto.md), update — [ServiceOrderUpdateDto](../dto/service-order/ServiceOrderUpdateDto.md), а привязка контейнеров выполняется отдельным [ServiceOrderContainerSaveDto](../dto/catalog/serviceordercontainer/ServiceOrderContainerSaveDto.md). Accept request body не имеет и проверяет уже сохранённые связи.

| ID | Правило |
|---|---|
| `BR-SRV-001` | Новый объект создаётся со статусом `DRAFT`. |
| `BR-SRV-002` | Сейчас допустима только услуга `CHANGE_OWNER`. |
| `BR-SRV-003` | В `DRAFT` можно менять только `service` и `comment`. |
| `BR-SRV-004` | Удаление разрешено только в `DRAFT`; перед удалением удаляются связи с контейнерами. |
| `BR-SRV-005` | Accept разрешён только из `DRAFT` и требует минимум один контейнер. |
| `BR-SRV-006` | При accept владельцы всех связанных КТК меняются на клиента заявки. |
| `BR-SRV-007` | После выполнения устанавливаются `DONE`, `completionAt=Instant.now()` и создаётся исходящая интеграция. |

## Сценарий выполнения

```mermaid
flowchart LR
    A[Создать DRAFT] --> B[Выбрать минимум один КТК]
    B --> C[POST /service-order/id/accept]
    C --> D[Владельцы → клиент заявки]
    D --> E[DONE + completionAt]
    E --> F[SERVICE_ORDER_CHAIN_PACKAGE]
```

Если контейнеров нет, возвращается validation error `Service order must contain at least one container`. После `DONE` update/delete/повторный accept запрещены.

Важно: update/delete/редактирование состава после `DONE` дают HTTP `403`, но повторный accept выбрасывает `IllegalStateException` и попадает в общий HTTP `500`. Полная таблица ошибок и конкурентных сценариев приведена в [lifecycle](service-order-lifecycle.md#ошибки-http).

## Граница агрегата

Корень — `ServiceOrder`; контейнеры входят через link-сущности `ServiceOrderContainer`. Сам `Container` не удаляется вместе с заявкой. В текущем `accept` владельцы, история, `DONE`, `completionAt` и строка outbound фиксируются одной транзакцией; фактическая отправка Datareon выполняется позже и имеет собственные повторы.

## Вопросы для развития

- Должен ли `ServiceOrderType` расширяться другими операциями или каждая операция требует собственного агрегата?
- Нужно ли сохранять снимок прежнего владельца непосредственно в заявке или достаточно `ContainerOwnerHistory`?
- Нужна ли компенсация уже выполненной заявки после исчерпания попыток outbound?
- Нужна ли повторная проверка доступности/старого владельца каждого КТК непосредственно в `accept`?
- Должен ли один КТК иметь возможность одновременно находиться в двух `DRAFT` при конкурентном выборе?
