# Модель ошибок HTTP API: `AlisException` и `ApiErrorDto` AS-IS

Проверено по checkout `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026): Java exception/error/advice source. **Source-level реконструкция**, тесты не прогонялись. Новая иерархия введена тремя последовательными коммитами: `ce272f3e` (KIS-4683, «create common error model and AlisException hierarchy», 9 сентября 2026), `8e9b494b`/`d24879c6` (KIS-4682, «refactor global exception handler», 16 сентября 2026), `575ae6b9` (KIS-4724, «unify Spring Validation handling to legacy ApiErrorDto», 16 сентября 2026).

## Главный вывод: контракт ответа на wire не изменился

Все обработчики — старые и новые — в итоге строят один и тот же `ApiErrorDto` (`{contextObject, errorMessage, errorCode}`) через единый [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) (`@RestControllerAdvice`) и [`ExceptionAdviceUtils.prepareErrorDto`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java). Новая иерархия `AlisException` **не меняет форму JSON-ответа** — она только переорганизует, как код бросает исключения на сервере, и добавляет новую HTTP-статус-семантику для будущих исключений (см. ниже про `422`).

## Два параллельных исключения-дерева на 29.09.2026

| Дерево | Базовый класс | С какого времени | Типичные представители | Как строится `ApiErrorDto` |
|---|---|---|---|---|
| Старое | [`WmsEntityException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/WmsEntityException.java) (март 2025) | До этого периода | `IllegalStateWithCodeException` — используется повсеместно, включая `INVALID_STATUS` в `ReceivingOrderService.accept/reject`, `ShippingOrderService.accept/reject` | `errorCode = errorMessage = exception.getMessage()`; `contextObject` — из `exception.getContextObject()` |
| Новое | [`AlisException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/AlisException.java) (KIS-4683, 9 сентября 2026) | Этот период | См. таблицу категорий ниже | См. раздел «Заполнение `ApiErrorDto`» |

Обе ветки не связаны наследованием и обрабатываются в `ExceptionAdviceUtils.fillDetails` раздельными `if/else`-ветками по типу исключения. Единой миграции старых `IllegalStateWithCodeException`-мест на новую иерархию в этом периоде не было — это два сосуществующих механизма, а не замена одного другим.

## Новая иерархия: категория → HTTP-статус

[`AlisException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/AlisException.java) — абстрактный класс с обязательным непустым списком `List<ErrorDetails> errors` (`ErrorDetails` = `code` из `ApiErrorCode` + опциональные `field`/`params`) и абстрактным `getCategory(): ErrorCategory`. `ExceptionAdvice.resolveHttpStatus` мапит категорию на статус:

| `ErrorCategory` | HTTP-статус | Конкретный класс-исключение | Используется в production-коде на 29.09.2026? |
|---|---|---|---|
| `INVALID_REQUEST` | 400 | `InvalidRequestException` | **Нет** — класс существует, нигде не создаётся (`grep` по `new InvalidRequestException` не даёт совпадений в бизнес-коде) |
| `ACCESS_DENIED` | 403 | `AccessDeniedException` | Да — рефакторинг существовавшего класса; deprecated-конструкторы (`Secure`/`Secure[]`/`String context`) сохранены ради обратной совместимости вызывающего кода |
| `NOT_FOUND` | 404 | `NotFoundException` | Да — аналогично, рефакторинг существовавшего класса, deprecated-конструкторы (`Class+UUID`, `Class+String`, `String message`) сохранены |
| `CONFLICT` | 409 | `ConflictException` | **Нет** — не создаётся; фактический 409 для дублей по-прежнему идёт через отдельный `@ExceptionHandler({UniqueViolationException.class, DuplicateEntityException.class})`, не через `ConflictException` |
| `BUSINESS_RULE_VIOLATION` | **422** (`UNPROCESSABLE_ENTITY`) | `BusinessRuleViolationException` | **Нет** — класс существует, нигде не создаётся |
| `TECHNICAL` | 500 | `TechnicalException` | **Нет** — класс существует, нигде не создаётся |

**Вывод для ТЗ:** на 29 сентября 2026 из шести подклассов `AlisException` реально бросаются только `AccessDeniedException` и `NotFoundException` — оба являются рефакторингом уже существовавших классов, поведение (403/404) не изменилось для их текущих вызывающих мест. Остальные четыре, включая единственный новый HTTP-статус `422`, — заготовка на будущее: ни один endpoint сейчас не возвращает `422` через этот механизм. Если ТЗ описывает бизнес-ошибки как `422`, нужно явно проверять, реализовано ли это на момент проверки, а не полагаться на факт существования класса.

## Заполнение `ApiErrorDto` из `AlisException` — асимметрия при нескольких ошибках

[`ExceptionAdviceUtils.fillFromException(AlisException, ApiErrorDto)`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java):

- **Один `ErrorDetails`** (частый случай): `errorMessage = errorCode = error.getCode()` — оба поля получают **один и тот же** код ошибки (например `"AccessDenied"`), а не человекочитаемое сообщение; `contextObject` собирается из `error.getParams()` и, если задан, `error.getField()`.
- **Несколько `ErrorDetails`** (`errors.size() > 1`): `errorMessage` = коды через `", "`, а **`errorCode` не устанавливается вовсе** (остаётся значением по умолчанию из конструктора `ApiErrorDto`, то есть `null`) — метод делает `return` раньше строки `dto.setErrorCode(...)`. `contextObject` в этом случае также не заполняется. Клиент API, ожидающий `errorCode` для программной обработки, для multi-error `AlisException` его не получит.

Это наблюдаемая асимметрия в текущем коде, не задокументированный явно контракт — открытый вопрос, ожидаемое ли это поведение для API-потребителей.

## Bean Validation (KIS-4724) — тоже не мигрировано на новую иерархию

Коммит `575ae6b9` («unify Spring Validation handling to legacy ApiErrorDto») правит [`ExceptionAdviceUtils.fillFromValidationErrors`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java) для `MethodArgumentNotValidException`/`HandlerMethodValidationException`: берётся **последняя** ошибка из списка (`validationErrors.get(size - 1)`), `errorMessage` — её default message, `errorCode` — первый Spring validation code или тот же default message. Существует параллельный enum [`ValidationErrorCode`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/error/code/ValidationErrorCode.java) (`Validation.NotNull`, `Validation.Size` и т.д., тоже добавлен в этот период) — он **нигде не используется** (`grep` не находит ссылок за пределами собственного файла). Bean Validation на 29.09.2026 продолжает отдавать Spring-овские default messages/codes, а не эти новые коды.

## Каталог кодов: `CommonErrorCode` vs `order-errors.md`

[`CommonErrorCode`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/error/code/CommonErrorCode.java) (`InternalError`, `InvalidRequest`, `AuthenticationRequired`, `AccessDenied`, `NotFound`, `MethodNotAllowed`, `Conflict`, `BusinessRuleViolation`) — это HTTP-уровневые generic-коды новой иерархии. Это **отдельный, не связанный** механизм от предметных бизнес-кодов заявок, описанных в [каталоге бизнес-ошибок](order-errors.md) (`X.MissingTransport`, `XContainer.MissingOwnerContainer` и т.п. — строковые константы `IllegalStateWithCodeException`/`ValidationException`, не реализующие `ApiErrorCode`). Не путать одно с другим при проверке ТЗ на конкретный код ошибки.

## Открытые вопросы

1. Планы по миграции `IllegalStateWithCodeException`/`ValidationException`-мест (включая весь `order-errors.md`) на `AlisException` — не source-level вопрос, нужен ответ у разработчиков.
2. Осознанность отсутствия `errorCode` для multi-error `AlisException`.
3. Судьба неиспользуемых `InvalidRequestException`/`ConflictException`/`BusinessRuleViolationException`/`TechnicalException`/`ValidationErrorCode` — заготовка для конкретной будущей задачи или общий рефакторинг «на будущее» без привязки к тикету.
4. Тесты (`*ExceptionAdvice*`, если есть) в рамках этой сверки не запускались и не искались отдельно.
