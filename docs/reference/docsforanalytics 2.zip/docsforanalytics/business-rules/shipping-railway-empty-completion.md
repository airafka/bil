# Завершение порожнего ЖД-вывоза без КТК по входящему событию

Документ фиксирует **текущий AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 11.09.2026). Он описывает только путь `POST /datareon/event` → действие `CARRIAGE_ARRIVED` → `ShippingOrderRailwayCarriage`. Проектирование исправления здесь отсутствует.

## Результат сценария

| ID | Подтверждённое правило AS-IS |
|---|---|
| `BR-SO-RAIL-001` | Для подходящей заявки `CONTAINER + RAILWAY` действие переводит заявку в `IN_PROGRESS`, если переход разрешён. |
| `BR-SO-RAIL-002` | Вагонная задача, идентификатор которой передан в `_id`, блокируется и переводится в `FINISHED`. |
| `BR-SO-RAIL-003` | Shipping-ветка не проверяет, завершены ли все вагоны и отсутствуют ли КТК, и не переводит `ShippingOrder` в `DONE`. Поэтому даже последний успешно завершённый вагон оставляет заявку в `IN_PROGRESS`. |
| `BR-SO-RAIL-004` | Статус журнала `InboundEvent=DONE` означает успешное выполнение настроенных actions, а не завершение бизнес-заявки. |

`BR-SO-RAIL-003` — подтверждённый дефект/пробел текущей реализации. В receiving-ветке того же action есть отдельный `tryMarkOrderDone()`, а в shipping-ветке симметричного шага нет.

### Повлиявшие изменения Git

| Commit | Влияние на текущий сценарий |
|---|---|
| `b2dd03a463b9b355b3f1c22004c5e6aeed619a8f` (`KIS-3355`, author date 26.02.2026, commit date 13.03.2026) | Добавил закрытие заявки без контейнеров после завершения всех вагонов только в receiving-ветку; shipping-ветка осталась с завершением вагонной задачи без `ShippingOrder=DONE`. |
| `6398c0afca12be365a7a44ed58f616860d72280e` (`KIS-3648`, 02.04.2026) | Массово переформатировал файл без изменения этой семантики; поэтому значительная часть текущих строк относится `git blame` к этому commit, хотя асимметрия появилась раньше. |
| `5de66acd108609c94e123e3e2639a2ee025f613c` (16.09.2024) | Добавил миграцию rename `message_id → task_id` и удаление unique index журнала событий, что влияет на гарантии повторной доставки. |

Это история влияния по Git, а не утверждение о версии, развернутой на конкретной среде.

## Связанные контракты

- HTTP endpoint: [`DatareonController.handleEvent`](../api/endpoints-generated.md#datareoncontroller), `POST /datareon/event`.
- Request DTO: [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md).
- Вагонная задача: [ShippingOrderRailwayCarriage](../entities/catalog/entities/shippingorderrailwaycarriage/ShippingOrderRailwayCarriage.md).
- Корневая заявка: [ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md).
- Общие переходы: [статусная модель](order-statuses.md).
- Исходный исторический разбор: [реестр исследования](../research/README.md#завершение-порожнего-жд-вывоза). Его вывод о дедупликации уточнён ниже по полной найденной цепочке миграций.

## Предусловия успешной обработки

1. Тело запроса является **одним плоским `InboundEventDto`**, а не envelope с `MessageID` и `EventData`.
2. `_order` содержит UUID существующей `ShippingOrder`; `_id` — UUID существующей `ShippingOrderRailwayCarriage`.
3. `site` разрешается через справочник площадок в `TerminalArea` с кодом `CONTAINER`.
4. Фактическая заявка имеет `terminalArea=CONTAINER` и `transportType=RAILWAY`.
5. В `INBOUND_EVENT_CONFIG` есть строка с данным `eventCode` и `actionCode=CARRIAGE_ARRIVED`. Для shipping-сценария её фильтры должны разрешать `SHIPMENT`, `CONTAINER` и `RAILWAY`; пустой список в каждом таком фильтре означает wildcard.
6. Если заявка ещё не `IN_PROGRESS`, модель переходов должна разрешать перевод текущего статуса в `IN_PROGRESS`.

В репозитории нет миграции, которая однозначно создаёт production mapping `VH_ARRIVED → CARRIAGE_ARRIVED`: integration test добавляет его самостоятельно. Поэтому конкретный `eventCode` и фактическое содержимое применённой конфигурации среды остаются внешним предусловием, а не доказанным значением production.

## HTTP request

Минимальный по структуре пример для этого action:

```json
{
  "_id": "<UUID ShippingOrderRailwayCarriage>",
  "_order": "<UUID ShippingOrder>",
  "orderNumber": "20530",
  "source": "TOS",
  "site": "Терминал",
  "eventName": "Вагон прибыл",
  "eventCode": "VH_ARRIVED",
  "eventDateTime": "2026-09-08T01:04:02Z"
}
```

`cargoResult`, `itemsResult`, `addServicesResult` и `dock` для `CARRIAGE_ARRIVED` не используются и могут отсутствовать. Неизвестные JSON-поля игнорируются. Заголовок `External-ID` необязателен, попадает в лог контроллера, но не участвует в routing или идемпотентности.

### Обязательность полей request

| JSON-поле | Bean Validation | Дополнительная серверная семантика |
|---|---|---|
| `_id` | `@NotBlank` | Парсится как UUID; используется как ID вагонной задачи. |
| `_order` | `@NotBlank` | Парсится как UUID; используется как ID заявки. |
| `orderNumber` | `@NotNull` | Пустая строка Bean Validation не нарушает; значение пишется в журнал, но не выбирает заявку. |
| `source` | `@NotNull` | Пустая строка допустима; в `InboundEventData` этого пути не переносится и routing не определяет. |
| `site` | `@NotBlank` | Должен разрешиться в существующую площадку; для данного action `WAREHOUSE` запрещён. |
| `eventName` | `@NotNull` | Пустая строка допустима; действие выбирается не по имени. |
| `eventCode` | `@NotBlank` | По точному коду ищутся строки `INBOUND_EVENT_CONFIG`. |
| `eventDateTime` | `@NotNull` | Должен десериализоваться как `Instant`; shipping-ветка `CARRIAGE_ARRIVED` не пишет его в заявку или вагон. |

## Серверный flow

```mermaid
flowchart TD
    A[POST /datareon/event] --> B{JSON и Bean Validation}
    B -->|ошибка| B400[HTTP 400, журнал InboundEvent не создан]
    B -->|OK| C[UUID parsing и site → TerminalArea]
    C -->|ошибка| CERR[HTTP 500 через общий handler; журнал не создан]
    C --> D[Найти config по eventCode]
    D -->|нет строк| SKIP[Создать InboundEvent = SKIPPED; HTTP 200]
    D -->|есть actions| LOG[Создать InboundEvent]
    LOG --> ACT[REQUIRES_NEW: actions по priority]
    ACT --> V{CARRIAGE_ARRIVED validation и filters}
    V -->|IllegalArgumentException| INV[Rollback actions; InboundEvent = INVALID; HTTP 200]
    V -->|иная ошибка| FAIL[Rollback actions; InboundEvent = FAILED; HTTP 200]
    V -->|OK| O{ShippingOrder найден}
    O -->|нет| NOORDER[Вернуться без изменения; InboundEvent = DONE; HTTP 200]
    O -->|да| SUIT{CONTAINER + RAILWAY и config разрешает значения}
    SUIT -->|нет| FAIL
    SUIT -->|да| IP[Если разрешено: ShippingOrder → IN_PROGRESS]
    IP --> LOCK[Lock вагона по _id]
    LOCK -->|не найден| FAIL
    LOCK -->|уже FINISHED| EVTDONE[InboundEvent = DONE; HTTP 200]
    LOCK -->|иначе| WFIN[Вагонная задача → FINISHED]
    WFIN --> EVTDONE
    EVTDONE --> GAP[ShippingOrder в DONE не переводится]
```

### Порядок действий

1. Контроллер валидирует DTO, пишет входящий пакет в monitor и преобразует два строковых ID в UUID; `site` разрешается в `TerminalArea`.
2. Сервис ищет все строки конфигурации по `eventCode`, создаёт отдельную запись `InboundEvent` и сохраняет список найденных action codes.
3. При отсутствии конфигурации событие получает `SKIPPED / No actions required`; предметные данные не меняются.
4. Actions сортируются по числовому priority. У `CARRIAGE_ARRIVED` priority равен `0`; несколько actions выполняются в одной новой транзакции.
5. `CarriageArrivedAction` проверяет наличие order/task ID и отклоняет `WAREHOUSE`, затем включает shipping-ветку, если config разрешает `SHIPMENT` либо не ограничивает тип заявки.
6. Заявка загружается по `_order`. Если её нет, action только пишет debug log и завершается успешно.
7. Для найденной заявки проверяются фактические `CONTAINER + RAILWAY` и соответствие config-фильтрам. Затем допустимый переход выполняется в `IN_PROGRESS`.
8. Вагонная задача блокируется по `_id`. Повтор для уже `FINISHED` задачи является предметно no-op.
9. Иначе задача получает `FINISHED`. Проверка «последний вагон», проверка отсутствия КТК и переход заявки в `DONE` отсутствуют.
10. После успешного завершения всех настроенных actions запись входящего события получает `DONE`.

## Изменяемое состояние и транзакции

| Объект | Успешное изменение | Блокировка / атомарность |
|---|---|---|
| `InboundEvent` | создаётся до actions; затем `DONE`, `INVALID`, `FAILED` или сразу `SKIPPED` | Журнал сохраняется вне новой транзакции actions и остаётся после их rollback. |
| `ShippingOrder` | допустимый исходный статус → `IN_PROGRESS` | В shipping-ветке заявка загружается без явного `findAndLock`; update входит в общую `REQUIRES_NEW` транзакцию actions. |
| `ShippingOrderRailwayCarriage` | текущий статус → `FINISHED` | Загружается через `findAndLock`; update атомарен с остальными actions данного события. |

Если любой action из набора падает, транзакция всех actions откатывается, после чего журнал обновляется отдельно. Исключения action-слоя поглощаются сервисом: `INVALID`/`FAILED` обычно сопровождаются HTTP `200`, поэтому транспортный успех не является подтверждением предметного успеха.

## Routing, идентификаторы и граница доверия

`eventCode` выбирает конфигурацию, а `eventName`, `source`, `orderNumber` и `External-ID` не участвуют в выборе действия. Пустые `orderType`, `terminalArea` и `transportType` в config расширяют действие до любых значений соответствующей категории.

Endpoint `/datareon/**` явно настроен как `permitAll`, CSRF отключён, method-level permission у `handleEvent` отсутствует. Следовательно, на уровне проверенного Spring-кода bearer token и ALIS permission для вызова не требуются. Возможные ограничения reverse proxy, сети или внешнего integration gateway в репозитории не подтверждены.

Код независимо доверяет двум входным ссылкам:

- `_order` выбирает `ShippingOrder`;
- `_id` выбирает `ShippingOrderRailwayCarriage`.

Shipping-ветка не проверяет, что найденная вагонная задача принадлежит заявке из `_order`. Поэтому согласованность пары ID должна обеспечиваться отправителем/интеграционным контуром; в приложении это не является инвариантом данного action.

## Негативные ветки и наблюдаемый ответ

| Условие | Журнал | HTTP по текущему коду | Предметный эффект |
|---|---|---|---|
| Невалидный JSON, отсутствует `@Not*`, неверный формат `Instant` | не создаётся | `400` | нет |
| `_id`/`_order` не UUID | не создаётся | `500` через общий handler `IllegalArgumentException` | нет |
| `site` не найден | не создаётся | `500` через общий handler `IllegalArgumentException` | нет |
| Для `eventCode` нет config | `SKIPPED` | `200` | нет |
| Config не включает shipping-ветку | `DONE` | `200` | нет |
| `ShippingOrder` по `_order` не найден | `DONE` | `200` | нет |
| Заявка не `CONTAINER + RAILWAY` или не проходит config-фильтры | `FAILED` | `200` | транзакция actions откатывается |
| Вагон по `_id` не найден | `FAILED` | `200` | транзакция actions откатывается |
| Вагон уже `FINISHED` | `DONE` | `200` | no-op после возможного перевода заявки в `IN_PROGRESS` |
| Action выбросил `IllegalArgumentException` | `INVALID` | `200` | транзакция actions откатывается |
| Action выбросил иное исключение | `FAILED` | `200` | транзакция actions откатывается |

OpenAPI-декларация endpoint указывает `406` для unique violation, но общий `ExceptionAdvice` текущего кода сопоставляет `UniqueViolationException` с `409 Conflict`. Фактическая ветка повтора зависит от схемы БД, описанной далее.

## Повторы и дедупликация

Гарантированного idempotency key в проверенной модели нет:

- `External-ID` только логируется;
- service перехватывает `DataIntegrityViolationException` при вставке журнала и превращает его в `UniqueViolationException`;
- первоначальная миграция создала unique index `INBOUND_EVENT(message_id)`, но следующая миграция переименовала колонку в `task_id` и **удалила индекс**;
- последующей миграции, восстанавливающей uniqueness `task_id`, и `unique=true` в JPA entity не найдено.

Следовательно, по репозиторию нельзя утверждать, что повторный `_id` будет отклонён до actions. Если применённая БД соответствует найденной цепочке миграций, повтор может создать ещё один `InboundEvent` и снова запустить actions; блокировка и проверка `FINISHED` делают повторную обработку того же вагона частично безопасной, но это не дедупликация события. Фактическая схема развернутой БД не проверялась.

## Тестовая трассировка и доказательства

- Integration test `shouldUpdateShippingOrderRailwayCarriageWhenProcessingCarriageArrivedAction` создаёт mapping `VH_ARRIVED → CARRIAGE_ARRIVED`, вызывает service и проверяет `ShippingOrderRailwayCarriage.status=FINISHED` и `InboundEvent.status=DONE`.
- Этот тест не проверяет итоговый `ShippingOrder.orderStatus`, поэтому дефект отсутствующего `DONE` тестом не зафиксирован как ожидаемое требование.
- Controller integration test подтверждает `200` и `SKIPPED` при отсутствии config.
- Тесты в данном подэтапе были просмотрены, но не запускались.

Ключевые реализации: [`DatareonController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java), [`InboundEventDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/inbound/InboundEventDto.java), [`InboundEventConverter`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/converter/InboundEventConverter.java), [`InboundEventDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonService.java), [`ActionsProcessor`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessor.java), [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java), [`ResourceServerSecurity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java), [integration test](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonServiceTest.java), [создание unique index](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_30240822_ALG-694_add_table_incoming_event.sql), [удаление unique index](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240913_ALG-694_alter_table_incoming_event.sql).

## Что подтверждено и что неизвестно

**Подтверждено исходниками:** request DTO, разрешение `/datareon/**` без аутентификации, config-driven routing, транзакционная граница actions, блокировка вагонной задачи, статусы журнала, отсутствие проверки связи двух ID и отсутствие shipping-перехода в `DONE`.

**Не подтверждено без среды:** production mapping к `CARRIAGE_ARRIVED`, сетевые ограничения перед ALIS, преобразование envelope Datareon в плоский DTO, фактически применённая схема и ограничения БД, мониторинг/повторная доставка, реальный HTTP-ответ gateway.

**Не входит в этот AS-IS:** целевой алгоритм закрытия последнего вагона, схема исправления связи `_id`/`_order`, новый ключ идемпотентности и изменение HTTP-контракта.
