# Договоры ЭДО и Datareon: AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 14.09.2026): `POST /datareon/contract` от [ContractEdoDatareonDto](../dto/catalog/datareon/ContractEdoDatareonDto.md) через разрешение Client, Company и Currency до [Contract](../entities/catalog/entities/contract/Contract.md), включая даты, повтор, транзакцию, ошибки, пользовательский CRUD и тесты. Бизнес-код, runtime-конфигурация и миграции не изменялись; работающие ALIS/Datareon, production payload и применённая схема БД не проверялись.

## HTTP-контракт и место в процессе

| Метод и путь | Request | Response | Доступ AS-IS |
|---|---|---|---|
| `POST /datareon/contract` | [ContractEdoDatareonDto](../dto/catalog/datareon/ContractEdoDatareonDto.md), обязательный body с `@Valid` | `200` без тела при успешном create | `/datareon/**` разрешён security-конфигурацией без аутентификации |

Endpoint находится в [DatareonController](../api/endpoints-generated.md#datareoncontroller). **Устарело** (коммит `a5a40f94` «remove datareon monitoring», 17 сентября 2026): описанный ниже best-effort мониторинг по `_id` (`MonitorClient.logInboundPacket`) удалён из кода без замены; endpoint теперь сразу передаёт DTO в [ContractEdoDatareonService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/ContractEdoDatareonService.java).

Договор ссылается на уже существующий Client по `_client`. Поэтому первый успешный create контрагента через [POST `/datareon/contractor`](contractor-edo-datareon-as-is.md) должен предшествовать договору. Company и Currency этот endpoint не создаёт; доступные read endpoints, physical constraints и неподтверждённый источник их наполнения разобраны в [Company и Currency для договоров](company-currency-contract-prerequisites-as-is.md).

## DTO, форматы и mapping

Все девять полей внешнего DTO имеют `@NotNull`; `@Valid` на строках `_client` и `_company` дополнительных ограничений не добавляет. `@NotNull` разрешает пустые строки и пробелы.

| JSON | Mapping / фактическое правило AS-IS |
|---|---|
| `_id` | Копируется в nullable `Contract.edoId`; lookup существующего договора по нему отсутствует. Blank допустим. Physical максимум 50 символов. |
| `_client` | Case-insensitive lookup `Client.edoId`; найденный Client затем повторно загружается по внутреннему UUID в create transaction. |
| `_company` | Case-insensitive lookup `Company.edoId`; найденная Company повторно загружается по UUID. |
| `number` | Копируется в `Contract.code`; blank допустим, physical `VARCHAR(100) NOT NULL`. Отдельный `contract_number` удалён. |
| `date` | `Instant.parse`: требуется ISO-8601 instant с offset, например `2026-08-20T00:00:00Z`; сохраняется как `contractDate`. |
| `dateFrom` | `LocalDate.parse`, формат ISO `YYYY-MM-DD`; преобразуется в начало дня UTC. |
| `dateTo` | То же; `ContractService` запрещает значение раньше `validFrom`, равенство допустимо. |
| `currency` | Точный case-sensitive repository lookup по `Currency.code`; неизвестный код превращается в `null`, а не в предметную not-found ошибку. |
| `contractType` | Только enum `TOE` или `OX`; unknown JSON не десериализуется. Сохраняется строкой. |

Внутренний [ContractCreationDto](../dto/catalog/contract/ContractCreationDto.md) создаётся программно и не проходит controller/method Bean Validation. Поэтому его `@NotBlank name` не выполняется: `name` интеграционный mapper вообще не задаёт, но physical колонка `contract.name` nullable и create может пройти с `name=null`. Аналогично не запускается `@NotBlank/@Size` для code; ограничения длины остаются DB boundary.

Сервер принудительно задаёт `active=true`. Входного `syncId` нет; [ContractService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/contract/ContractService.java) присваивает `syncId = generated Contract.id`.

## Серверный алгоритм

```mermaid
flowchart TD
    A[POST /datareon/contract] --> V[Bean Validation внешнего DTO]
    V -->|любое поле null / enum invalid| E400[HTTP 400]
    V --> M[Best-effort monitor по _id]
    M --> CL[Найти Client по edoId<br/>ignore case]
    CL -->|не найден| EC[Client.NotFoundByEdoId → HTTP 500]
    CL --> CO[Найти Company по edoId<br/>ignore case]
    CO -->|не найдена| EO[Company.NotFoundByEdoId → HTTP 500]
    CO --> CU[Найти Currency по точному code]
    CU --> P[Распарсить date/dateFrom/dateTo]
    P -->|ошибка формата| ED[HTTP 500]
    P --> D[Собрать ContractCreationDto<br/>name=null, active=true]
    D --> TX[ContractService.add transaction]
    TX --> FK[Повторно загрузить Client/Company/Currency по UUID]
    FK -->|currency null или связь исчезла| EF[HTTP 500; rollback]
    FK --> R{validTo раньше validFrom?}
    R -->|да| EV[ValidationException → HTTP 400]
    R -->|нет| G[UUID id; syncId=id]
    G --> I[INSERT Contract]
    I --> OK[HTTP 200 без тела]
```

Вызовы lookup и parsing выполняются до `ContractService.add`, то есть до write transaction. Внутри transaction `preAdd` заново получает Client, Company и Currency по UUID, затем проверяются даты и выполняется insert. Если связь исчезла между двумя фазами, create откатывается.

Неизвестная Currency даёт `null` IdDto. Затем `preAdd` разыменовывает `newModel.getCurrency().getId()`, поэтому результат — NPE/HTTP `500`, а не управляемая ошибка `Currency.NotFound`.

## Create-only и повторы

```mermaid
flowchart LR
    P1[Первый payload<br/>_id=X] --> C1[(Contract A<br/>edoId=X, syncId=A.id)]
    P2[Точный повтор<br/>_id=X] --> C2[(Contract B<br/>edoId=X, syncId=B.id)]
    P3[Параллельный повтор<br/>_id=X] --> CN[(Ещё Contract<br/>если оба insert успешны)]
```

`ContractEdoDatareonService.add` всегда вызывает `ContractService.add`; он не ищет Contract ни по `edoId`, ни по number/code. В просмотренных миграциях нет unique для `contract.edo_id`, `code` или `sync_id`. Поэтому последовательный точный повтор штатно создаёт ещё один договор с новым `id/syncId`, тем же `edoId`, code и связями. Параллельные повторы также не сериализуются.

Следствия:

- `_id` является сохранённым атрибутом и monitor ID, но не idempotency key;
- изменённый payload с тем же `_id` не обновляет старую запись, а создаёт новую;
- delete/deactivate/patch веток нет;
- последующий поиск договора по `edoId` в этом сервисе отсутствует, а пользовательский CRUD работает по внутреннему UUID;
- JPA inherited `BaseIdCode.code` содержит `unique=true`, но physical Liquibase chain unique code не задаёт.

Endpoint также не создаёт `OutboundData`: `ContractService` не реализует outbound integration, а в `MessageType`/OutboundConfig нет отдельного CONTRACT. Договор позднее включается в payload заявок и route packages, но сам create не ставит его в отдельную исходящую очередь.

## Даты и бизнес-проверки

| Сценарий | Результат AS-IS |
|---|---|
| `date="2026-08-20"` без времени/offset | `Instant.parse` падает → HTTP `500`. |
| `dateFrom/dateTo` содержат time или offset | `LocalDate.parse` падает → HTTP `500`. |
| `dateTo < dateFrom` | Явная `ValidationException` в write transaction → HTTP `400`, insert отсутствует. |
| `dateTo = dateFrom` | Допустимо. |
| `contractDate` вне `[validFrom, validTo]` | Допустимо: такой проверки нет. |
| Даты в прошлом/будущем | Допустимо; сравнения с текущей датой нет. |

`dateFrom/dateTo` стабильно конвертируются через `ZoneId.of("UTC")`, а не системную timezone. Physical колонки `contract_date`, `valid_from`, `valid_to` nullable, хотя внешний DTO требует строки и mapping либо создаёт Instant, либо падает до insert.

## Lookup справочников и пограничные случаи

Client/Company ищутся через `SearchString` с default `EXACTLY_MATCHES_IGNORE_CASE`. В обеих physical таблицах просмотренные миграции не задают unique `edo_id`; `findFirst` при дублях выбирает одну запись без явной сортировки.

Blank или whitespace `_client`/`_company` проходит `@NotNull`, но `SearchString.isNotBlank` исключает такое условие из predicate. В результате выбирается первый произвольный Client/Company, если таблица непуста, вместо not-found. Это создаёт риск привязки договора к неверной стороне.

Currency ищется Spring Data методом `findByCode(code)`, то есть точным сравнением. В physical Currency также не найден unique code, несмотря на JPA `unique=true`; при дублях repository-метод, ожидающий один result, способен завершиться `IncorrectResultSizeDataAccessException`.

Поля `_client` и `_company` названы внешними ссылками, но имеют тип String, а не UUID: сервер не парсит их как UUID и сравнивает с `edoId`. `_id` договора также может быть любой строкой до DB length, не обязательно UUID.

## Physical Contract

По Liquibase chain актуальная таблица `contract` содержит:

- `id UUID PRIMARY KEY`, `code VARCHAR(100) NOT NULL`, `name VARCHAR(255)` nullable, `active BOOLEAN NOT NULL`;
- `sync_id UUID NOT NULL`, `edo_id VARCHAR(50)` nullable;
- `client_id`, `company_id`, `currency_id` — `UUID NOT NULL` с FK;
- `contract_date`, `valid_from`, `valid_to` — nullable timestamp without time zone;
- `contract_type VARCHAR(20) NOT NULL`; DB CHECK по `TOE/OX` не найден;
- `created_at/created_by NOT NULL`, update audit nullable;
- отдельная колонка `contract_number` удалена; `number` интеграции хранится в `code`;
- unique/index по `edo_id`, code или syncId в просмотренной цепочке не найден.

Источники: [создание Contract](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_ALG-49_add_table_contract.sql), [audit NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240708_ALG-248_set_created_by_created_at_not_null.sql), [syncId NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240822_ALG-784_make_sync_id_columns_not_null.sql), [edoId](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240906_ALG-737_add_edo_id_field.sql), [contract type](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250116_KIS-265_add_contract_type_to_table_contract.sql), [number → code](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250616_KIS-398_move_contract_number_to_code_of_table_contract.sql), [client FK rename](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250918_KIS-1623_RemoveClientTable_RenameLegalEntityTable.sql), [удаление contract_number](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260622_KIS-4162_remove_contract_number_from_contract.sql).

## Пользовательские endpoints Contract

Соседний [ContractController](../api/endpoints-generated.md#contractcontroller) предоставляет `/contract/all`, `/page`, `/meta/{fieldName}`, `GET /{id}`, create и update. Полный CRUD-контракт связан в [API клиентов и договоров](../api/client-contract-api.md#2-договоры-contract).

Это другой validation boundary:

- пользовательские create/update принимают [ContractCreationDto](../dto/catalog/contract/ContractCreationDto.md)/[ContractUpdateDto](../dto/catalog/contract/ContractUpdateDto.md) и запускают `@NotBlank name/code`, `@NotNull` полей и nested IdDto validation;
- Datareon принимает строковые external references и программно строит DTO без повторной Bean Validation;
- пользовательские page/get/create/update имеют `CLIENT_CONTRACT` permissions, `/contract/all` не имеет method-level `@Secure`, но глобальная security требует аутентификацию вне `/datareon/**`;
- пользовательский update работает по internal UUID и способен изменить существующий договор; Datareon endpoint update не вызывает.

## Ошибки HTTP

| Условие | Результат AS-IS |
|---|---|
| Нет body, JSON type mismatch, null обязательного поля, unknown `contractType` | HTTP `400`. |
| `validTo < validFrom` | HTTP `400` с validation error. |
| Unknown Client/Company | `IllegalStateWithCodeException` с `Client.NotFoundByEdoId` / `Company.NotFoundByEdoId`, но catch-all advice → HTTP `500`. Для Company context class ошибочно передаётся `ClientFilter.class`. |
| Unknown Currency | NPE в `ContractService.preAdd` → HTTP `500`. |
| Invalid date/dateFrom/dateTo | `DateTimeParseException` → HTTP `500`. |
| DB length/FK/non-duplicate integrity | HTTP `500`. |
| Возможный duplicate constraint | Текущий advice возвращает `409`, но business unique договора в миграциях не найден. |
| ~~Ошибка мониторинга~~ | **Удалено** 17 сентября 2026 (см. заметку выше) — строка описывала поведение до этой даты, сейчас мониторинга на этом пути нет вовсе. |

OpenAPI заявляет `406 Unique violation problems`, однако актуальный [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) использует `409` для duplicate и `500` для остальных неперехваченных/integrity ошибок. Ни content, ни error schema в endpoint declaration не указаны.

## Влияющие commits

| Commit | Влияние на текущий AS-IS |
|---|---|
| `b67b2971707c0a1d8e296b8b50071776376722ac` (10.09.2024) | Добавил Datareon contract DTO/controller/service, `edoId` и create-only flow. |
| `5de66acd108609c94e123e3e2639a2ee025f613c` (16.09.2024) | Перевёл ссылки на lookup по external IDs, добавил справочные ошибки и date range validation. |
| `6dd2b1060cb1f6c6625692510ae8de045345c32d` (`KIS-265`, 17.01.2025) | Добавил physical/JPA/CRUD `contractType NOT NULL`. |
| `ca20a974a6fc99ef40b2b675a250bfa7868eacfa` (`KIS-1230`, 28.05.2025) | Добавил `contractType` во внешний DTO и mapping. |
| `bcc7b08653f6c7896f4346ef404dce10989e4fb6` (`KIS-398`, 16.06.2025) | Перенёс номер договора в code. |
| `4212247da70d3ca69e7b3acd6a51f4a7f2bd68ef` / `a90b9076f153c8f9021b30e264bae782850505f1` (30.07–29.09.2025) | Объединили Client/LegalEntity и переименовали physical relation договора в client_id. |
| `ef2ea5afa102aa2b77f3f7cfc50a4181becadf05` (`KIS-3994`, 04.06.2026) | Перестроил ContractService create/update и повторное разрешение FK внутри transaction. |
| `7400c51cd27d3c07b48ad652c78ce5bcde7cee05` (`KIS-4162`, 06.07.2026) | Удалил deprecated contractNumber из Java и БД, оставив code. |
| `d3e370db11453f73e21ebead0eabcb89b9dd584a` / `5b45baf1941eff3349f5203c0c4c4b67681e50f8` / `84204c4bb53ca9567beccfccee3797cee8559d2d` | Добавили мониторинг и позднее убрали неэффективную class-level validation/служебные аннотации без добавления upsert. |

## Тестовая доказательность и расхождения исследований

[ContractEdoDatareonServiceTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/datareon/ContractEdoDatareonServiceTest.java) проверяет только mapping дат и найденных Client/Company/Currency. Он прямо допускает `name=null`; test fixture не задаёт `contractType` и не вызывает controller, `add`, physical DB или repeat. [ContractDaoServiceTest](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/contract/ContractDaoServiceTest.java) проверяет общий DAO add/find/filter/update с заполненным name, но не Datareon flow. Тесты не запускались.

Входной материал [«Интеграция договоров и контрагентов из 1С:ДО»](../../integrations/1c-edo-contract-with-contractor-api.md) верно отмечает create-only и предварительное наличие справочников, но требует уточнения: неизвестные Client/Company/Currency дают текущие `500`, `_id` не защищает от повторного insert, blank external references могут выбрать произвольную строку, name остаётся null, а отдельного outbound договора нет. Предложенный `/datareon/contract-with-client` и его единая транзакция/upsert/error contract остаются TO-BE и в коде отсутствуют. **Отдельно** от него, начиная с 18 сентября 2026 (коммит `f11ff7ba`, доработан `a912531c` 23 сентября 2026), в коде уже есть `POST /datareon/contract_with_contractor` — но это явно временный stub (`@Operation(description = "Temporary endpoint...")`), который принимает `JsonNode` любой формы, логирует его и ничего не сохраняет (`ContractEdoDatareonService`/БД не вызываются). Не путать со связанным, но другим по назначению TO-BE предложением выше.

Не подтверждены production payload, правила отбора 1С:ДО, gateway/auth вне source security, порядок Contractor→Contract, внешние retry и live schema. Для нового ТЗ необходимо явно определить upsert key, uniqueness, lookup errors, blank/format validation, date semantics, ответ, идемпотентность, конкурентность и атомарность клиента с договором.
