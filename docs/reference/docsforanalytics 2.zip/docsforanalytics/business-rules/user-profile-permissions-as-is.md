# Профиль пользователя и сводка прав AS-IS

Проверено относительно checkout `22fac945e8116d04972ccc87b06b2303acf7a561`. Контур — четыре source-level mappings [`UserInfoController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/userinfo/UserInfoController.java): личный профиль, сводка разрешений и две выборки доступных клиентов. Это **представление для клиента**, не гарантия фактического HTTP/row-level доступа. Базовая модель [ролей и permission forest](roles-permissions-as-is.md), [групп/клиентов](user-groups-client-restriction-as-is.md) и [прав отчётов](order-report-access-as-is.md) описана отдельно, без повторения всей матрицы. Runtime Spring context, JWT issuer/claims, Keycloak/БД и grants стенда не проверялись.

## HTTP и конкретные DTO

| Метод | Request → response | Источник права/данных |
|---|---|---|
| `GET /userInfo` | Без параметров → [`UserInfoDto`](../dto/catalog/userinfo/UserInfoDto.md), default `200` | [`UserInfoService.getDetailedUserInfo`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/userinfo/UserInfoService.java): профиль из Keycloak по текущему JWT `sub`, роли из JWT authorities, доступные client IDs из Keycloak groups + ALIS `client_user_group`. `@Secure` нет. |
| `GET /userInfo/all` | Без параметров → [`UserInfoWithPermissionsDto`](../dto/catalog/userinfo/UserInfoWithPermissionsDto.md), default `200` | Роли и username из JWT; `userPermissions` — максимум уровня по path из forest каждого сопоставленного role ID. `@Secure` нет. При пустых ролях controller создаёт monitoring incident, но не отказывает сам по этому условию. |
| `POST /userInfo/client/page` | Обязательный Spring body [`FilterWithPaging`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/FilterWithPaging.java)<[`ClientFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/client/ClientFilter.java)> → page<[`ClientDto`](../dto/catalog/client/ClientDto.md)> | `@Secure(Client:READ)`; [`ClientService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/client/ClientService.java) наследует `BasePageableService.getPage`, который передаёт фильтр в client restriction. |
| `POST /userInfo/client/meta/{fieldName}` | Path `fieldName`, body `FilterWithPaging<`[`ClientMetaFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/client/ClientMetaFilter.java)`>` → `List<IdsCodeDto>` | `@Secure(Client:READ)`; inherited [`BaseService.getMetaField`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) добавляет client restriction к filter перед meta query. |

Точный transport contract, Spring required, OpenAPI responses и links на handlers фиксирует [endpoint-каталог](../api/endpoints-generated.md). `UserInfoDto` содержит `userName`, `longName`, `phoneNumber`, `email`, `additionalEmail`, `userType`, `roles` и [`ClientShortDto`](../dto/catalog/client/ClientShortDto.md) список с `id/code/inn`. Extended DTO содержит `userName`, `roles` и `List<`[`PermissionModel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/PermissionModel.java)`>`; это не validation contract. Client page/meta request filters тоже не доказывают обязательность отдельного client ID.

Если [`ResourceServerSecurity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) активен по issuer URI, все четыре пути требуют authenticated JWT; два client POST дополнительно имеют method `@Secure`. GET profile/summary такого method gate не имеют. `@Secure(Client:READ)` для page/meta и displayed permission level не заменяют проверки фактического владельца каждого возвращаемого объекта.

## Источники профиля и рассогласование времени

[`SecurityUtils`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/utils/SecurityUtils.java) берёт UUID user ID из JWT `sub`, username — из `preferred_username`, а роли — из `ROLE_*` authorities. [`ResourceServerSecurity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) получает эти authorities из `realm_access.roles` token и отдельно `GROUP_*` из `groups` claim. `GET /userInfo` вызывает [`WmsKeycloakFacade.getUser`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/keycloak/WmsKeycloakFacade.java) по ID; возвращает username/full name/email/type, а phone/additional email — по [`KeycloakUserAttributeName`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/user/KeycloakUserAttributeName.java). [`KeycloakUser.getFullName`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/user/KeycloakUser.java) выбирает `longName`, затем `fullName`, затем компонует фамилию/имя/отчество. Сводный `/all` вместо Keycloak username использует текущий JWT `preferred_username` и вообще не читает профиль.

`GET /userInfo` берёт `roles` из предъявленного JWT, **не** из ответа `getUser`. Client IDs [`FilterEnrichServiceImpl.getAvailableEntitiesForUser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java) получает через [`ClientUserGroupService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientusergroup/ClientUserGroupService.java): текущая Keycloak user-group membership → `client_user_group` в ALIS → множество client UUID. Поэтому профиль, JWT roles и доступные клиенты могут представлять разные моменты после изменения роли/группы; скорость обновления JWT, Keycloak и БД на живой среде неизвестна. `GROUP_*` authority из token не является входом в этот client-ID lookup.

```mermaid
flowchart TD
    J[Текущий JWT sub/roles/username] --> P[GET /userInfo]
    J --> S[GET /userInfo/all]
    P --> K[Keycloak getUser sub → личные поля]
    P --> G[Keycloak getUserGroups sub]
    G --> D[ALIS CLIENT_USER_GROUP → client IDs]
    D --> C[ClientDaoService → id/code/inn]
    S --> R[Cached role name → UUID + permission forests]
    R --> M[Max level по каждому path]
```

## Сводка permission forest — не матрица фактического доступа

[`UserInfoService.getPermissions`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/userinfo/UserInfoService.java) сопоставляет имена ролей из JWT со списком `role name → UUID` в [`RolePermissionService`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionService.java), затем обходит forest каждой найденной роли. Если имя роли не попало в синхронизированный список, для него нет forest в summary. По одному permission `path` HashMap сохраняет node с наибольшим [`PermissionLevel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/base/PermissionLevel.java); список берётся из `map.values()` без явно заданной сортировки. Объект [`PermissionModel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/PermissionModel.java) содержит permission path/id/type/level и ID конкретной *persisted RolePermission row* либо `null`; он не обозначает, какая из нескольких ролей дала итоговый максимум.

Forest строится со всеми известными путями, включая `NO_ACCESS`, поэтому **наличие path в `userPermissions` не означает grant**. Реальный [`PermissionCheckStrategy`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategy.java) сравнивает enum permission и требуемый method level в актуальной для проверки map forest, а `@Secures` может применять OR/AND условия. Summary не включает фактические annotations каждого endpoint, row/client ownership, filter/body null handling или внешние gateway rules. Cache sync и уровни могут на момент двух последовательных запросов отличаться; runtime snapshot не установлен. Для анализа ТЗ нужно соединять displayed path/level с конкретным controller method и data-scope правилом, а не выводить доступ из одного DTO.

**Устарело (коммит `a5a40f94`, «remove datareon monitoring», 17 сентября 2026):** весь datareon-мониторинг удалён из кодовой базы — `MonitorClient`, `IncidentDto`/`IncidentType`/`IncidentSeverity` и вызов `logIncident` для пустого `roles` больше не существуют, замены не добавлено. При пустом `roles` контроллер теперь просто продолжает `getUserInfoWithPermissions()` и возвращает пустой permissions list без какой-либо фиксации инцидента (ни monitoring, ни лога). Ранее (до удаления) controller `/all` вызывал `MonitorClient.logIncident` с `AUTHENTICATION_ERROR/MEDIUM`; исходный `FeatureFlags` и `application.yaml` задавали monitoring flag с default `false`.

## Доступные клиенты: два пути и один пограничный дефект

`POST /userInfo/client/page` и `/meta` передают inner `ClientFilter`/`ClientMetaFilter` в [`FilterEnrichServiceImpl.addUserRestriction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java): для не-admin JWT оно вписывает доступные UUID в `client.anyOfId`; admin определяется по имени Keycloak admin role в JWT и обходит client enrichment. Если body `FilterWithPaging` содержит `filter=null`, enrichment не срабатывает; конкретный DAO/meta behavior требует отрицательного HTTP теста. Пустое пересечение requested/available `anyOfId` и его [deny-by-default риск](user-groups-client-restriction-as-is.md#ограничение-клиента-при-чтении) отдельно разобраны в документе групп.

`GET /userInfo` строит client list **другим путём**: [`UserInfoService.mapToClientShortDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/userinfo/UserInfoService.java) вызывает `clientDaoService.findAll(ClientFilter.builder().anyOfId(availableClients).build())` напрямую, без `FilterEnrichServiceImpl.addUserRestriction`. Если `availableClients` — пустое множество, [`BaseIdentifierPredicate`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/predicate/BaseIdentifierPredicate.java) добавляет `id IN (...)` только при `CollectionUtils.isNotEmpty(anyOfId)` и игнорирует пустой set. Поэтому при корректном JWT user ID, но отсутствии групповых client links source-level профиль способен вернуть **весь список клиентов** вместо `[]` (при прочих условиях пустого фильтра). Это вывод из DAO/predicate chain, не проведённый production HTTP test. Даже при `userId=null` service сначала вызывает Keycloak `getUser(null)`, так что такой request может упасть раньше этой ветки; null-identity leakage здесь отдельно не утверждается.

```mermaid
flowchart TD
    A[Keycloak groups + CLIENT_USER_GROUP] --> I[available client IDs]
    I -->|непусто| F[GET profile: ClientFilter.anyOfId = IDs]
    F --> Q[Client DAO id IN IDs]
    I -->|пусто| E[GET profile: anyOfId = empty set]
    E --> B[BaseIdentifierPredicate игнорирует empty set]
    B --> L[Source-level риск: все Client rows]
    I --> P[POST page/meta: restriction enrichment]
    P --> H[@Secure Client:READ + client predicate]
```

## Тесты, история и вопросы для ТЗ

[`UserInfoServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/userinfo/UserInfoServiceIntegrationTest.java) с mocked Keycloak и FilterEnrichService проверяет положительный профиль для двух доступных клиентов и роли JWT на isolated Postgres. Он не покрывает пустое множество, `/all` permission merge/NO_ACCESS, client page/meta HTTP/RLS, JWT-profile drift или monitoring behavior. Соседний [`PermissionCheckStrategyTest`](../../../web-layer/src/test/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategyTest.java) проверяет method-level сравнение с mocks, но не UserInfo API. Тесты не запускались; прямых тестов четырёх UserInfo mappings source-wide поиск не нашёл.

| Commit | Подтверждённое влияние |
|---|---|
| `2d3d0f45` (2025-12) | Добавлен UserInfo профиль, клиентские IDs и JWT роли в response |
| `cdae4eec` (2026-01) | В краткий client DTO добавлен `inn` |
| `d3aceae5` (2026-06) | Добавлены client page/meta UserInfo endpoints с `Client:READ` |
| `0ab5f3ae` (2026-08) | Spring Boot upgrade warning fixes в данном source contour |

Для ТЗ различать profile username и JWT username, cache snapshot summary и фактический method gate, `NO_ACCESS` path и grant, показанный клиент и row-level ownership. Для подтверждения пустого client list нужны negative integration/HTTP tests на Client DAO/UserInfo, для actual grants — live JWT/Keycloak/RolePermission и данные БД. Источники вне ALIS/Keycloak/gateway по именам DTO не выводятся.
