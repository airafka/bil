# Company и Currency для договоров: AS-IS справочников

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 14.09.2026): доступные HTTP endpoints Company/Currency, фильтрацию, permissions, DTO, сервисы и physical constraints, а также их роль как обязательных предварительных данных для [`POST /datareon/contract`](contract-edo-datareon-as-is.md). Работающее приложение, production-наполнение справочников, применённая схема БД и внешние загрузчики не проверялись.

## Главный вывод

Company и Currency представлены в ALIS только read endpoints. В текущих controllers нет create, update, delete, synchronize или Datareon import для этих сущностей. В business source также не найдены вызовы `CompanyDaoService.add/update` или `CurrencyDaoService.add/update`; Liquibase создаёт таблицы и permission paths, но не загружает справочные строки.

Следовательно, исходники этого репозитория не объясняют, каким штатным runtime-процессом в БД появляются:

- `Company.edoId`, по которому `_company` договора разрешается без учёта регистра;
- `Currency.code`, по которому поле `currency` договора ищется точным repository-запросом.

Для ТЗ нельзя считать создание этих prerequisites частью `/datareon/contract`: они должны существовать заранее, а источник и владелец их загрузки требуют отдельного внешнего подтверждения.

## Endpoints и DTO

Полный декларативный inventory находится в разделах [CompanyController](../api/endpoints-generated.md#companycontroller) и [CurrencyController](../api/endpoints-generated.md#currencycontroller).

| Метод и путь | Request | Response | Method permission | Серверная логика |
|---|---|---|---|---|
| `POST /company/all` | `FilterWithPaging<CompanyFilter>`, body объявлен `required=false` | `List<CommonDto>`: `id`, `code`, `active`, `name` | отсутствует | User restriction неприменим к обычному CompanyFilter; QueryDSL-фильтр и pageInfo, затем short mapping. |
| `GET /company/{id}` | path UUID | [CompanyDto](../dto/catalog/company/CompanyDto.md) | `COMPANY/READ` | Поиск по internal UUID, полный DTO либо `404`. |
| `POST /company/meta/{fieldName}` | `FilterWithPaging<CompanyMetaFilter>` | `List<IdsCodeDto>` | `COMPANY/READ` | Группирует internal IDs по выбранному простому полю entity. |
| `POST /currency/all` | `FilterWithPaging<CurrencyFilter>`, body объявлен `required=false` | `List<CommonDto>` | отсутствует | QueryDSL-фильтр и pageInfo, затем short mapping. |
| `GET /currency/{id}` | path UUID | [CurrencyDto](../dto/catalog/currency/CurrencyDto.md) | `CURRENCY/READ` | Поиск по internal UUID, полный DTO либо `404`. |
| `POST /currency/meta/{fieldName}` | `FilterWithPaging<CurrencyMetaFilter>` | `List<IdsCodeDto>` | `CURRENCY/READ` | Группирует internal IDs по выбранному простому полю entity. |

Все маршруты вне `/datareon/**` требуют authentication глобальной security chain. Поэтому `/all` без method-level `@Secure` доступен любому аутентифицированному запросу, прошедшему остальные фильтры, тогда как detail/meta требуют соответствующее READ permission.

Class-level controller mapping задаёт `consumes=application/json` даже для `GET /{id}`. Generated-каталог сохраняет эту декларацию; фактическое поведение клиента/proxy без `Content-Type` runtime не проверялось.

## Фильтры и фактическая обязательность body

CompanyFilter поддерживает inherited `id/code/name/active/audit` и собственные `syncId`, `inn`, `kpp`, `okpo`, `ogrn`, `edoId`, адреса и данные подписанта. CurrencyFilter добавляет `codeOkvNum` к inherited полям. Строковые условия представлены `SearchString`; если type отсутствует, используется `EXACTLY_MATCHES_IGNORE_CASE`.

Несмотря на `@RequestBody(required=false)`, `/company/all` и `/currency/all` фактически не работают без wrapper: `BaseService.getAllShort` сразу обращается к `filter.getFilter()`. Пустое тело приводит к NPE/HTTP `500`. Wrapper без `pageInfo` также доходит до разыменования pagination object. Практический минимальный запрос должен содержать pageInfo, например:

```json
{
  "pageInfo": {
    "page": 0,
    "size": 25
  },
  "filter": null
}
```

Meta body обязателен на уровне Spring. `fieldName` динамически разрешается через JPA metamodel после удаления не буквенно-цифровых символов. Неизвестное поле даёт `404`; collection/association или недопустимый промежуточный путь — validation `400`. Это не фиксированный whitelist: для Company доступны простые поля, включая `edoId` и реквизиты, при наличии `COMPANY/READ`.

## Выходные модели

[CompanyDto](../dto/catalog/company/CompanyDto.md) возвращает `id/code/active/name`, `syncId`, `inn`, `kpp`, `okpo`, `ogrn`, `edoId`, юридический/фактический адрес, ФИО/должность подписанта и `okved`. [CurrencyDto](../dto/catalog/currency/CurrencyDto.md) возвращает `id/code/active/name` и `codeOkvNum`.

Это response DTO без Bean Validation. В Company/Currency controllers нет request DTO создания или обновления. Наличие generic `CompanyService.add/update` и `CurrencyService.add/update` в наследуемом Java API не публикует HTTP-операцию и не доказывает внешний способ наполнения.

## Prerequisites договора

```mermaid
flowchart TD
    EXT[Не установленный в репозитории<br/>источник справочников] --> CP[(Company<br/>edoId должен быть заполнен)]
    EXT --> CU[(Currency<br/>code должен быть заполнен)]
    READ[Read-only Company/Currency endpoints] --> CP
    READ --> CU
    P[POST /datareon/contract] --> PC[_company: @NotNull String]
    P --> PU[currency: @NotNull String]
    PC --> LC[CompanyFilter.edoId<br/>EXACTLY_MATCHES_IGNORE_CASE]
    LC --> CP
    PU --> LU[CurrencyRepository.findByCode<br/>точное сравнение]
    LU --> CU
    CP --> TX[ContractService.add]
    CU --> TX
    TX --> FK[(contract.company_id/currency_id<br/>NOT NULL FK)]
```

Lookup не проверяет `active`, поэтому неактивные Company/Currency также могут быть связаны с новым договором.

Для Company `findFirst` не задаёт сортировку. Blank/whitespace `_company` проходит внешнее `@NotNull`, `SearchString.isNotBlank` снимает edoId-predicate, и сервис способен выбрать первую произвольную Company. При неизвестном непустом edoId выбрасывается `IllegalStateWithCodeException("Company.NotFoundByEdoId")`, но текущий advice не имеет отдельного handler и отвечает `500`; context ошибочно содержит `ClientFilter.class`.

Для Currency используется `CurrencyRepository.findByCode(String)`: сравнение не переводится в lower case и не trim-ится. Неизвестный code преобразуется в `null`, затем `ContractService.preAdd` разыменовывает `currency.id`, что даёт NPE/HTTP `500`. При двух physical строках с одинаковым code repository-метод, ожидающий один результат, способен дать `IncorrectResultSizeDataAccessException`/HTTP `500`.

## Повторы и дубли prerequisites

```mermaid
flowchart LR
    C1[(Company A<br/>edoId=X)] --> F[findFirst без sort]
    C2[(Company B<br/>edoId=X)] --> F
    F --> R[Одна из строк<br/>выбор не определён]
    U1[(Currency A<br/>code=RUB)] --> Q[findByCode]
    U2[(Currency B<br/>code=RUB)] --> Q
    Q --> E[Ожидался один result<br/>возможен HTTP 500]
```

В просмотренной Liquibase chain нет unique или index для `company.edo_id`, `company.sync_id`, `company.code`, `currency.code` либо `currency.code_okv_num`. JPA inherited `BaseIdCode.code` объявляет `unique=true`, но это не отражено в migration DDL; источником physical AS-IS считается Liquibase/applied schema, а applied schema не проверена.

Так как backend не предоставляет write/import endpoints этих справочников, правила дедупликации, нормализации регистра/пробелов, конкурентного создания и назначения external ID в репозитории отсутствуют.

## Physical Company

По Liquibase chain таблица `company` содержит:

- `id UUID PRIMARY KEY`;
- `code VARCHAR(100) NOT NULL`, `name VARCHAR(255)` nullable, `active BOOLEAN NOT NULL`;
- `sync_id UUID NOT NULL` после backfill случайным UUID;
- `inn VARCHAR(12)`, `kpp VARCHAR(9)`, `okpo VARCHAR(10)`, `ogrn VARCHAR(13)`, `edo_id VARCHAR(46)` — nullable;
- `address_legal/address_fact VARCHAR(1000)`, `signatory_name/signatory_position VARCHAR(50)` — nullable;
- `okved TEXT[]` nullable;
- `created_at/created_by NOT NULL`, update audit nullable;
- unique/check/index для business identifiers в просмотренной цепочке не найдены.

Источники: [создание Company](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_ALG-57_add_table_company.sql), [OKVED](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240729_ALG-417_alter_table_company.sql), [audit NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240708_ALG-248_set_created_by_created_at_not_null.sql), [syncId backfill/NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240822_ALG-784_make_sync_id_columns_not_null.sql).

## Physical Currency

Таблица `currency` содержит:

- `id UUID PRIMARY KEY`;
- `code VARCHAR(100) NOT NULL`, `name VARCHAR(250)` nullable, `active BOOLEAN NOT NULL`;
- `code_okv_num VARCHAR(4) NOT NULL`;
- `created_at/created_by NOT NULL`, update audit nullable;
- `syncId` и `edoId` отсутствуют;
- справочные INSERT и unique/check/index в просмотренной Liquibase chain не найдены.

JPA inherited `BaseNamed.name` объявляет length 255, тогда как physical Currency ограничивает имя 250 символами. Источники: [создание Currency](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v.1.0.0_ALG-58_add_table_currency.sql) и [audit NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240708_ALG-248_set_created_by_created_at_not_null.sql).

## Ошибки HTTP

| Сценарий | Результат AS-IS |
|---|---|
| `/all` без body или без пригодного pageInfo | NPE в inherited list flow → HTTP `500`, несмотря на `required=false`. |
| Невалидный UUID в `GET /{id}` | HTTP `400`. |
| UUID корректен, запись отсутствует | `NotFoundException` → HTTP `404`. |
| Нет authentication | Запрос отклоняется resource-server security. |
| Нет COMPANY/CURRENCY READ на detail/meta | `AccessDeniedException` → HTTP `403`. |
| Неизвестный meta field | `NotFoundException` → HTTP `404`. |
| Meta field является collection/association | `ValidationException` → HTTP `400`. |
| Дубль Currency.code при lookup договора | Возможная incorrect-result ошибка → HTTP `500`. |
| Company/Currency отсутствует при импорте договора | Текущий результат HTTP `500`, но по разным причинам, описанным выше. |

## Влияющие commits

| Commit | Влияние на текущий AS-IS |
|---|---|
| `11de138554ed6935c9906dd7f5716bef8f8c1889` (26.08.2024) | Исходные Company/Currency models, таблицы, read-only controllers, services, filters и DAO tests. |
| `0e530be7b92c4e0f03dc800f126a0c4fe2dbd4fb` (18.09.2024) | Backfill и physical `company.sync_id NOT NULL`. |
| `b67b2971707c0a1d8e296b8b50071776376722ac` / `5de66acd108609c94e123e3e2639a2ee025f613c` (10–16.09.2024) | Добавили Contract Datareon flow и актуальный lookup Company/Currency prerequisites. |
| `3b299749ede9947a24dc618f0d9c182e708932be` (`KIS-3945`, 11.06.2026) | Добавил отдельные `/company/meta/{fieldName}` и `/currency/meta/{fieldName}` и typed permissions. |

## Тестовая доказательность и границы

[CompanyDaoServiceTest](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/company/CompanyDaoServiceTest.java) и [CurrencyDaoServiceTest](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/currency/CurrencyDaoServiceTest.java) напрямую создают тестовые entities и проверяют generic DAO add/find/page/update. Они не доказывают наличие HTTP write endpoints, production seed/import, uniqueness или prerequisite lookup.

[MetaEndpointIntegrationTest](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/controller/MetaEndpointIntegrationTest.java) проверяет общий meta engine и использует Company/Currency как fixtures договоров, но не вызывает их собственные endpoints. [ContractEdoDatareonServiceTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/datareon/ContractEdoDatareonServiceTest.java) mock-ирует успешное разрешение одной Company и одной Currency; unknown/blank/duplicate/inactive cases не покрывает. Тесты не запускались.

Не подтверждены production owner справочников, загрузка Company и Currency, source of truth, расписание/transport, формат external Company ID, набор валют, правила активности, очистка/дедупликация и applied constraints. Для нового ТЗ эти prerequisites должны быть либо частью атомарного интеграционного процесса, либо отдельным явно документированным договором загрузки с unique keys и управляемыми ошибками.
