# Партии товаров и Datareon: AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026): `POST /datareon/batch` от JSON до [Batch](../entities/catalog/entities/batch/Batch.md), его повторную обработку, ошибки, транзакции и связь с [GoodRemain](good-remain-inbound-as-is.md). Бизнес-код, миграции и конфигурация не изменялись; работающий endpoint, Datareon/WMS и применённая схема БД не проверялись.

## HTTP-контракт

Endpoint находится в [DatareonController](../api/endpoints-generated.md#datareoncontroller):

| Метод и путь | Request | Response и доступ |
|---|---|---|
| `POST /datareon/batch` | [`BatchDatareonDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/batch/BatchDatareonDto.java) | `200` без тела; текущая security-конфигурация разрешает `/datareon/**` без аутентификации. |

DTO лежит в `datareon/dto`, вне текущего generated DTO-каталога, поэтому ссылка ведёт непосредственно на Java-источник. OpenAPI заявляет только `200` и `400`, без content/error schema.

Controller сначала вызывает best-effort мониторинг пакета, затем предметный сервис. Для monitor ID используется `String.valueOf(MessageID)`: при `MessageID=null` передаётся буквальная строка `"null"`. Ошибки HTTP мониторинга перехватываются `MonitorClient` и не отменяют импорт.

## DTO и обязательность

На body стоит `@Valid`, однако в `BatchDatareonDto` и nested `Batch` нет Bean Validation-аннотаций и нет каскадного `@Valid` на списке. Поэтому декларативно ни одно JSON-поле не обязательно. Фактические требования возникают позднее из lookup, парсинга дат, DAO-validation и DB constraints.

| JSON | Java-тип | Фактическая семантика AS-IS |
|---|---|---|
| `MessageID` | UUID | Только мониторинг и application log ошибки; не сохраняется и не дедуплицируется. Невалидный UUID не десериализуется и даёт `400`. |
| `batch` | array | `null` или пустой список → тихий `200` без изменений. Элементы обрабатываются последовательно и независимо. |
| `number` | String | Код партии и часть lookup `(ClientGood, code)`; trim/нормализации нет. DTO не запрещает blank/null. |
| `item` | UUID | `ClientGood.syncId`; неизвестный/null → ошибка только этого элемента. |
| `issueDate` | String | Всегда парсится в `LocalDateTime` и затем через системную timezone; null, offset (`Z`/`+03:00`) или иной invalid format → ошибка элемента. |
| `expirationDate` | String | То же; сравнения с issueDate и текущей датой нет. |
| `barcode` | String | Полностью перезаписывает `batchBarcode`, включая `null`; DTO не ограничивает длину, DB — 50 символов. |
| `syncId` | UUID | Integration ID. Обязателен для create из-за DB `NOT NULL UNIQUE`; при update `null` сохраняет прежнее значение, ненулевое другое значение его заменяет. |
| `type` | `BatchAccountingType` | Принимаются только точные enum-имена `EXPIRATION_DATE`, `MANUFACTURE_DATE`, `NOT_USED`. Blank/unknown, включая русское display-name, custom deserializer превращает в `null`, а не в HTTP `400`. |
| `active` | primitive boolean | Отсутствующее значение десериализуется как `false`, но **поле полностью игнорируется сервисом**. |

Новая Batch получает inherited default `active=true`; существующая сохраняет прежний active независимо от входа. Таким образом `active=false` не деактивирует партию, а повтор `active=true` её не активирует.

## Серверный алгоритм

```mermaid
flowchart TD
    A[POST /datareon/batch] --> M[Monitor по MessageID]
    M --> E{batch null/empty?}
    E -->|да| OK[HTTP 200 без изменений]
    E -->|нет| N[Следующий элемент]
    N --> TX[REQUIRES_NEW transaction]
    TX --> CG[Найти ClientGood по item=syncId]
    CG --> FIND[Найти Batch по ClientGood.id + code<br/>ignore case]
    FIND --> EXISTS{Найдена?}
    EXISTS -->|нет| CREATE[UUID id; syncId из входа;<br/>active default true]
    EXISTS -->|да| UPDATE[Сохранить id/active;<br/>при ненулевом входе заменить syncId]
    CREATE --> MAP[Перезаписать type/code/dates/barcode;<br/>createdBy=DATAREON]
    UPDATE --> MAP
    MAP --> SAVE{create или update}
    SAVE -->|успех| COMMIT[Commit элемента]
    SAVE -->|ошибка| ROLLBACK[Rollback элемента; application log]
    COMMIT --> MORE{Есть ещё?}
    ROLLBACK --> MORE
    MORE -->|да| N
    MORE -->|нет| OK2[HTTP 200 без статистики]
```

Каждый элемент выполняется через отдельный `TransactionTemplate` с `PROPAGATION_REQUIRES_NEW`. Ошибка откатывает только текущий элемент, перехватывается внешним циклом и записывается только в application log. В отличие от остатков, для Batch нет persistent integration log/details, счётчиков успеха/ошибок и response body. Поэтому пакет с одной, несколькими или всеми ошибочными строками штатно возвращает одинаковый `200`.

`null`-элемент является исключением из этой схемы: transaction падает при первом обращении к элементу, после чего `catch` снова вызывает `sourceBatch.getNumber()/getSyncId()/getGoodId()` для логирования. Этот повторный `NullPointerException` выходит из цикла и даёт общий HTTP `500`; предыдущие элементы уже закоммичены.

## Поиск и update semantics

ClientGood ищется по точному `syncId`. Партия затем ищется **не по входному `syncId`**, а по:

```text
ClientGood.id + Batch.code (EXACTLY_MATCHES_IGNORE_CASE)
```

Для найденной строки сервер сохраняет её `id` и active, но полностью заменяет type, code, manufactureDate, expirationDate и barcode. Если входной `syncId` ненулевой и отличается, существующий integration ID также заменяется. Вызов `setCreatedBy(DATAREON)` выполняется и для update, но physical поле `created_by` унаследовано как `updatable=false`, поэтому существующее значение БД штатно не перезаписывается этой строкой.

Следствия ключа:

- тот же ClientGood и code в другом регистре считаются существующей партией; code меняет регистр на входной;
- тот же `syncId`, но новый number не переименовывает партию: lookup промахивается, create конфликтует с global `sync_id UNIQUE`, ошибка скрывается за HTTP `200`;
- тот же number/ClientGood с новым `syncId` меняет integration ID существующей строки;
- одинаковый number у разных ClientGood допустим физическим composite unique;
- повтор одного ключа внутри пакета обрабатывается последовательно, поэтому последний успешный элемент перезаписывает поля предыдущего.

`BatchDaoService.add` запрещает create с `type=NOT_USED` и create для ClientGood, у которого собственный `batchAccountingType=NOT_USED`. При этом он не требует равенства входного type и типа ClientGood. Update идёт через inherited `update` и **не вызывает эту validation**: существующую партию можно обновить до `NOT_USED`, хотя создать такую нельзя. Unknown/blank type превращается в `null` и отклоняется DB `NOT NULL` как при create, так и при update.

## Повторы и конкурентность

| Ситуация | Результат AS-IS |
|---|---|
| Повтор `MessageID` | Полный новый проход; idempotency отсутствует. |
| Повтор того же элемента | Update по ClientGood+case-insensitive code; даты/type/barcode и, возможно, syncId заменяются. |
| Элемент отсутствует в новом пакете | Партия остаётся; delete/deactivate нет. |
| Два новых одинаковых ключа в одном пакете | Последовательно create, затем update. |
| Два параллельных HTTP с одинаковым новым ключом | Оба могут не найти строку; один конфликтует на DB unique, но оба HTTP обычно `200`. |
| Параллельные code с разным регистром при отсутствии строки | Application lookup считает их одним ключом, но race до insert возможен; case-sensitive DB composite unique может допустить обе строки. |
| Параллельные update одной партии | Нет row lock/`@Version`; итоговые поля last-commit-wins. |
| Ошибка позднего элемента | Предыдущие `REQUIRES_NEW` commits сохраняются. |

Параллельный create с одинаковым `syncId`, но разными business keys, разрешается глобальным `sync_id UNIQUE`: одна строка откатывается. Какой HTTP-пакет фактически победит, сервис вызывающей стороне не сообщает.

## Физические ограничения

По цепочке миграций текущая physical-модель Batch включает:

- `id UUID PRIMARY KEY`;
- `client_good_id UUID NOT NULL` с FK;
- `sync_id UUID NOT NULL UNIQUE`;
- composite unique `(code, client_good_id)`;
- `active`, `batch_accounting_type`, `manufacture_date`, `expiration_date`, `created_at`, `created_by` — `NOT NULL`;
- `code` nullable и до 100 символов, `batch_barcode` nullable и до 50 символов;
- отдельный `client_id` удалён: клиент выводится через `ClientGood.client`.

JPA inherited `BaseIdCode.code` помечен `unique=true`, но просмотренные миграции задают именно composite unique, а не global unique code. Применённая схема не проверялась, поэтому физическим основанием документа считается Liquibase chain, а не возможный schema-generation DDL.

Нет DB CHECK или server validation для `expirationDate >= manufactureDate`, непрошедшей даты, соответствия `type` настройке ClientGood и смысла barcode. Date conversion использует `ZoneId.systemDefault()`, поэтому одинаковая local datetime может стать разным Instant при разной timezone процесса.

Источники: [исходная Batch](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240711_ALG-257_add_table_batch.sql), [expiration date](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250311_KIS-384_add_expiration_date_for_batch_table.sql), [sync_id](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250414_KIS-930_add_sync_id_to_batch.sql), [composite unique](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251211_KIS-2219_add_unique_index_for_client_good_id_and_code_for_batch_table.sql), [sync_id NOT NULL](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251211_KIS-2219_set_not_null_sync_id_in_batch_table.sql), [удаление client_id](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260211_KIS-3144_remove_client_id_from_batch.sql).

## Связь с GoodRemain и другими Batch endpoints

```mermaid
flowchart LR
    BD[POST /datareon/batch] -->|создаёт/меняет syncId| B[(Batch)]
    GR[POST /datareon/remain] -->|поле batch ищется по Batch.syncId| B
    WMS[POST /batch/synchronize] -->|другой WMS GET; только новые syncId| B
    CRUD[/batch all/page/create/id] --> B
    WR[WMS_RECEIVING_RESULT / WMS_SHIPMENT_RESULT] -->|createOrUpdateBatch: ClientGood + code| B
    WU[WMS result для строки batchUnknown] -->|resolveUnknownBatch: только syncId| B
```

Дополнение 15.10.2026 (сверено на `729c9a17`): кроме Datareon-пакета, партии пишут входящие WMS-результаты заявок ([поставка](receiving-inbound-actions.md#wms_receiving_result), [вывоз](shipping-inbound-actions.md#wms_shipment_result)) через [`BaseWmsResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseWmsResultAction.java):

- `createOrUpdateBatch` — существующий writer: lookup по `ClientGood.id + code` (`SearchString` по умолчанию — `EXACTLY_MATCHES_IGNORE_CASE`, как у Datareon); ненулевой входной `syncId` заменяет integration ID; type берётся из WMS.
- `resolveUnknownBatch` — **третий writer**, с 13.10.2026 (`8ee1ab68`, KIS-4841), вызывается только для товарной строки с `batchUnknown=true`. Lookup **только по `syncId`**; партия другого `ClientGood` → `IllegalArgumentException` «Actual batch belongs to another client good»; новая создаётся с `active=true`, найденная обновляется. `batchAccountingType` берётся из `ClientGood`, а не из WMS; code/даты/barcode — из WMS. Иной ключ поиска, чем у двух других writer-ов: при известном коде и новом `syncId` возможен конфликт composite unique (`INFERENCE`).

Для [GoodRemain inbound](good-remain-inbound-as-is.md) поле `batch` фактически обязательно и разрешается по `Batch.syncId`. Поэтому скрытая ошибка batch-пакета либо замена syncId существующей партии приводит к последующей row error остатка, но оба Datareon endpoint могут вернуть `200`.

Соседний [BatchController](../api/endpoints-generated.md#batchcontroller) — другой контракт:

- `/batch/all`, `/batch/page`, `POST /batch`, `GET /batch/{id}` используют `BatchFilter`, [BatchCreationDto](../dto/catalog/batch/BatchCreationDto.md) и [BatchDto](../dto/catalog/batch/BatchDto.md); page/create/id защищены `BATCH` permissions, `/all` method-level `@Secure` не имеет;
- `POST /batch/synchronize` запускает отдельный синхронный WMS GET `/hs/ExchangeNSI/Batches`, пропускает null/already-existing syncId и `NOT_USED`, добавляет только новые партии и также не возвращает статистику;
- публичных update/delete методов в `BatchController` нет.

Эти endpoints перечислены для разграничения, но их полный CRUD/WMS lifecycle не подменяет Datareon-алгоритм этого документа.

## Ошибки HTTP

| Условие | Внешний результат |
|---|---|
| Невалидный JSON/UUID root или body отсутствует | Jackson/Spring → HTTP `400`. |
| `batch=null`/пустой | HTTP `200`, изменений нет. |
| Unknown ClientGood, invalid date, `NOT_USED` при create, DB null/length/unique | Текущий элемент rollback; application log; пакет обычно HTTP `200`. |
| Unknown/blank `type` | Десериализуется в `null`; поздний DB error элемента; обычно HTTP `200`, не `400`. |
| `null`-элемент списка | Повторный NPE в catch/logging → HTTP `500`, ранние элементы сохранены. |
| Ошибка мониторинга | Логируется внутри MonitorClient; предметная обработка продолжается. |

Глобальный формат ошибок для не перехваченных исключений задаёт [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java). Перехваченные element errors в response не отражаются.

## Влияющие commits

| Commit | Влияние на текущее поведение |
|---|---|
| `bd0669045e469c1735ca65ee248cc23e62b011bf`, 21.08.2025, `KIS-1556 Added processing of batch for datareon...` | Добавил DTO/endpoint/service Datareon Batch и отделил создание Batch от GoodRemain. |
| `0d23560a8d924e6551206b79c2c6999584d5f041`, 10.10.2025, `KIS-1774 Changed searching of batch existence` | Заменил поиск по syncId на текущий ClientGood + code. |
| `82ff0e096eec05cdf69e16e89054f4461a8c0eea`, 22.10.2025, `KIS-1801 Added override of sync_id...` | Разрешил ненулевому входному syncId заменять integration ID найденной партии. |
| `962cffd827ea5142b84ba8aab457a76d67a9e4a7`, 27.10.2025, `KIS-1710 add error codes when add batch` | Сосредоточил accounting-type validation только в DAO add, оставив update без неё. |
| `fe5e73c1a275abc808041c4ffa4a5a51d6275f58`, 12.12.2025, `KIS-2219 add unique constraint for batch and make sync_id not null` | Добавил physical composite unique и `sync_id NOT NULL`; в `dev` изменения пришли через merge `528d650c…`. |
| `625193966dc176a44095bdcc62dd4894be1de5c3`, 19.02.2026, `KIS-3144 the data type in the batch package has been changed...` | Перевёл payload на список, добавил per-item `REQUIRES_NEW`, partial processing и единственный integration test. |
| `8ee1ab68`, 13.10.2026, `KIS-4841 add batchUnknown` | Datareon-алгоритм не меняет; добавил третий writer партий `resolveUnknownBatch` во входящих WMS-результатах (см. выше). |

## Тесты и граница доверия

[BatchDatareonServiceIntegrationTest](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/datareon/service/batch/BatchDatareonServiceIntegrationTest.java) содержит один сценарий: валидная строка сохраняется, строка с неизвестным ClientGood пропускается, обработка продолжается. Он проверяет service напрямую, не HTTP/monitoring/OpenAPI.

Не найдены проверки create vs update всех полей, игнорирования active, enum deserializer, дат/timezone, null/empty/null-element, syncId replacement/conflict, case-insensitive lookup против DB constraint, параллельности и связи с GoodRemain. Тест на этом подэтапе не запускался.

Для ТЗ нельзя считать `MessageID` idempotency key, `syncId` ключом поиска, `active` применяемым полем, все element errors HTTP-ошибками или пакет единой транзакцией. Эти гарантии отсутствуют в текущем backend AS-IS.
