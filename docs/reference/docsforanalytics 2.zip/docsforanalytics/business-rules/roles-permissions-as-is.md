# Роли и разрешения, часть 1 AS-IS

Проверено относительно commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Контур включает 17 source-level WMS mappings четырёх контроллеров: роли Keycloak, назначение ролей пользователям, записи `RolePermission` и чтение `PermissionPath`. Их подключение к текущему ALIS component scan разобрано в [каталоге API](../api/endpoints-generated.md); регистрация Spring context, применённые миграции и работающий Keycloak не проверялись. Для использования этих данных в ТЗ важно различать: имя роли/назначение пользователя хранится в Keycloak, path и level разрешения — в БД ALIS, а проверка HTTP метода использует текущий JWT плюс локальный permission forest. [Матрица прав отчётов](order-report-access-as-is.md) — пример потребителя этой модели.

## HTTP и реальные DTO

| Группа | Методы / требуемое право | Request → response / источник |
|---|---|---|
| [RoleController](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/role/RoleController.java) | `POST /role/all`, `POST /role/page`, `GET /role/{id}`, `POST /role/meta/{fieldName}` — `Role:READ`; `POST /role` — `Role:CREATE`; `PUT /role/` — `Role:WRITE`; `DELETE /role/{id}` — `Role:DELETE` | Чтение: [`FilterWithPaging`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/FilterWithPaging.java)<[`KeycloakRoleFilter`](../dto/catalog/wms/role/KeycloakRoleFilter.md)> → [`RoleDto`](../dto/catalog/wms/role/RoleDto.md)/page/meta. Запись: [`RoleCreationDto`](../dto/catalog/wms/role/RoleCreationDto.md), [`RoleUpdateDto`](../dto/catalog/wms/role/RoleUpdateDto.md) → `RoleDto`. `all` body optional; `page`/meta body required. |
| [UserRoleController](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/role/UserRoleController.java) | `GET /user/{userId}/role` — `User.UserRole:READ`; `POST /user/{userId}/role/{roleId}` — `WRITE`; `DELETE` того же path — `DELETE` | UUID пользователя/роли в path; GET → Page<`RoleDto`>, assignment/unassignment → `RoleDto`. OpenAPI annotation у assignment объявляет `CommonDto`, но Java method возвращает `RoleDto`. |
| [RolePermissionController](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/permission/RolePermissionController.java) | `GET /role/{roleId}/permission/tree`, `POST /role/{roleId}/permission/meta/{fieldName}` — `Role.RolePermission:READ`; `POST /role/{roleId}/permission` — `CREATE`; `PUT /role/{roleId}/permission/{id}` — `WRITE`; `DELETE` того же path — `DELETE` | Tree → [`TreeRolePermissionDto`](../dto/catalog/wms/permission/TreeRolePermissionDto.md); meta → grouped `IdsCodeDto`; write: [`RolePermissionCreationDto`](../dto/catalog/wms/permission/RolePermissionCreationDto.md), [`RolePermissionUpdateDto`](../dto/catalog/wms/permission/RolePermissionUpdateDto.md) → [`RolePermissionDto`](../dto/catalog/wms/permission/RolePermissionDto.md). |
| [PermissionPathController](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/permission/PermissionPathController.java) | `POST /permissionPath/all`, `GET /permissionPath/{id}` — строковый `Role.PermissionPath:READ` | Optional [`FilterWithPaging`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/FilterWithPaging.java)<`CommonIdFilter`> либо UUID → [`PermissionPathDto`](../dto/catalog/wms/permission/PermissionPathDto.md). Указанное строковое право не соответствует текущему enum — см. дефект ниже. |

`RoleCreationDto.name` — `@NotBlank`; `RoleUpdateDto.id` — `@NotNull`. Для RolePermission write body `permissionId` и `level` — `@NotNull`, тогда как `roleId`/`id` заполняются controller из path. Уровни [`PermissionLevel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/base/PermissionLevel.java): `NO_ACCESS < READ < WRITE < CREATE < DELETE`. Эти Bean Validation требования не доказывают существование Keycloak роли/permission path в БД. Все методы имеют `@Secure` на method level; JWT authentication и фактическое право на стенде отдельно не проверены.

## Создание роли и назначение пользователю

[`RoleService`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/role/RoleService.java) обращается к [`WmsKeycloakFacade`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/keycloak/WmsKeycloakFacade.java), не пишет строку `ROLE` в БД:

- `getAll/getPage/findById/meta` читают Keycloak; filter имеет `name`, `description`, default `clientRole=false` и `excludeDefaultRealmRole=true`.
- Create преобразует body в realm role, вызывает `createRole`, затем перечитывает её по имени. Keycloak `409` превращается facade в `DuplicateEntityException`/HTTP `409`; другие `KeycloakException` идут в `500` через [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java).
- Update ищет role по body ID, сохраняет прежнее имя для Keycloak API path, затем меняет name/description/composite. Отдельного server-side запрета update admin role здесь нет.
- Delete сначала проверяет `roleIsAssigned` через Keycloak user members, затем удаляет role по имени. Проверки на наличие связанных `ROLE_PERMISSION.role_id` и отдельного admin guard в этом service нет. `RoleDto.restricted=true` выставляет [`RoleMapper`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/mapper/role/RoleMapper.java) по `adminRoleId`, но это output flag, не проверка update/delete. Следовательно, удаление неиспользуемой роли может оставить записи role permissions с её UUID (миграция не определяет FK к Keycloak); дальнейшие последствия на live data не проверены.

[`UserRoleService`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/role/UserRoleService.java) читает realm-level roles пользователя в Keycloak. Assign сначала ищет роль, проверяет отсутствие её ID в текущем наборе, вызывает `addUserRoles` и затем `syncRolesFromKeycloak()`. Repeat assignment возвращает `UniqueViolationException`, а unassign отсутствующей связи внутри `try` оборачивается в `KeycloakException` и ожидаемый `500`, хотя controller OpenAPI указывает `404`; фактический endpoint не запускался. Unassign после вызова Keycloak `deleteUserRoles` также синхронизирует список ролей. Этот вызов не обновляет уже выданный JWT: [ResourceServerSecurity](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) строит authorities из claims предъявленного token, так что время появления нового набора `ROLE_*` зависит от внешнего перевыпуска токена.

```mermaid
flowchart TD
    C[POST /role] --> K[Keycloak create role]
    K --> S[RolePermissionService: scheduled role-list sync]
    A[POST /user/id/role/id] --> U[Keycloak realm-level assignment]
    U --> M[Immediate syncRolesFromKeycloak]
    M --> R[Server role-name → UUID list]
    T[Existing JWT ROLE_* claims] -. не переписывается этим вызовом .-> P[PermissionCheckStrategy]
    R --> P
```

RoleService create/update/delete не вызывает `syncRolesFromKeycloak` напрямую. [`RolePermissionServiceImpl`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImpl.java) синхронизирует список ролей при создании сервиса и затем по `config.caching.roleTTL`; в исходном [`application.yaml`](../../../web-layer/src/main/resources/application.yaml) это `60000` мс. Если роль создана/переименована/удалена между синхронизациями, server map `role name → UUID` может временно отставать от Keycloak. Runtime задержка не измерялась.

## PermissionPath, RolePermission и изменение дерева

[`PermissionPath`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/PermissionPath.java) описывает path `ltree` и `PermissionType`. [`RolePermission`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/RolePermission.java) содержит `roleId`, FK `permissionPath` и `level`. WMS [`1.1.6 migration`](../../../wms-layer/src/main/resources/db/changelog/1.1.6_20240525_koruswms5837_permissions.sql) создаёт `PERMISSION_PATH` с unique `path` и `ROLE_PERMISSION` с PK `id`, FK на permission path (`ON DELETE CASCADE`) и индексом по role ID; FK на Keycloak role ID и unique `(role_id,permission_path_id)` в этом source migration нет. Полная применённая схема БД не проверена.

`RolePermissionController.create` копирует `roleId` из path в body и блокирует admin role ID. Update копирует `id` и `roleId` из path; delete имеет только IDs в path. Все три блокируют admin **по path `roleId`**, а не по фактической роли найденной записи. `BaseService.update/remove` ищет объект по permission record ID; [`RolePermissionServiceImpl.prepareModelToUpdate`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImpl.java) меняет path/level у existing record и не сверяет `existingModel.roleId` с path ID. `remove(id)` также не сверяет owner. Поэтому с правом `Role.RolePermission:WRITE/DELETE` запрос с не-admin path ID и ID чужой записи source-level способен изменить/удалить чужое право. Для администраторской записи persisted `RolePermission` special forest всё равно строит `DELETE` из admin ID, но ошибка проверки принадлежности остаётся. Это вывод из кода; negative HTTP test не найден.

При update, если `permissionId` не находится через DAO, `ifPresent` не меняет existing path/level; явной предметной ошибки в этой ветке нет. Нет и source-level запрета нескольких RolePermission записей для одной пары `roleId + permissionPathId`; при duplicate rows загрузка forest сортирует только по path, и порядок одинаковых путей не задан. Для ТЗ это отдельный вопрос разрешения дубликатов, не заявление о фактических дублях в live DB.

[`RolePermissionServiceImpl`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImpl.java) строит forest для обычной роли со всеми известными paths на `NO_ACCESS`, затем последовательно накладывает persisted RolePermission по `permissionPath.path ASC`. Родительский уровень распространяется рекурсивно через [`RolePermissionService.propagateInheritance`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionService.java); более точная child запись позднее перекрывает его. Admin ID получает `DELETE` на все пути без чтения persisted role permissions. [`RolePermissionDaoService.updateLowerLevel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/RolePermissionDaoService.java) при add/update записывает тот же level в *уже существующие* дочерние RolePermission rows той же роли, используя ltree `<@`; не создаёт отсутствующие rows. Это отдельный write-side эффект сверх вычисляемого наследования.

```mermaid
flowchart TD
    P[PermissionPath ltree catalog] --> Z[Forest: все paths NO_ACCESS]
    K[Keycloak role name + ID] --> Z
    R[ROLE_PERMISSION rows по path ASC] --> I[Наложить explicit levels]
    Z --> I
    I --> H[Parent level → children]
    H --> O[Later child row overrides]
    O --> C[PermissionCheckStrategy: max level across token roles]
    W[Add/update parent row] --> D[DAO updateLowerLevel: перезаписать существующие descendants]
    D --> R
```

Tree endpoint возвращает вычисленные nodes как [`TreeRolePermissionDto`](../dto/catalog/wms/permission/TreeRolePermissionDto.md). `id` такого node — UUID *explicit RolePermission row* либо `null` для только унаследованного/не заданного узла; вложенное `permission.id` — UUID PermissionPath. Поэтому `PUT/DELETE .../{id}` нельзя строить по `permission.id`. Meta endpoint разрешает только `permissionPath` и `level`, иначе `NotFoundException`/`404`; сортировка и paging берутся из `FilterWithPaging<RolePermissionFilter>`.

## Cache и ожидаемые ошибки

[`ApplicationEventListener`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/event/ApplicationEventListener.java) по `RoleEvent` очищает cache forest конкретной роли и тут же перечитывает его; по `PermissionEvent` очищает и перечитывает *только список PermissionPath*. `RolePermissionServiceImpl.add/update` публикует `RoleEvent` **перед** `BaseService` записью и ещё после add/update через hooks; remove публикует после удаления. Эти hooks исполняются внутри `@Transactional` записи БД. Не подтверждено, что event listener на каждом стенде видит уже committed state: без проверки transaction/event multicaster/cache нельзя гарантировать мгновенную консистентность. Дополнительный scheduled refresh каждый `config.caching.permissionTTL=60000` мс обновляет по одной роли round-robin; это не обязательно TTL каждого forest.

PermissionPath writes сейчас не опубликованы этим HTTP controller, но [`PermissionPathService`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/permission/PermissionPathService.java) генерирует `PermissionEvent` после add/update/remove. После изменения catalog список paths обновляется, а role forest этим event напрямую не очищается; до периодического RoleEvent возможен старый tree. Это source-level риск, а не измеренная production задержка.

| Случай | AS-IS по исходникам |
|---|---|
| Недостаточно method permission | `AccessDeniedException` → `403` |
| `RolePermission` admin path ID в create/update/delete | `AccessDeniedException` → `403` |
| Отсутствует/некорректен Bean Validation body | `400` до service |
| Keycloak duplicate create/update | `DuplicateEntityException` → `409` |
| Другой Keycloak failure | `KeycloakException` → `500` |
| `UserRole` duplicate assign | `UniqueViolationException` → `409` |
| `UserRole` missing mapping on unassign | Обёрнутый `KeycloakException` → ожидаемый `500` |
| Unknown role/permission record ID | `NotFoundException` → `404`, если поиск действительно выполнен по этому ID |

### Недостижимое чтение PermissionPath при текущем enum

Оба метода `PermissionPathController` с commit `c037494a` используют deprecated `@Secure(permissionName="Role.PermissionPath")`. [`Permission.fromPath`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/permission/Permission.java) на текущем HEAD не находит этот path и возвращает `UNKNOWN`: enum имеет `PERMISSION_PATH("PermissionPath")`, но не `Role.PermissionPath`. [`PermissionAspectConfiguration`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/permission/PermissionAspectConfiguration.java) выбирает строковый `permissionName` вместо enum, а [`PermissionCheckStrategy.findPermissionLevel`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategy.java) всегда даёт `NO_ACCESS` для `UNKNOWN`. Следовательно, при работающих aspect/role dependencies эти два GET/POST-read метода ожидаемо дают `403` для любой роли, включая admin. Наличие PermissionPath в migration или UI grant не исправляет enum mismatch. Runtime endpoint отдельно не запускался.

## Проверки, история и вопросы для ТЗ

[`RolePermissionServiceImplTest`](../../../web-layer/src/test/java/ru/korusconsulting/wms/service/permission/RolePermissionServiceImplTest.java) проверяет parent inheritance, child override и admin forest с mocks. [`PermissionCheckStrategyTest`](../../../web-layer/src/test/java/ru/korusconsulting/wms/config/permission/PermissionCheckStrategyTest.java) проверяет роль/уровень/доступ. Прямых tests четырёх WMS controllers, PermissionPath `UNKNOWN`, cross-role permission ID, delete orphan, cache visibility, Keycloak write/retry или JWT refresh source-wide поиск не нашёл. Тесты не запускались.

| Commit | Влияние |
|---|---|
| `c037494a` (2025-03-06, KIS-625) | Подключил WMS source, включая текущие строковые `Role.PermissionPath` annotations; WMS permission migration исторически предшествует ALIS копии |
| `1e2012cc` (2025-08, KIS-1404), `cbf478f8` (2025-07, KIS-1413) | Keycloak/auth integration |
| `972ce6c7` (2026-04, KIS-3803) | Обработка Keycloak `409` при role create/update |
| `3859af95`, `76698b4a` (2026-07/08) | Meta endpoints и permission tree service changes |
| `7661266b` (2026-08) | Согласование enum/database paths; строковый `Role.PermissionPath` в controller остался |

Для ТЗ зафиксировать owner роль/разрешение и правила cross-role path ID, admin immutability на сервере, жизненный цикл удаления Keycloak роли и её RolePermission rows, уникальность role/path, состояние cache после commit и после PermissionPath migration, валидный permissionName, повторное назначение/снятие и обновление JWT. Для фактической матрицы доступов нужны применённые `PERMISSION_PATH`/`ROLE_PERMISSION`, Keycloak roles/user assignments, server auth config и проверки живого Spring aspect; из source их нельзя восстановить.
