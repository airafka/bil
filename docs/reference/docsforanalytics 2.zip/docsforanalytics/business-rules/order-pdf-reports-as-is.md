# PDF-отчёты заявок: availability и download AS-IS

Документ фиксирует PDF-контур `ReceivingOrder` и `ShippingOrder` на commit `22fac945e8116d04972ccc87b06b2303acf7a561`: реестр типов, вычисление доступности и пять download endpoints [`ReportController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportController.java). Excel-выгрузки заявок и `ReportControllerV2` в этот разбор не входят.

Базовые правила агрегатов описаны в документах [поставки](receiving-orders.md), [вывоза](shipping-orders.md) и [валидации](order-validation.md). Общая реализация `ContainerTN`, которую используют и заявка на вывоз, и рейс, дополнительно разобрана в [отчётах рейса](route-reports-as-is.md#данные-pdf-containertn). Полный декларативный список методов находится в [generated endpoint-каталоге](../api/endpoints-generated.md#reportcontroller).

## HTTP-контур и DTO

Связанный endpoint `POST /report/all` возвращает все значения [`OrderReportType`](../dto/catalog/report/OrderReportType.md), не учитывая конкретную заявку, permission каждого документа или его применимость. `GET /report/order/{id}/available` возвращает только применимые типы для найденной заявки.

| Endpoint | Request | Response | Controller permission | Тип / шаблон |
|---|---|---|---|---|
| `POST /report/all` | Без body | `OrderReportType[]` | `REPORT:READ` | Все пять enum-значений |
| `GET /report/order/{id}/available` | Path UUID | `List<OrderReportType>` | `RECEIVING_ORDER_REPORT:READ` **или** `SHIPPING_ORDER_REPORT:READ` | Вычисляемый список |
| `POST /report/receivingorder/mx1/{id}/download` | Path UUID, без body | `StreamingResponseBody` | `RECEIVING_ORDER_REPORT_MX1:READ` | `MX_1` / `reports/MX-1.jrxml` |
| `POST /report/receivingorder/m7/{id}/download` | Path UUID, без body | `StreamingResponseBody` | `RECEIVING_ORDER_REPORT_M7:READ` | `M_7` / три `reports/M-7/part-*.jrxml` |
| `POST /report/shippingorder/mx3/{id}/download` | Path UUID, без body | `StreamingResponseBody` | `SHIPPING_ORDER_REPORT_MX3:READ` | `MX_3` / `reports/MX-3.jrxml` |
| `POST /report/shippingorder/th/{id}/download` | Path UUID, без body | `StreamingResponseBody` | `SHIPPING_ORDER_REPORT_TH:READ` | `ContainerTN` / `reports/ContainerTN.jrxml` |
| `POST /report/shippingorder/packinglist/{id}/download` | Path UUID, без body | `StreamingResponseBody` | `SHIPPING_ORDER_REPORT_PACKING_LIST:READ` | `PACKING_LIST` / `reports/packing_list.jrxml` |

Request DTO у семи методов нет. Download не возвращает JSON DTO: его контракт — поток байтов. Единственный собственный DTO данных отчёта используется Packing List: [`PackingListReportDto`](../dto/catalog/packinglist/PackingListReportDto.md). MX-1, MX-3 и M-7 передают в Jasper JPA entities и коллекции напрямую, а `ContainerTN` формирует карту строковых/числовых параметров.

Имена enum сериализуются как `MX_1`, `MX_3`, `ContainerTN`, `PACKING_LIST`, `M_7`. Фиксированный порядок `/report/all` совпадает с порядком enum, а порядок availability определяется списком соответствующего типа заявки:

- поставка: `[MX_1, M_7]` после фильтрации;
- вывоз: `[MX_3, ContainerTN, PACKING_LIST]` после фильтрации.

`MX_1`, `MX_3` и `ContainerTN` декларативно `produces = application/pdf`. У Packing List и M-7 OpenAPI также указывает PDF, но в `@PostMapping` атрибут `produces` отсутствует. Следовательно, для этих двух методов `application/pdf` не закреплён Spring mapping-контрактом и должен быть проверен на runtime. Все `POST` наследуют class-level `consumes = application/json`, несмотря на отсутствие body.

Enum хранит имена `MX_1.pdf`, `MX_3.pdf`, `ContainerTN.pdf`, `Packing_List.pdf`, `M_7.pdf`, но контроллер не устанавливает `Content-Disposition`; backend не гарантирует клиенту эти имена скачиваемых файлов.

```mermaid
flowchart LR
    HTTP[ReportController] --> RS[ReportService]
    RS --> REG[OrderReportDataCollectorService<br/>strategy by OrderReportType]
    REG --> MX1[Mx1 collector]
    REG --> M7[M7 collector]
    REG --> MX3[Mx3 collector]
    REG --> TN[Order ContainerTN collector]
    REG --> PL[Packing List collector]
    MX1 --> J[JasperReportGenerator]
    M7 --> J
    MX3 --> J
    TN --> J
    PL --> J
```

## Как определяется тип заявки

[`ReportService.getAvailableOrderReports`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ReportService.java) не получает discriminator от клиента. Он сначала вызывает raw repository lookup `ShippingOrderDaoService.getById(id)`, затем — только если вывоз не найден — `ReceivingOrderDaoService.getById(id)`.

```mermaid
flowchart TD
    A[GET /report/order/id/available] --> B{Есть ShippingOrder с UUID?}
    B -- да --> S[Проверить MX_3, ContainerTN, PACKING_LIST]
    B -- нет --> C{Есть ReceivingOrder с UUID?}
    C -- да --> R[Проверить MX_1, M_7]
    C -- нет --> N[NotFoundException]
    S --> F[Оставить только canExport=true]
    R --> F
    F --> O[JSON-массив enum names]
```

При теоретическом совпадении UUID в двух независимых таблицах приоритет получает `ShippingOrder`. Ни lookup типа, ни collector direct lookup не проходят через `FilterEnrichService`; client row-level restriction по конкретному UUID в этом коде не подтверждён. Это относится и к availability, и к пяти прямым download endpoints.

Endpoint availability разрешён при наличии хотя бы одного из двух общих прав — receiving **или** shipping report. Право не сопоставляется с фактически найденным направлением заявки. Затем каждый collector отдельно проверяет своё узкое право. Поэтому пользователь с общим правом одного направления может вызвать availability для другого направления, а без узких прав получит `[]`.

Direct download, наоборот, требует только узкое право конкретного отчёта; общее `RECEIVING_ORDER_REPORT`/`SHIPPING_ORDER_REPORT` там не проверяется. `POST /report/all` защищён третьим, отдельным правом `REPORT:READ` и также не показывает применимость.

## Общий pipeline и транзакции

Для download [`BaseReportDataCollectorService.collectReportData`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) открывает `REPEATABLE_READ`, повторно вызывает `checkCanExport`, собирает parameter map и добавляет locale `ru_RU`. После выхода из collector [`JasperReportGenerator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/JasperReportGenerator.java) компилирует и заполняет шаблон, формирует PDF во внутреннем буфере и сохраняет объединённый документ в HTTP output stream.

Для M-7 три шаблона обрабатываются в порядке `part-1`, `part-2`, `part-3`. В каждый следующий передаётся `START_PAGE`, увеличенный на число страниц предыдущей части; затем три PDF объединяются в один.

Availability вызывает `checkCanExport` напрямую, а не через транзакционный `collectReportData`. Его отдельные DAO-вызовы поэтому не образуют общий repeatable-read snapshot. Результат availability является подсказкой на момент чтения: download повторяет проверки в своей транзакции и может получить другой результат после изменения статуса, состава товаров или permissions.

## Матрица явной доступности

Таблица показывает только условия `checkCanExport`. Она не означает, что всех данных достаточно для успешного Jasper render.

| Тип | Направление | Узкое право | Статус | Площадка | Транспорт | Дополнительное условие |
|---|---|---|---|---|---|---|
| `MX_1` | Поставка | `RECEIVING_ORDER_REPORT_MX1` | `DONE` | `WAREHOUSE` | `VEHICLE` | Нет |
| `M_7` | Поставка | `RECEIVING_ORDER_REPORT_M7` | `DONE` | `WAREHOUSE` | `VEHICLE` | delivery type — `BY_GOOD`, `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` или `BY_GOOD_WITH_CARGO_WITH_DETAILS`; есть расхождение количества |
| `MX_3` | Вывоз | `SHIPPING_ORDER_REPORT_MX3` | `DONE` | `WAREHOUSE` | `VEHICLE` | Нет |
| `ContainerTN` | Вывоз | `SHIPPING_ORDER_REPORT_TH` | Любой | Фактически только `CONTAINER` | `VEHICLE` | Нет проверки delivery/filling type или статуса |
| `PACKING_LIST` | Вывоз | `SHIPPING_ORDER_REPORT_PACKING_LIST` | `DONE` | `WAREHOUSE` | `VEHICLE` | Проверка запрещает только `BY_CARGO`; `null` формально проходит, но даёт пустой набор строк |

Код площадки преобразуется через `TerminalAreaEnum.valueOf(terminalArea.code)`. `terminalArea = null` либо динамический code, которого нет в enum, не даёт аккуратного `unavailable`: возможны `NullPointerException`/`IllegalArgumentException` и `500`.

У `OrderTNContainerReportDataCollectorService` есть избыточная двухступенчатая проверка: сначала разрешены `CONTAINER` и `WAREHOUSE`, затем superclass запрещает `WAREHOUSE`. Итоговое правило — только `CONTAINER + VEHICLE`.

### Расхождение количества для M-7

[`M7ReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/M7ReportDataCollectorService.java) считает M-7 доступным, если хотя бы у одного неудалённого `ReceivingOrderGood`:

- оба значения заданы и `plannedQuantity != actualQuantity`;
- `actualQuantity = null`, а planned строго больше нуля;
- `plannedQuantity = null`, а actual строго больше нуля.

Если оба значения `null`, оба равны либо единственное заданное значение равно нулю/отрицательно, такая строка не создаёт discrepancy. Наличие грузов, транспорта и событий `REC_START`/`REC_FINISH` в availability не проверяется.

```mermaid
flowchart TD
    A[checkCanExport] --> P{Есть узкое право?}
    P -- нет --> N[Тип исключается из available]
    P -- да --> O[Direct find order by UUID]
    O --> S{Статус / площадка / транспорт}
    S -- не подходят --> N
    S -- подходят --> X{Специальное условие типа}
    X -- не выполнено --> N
    X -- выполнено --> Y[Тип доступен]
    Y --> D[download повторяет check]
    D --> G[Сбор entities/DTO]
    G --> R[Jasper render]
    R --> E{Все неявные данные пригодны?}
    E -- нет --> F[Ошибка генерации 500]
    E -- да --> PDF[PDF stream]
```

## MX-1: приходный ордер

[`Mx1ReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/Mx1ReportDataCollectorService.java) передаёт в `MX-1.jrxml`:

- `ReceivingOrder` — сущность [ReceivingOrder](../entities/catalog/entities/receivingorder/ReceivingOrder.md);
- `ReceivingOrderCargos` — все неудалённые [ReceivingOrderCargo](../entities/catalog/entities/receivingordercargo/ReceivingOrderCargo.md) заявки;
- `Waybill` — *(изменено KIS-4093, коммит `d30d77ad`, 24 сентября 2026)* теперь напрямую `receivingOrder.getWaybill()`; поле `ReceivingOrderTransport.waybill` было перенесено на корень `ReceivingOrder` этой миграцией (сущность `ReceivingOrderTransport` удалена), а не читается из отдельной optional-строки.

Минимальное количество грузов и наличие waybill не проверяются. Перед render collector инициализирует `GoodPackage.UnitOfMeasure`, только если обе ссылки есть.

Шаблон при этом напрямую обращается к `order.createdAt`, `order.contract`, `contract.company`, `contract.contractDate` и `order.client`. Эти зависимости не входят в availability. Если historical/неконсистентная запись не содержит одной из них, тип может присутствовать в available, но download завершится Jasper-ошибкой.

## MX-3: акт оказанных услуг

[`Mx3ReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/Mx3ReportDataCollectorService.java) читает [ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md), все неудалённые [ShippingOrderGood](../entities/catalog/entities/shippingordergood/ShippingOrderGood.md) и [ShippingOrderRequestedService](../entities/catalog/entities/shippingorderrequestedservice/ShippingOrderRequestedService.md).

Он вычисляет суммы с НДС и без НДС, разницу НДС и их словесные представления, форматирует даты договора/создания. Если заказанных услуг нет, в datasource помещаются пять пустых объектов для строк формы. Минимум товаров availability не требует.

Неявные требования сильнее eligibility: `shippingOrder.contract` разыменовывается в Java; шаблон использует contract/company/client и вложенные поля товаров/услуг. У каждой непустой requested service `priceWithVAT` и `priceWithoutVAT` должны быть ненулевыми, иначе `reduce(BigDecimal::add)` способен завершиться `500` ещё до Jasper.

## ContainerTN: транспортная накладная

[`OrderTNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/OrderTNContainerReportDataCollectorService.java) специализирует общий [`TNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/TNContainerReportDataCollectorService.java).

После проверки `CONTAINER + VEHICLE` он читает заявку, optional transport, optional route, текущего пользователя, все container items и не более одного неудалённого [ShippingOrderContainer](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainer.md). Ноль контейнеров допустим и даёт пустые/default-поля; больше одного приводит к `TNContainerReportException` уже при сборе данных, хотя availability предварительно вернул тип.

Статус, `deliveryType`, `fillingType`, наличие route/водителя/автомобиля и транспортной строки не проверяются. Большинство отсутствующих значений превращается в пустые строки. Но `UserInfoDto` должен быть получен: формирование `OperatorLongName` разыменовывает его напрямую.

Массы `TotalWeight` и `GrossWeight` умножаются на `1000`. Полный перечень параметров и вычислений описан один раз в [разборе общего ContainerTN](route-reports-as-is.md#данные-pdf-containertn).

## Packing List

[`PackingListReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/PackingListReportDataCollectorService.java) формирует `PackingListReportDto` по разным источникам:

| `deliveryType` | Источник строк | Mapping |
|---|---|---|
| `BY_GOOD` | Неудалённые [ShippingOrderGood](../entities/catalog/entities/shippingordergood/ShippingOrderGood.md) | clientGood, batch, actualQuantity; `weight` и `goodPackage` mapper игнорирует |
| `BY_GOOD_WITH_CARGO_WITH_DETAILS` | Неудалённые [ShippingOrderCargo](../entities/catalog/entities/shippingordercargo/ShippingOrderCargo.md) | clientGood/batch через shippingOrderGood плюс actualQuantity, weight, goodPackage |
| `BY_CARGO` | Не формируется | Тип отчёта недоступен |

Для detailed cargo дополнительно собирается уникальное множество ненулевых `executor`. В Jasper передаются `ShippingOrder`, `ShippingOrderTransport`, datasource строк и executors.

Availability не проверяет, что строки вообще существуют, и не требует transport. Шаблон же напрямую обращается к client, contract и `ShippingOrderTransport.consignee`; для cargo-строк вычисляет вес в тоннах и вес паллеты через `actualQuantity`, `weight` и `goodPackage.conversionQty`. Нулевые/отсутствующие значения или деление на ноль могут сделать формально доступный отчёт негенерируемым.

## M-7: акт о расхождениях

После проверки discrepancy collector передаёт:

- [ReceivingOrder](../entities/catalog/entities/receivingorder/ReceivingOrder.md), его transport и `contract.company`;
- все неудалённые [ReceivingOrderGood](../entities/catalog/entities/receivingordergood/ReceivingOrderGood.md) и [ReceivingOrderCargo](../entities/catalog/entities/receivingordercargo/ReceivingOrderCargo.md);
- первый `InboundEvent` со статусом `DONE` и кодом `REC_START`;
- первый `InboundEvent` со статусом `DONE` и кодом `REC_FINISH`.

Поиск события использует exact case-insensitive match, но не сортирует по `eventDateTime`: `findFirst` наследует default ascending sort по `id`, поэтому выбор при нескольких подходящих событиях определяется ID, а не явно последним или первым временем события.

Если событие не найдено, collector только пишет warning и передаёт `null`. Однако `part-1.jrxml` затем напрямую разыменовывает оба события и создаёт `List.of(RecStartEvent)`, который не принимает `null`. Поэтому отсутствие хотя бы одного события фактически способно дать `500`, хотя M-7 был показан как доступный. Аналогично `contract.company` разыменовывается collector-ом, а `part-3` обращается к `ReceivingOrderTransport` без полной null-защиты. Эти поля являются технически обязательными для текущего шаблона, но не включены в `checkCanExport`.

## Ошибки и HTTP-семантика

Недоступность отчёта в `GET .../available` не является ошибкой: тип удаляется из массива, причина записывается только в debug log. Direct download повторяет ту же проверку и при `canExport=false` выбрасывает `IllegalArgumentException`.

| Случай | AS-IS до начала передачи ответа |
|---|---|
| Нет controller permission | Ожидаемо `403`; runtime security chain не проверялся |
| UUID не найден в нужной таблице | `NotFoundException` → `404` |
| Статус/type/area/transport/discrepancy не подходят | Direct download: `IllegalArgumentException` → catch-all `500` |
| Неизвестный enum-код, null dependency, arithmetic/mapping failure | Catch-all `500` |
| Jasper compile/fill/merge/write failure | `JasperReportProcessingException` → `500` |
| Ошибка после начала streaming | Возможен неполный ответ; стандартный JSON `ApiErrorDto` и смена статуса не гарантированы |

OpenAPI всех download методов декларирует `400 Validation problems`, но текущий [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) не сопоставляет `IllegalArgumentException` с `400`. Таким образом, основной предметный отказ download расходится с декларацией и ожидаемо становится `500`.

Причины недоступности — английские строки без стабильного error code. Клиент availability их не получает. `GET .../available` также способен завершиться исключением вместо массива, например при unknown terminal area code.

## Тестовое покрытие

[`ReportServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/report/ReportServiceIntegrationTest.java) содержит включённые успешные тесты MX-1, MX-3, двух вариантов Packing List и M-7. Они формируют PDF, извлекают текст и проверяют отдельные значения. Есть включённый `NotFoundException` для отсутствующей заявки MX-1.

Положительный тест `ContainerTN` помечен `@Disabled`, поэтому текущий успешный сценарий ТН автоматически не подтверждается. В `@BeforeEach` обе формы `PermissionCheckStrategy` всегда мокируются как `true`, следовательно permission-ветки этими тестами не покрыты.

Не найдены прямые тесты:

- `/report/all`, `/report/order/{id}/available` и порядка/фильтрации enum;
- всех отрицательных eligibility-веток status/area/transport/delivery/discrepancy;
- client row-level access и UUID другого направления;
- M-7 без событий/transport/company и с несколькими событиями;
- ContainerTN с нулём/несколькими контейнерами именно для order endpoint;
- media type Packing List/M-7, `Content-Disposition`, controller status/body и сбоя после начала streaming.

Тесты при документировании не запускались.

## История изменений

| Commit | Влияние на текущий AS-IS |
|---|---|
| `b67b2971` (2024-09-10) | Исходный MX-1/report framework и `/report/all` |
| `0e530be7` (2024-09-18) | Добавил MX-3 |
| `693c3cbf` (2024-09-30) | Добавил исходную ТН вывоза |
| `602865e9` / `694950c2` (2025-02-13 / 2025-02-12) | Изменили шаблоны/данные MX-1 и MX-3 |
| `141464c7` (2025-04-18, KIS-928) | Добавил Packing List, endpoint, collector, DTO, template и тест |
| `d03b174f` / `d06bd00b` (2025-05-15 / 2025-05-21) | Добавили и исправили M-7, включая multi-part generation |
| `e6de1276` (2025-07-24, KIS-1426) | Исправил генерацию Packing List и текущую ветвящуюся модель строк |
| `24e0ddaa` (2026-02-09, KIS-2448) | Добавил eligibility-проверки M-7 |
| `443ae69a` (2026-04-14) | Обновил OpenAPI-описания report endpoints |
| `6611ec27` (2026-06-09, KIS-3965) | Добавил общий availability, списки типов, permission/eligibility checks всех PDF collectors и repeatable-read recheck |
| `b2392502`, `49b109ed`, `84a9e5eb` (2026-06-17…26) | Переименовали/переработали `ContainerTN` и перенесли его вычисления в Java |
| `0b120809` (2026-07-10, KIS-4318) | Заменил глобальное право availability на OR из receiving/shipping report permissions |

## Чек-лист для ТЗ

Для нового или изменяемого PDF-отчёта заявки следует явно зафиксировать:

1. направление заявки и точный `OrderReportType`;
2. общее и узкое permission, включая ожидаемое поведение availability;
3. eligibility: статус, площадка, транспорт, delivery/filling type, discrepancy;
4. полный набор обязательных данных для успешного шаблона, а не только `checkCanExport`;
5. правила выбора события при нескольких `REC_START`/`REC_FINISH`;
6. client row-level проверку для direct UUID;
7. стабильные HTTP status/error code и доступность причины клиенту;
8. `Content-Type`, имя файла и `Content-Disposition`;
9. snapshot между availability, сбором данных и render;
10. поведение streaming failure и контрольные автотесты содержимого PDF.
