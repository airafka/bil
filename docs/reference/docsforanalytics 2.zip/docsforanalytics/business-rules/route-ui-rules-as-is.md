# UI-правила рейсов: frontend AS-IS

> Сверено с репозиторием `alis-frontend`, ветка `dev`, commit `ab02fa985` (14 октября 2026; предыдущая сверка — `971288126`, 7 октября 2026; первичная — `62e1edfb`, 1 октября 2026). Серверная сторона — [основной lifecycle рейса](route-lifecycle-as-is.md), [отчёты рейса](route-reports-as-is.md) и [каталог endpoints](../api/endpoints-generated.md).

Документ фиксирует, как пользователь работает с рейсом в UI: какие вкладки видит, когда может редактировать, назначать заявки, отправлять и отменять рейс, какие права для этого проверяются. После KIS-4735 рейс — **единственная точка смены статуса транспортных заявок из интерфейса** (см. [`UI-ORDER-003`](order-ui-rules-as-is.md#общие-правила)), поэтому правила рейса фактически определяют пользовательский lifecycle заявок.

Все тезисы — `[AS_IS · SOURCE_CONFIRMED]` по frontend source, если не указано иное.

## Главное

1. **Пользовательский путь статусов:** `DRAFT → ACCEPTED` кнопкой «Отправить» рейса (accept рейса = accept каждой заявки, [`BR-ROUTE-006`](route-lifecycle-as-is.md)); `ON_REVIEW` в UI не используется.
2. **Для назначения UI предлагает только `DRAFT`-заявки** той же площадки и транспорта, но **не исключает заявки, уже назначенные на другой рейс**. Вместе с серверным пробелом [`BR-ROUTE-004`](route-lifecycle-as-is.md) это позволяет «перетянуть» заявку из чужого рейса.
3. **Отмена рейса проверяет разные права в карточке и в реестре** — `Route.Reject` в карточке и `Route` с уровнем `DELETE` в реестре ([`UI-RDIFF-03`](#реестр-расхождений-ui--backend)).
4. **Удалить рейс из UI нельзя** — функция `DELETE /routes/{id}` во фронте есть, но не вызывается.
5. **Вкладка «Документы» требует `Route.Report` уровня `DELETE`**, а сервер — `READ` ([`UI-RDIFF-04`](#реестр-расхождений-ui--backend)).

## Правила

| ID | Правило | Источник |
|---|---|---|
| `UI-ROUTE-001` | Рейс создаётся в два шага: «Основное» (создание `POST /routes`), затем «Заявки» (назначение). Других вкладок в мастере создания нет. | [useRouteConfig](../../../src/features/Routes/configs/useRouteConfig.tsx) |
| `UI-ROUTE-002` | Обязательны тип рейса, дата/время, площадка и тип транспорта; для `VEHICLE` — перевозчик, водитель и ТС. Совпадает с [`BR-ROUTE-001/002`](route-lifecycle-as-is.md). | [schema](../../../src/features/Routes/UI/MainInfo/edit-config/schema.ts) |
| `UI-ROUTE-003` | После создания тип рейса, площадка и транспорт блокируются. При выборе складской площадки транспорт подставляется `VEHICLE`; при выборе `RAILWAY` перевозчик, водитель и ТС очищаются (сервер с KIS-4667 их для ЖД запрещает). | [fields](../../../src/features/Routes/UI/MainInfo/edit-config/fields.ts), [effects](../../../src/features/Routes/UI/MainInfo/edit-config/effects.ts) |
| `UI-ROUTE-004` | Перевозчик, водитель и ТС выбираются из **всех активных** записей справочников — без фильтра по клиенту и без фильтра по роли «перевозчик». Телефон и доверенность подставляются из водителя, страховка и прицеп — из ТС, и редактировать их в форме рейса нельзя. Сервер принадлежность клиенту тоже не проверяет. | [fields](../../../src/features/Routes/UI/MainInfo/edit-config/fields.ts) |
| `UI-ROUTE-005` | Редактирование основной формы в карточке: статус `DRAFT` и `Route` `WRITE`. В меню реестра «Редактировать» доступно в любом статусе, кроме `ACCEPTED`, `IN_PROGRESS`, `DONE`, `REJECTED` — то есть ещё и в `ON_REVIEW`, как допускает сервер ([`BR-ROUTE-003`](route-lifecycle-as-is.md)). | [useMainInfoView](../../../src/features/Routes/configs/MainInfo/useMainInfoView.tsx), [RouteTable](../../../src/features/Routes/UI/RouteTable/RouteTable.tsx) |
| `UI-ROUTE-006` | Назначать и снимать заявки можно только в рейсе со статусом `DRAFT`; правка конкретной заявки из рейса — только если сама заявка в `DRAFT`. **Права `Route` `CREATE`/`DELETE`, которые сервер требует для assign/unassign, UI не проверяет** — пользователь без них увидит кнопки и получит 403. | [useOrdersConfig](../../../src/features/Routes/configs/Orders/useOrdersConfig.tsx), [OrdersView](../../../src/features/Routes/UI/Orders/OrdersView.tsx) |
| `UI-ROUTE-007` | Список заявок для назначения — `POST /receivingorder/page` или `/shippingorder/page` (по типу рейса) с фильтром: та же площадка, тот же транспорт, `orderStatus=DRAFT`, поиск только по номеру. Фильтра «не назначена на рейс» нет. | [buildAvailableOrdersPageRequest](../../../src/features/Routes/api/route.queries.ts) |
| `UI-ROUTE-008` | «Отправить» — только в `DRAFT` и при `Route.SendToAccept` (BUTTON, `DELETE`); вызывает `POST /routes/{id}/change-status/accept`. Ошибка `Route.IsEmpty` показывается отдельным сообщением «пустой рейс»; ошибки валидации заявок — списком с привязкой к заявкам, в т.ч. отдельные сообщения по занятости КТК (`ContainerStatus.ReceivingAlready{Reserved,InShipping,InRemains}`, `ShippingAlreadyReserved`, `ShippingNotReceived` — КТК ещё ожидаются по поставке, `ShippingMissingInRemains` — КТК нет в остатках); прочие коды `Route.*` переводятся, если есть перевод. | [useSendRouteSlideAction](../../../src/features/Routes/helpers/useSendRouteSlideAction.tsx) |
| `UI-ROUTE-009` | Отмена в карточке — при `Route.Reject` (BUTTON, `DELETE`) и статусе не `REJECTED`, с подтверждением. Отмена из меню реестра — при `Route` (FORM, `DELETE`), без проверки статуса. Сервер каскадно отклоняет все заявки рейса ([`BR-ROUTE-007`](route-lifecycle-as-is.md)); UI об этом в диалоге не предупреждает отдельно (текст диалога — общий). | [useMainInfoView](../../../src/features/Routes/configs/MainInfo/useMainInfoView.tsx), [RouteTable](../../../src/features/Routes/UI/RouteTable/RouteTable.tsx) |
| `UI-ROUTE-010` | Копирование — из меню реестра при `Route.Copy` (BUTTON, `DELETE`), в любом статусе; вызывает `POST /routes/{id}/partial-copy` и открывает копию в режиме редактирования. Сервер требует для копирования лишь `ROUTE_COPY/READ`. | [RouteTable](../../../src/features/Routes/UI/RouteTable/RouteTable.tsx) |
| `UI-ROUTE-011` | Состав вкладок: «Основное» и «Заявки» всегда. Для рейса **вывоза** с контейнерной площадки: ЖД — «Вагоны» и «Количество КТК»; авто — «Количество КТК». В режиме просмотра для этих рейсов добавляется «Просмотр» (план/факт), а для авто-вывоза — «Документы». У рейсов поставки и складских рейсов дополнительных вкладок нет. | [useRouteConfig](../../../src/features/Routes/configs/useRouteConfig.tsx) |
| `UI-ROUTE-012` | «Вагоны», «Количество КТК» и «Просмотр» только читают данные (`POST /routes/{id}/shipping-order/{railway-carriage,container,fact,auto/fact}`); редактирования плана/факта в UI нет. | [route.api](../../../src/features/Routes/api/route.api.ts) |
| `UI-ROUTE-013` | «Документы» показываются при `Route.Report` уровня `DELETE` и непустом ответе `GET /report/route/{id}/available`; поддерживается только тип `ContainerTN` (`POST /report/route/{id}/th/download`). | [useRouteConfig](../../../src/features/Routes/configs/useRouteConfig.tsx), [route.documents](../../../src/features/Routes/api/route.documents.ts) |
| `UI-ROUTE-014` | Статус `ON_REVIEW` исключён из списка статусов рейса в форме (KIS-4735). | [fields](../../../src/features/Routes/UI/MainInfo/edit-config/fields.ts) |
| `UI-ROUTE-015` | Вкладка «Заявки» в режиме редактирования (с 14.10.2026, `999b26824`, KIS-4863) — таблица выбора по общей схеме [`UI-ORDER-013`](order-ui-rules-as-is.md#общие-правила): **все** уже назначенные заявки (`POST /routes/{id}/orders`) идут в начале списка, а не только на первой странице; кандидаты [`UI-ROUTE-007`](#правила) — после них, без дублей; общее число строк считается по объединённому списку. Включены текстовые фильтры колонок (номер, дата, статус и др.) — фильтруют в браузере только кандидатов, назначенные заявки не скрывают. Серверный фильтр кандидатов не изменился. | [OrdersEdit](../../../src/features/Routes/UI/Orders/OrdersEdit.tsx), [useRouteAvailableOrdersTableStoreAdapter](../../../src/features/Routes/hooks/useRouteAvailableOrdersTableStoreAdapter.ts) |

## Реестр расхождений UI ↔ backend

| ID | Тема | UI | Backend | Тип | Что решить |
|---|---|---|---|---|---|
| `UI-RDIFF-01` | Заявки другого рейса | в списке для назначения видны все `DRAFT`-заявки, в т.ч. уже назначенные | принадлежность другому рейсу не проверяется (`BR-ROUTE-004`) | пробел на обоих уровнях | Запрещать переназначение или показывать текущий рейс заявки |
| `UI-RDIFF-02` | Назначение в `ON_REVIEW` | только `DRAFT`-заявки и только `DRAFT`-рейс | `DRAFT`/`ON_REVIEW` | строже | Ожидаемо после KIS-4735; серверное правило можно сузить |
| `UI-RDIFF-03` | Право на отмену рейса | карточка: `Route.Reject` BUTTON `DELETE`; реестр: `Route` FORM `DELETE` | `ROUTE_REJECT/DELETE` | **несогласованность UI** | Реестр должен проверять `Route.Reject`, иначе пользователь без права видит пункт и получает 403, а пользователь с правом, но без `Route` `DELETE`, пункта не видит |
| `UI-RDIFF-04` | Вкладка «Документы» | `Route.Report` уровня `DELETE` | `ROUTE_REPORT:READ` + `ROUTE_REPORT_TH:READ` | строже | Скорее всего ошибка уровня в UI: пользователь с правом чтения отчётов вкладку не увидит |
| `UI-RDIFF-05` | Копирование | `Route.Copy` уровня `DELETE` | `ROUTE_COPY/READ` | строже | Выровнять уровень права |
| `UI-RDIFF-06` | Assign/unassign без проверки прав | кнопки видны всем, кто может открыть рейс в `DRAFT` | `ROUTE/CREATE` и `ROUTE/DELETE` | мягче (ошибка после клика) | Скрывать действия по праву |
| `UI-RDIFF-07` | Отмена из реестра без проверки статуса | пункт есть и для `REJECTED` | недопустимый переход → `IllegalArgumentException` → HTTP 500 | мягче | Скрывать пункт для `REJECTED`, как в карточке |
| `UI-RDIFF-08` | Удаление рейса | недоступно | `DELETE /routes/{id}` для пустого `DRAFT`/`ON_REVIEW` | только backend | Нужно ли удаление пользователю; иначе пустые рейсы копятся (отменить пустой рейс можно) |
| `UI-RDIFF-09` | Справочники перевозчика/водителя/ТС | все активные, без фильтра по клиенту и роли | не проверяет | пробел на обоих уровнях | Решить, должны ли водитель/ТС/перевозчик принадлежать клиенту заявок |

## Вопросы для ТЗ

1. `UI-RDIFF-01` — правило переназначения заявки между рейсами.
2. `UI-RDIFF-03…05` — согласовать с владельцем ролевой модели и исправить уровни прав в UI.
3. `UI-RDIFF-08` — нужен ли пользовательский сценарий удаления рейса.
