# Настройки пользователя AS-IS

Проверено по текущему checkout `22fac945e8116d04972ccc87b06b2303acf7a561`. Контур — три source-level mappings [`UserSettingController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/usersetting/UserSettingController.java), хранилище ALIS `user_setting` и значения по умолчанию. Это настройки отображения/таблиц, а **не** [роли и методные права](roles-permissions-as-is.md) и не [доступные клиентские записи](user-groups-client-restriction-as-is.md). Runtime registration, security chain, applied migrations и фактические пользовательские данные не проверялись; декларации HTTP отдельно есть в [каталоге endpoints](../api/endpoints-generated.md).

## HTTP и реальные DTO

| Метод | Request / результат | Source-level логика |
|---|---|---|
| `GET /usersetting` | Нет параметров → `List<`[`UserSettingDto`](../dto/catalog/usersetting/UserSettingDto.md)`>`; default Spring `200` | [`SecurityUtils.getUserId`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/utils/SecurityUtils.java) берёт UUID из JWT `sub`; [`UserSettingService.getAll`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/usersetting/UserSettingService.java) ищет только записи этого user ID. Default rows **не добавляются** к списку. |
| `GET /usersetting/{key}` | Строка `key` в path → `UserSettingDto`, `200`; если нет личной и default строки — `204 No Content` | Service сначала ищет `(userId,key)`, затем `(defaultUserSettingId,key)`. Response `key` берётся из запроса, `value` — из найденной строки. |
| `POST /usersetting/{key}` | Строка `key` в path, обязательный Spring body `Map<String,Object>` → `UserSettingDto`, default `200` | [`UserSettingService.setUserSettingsByKey`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/usersetting/UserSettingService.java) в `@Transactional` удаляет прежние строки **этого** `(userId,key)`, вставляет новый JSON map и возвращает body. Это замена всей настройки, не PATCH/merge и не update JPA row. |

[`UserSettingDto`](../dto/catalog/usersetting/UserSettingDto.md) содержит `key: String` и `value: Map<String,Object>` без Bean Validation. В POST используется *не DTO*, а raw `Map<String,Object>`; отсутствующий request body Spring отклоняет до service, но service не задаёт whitelist допустимых ключей, JSON-полей, типов вложенных значений, версий или верхней границы размера. Path `key` тоже не имеет `@NotBlank`/length validation. DTO-паспорт описывает Java/JSON структуру response, а не доказанную бизнес-обязательность произвольных `value` полей.

Все три controller methods не имеют `@Secure`. Если действует [`ResourceServerSecurity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java) с issuer URI, `/usersetting/**` требует аутентификацию как обычный URL; роль/permission `UserSetting` method gate в этом controller не объявлен. Фактические JWT grants, proxy rules и безопасность стенда не проверены.

## Хранение, default и идентичность пользователя

[`UserSetting`](../entities/catalog/entities/usersetting/UserSetting.md) — JPA entity с `userId`, `key`, `value: Map<String,Object>` и `@JdbcTypeCode(SqlTypes.JSON)`/`@Immutable`. Source миграция [`1.31.0` create](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251119_KIS-1284_add_table_user_setting.sql) определяет UUID PK, `user_id UUID NOT NULL` без FK к Keycloak, `key VARCHAR(128) NOT NULL` и metadata `created_at/by`. Следующая [`JSONB conversion`](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251125_KIS-1284_change_type_of_value_in_table_user_setting.sql) удаляет старую `value VARCHAR(128)`, добавляет `value jsonb NOT NULL` и `UNIQUE(user_id,key)`. Значения старой колонки при этом SQL преобразовании не переносятся. JPA `@Immutable` согласуется с delete/insert write pattern; состояние реально применённой схемы не проверено.

`defaultUserSettingId` из текущего [`application.yaml`](../../../web-layer/src/main/resources/application.yaml) — `49d19fdf-d3ed-4d48-9450-e4b8517a5150`. Default values — **обычные строки той же таблицы** с этим `user_id`, а не отдельный JSON-файл: [первая вставка `1.33.0`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260123_KIS-2917_add_default_user_setting_values.sql) и [текущий набор `1.35.0`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260826_KIS-4624_update_default_values_in_user_settings_table.sql). Последняя source migration вставляет 100 ключей; например `menu-visibility` с `hiddenKeys` и `tablecolumns-usergroupstore` с `order`/`visibility`/`size`/`version`. Это подтверждённые формы *default rows*, не серверная схема validation: POST может записать другие maps или keys.

Критичный эффект [`1.35.0 SQL`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260826_KIS-4624_update_default_values_in_user_settings_table.sql): `BEGIN; DELETE FROM user_setting; INSERT ... 100 default rows; ... COMMIT;`. Если эта миграция была применена, она удаляла **все персональные значения**, а не только прежние defaults, и не восстанавливала их из backup в SQL. Это действие миграции commit `15f90451` (2026-08-26); факт применения, предмиграционные данные и возможность восстановления неизвестны. В ТЗ по изменению defaults нельзя предполагать, что пользовательские overrides переживают такой deployment.

```mermaid
flowchart TD
    U[JWT sub → user UUID] --> L[GET key: поиск личной строки]
    L -->|есть| R[200 личный JSON value]
    L -->|нет| D[Поиск default UUID + key]
    D -->|есть| V[200 default JSON value]
    D -->|нет| N[204 No Content]
    U --> A[GET all: только личные строки]
    A --> E[200 список, без default rows]
```

## Проверка owner, ключа, ошибок и повторов

Controller не принимает произвольный `userId` в path/body: owner выбирается из `SecurityUtils.getUserId()` текущего authentication. При корректном UUID `sub` [`UserSettingPredicate`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/usersetting/UserSettingPredicate.java) добавляет `userId = ...`, а [`UserSettingRepository.deleteByUserIdAndKey`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/usersetting/UserSettingRepository.java) удаляет только точную пару. Нет отдельной проверки, запрещающей писать под зарезервированным default UUID; может ли такой `sub` появиться у живого пользователя, не подтверждено.

Null identity **не fail-closed в чтении**: `SecurityUtils.getUserId()` возвращает `null` для authenticated principal без JWT `sub`, а predicate добавляет `userId` condition лишь при `filter.getUserId()!=null`. Тогда `GET /usersetting` по коду может прочитать строки всех пользователей и defaults. Для `GET /{key}` `findOne` при нескольких результатах ловит `IncorrectResultSizeDataAccessException` и возвращает empty/default; если совпадает ровно одна строка чужого user ID, возможна её выдача. При не-UUID `sub` `UUID.fromString` сам выбрасывает exception. Это условные source-level риски: не доказано, что текущая security chain допускает такой authenticated request; нужен negative HTTP test с проверенными token claims.

`GET /{key}` использует [`SearchString`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/searchtype/SearchString.java) с default `EXACTLY_MATCHES_IGNORE_CASE`: `key` ищется без учёта регистра. POST `deleteByUserIdAndKey` и SQL unique `(user_id,key)` используют буквальный key; source не нормализует регистр до записи. Поэтому `POST` с `TableColumns-X` после `tablecolumns-x` может оставить две разные SQL строки, а case-insensitive GET на обе даст `findOne` с несколькими совпадениями → `Optional.empty()` и fallback к default/`204`. Пустая/blank строка в key search не образует key predicate; обычный URL с пустым сегментом не совпадает с `/{key}`, а encoded whitespace и его runtime decoding отдельно не проверялись.

Транзакционная замена `delete → insert` сохраняет другое user/key. Если insert падает, в типовой Spring transaction удаление откатывается; отдельно DB/runtime не запускались. Повторный последовательный POST того же JSON оставляет то же *значение*, но создаёт новый row ID/`created_at`; одновременные POST одного `(userId,key)` не имеют version/lock и могут спорить за unique constraint. Исходный [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) трактует PostgreSQL duplicate-key `DataIntegrityViolationException` как `409`, другие integrity failures — `500`; malformed/missing JSON Spring даёт `400`. Какое конкретно исключение возникает при race, oversized key или null JSON value, без DB/HTTP tests не подтверждено.

```mermaid
flowchart TD
    P[POST key + Map body] --> I[JWT sub → UUID]
    I --> T[@Transactional]
    T --> D[DELETE exact user_id + key]
    D --> A[INSERT new UUID + JSONB value]
    A --> O[200 UserSettingDto]
    A -->|DB failure| B[Rollback; Advice 409 или 500 по SQLState]
    M[1.35.0 migration] --> X[DELETE all user_setting rows]
    X --> Y[INSERT 100 default rows]
```

## Тесты, история и вопросы для ТЗ

[`UserSettingServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/usersetting/UserSettingServiceIntegrationTest.java) описывает замену `BATCH` без изменения `CLIENT_GOOD` в isolated Postgres container. Тест не был запущен сейчас и не покрывает HTTP/JWT/owner, fallback default, migration wipe, case variants, empty/null sub, invalid JSON, concurrent POST или retry ID. Прямых controller tests source-wide поиск не нашёл.

| Commit | Влияние на AS-IS |
|---|---|
| `9b4bcd91` (2025-11) | Добавлены UserSetting endpoint/service/table |
| `3ca963c4` (2025-11) | JSONB value и транзакционная замена |
| `b17d27b8` (2025-12) | Ответ `204` при отсутствии настройки по key |
| `3c8ce192` (2026-01) | Lookup с fallback на default UUID |
| `15f90451` (2026-08) | SQL удаляет все rows и вставляет новый default set |

Для ТЗ фиксировать, нужен ли общий список с defaults; как выбирать key (case-sensitive/нормализация/limit); допустимую схему map и версионирование; сохранение пользовательских overrides при миграциях; fail-closed при отсутствии валидного `sub`; права endpoint независимо от групп/ролей; ожидаемые race/retry semantics. Фактические role grants, работающая БД и клиентский UI не восстанавливаются из этих исходников.
