# Каталог бизнес-ошибок заявок

> Сверено с checkout `22fac945e8116d04972ccc87b06b2303acf7a561` 18.09.2026 в рамках повторного аудита базовых документов этапа 3 (этот коммит с тех пор не входит в историю `dev` — см. [журнал сверки](../traceability/repository-change-log.md)). Коды, пересекающиеся с частями 16–23 (`MissingTransport`, `MissingConsignee`, `InvalidConsigneeClient/Role`, `MissingOwnerContainer`), сверены с соответствующими физическими моделями на дату аудита. `MissingTransport` с тех пор изменился (KIS-4093, см. [валидацию заявок](order-validation.md)); `MissingOwnerContainer` частично устарел (KIS-4716, см. ниже).
>
> Эта таблица — только про бизнес-коды `X.Что-то`, собираемые в один `ValidationException` при review/accept. Отдельный, не связанный с этой таблицей механизм — generic HTTP-уровневые коды новой иерархии `AlisException` (`AccessDenied`, `NotFound`, `Conflict` и т.д.) — описан в [модели ошибок HTTP API](error-model-as-is.md).

Ошибки review/accept собираются списком и объединяются через `", "`. В таблице `X` означает префикс `ReceivingOrder` или `ShippingOrder`.

## Общие для поставки и вывоза

| Код/шаблон | Когда возникает | Типы заявок |
|---|---|---|
| `X.InvalidStatus` | Недопустимый переход review/accept | транспортные |
| `X.MissingCurrency` | Не задана валюта | все варианты поставки/вывоза |
| `X.MissingPlannedReceivingDateTime` / `X.MissingPlannedShippingDateTime` | Не задана плановая дата | все варианты |
| `X.MissingTransport` | Нет one-to-one транспортной строки | `WAREHOUSE+VEHICLE`, `CONTAINER+VEHICLE` |
| `X.MissingGoods` | Нет товаров, когда их требует `deliveryType` | склад |
| `XGood.MissingPlannedQuantity` | Плановое количество товара ≤ 0 | склад с товарами |
| `XGood.MissingPrice` | Цена товара ≤ 0 | склад с товарами |
| `XGood.MissingTotalPrice` | Общая цена товара ≤ 0 | склад с товарами |
| `X.MissingCargos` | Нет детальных грузовых мест | `BY_GOOD_WITH_CARGO_WITH_DETAILS` |
| `X.MissingCargo` | В строке груза нет ссылки на `Cargo` | детальный груз |
| `XCargo.MissingPackageQuantity` | Фактически: количество упаковок < 0 | детальный груз |
| `XCargo.MissingConversionQuantity` | Фактически: коэффициент/количество < 0 | детальный груз |
| `XCargo.MissingTotalQuantity` | Фактически: итоговое количество < 0 | детальный груз |
| `X.MissingBlackbox` | Нет blackbox или общее число мест равно 0 | недетализированный груз |
| `X.MissingContainers` | Нет контейнеров | контейнерная площадка + авто |
| `ReceivingOrderContainer.MissingOwnerContainer` | У известного КТК нет владельца | контейнерная площадка поставки |
| ~~`ShippingOrderContainer.MissingOwnerContainer`~~ | **Удалено KIS-4716** (коммит `156bcd48`, 25 сентября 2026): у вывоза владелец больше не выбирается и не валидируется на уровне строки заявки — см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md) | — |
| `X.ItemsMissingForContainers` | Непорожний КТК не содержит items | контейнерная площадка |
| `X.EmptyContainerCantHaveItems` | Порожний КТК содержит items | контейнерная площадка |
| `X.ContainerAlreadyInUse` | КТК занят активной заявкой того же направления | при включённом feature flag |
| `<orderNumber>.XContainer.KtkNumberUnknown` | Accept авто-заявки с неизвестным КТК | `CONTAINER+VEHICLE` |
| `X.MissingRailwayCarriages` | Нет конкретных/количественных вагонов | `CONTAINER+RAILWAY` |
| `X.MissingEtranInvoice` | Нет требуемых документов | `CONTAINER+RAILWAY` |

`XContainer.%s.MissingWeight` у вывоза включает идентификатор контейнера и иногда вагона; у поставки используется `ReceivingOrderContainer.MissingWeight` без идентификатора.

## Только поставка

| Код | Условие |
|---|---|
| `ReceivingOrder.MissingShipper` | На контейнерной площадке не задан грузоотправитель |
| `ReceivingOrder.UndefinedRailwayCarriageType` | При accept найден вагон накладной с неопределённым типом |
| `ReceivingOrderContainerItem.MissingDescription` | Метод проверки существует, но сейчас не включён в карту вызовов |

## Только вывоз

| Код | Условие |
|---|---|
| `ShippingOrder.MissingConsignee` | На контейнерной площадке не задан грузополучатель |
| `ShippingOrder.MissingRailwayCarriageEtranInvoice` | При `fillingType=ALL` вагон не связан с ЭТРАН |
| `ShippingOrder.InvalidNoneContainerData` | Нарушена специальная форма единственного неизвестного порожнего КТК |
| `ShippingOrder.RejectNotAllowed` | Недопустим переход в `REJECTED` |
| `ShippingOrder.InvalidConsigneeClient` | Грузополучатель не принадлежит клиенту заявки |
| `ShippingOrder.InvalidConsigneeRole` | Связанное лицо не имеет роли грузополучателя |
| `ShippingOrderContainerItem.MissingDescription` | Константа существует, но фактическая проверка не вызывается |

## Ошибки сохранения товарной строки (не review/accept)

С 13.10.2026 (`8ee1ab68`, KIS-4841) отдельный `ValidationException` с одним кодом (без префикса заявки) выбрасывается при add/update `ReceivingOrderGood`/`ShippingOrderGood`, HTTP 400. Подробнее — [валидация заявок](order-validation.md#партия-товарной-строки-уровень-3).

| Код | Условие |
|---|---|
| `OrderGood.BatchUnknownNotAllowed` | `batchUnknown=true` у номенклатуры без партионного учёта |
| `OrderGood.BatchUnknownWithBatch` | `batchUnknown=true` и одновременно передана партия |
| `OrderGood.MissingBatch` | Партионный учёт (`MANUFACTURE_DATE`/`EXPIRATION_DATE`), партии нет и `batchUnknown=false` |

Коды Excel-импорта номенклатуры (`clientGoods.*`) описаны в [импорте товаров Авто СК](order-goods-excel-import-as-is.md#коды-ошибок).

## Ошибки комбинаций

| Код | Условие |
|---|---|
| `ReceivingOrder.InvalidTerminalAreaTransportType` / `ShippingOrder.InvalidTerminalAreaTransportType` | ЖД выбрано не для контейнерной площадки |
| `*.MissingDeliveryType` | Для склада + авто не задан `deliveryType` |
| `ShippingOrder.InvalidFillingType` | `NONE_CONTAINER` выбран не для контейнерной площадки + авто |

Связано: [типы заявок](order-types.md), [поставка](receiving-orders.md), [вывоз](shipping-orders.md), [статусы](order-statuses.md).
