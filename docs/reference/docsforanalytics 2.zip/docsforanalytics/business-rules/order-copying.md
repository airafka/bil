# Копирование заявок

> Сверено с checkout `22fac945e8116d04972ccc87b06b2303acf7a561` 18.09.2026 в рамках повторного аудита базовых документов этапа 3. Таблица «Full copy: вывоз» перепроверена напрямую по `ShippingOrderService`-оркестрации (`shippingOrderContainerService.copy`/`shippingOrderContainerItemService.copy`/`shippingOrderGoodService.copy`/`shippingOrderCargoService.copy`/`shippingOrderBlackboxService.copy`) — расхождений не найдено; отсутствие вызова для транспорта и услуг подтверждено (услуги пересоздаются как часть обычного create, а не отдельным copy).

Копирование создаёт новый корень через обычный create-процесс. Поэтому новая заявка получает новый UUID, новый номер, статус `DRAFT` и заново созданные обязательные услуги договора.

Copy endpoints не принимают request DTO: единственный входной параметр — UUID исходной заявки в path. Внутри сервис формирует модель новой заявки и проводит её через тот же create lifecycle; обязательность полей обычных HTTP create DTO к copy-запросу напрямую не применяется. Контракты ручного создания: [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md) и [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md).

## Общая семантика

| Операция | Копирует корень | Копирует дочерние данные |
|---|---:|---:|
| partial copy | да | нет |
| full copy | да | да, в зависимости от типа заявки |

Обе операции доступны по `POST /{id}/partial-copy` и `POST /{id}/full-copy` с permission `*_ORDER_COPY` и READ level.

## Поля корня

### Поставка

Копируются: клиент, договор, площадка, транспорт, валюта, `deliveryType`, срок хранения, `needTransport`, контакт, грузоотправитель, комментарий, номер транспортной накладной, плательщик и станции.

Не копируются: исходные `id`, `number`, `status`, audit-поля, плановая/фактическая дата, маршрут, решение по документам, агрегированные итоги и `ktkNumberUnknown` корня.

### Вывоз

Копируются: клиент, договор, площадка, транспорт, `fillingType`, валюта, `deliveryType`, `needTransport`, грузополучатель, контакт и комментарий.

Не копируются: исходные `id`, `number`, `status`, audit-поля, плановая/фактическая дата, маршрут, адрес грузополучателя, агрегаты и `ktkNumberUnknown`.

В обоих copy-методах контакт читается без null-check, хотя поле модели nullable. Копирование заявки без контакта может завершиться `NullPointerException`; это дефект/ограничение текущей реализации.

## Full copy: поставка

Full copy запрещён для `transportType=RAILWAY`.

| Тип | Что копируется |
|---|---|
| `CONTAINER + VEHICLE` | `ReceivingOrderContainer`, затем их `ReceivingOrderContainerItem` с переназначением на новые контейнерные строки |
| `WAREHOUSE + VEHICLE + BY_GOOD` | товары |
| `... + BY_CARGO` | blackbox-строки |
| `... + BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` | товары и `totalCargoQuantity` |
| `... + BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары, затем грузы с переназначением на новые товарные строки |

Не копируются транспорт, накладные и старые дополнительные операции; обязательные услуги создаются заново по актуальным условиям договора.

## Full copy: вывоз

Full copy запрещён для `transportType=RAILWAY`.

| Тип | Что копируется |
|---|---|
| `CONTAINER + VEHICLE` | `ShippingOrderContainer`, затем `ShippingOrderContainerItem` |
| `WAREHOUSE + VEHICLE + BY_GOOD` | товары |
| `... + BY_CARGO` | blackbox-строки |
| `... + BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары, затем грузы |

Не копируются транспорт, ЭТРАН, вагоны, адрес грузополучателя и старые дополнительные операции.

## Требования к будущим изменениям

В ТЗ на копирование нужно перечислять поля белым списком. Формулировка «скопировать заявку полностью» недостаточна: маршрут, даты, транспортные документы, интеграционные состояния и фактические значения обычно не должны наследоваться.

Связанные документы: [типы заявок](order-types.md), [поставка](receiving-orders.md), [вывоз](shipping-orders.md), [DTO](../dto/README.md).
