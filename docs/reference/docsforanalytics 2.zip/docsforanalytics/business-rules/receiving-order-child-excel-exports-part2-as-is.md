# Дочерние Excel-выгрузки поставки, часть 2 AS-IS

Документ фиксирует на commit `22fac945e8116d04972ccc87b06b2303acf7a561` оставшиеся восемь V1/V2 Excel endpoints поставки: товары, заказанные услуги, накладные Waybill под legacy URI ЭТРАН и вагоны Waybill. Blackbox, cargo, КТК и содержимое КТК разобраны в [первой части](receiving-order-child-excel-exports-as-is.md).

Общий процесс Waybill и миграция старых ЭТРАН-сущностей описаны в [Waybill AS-IS](waybill-etran-as-is.md). Полный декларативный inventory находится в секциях [ReportController](../api/endpoints-generated.md#reportcontroller) и [ReportControllerV2](../api/endpoints-generated.md#reportcontrollerv2).

## HTTP-контур

| Ресурс | V1 endpoint | V2 endpoint | Permission V1/V2 | `PageReportType` / result file |
|---|---|---|---|---|
| Товар | `POST /report/receiving-order-good/{receivingOrderId}/download` | `POST /v2/report/receiving-order-good/download` | `RECEIVING_ORDER_RECEIVING_ORDER_GOOD:READ` | `RECEIVING_ORDER_GOOD_EXPORT` / `receiving_order_good.xlsx` |
| Услуга | `POST /report/receiving-order-requested-service/{receivingOrderId}/download` | `POST /v2/report/receiving-order-requested-service/download` | `RECEIVING_ORDER_RECEIVING_ORDER_REQUESTED_SERVICE:READ` | `RECEIVING_ORDER_REQUESTED_SERVICE_EXPORT` / `receiving_order_requested_service.xlsx` |
| Waybill | `POST /report/receiving-order-etran-invoice/{receivingOrderId}/download` | `POST /v2/report/receiving-order-etran-invoice/download` | `RECEIVING_ORDER_ETRAN_INVOICE:READ` | `RECEIVING_ORDER_WAYBILL_EXPORT` / `receiving_order_waybill.xlsx` |
| Вагон Waybill | `POST /report/receiving-order-railway-carriage/{receivingOrderId}/download` | `POST /v2/report/receiving-order-railway-carriage/download` | `RECEIVING_ORDER_RAILWAY_CARRIAGE:READ` | `RECEIVING_ORDER_RAILWAY_CARRIAGE_EXPORT` / `receiving_order_railway_carriage.xlsx` |

V1 принимает обязательный UUID заявки в path и не принимает body; method-level `consumes = */*`. V2 принимает optional `@Valid` body: [`ReceivingOrderGoodFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingordergood/ReceivingOrderGoodFilter.java), [`ReceivingOrderRequestedServiceFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingorderrequestedservice/ReceivingOrderRequestedServiceFilter.java), [`WaybillFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillFilter.java) либо [`WaybillRailwayCarriageFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillrailwaycarriage/WaybillRailwayCarriageFilter.java).

Все методы объявляют XLSX `produces` и возвращают `StreamingResponseBody`. V1 OpenAPI указывает `200`/`400` без schema; V2 явных responses не содержит. `Content-Disposition` не устанавливается.

URI накладной сохранил имя `etran-invoice`, но после KIS-3631 filter, collector, DTO и report type уже относятся к новой модели `Waybill`. Это compatibility route, а не работа со старой таблицей `receiving_order_etran_invoice`.

```mermaid
flowchart LR
    V1[V1 path receivingOrderId] --> R1[ReportService]
    V2[V2 optional filter body] --> R2[ReportServiceV2]
    R1 --> REG[Collector registry]
    R2 --> REG
    REG --> G[Good collector]
    REG --> S[Requested service collector]
    REG --> W[Waybill collector]
    REG --> C[Waybill carriage collector]
    G --> J[JXLS]
    S --> J
    W --> J
    C --> J
```

## Scope, soft-delete и client access

V1 Good/Service/Carriage создают filter по `receivingOrderId`; Good и Carriage также получают `deleted=false`, а Service — default `deleted=false` из builder. V1 Waybill вызывает `WaybillFilter.byReceivingOrderId(id)` напрямую.

V2 передаёт filter без серверного добавления заявки. Ни один из четырёх filters не реализует `ClientRestrictionFilter`. Good, Service и Carriage проходят через `BaseService`, но [`FilterEnrichServiceImpl`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java) игнорирует их root filter type. Waybill collector вообще вызывает DAO напрямую.

| Случай | Good / Service / Carriage | Waybill |
|---|---|---|
| V1 неизвестный UUID | Пустой XLSX | Пустой набор до попытки открыть отсутствующий template |
| V1 UUID другого клиента | Нет отдельной root/client access проверки | Нет отдельной root/client access проверки |
| V2 body отсутствует | Null filter становится пустым predicate; выбираются все строки, включая deleted | `WaybillDaoService.findAll(null)` вызывает non-null-safe predicate path и ожидаемо падает до генерации |
| V2 `{}` | Все неудалённые строки Good/Service/Carriage | Все Waybill без привязки к конкретной заявке |
| V2 `deleted=null` | Удалённые и неудалённые строки | Поля deleted у WaybillFilter нет |

```mermaid
flowchart TD
    A[Export] --> B{V1 или V2}
    B -- V1 --> I[Server filter receivingOrderId]
    B -- V2 --> F[Optional child/Waybill filter]
    I --> R[Client restriction enrichment]
    F --> R
    R --> N{Root filter implements ClientRestrictionFilter?}
    N -- нет --> Q[Запрос без автоматически добавленного client scope]
    Q --> M[Mapping DTO]
    M --> T[JXLS template]
```

Child permission является единственным controller-level gate. Право на конкретную заявку V1 и принадлежность выбранных строк разрешённым клиентам V2 в этом flow не проверяются. Runtime-роли/gateway могут добавить ограничения, но исходниками данного контура это не подтверждено.

## Товары

### Filter

`ReceivingOrderGoodFilter` поддерживает `receivingOrder`, `clientGood`, `batch`, aliases `item/article` и `clientGoodName/name/nomenclature`, `unitOfMeasure`, `deleted`, planned/actual quantity, price и total price.

`plannedQuantity` и `price` имеют dual JSON contract через `@JsonSetter`:

- объект с ключом `content` преобразуется в `SearchNumber` и может использовать `byOr`;
- объект без `content` преобразуется в `SearchNumberRange` с `from`, `to`, `type` и применяется через AND.

`item`, `clientGoodName` и `unitOfMeasure` также учитывают `byOr`. Некорректное число или enum type внутри custom setter ожидаемо становится unreadable-body `400`.

### DTO и XLSX

Collector передаёт `receivingOrderGoods` — список [`ReceivingOrderGoodDto`](../dto/catalog/receivingordergood/ReceivingOrderGoodDto.md). Шаблон [`receiving_order_good.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_good.xlsx) объявляет area `A1:L2`, но заполняет A–H:

| Колонка | Expression |
|---|---|
| Артикул | `clientGood.item` |
| Номенклатура | `clientGood.name` |
| Партия | `batch.code` |
| Ед. изм. | `clientGood.unitOfMeasure.code` |
| Кол-во всего, план | `plannedQuantity` |
| Цена за 1 ед. изм. | `price` |
| Стоимость | `totalPrice` |
| Кол-во всего, факт | `actualQuantity` |

I–L остаются пустыми. `clientGood`, `batch` или `unitOfMeasure = null` разыменовываются template expression и могут дать `500`.

## Заказанные услуги

### Filter

`ReceivingOrderRequestedServiceFilter` содержит `receivingOrder`, `termOfRequestedService`, default `deleted=false` и range filters `plannedQuantity`, `rate`, `priceWithoutVAT`, `priceWithVAT`, `actualQuantity`. Все собственные условия применяются через AND; отдельных `byOr` веток нет.

### DTO и XLSX

Collector передаёт `receivingOrderRequestedServices` — [`ReceivingOrderRequestedServiceDto`](../dto/catalog/receivingorderrequestedservice/ReceivingOrderRequestedServiceDto.md). Шаблон [`receiving_order_requested_service.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_requested_service.xlsx) имеет area `A1:G2`, но `jx:each lastCell="I2"`; фактические значения находятся в A–G.

В template обнаружены три несовместимых expression:

| Expression | Текущий Java getter | Проблема |
|---|---|---|
| `s.getTermOfRequestedService.getCode()` | `s.getTermOfRequestedService().getCode()` | Пропущены скобки вызова первого getter |
| `s.getPriceWithoutVat()` | `s.getPriceWithoutVAT()` | Java method name чувствителен к регистру acronym |
| `s.getPriceWithVat()` | `s.getPriceWithVAT()` | Java method name чувствителен к регистру acronym |

JXLS настроен как `silent=false`, `strict=true` и `withExceptionThrower`. Поэтому непустая выгрузка услуг ожидаемо завершается `JxlsReportProcessingException`; runtime endpoint отдельно не запускался. Пустая выборка способна вернуть только template headers, не вычисляя expressions.

## Waybill под legacy URI ЭТРАН

KIS-3631 удалил старый `ReceivingOrderEtranInvoiceExportReportDataCollectorService` и заменил его [`ReceivingOrderWaybillExportReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ReceivingOrderWaybillExportReportDataCollectorService.java). V1 выбирает Waybill по прямому `receiving_order_id`; V2 использует весь `WaybillFilter`.

Filter поддерживает identifier/number, дату создания, shipment type, status, payer/departure/destination IDs, `receivingOrderId`, status include/exclude collections, destination ESR codes и два варианта общего search. `receivingOrderIdNullOrEqual` учитывается только вместе с non-null `receivingOrderId`. Если одновременно заданы `search` и `previewSearch`, используется `search`.

Collector преобразует entities в [`WaybillDetailedDto`](../dto/catalog/waybill/WaybillDetailedDto.md) и кладёт список под ключом `receivingOrderWaybills`. Mapper без null-защиты строит departure/destination DTO, поэтому отсутствие станции может дать `500` ещё до JXLS.

### Отсутствующий template

`PageReportType.RECEIVING_ORDER_WAYBILL_EXPORT` указывает на `reports/receiving_order_waybill.xlsx`, но такого resource-файла в репозитории нет. Сохранился только legacy [`receiving_order_etran_invoice.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_etran_invoice.xlsx), который несовместим с новым collector:

- ожидает parameter `receivingOrderEtranInvoices`, а collector передаёт `receivingOrderWaybills`;
- ожидает old wrapper `s.getEtranInvoice()`, а collector передаёт `WaybillDetailedDto`;
- enum на legacy filename больше не ссылается.

```mermaid
flowchart TD
    E[POST ...etran-invoice.../download] --> C[ReceivingOrderWaybill collector]
    C --> D[WaybillDetailedDto list<br/>key receivingOrderWaybills]
    D --> P[PageReportType path<br/>reports/receiving_order_waybill.xlsx]
    P --> X{Resource существует?}
    X -- нет --> F[JxlsReportProcessingException → 500]
    L[Legacy receiving_order_etran_invoice.xlsx] -. другой key и DTO .-> F
```

Следовательно, V1 с любым UUID и V2 с non-null filter после успешного mapping ожидаемо падают при открытии template. V2 без body падает раньше на null filter. Коммит KIS-3631 добавил enum/collector, но не добавил новый XLSX и не переподключил legacy resource.

## Вагоны Waybill

### Filter и compatibility

[`WaybillRailwayCarriageFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillrailwaycarriage/WaybillRailwayCarriageFilter.java) содержит nested `waybill`, railway carriage, type/model, lifting capacity, ownership, depot-repair date, raw `TaskStatus`, common search и default `deleted=false`.

Aliases:

- `railwayCarriage`: `number`, `carriageNumber`;
- `railwayCarriageType`: `type`;
- `railwayCarriageModel`: `model`.

Legacy body `"receivingOrder":{"id":"..."}` принимается через `@JsonAnySetter` и преобразуется только в `waybill.receivingOrderId`. Другие поля внутри legacy object игнорируются. Некорректный UUID ожидаемо даёт deserialization `400`.

Общий `search` ищет по номеру, старому полю sort, model code, грузоподъёмности, ownership и depot date; type code и status в эту OR-группу не входят. Одинаковые границы `BETWEEN` для depot date превращаются в сутки `[start, start + 1 day)`.

### DTO и XLSX

Collector передаёт `receivingOrderRailwayCarriages` — [`WaybillRailwayCarriageDto`](../dto/catalog/waybillrailwaycarriage/WaybillRailwayCarriageDto.md). Mapper намеренно заполняет compatibility fields:

- `receivingOrder` из `waybill.receivingOrder`, code всегда `null`;
- `receivingOrderEtranInvoice` как `waybill.id + waybill.number`;
- `dataTimeKrugloyePole`, `customerService`, `ownerRailwayCarriage` всегда `null`.

Шаблон [`receiving_order_railway_carriage.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_railway_carriage.xlsx) имеет area `A1:G2`, но использует A–E: номер накладной, номер вагона, type code («Род вагона»), model code и грузоподъёмность. F–G пустые. Null waybill reference, railway carriage, type или model может привести к expression failure.

## Объём, сортировка и транзакции

Good, Service и Carriage collectors создают `PageInfo(page=0, size=Integer.MAX_VALUE)`. Это означает data query плюс count query, полный entity list, parallel mapping в полный DTO list и лишь затем JXLS streaming. V1 использует default `id ASC`, V2 сохраняет sorting fields request; null filter также даёт default `id ASC`.

Waybill collector отличается: он вызывает `WaybillDaoService.findAll(filter)` без pagination и count query, но также без лимита. Порядок задаётся `WaybillFilter.getSorting()`, default — `id ASC`.

Сбор выполняется в `REPEATABLE_READ`, render — после возврата из collector transaction. Parallel mapping создаёт уже описанный риск обращения к lazy JPA associations из common-pool threads.

## Ошибки и тесты

| Случай | AS-IS |
|---|---|
| Нет child permission | Ожидаемо `403` |
| Malformed UUID/body/custom setter | `400` до streaming |
| Unknown V1 order UUID | Пустой XLSX для Good/Service/Carriage; Waybill доходит до отсутствующего template |
| V2 Waybill без body | Null filter → ожидаемый `500` |
| Non-empty Service | Несовместимые template getters → ожидаемый `500` |
| Waybill после успешного mapping | Template resource отсутствует → `500` |
| Null nested DTO fields | Возможный JXLS/mapping `500` |
| Ошибка после начала stream | Частичный XLSX; JSON error/status не гарантированы |

Source-wide поиск не нашёл прямых tests восьми mappings, четырёх collectors, четырёх `PageReportType` или XLSX output. DAO/service/Waybill tests не вызывают этот export pipeline. Тесты при документировании не запускались.

## История изменений

| Commit | Влияние на текущий AS-IS |
|---|---|
| `7e50a680`, `bd4ec3d3`, `576e8787` (2025-08-13…18, KIS-47) | Добавили исходные receiving child exports, permissions и templates |
| `c2d41a09`, `4d870bdd`, `1b0c4917` (2025-08-22…27, KIS-47) | Рефакторинг collectors и templates |
| `905ef6e4` (2025-09-08, KIS-1336) | Добавил V2 optional-filter endpoints |
| `969e2059` (2025-09-11, KIS-1673) | Исправлял Good/legacy ЭТРАН templates |
| `1e0b0443`, `d2c385b6` (2025-12-02/11, KIS-1966) | Менял Requested Service template; текущие getter mismatches сохранились |
| `443ae69a` (2026-04-14, KIS-3631) | Удалил legacy ЭТРАН entities/collector, добавил Waybill collector/filter/DTO compatibility, но не добавил `receiving_order_waybill.xlsx` |
| `3256b8f0` (2026-06-18) | Перевёл paged collectors на новый PageInfo с `Integer.MAX_VALUE` |
| `42eee4ee`, `978f0601` (2026-08-25) | Изменили Waybill/carriage filters; V2 export автоматически унаследовал новые semantics |

## Чек-лист для ТЗ

1. Определить обязательный scope по заявке и client RLS для обеих версий.
2. Зафиксировать soft-delete и поведение absent body/`{}`/`deleted=null`.
3. Для Waybill решить, сохраняется ли legacy URI `etran-invoice` и какое имя файла возвращается.
4. Создать/выбрать фактический Waybill XLSX и согласовать parameter key с DTO.
5. Исправить и покрыть expressions Requested Service.
6. Утвердить dual-form plannedQuantity/price и legacy carriage filter compatibility.
7. Ограничить число строк либо перейти на async generation.
8. Определить null-policy nested справочников и станций.
9. Зафиксировать сортировку, Content-Disposition и streaming error contract.
10. Добавить HTTP/RLS/filter/template/content tests всех восьми методов.
