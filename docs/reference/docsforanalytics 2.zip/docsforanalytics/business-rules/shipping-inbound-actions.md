# Входящие действия завершения вывоза

Документ фиксирует **AS-IS** shipping-веток `TOS_SHIPMENT_RESULT`, `WMS_SHIPMENT_RESULT`, `VH_DEPARTURE` и `STATUS_COMPLETED`, изначально сверенных на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (11.09.2026; этот коммит с тех пор не входит в историю `dev` — см. [журнал сверки](../traceability/repository-change-log.md)). Общий транспортный контракт `POST /datareon/event`, журнал, HTTP-ответы, транзакция actions, права и отсутствие гарантированной дедупликации описаны в [сценарии `CARRIAGE_ARRIVED`](shipping-railway-empty-completion.md). **Владение КТК актуализировано 29.09.2026** под KIS-4661 (см. правки ниже и [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md)); остальной разбор `fillingType`/actions не менялся в диапазоне KIS-4093…KIS-4716 и не перепроверялся заново в этой сверке.

## Карта действий

| ID | Action | Основной payload | Изменяемые данные | Может поставить `ShippingOrder=DONE` |
|---|---|---|---|---|
| `BR-SO-IN-001` | `TOS_SHIPMENT_RESULT` | `cargoResult` **или** `addServicesResult` | КТК, вагоны, содержимое КТК, фактическое количество услуг, `ContainerMovement`, владелец КТК | Да, по собственной проверке завершения КТК/назначения КТК вагонам; зависит от `fillingType`. |
| `BR-SO-IN-002` | `WMS_SHIPMENT_RESULT` | непустой `itemsResult`; услуги необязательны | товары, грузовые места, партии, фактическое количество услуг, `GoodMovement` | Нет. |
| `BR-SO-IN-003` | `VH_DEPARTURE` | только общие поля события | `ShippingOrder.actualShippingDateTime` | Нет. |
| `BR-SO-IN-004` | `STATUS_COMPLETED` | только общие поля события | только `ShippingOrder.orderStatus` | Да: любой нетерминальный статус переводится прямо в `DONE`, без проверки дочерних задач. |

Все четыре действия выполняются только если для `eventCode` найдена строка `INBOUND_EVENT_CONFIG` с соответствующим `actionCode`. В production-миграциях подтверждён только mapping `VH_DEPARTURE → VH_DEPARTURE`; `LOAD_FINISH → TOS_SHIPMENT_RESULT`, `SHIP_FINISH → WMS_SHIPMENT_RESULT` и `VH_ARRIVED → STATUS_COMPLETED` используются тестами, но их production-настройка в репозитории не найдена.

## DTO и ключи

- Корневой request: [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md).
- TOS-результат: [CargoProcessingResultDto](../dto/catalog/datareon/inbound/CargoProcessingResultDto.md), [CargoSpecResultDto](../dto/catalog/datareon/inbound/CargoProcessingResultDto.CargoSpecResultDto.md), [SealResultDto](../dto/catalog/datareon/inbound/CargoProcessingResultDto.SealResultDto.md).
- WMS-результат: [ItemsProcessingResultDto](../dto/catalog/datareon/inbound/ItemsProcessingResultDto.md), [ItemsProcessingBatchDto](../dto/catalog/datareon/inbound/ItemsProcessingBatchDto.md).
- Фактические услуги: [AddServicesResultDto](../dto/catalog/datareon/inbound/AddServicesResultDto.md) и [ExtraOperationTypeDto](../dto/catalog/datareon/inbound/ExtraOperationTypeDto.md).

Общие `_order` и `_id`, а также `_item`, `_package` и `addServicesResult[].operationType._id` преобразуются в UUID до создания `InboundEvent`. Неверный UUID приводит к HTTP `500` через общий exception handler, и запись журнала не создаётся.

Для `itemsResult[].batch` DTO допускает отсутствие значения, но converter без null-check вызывает `batch.getNumber()`. Поэтому WMS-request с элементом без `batch` проходит Bean Validation, затем падает с `NullPointerException` до записи журнала. Пустой `batch.number` либо неизвестный `batch.type` уже после преобразования трактуется как отсутствие данных партии.

## Общая последовательность

```mermaid
flowchart TD
    E[POST /datareon/event] --> CFG[Config rows по eventCode]
    CFG --> P0[Actions priority 0]
    P0 --> TOS[TOS_SHIPMENT_RESULT]
    P0 --> WMS[WMS_SHIPMENT_RESULT]
    P0 --> VH[VH_DEPARTURE]
    TOS --> TD{Собственные условия DONE выполнены?}
    TD -->|да| DONE1[ShippingOrder → DONE и перевод владельцев КТК в DEPARTED]
    TD -->|нет| KEEP[Статус заявки не меняется]
    WMS --> WM[Товары, партии, услуги и GoodMovement; статус не меняется]
    VH --> DT[actualShippingDateTime; статус не меняется]
    DONE1 --> P1[STATUS_COMPLETED, priority 1]
    KEEP --> P1
    WM --> P1
    DT --> P1
    P1 -->|есть в config, заявка нетерминальна| DONE2[ShippingOrder → DONE без проверки задач]
    P1 -->|заявка уже DONE/REJECTED| RB[Ошибка: rollback всех actions]
    P1 -->|нет в config| END[Завершить набор actions]
```

`TOS_SHIPMENT_RESULT`, `WMS_SHIPMENT_RESULT` и `VH_DEPARTURE` имеют priority `0`; `STATUS_COMPLETED` — priority `1` и выполняется после них. Actions одного события находятся в одной `REQUIRES_NEW` транзакции: ошибка позднего action откатывает более ранние изменения, после чего журнал отдельно получает `INVALID` или `FAILED`.

## `TOS_SHIPMENT_RESULT`

Действие требует, чтобы был непустым хотя бы один из массивов `cargoResult` или `addServicesResult`, проверяет `orderType=SHIPMENT`, загружает заявку по `_order` и сопоставляет её фактические transport/terminal с фильтрами config. Жёсткой проверки конкретной площадки или транспорта внутри action нет.

### Логика по `fillingType`

| `fillingType` | `_id` означает | Обработка `cargoResult` | Условие `DONE` | Дополнительные эффекты |
|---|---|---|---|---|
| `ALL` | существующий `ShippingOrderContainer` | Первый результат задаёт `actualQuantity`; КТК получает `FINISHED`; random-КТК может быть заменён по `cargoNumber` | Все КТК заявки имеют `FINISHED` и переход в `DONE` разрешён | Обновляются переданные услуги; создаётся `ContainerMovement` для каждого результата. |
| `CONTAINER` | существующий ненумерованный КТК заявки | Для каждого результата создаётся вагон `FINISHED`; КТК связывается с вагоном, получает seals и `FINISHED` | Количество КТК, связанных с вагоном, равно `totalContainerQuantity` | `ContainerMovement` и услуги в этой ветке не создаются. |
| `RAILWAY_CARRIAGE` | ID создаваемого `ShippingOrderContainer` | Находится существующий вагон заявки по `transportNumber`, получает `FINISHED`; создаются КТК и строки ЕТСНГ | То же сравнение linked-container count с `totalContainerQuantity` | Один `_id` используется для каждого элемента массива; несколько `cargoResult` пытаются создать несколько КТК с одинаковым ID. |
| `NONE` | ID создаваемого `ShippingOrderContainer` | Создаются вагон `FINISHED`, КТК `FINISHED` и строки ЕТСНГ | То же сравнение linked-container count с `totalContainerQuantity` | Несколько `cargoResult` также используют один `_id` для разных создаваемых КТК. |
| `NONE_CONTAINER` | существующий либо создаваемый `ShippingOrderContainer` | Требуется ровно один результат; КТК привязывается к заявке, помечается пустым и `FINISHED` | Все КТК заявки имеют `FINISHED` и переход разрешён | Несмотря на имя типа, action создаёт/обновляет строку `ShippingOrderContainer` по переданному `cargoNumber`. |

**Обновлено KIS-4661/4716** (коммит между `c1848ad5` и `HEAD`, до 29 сентября 2026): при успешном собственном переходе в `DONE` действие вызывает `ContainerStatusService.markShipped` — регистр [ContainerOwner](../entities/catalog/entities/containerowner/ContainerOwner.md) переводится в статус `DEPARTED`, владелец (client) **сохраняется**, создаётся строка истории. Раньше (до этого периода) здесь вызывался `ContainerOwnerService.removeOwners`, который владельцев **удалял**; строка ниже описывала именно это старое поведение и была неверна на 29.09.2026. Если переход статуса не разрешён, дочерние данные всё равно изменяются, action считается успешным, а заявка сохраняет прежний статус.

`ALL` создаёт движения КТК после проверки статуса. В остальных четырёх ветках движения КТК не создаются. Фактические услуги обновляются только в `ALL`; переданные IDs, не найденные среди услуг заявки, игнорируются.

## `WMS_SHIPMENT_RESULT`

Действие требует непустой `itemsResult`, но **не вызывает** `hasSuitableOrderType`, `hasSuitableTerminalArea` или `hasSuitableTransportType`. Фильтры соответствующей config-строки для него не ограничивают предметную обработку.

Для каждого item:

1. ищется неудалённый `ShippingOrderGood` той же заявки по `_item` и batch sync ID (по коду партии, в отличие от поставки, не ищется); с 13.10.2026 (`8ee1ab68`, KIS-4841) строка с `batchUnknown=true` совпадает с любой партией этого товара, а несколько совпадений дают `IllegalArgumentException` «Ambiguous order good for client good syncId: …» (откат actions, `InboundEvent=INVALID`) вместо прежнего «не найдено»;
2. его `actualQuantity` увеличивается на `qty`; для строки `batchUnknown=true` фактическая партия находится/создаётся только по WMS `syncId` (`BaseWmsResultAction.resolveUnknownBatch`, ошибка, если партия принадлежит другому `ClientGood`), прикрепляется, а `batchUnknown` сбрасывается в `false`; для остальных строк, как раньше, партия при необходимости создаётся/обновляется по коду (`createOrUpdateBatch`). После первой привязки следующий item того же товара с другой партией строку не находит и создаёт новую (п. 4) — та же особенность, что у [поставки](receiving-inbound-actions.md#wms_receiving_result);
3. для delivery type, отличного от `BY_GOOD`, обновляется первое подходящее грузовое место и его фактическое количество также увеличивается;
4. если единственный товар не найден и заявка не `BY_CARGO`, создаётся новый `ShippingOrderGood` с `plannedQuantity=0`;
5. для каждого item безусловно добавляется новая строка `GoodMovement`; грузовое место `Cargo` ищется или создаётся по `cargoNumber`;
6. переданные `addServicesResult` обновляют `actualQuantity` только у услуг, принадлежащих `_order`; неизвестные IDs игнорируются.

Action не меняет `ShippingOrder.orderStatus`, `ShippingOrderContainer.status` или `ShippingOrderRailwayCarriage.status`. Повторная обработка неидемпотентна: фактические количества складываются повторно, а `GoodMovement` добавляются с новыми UUID.

## `VH_DEPARTURE`

Подтверждённая миграция создаёт config для `RECEIVING, SHIPMENT`, обеих площадок и обоих transport types. Сам action выполняет только shipping-ветку и имеет нетипичную проверку:

- требует, чтобы **список config** разрешал `SHIPMENT`;
- проверяет `hasSuitableTerminalArea(WAREHOUSE)`, то есть наличие `WAREHOUSE` в config, а не площадку найденной заявки;
- проверяет transport type фактической заявки по config;
- при выполнении блокирует заявку и перезаписывает `actualShippingDateTime` значением `eventDateTime`.

Следствие: config только с `CONTAINER` не обработает даже container-заявку, а config с `WAREHOUSE` способен обработать и container-заявку. Отсутствующая заявка или неподходящий transport приводят к тихому no-op и `InboundEvent=DONE`.

## `STATUS_COMPLETED`

Действие применяет config-фильтры типа заявки, фактической площадки и транспорта. Для найденной shipping-заявки оно блокирует строку и устанавливает `DONE`, если текущий статус не `DONE` и не `REJECTED`.

При этом action:

- не вызывает `OrderStatus.isStatusChangeAllowed` и поэтому допускает прямые `DRAFT → DONE` и `ON_REVIEW → DONE`;
- не проверяет состояния КТК, вагонов, товаров или услуг;
- не меняет статус/владельца КТК в регистре `ContainerOwner` (`ContainerStatusService` из этого action не вызывается);
- при отсутствии заявки завершает shipping-ветку без ошибки;
- для уже `DONE`/`REJECTED` выбрасывает ошибку «Suitable order not found», журнал получает `FAILED`.

Integration test прямо подтверждает `DRAFT → DONE` для shipping-заявки с завершёнными вагоном и КТК, но завершённость дочерних задач самим action не проверяется.

## Конфликты нескольких actions одного `eventCode`

| Config-сочетание | Результат AS-IS |
|---|---|
| `CARRIAGE_ARRIVED` + `STATUS_COMPLETED` | Сначала вагон получает `FINISHED`, заявка — возможный `IN_PROGRESS`; затем заявка без проверки остальных задач получает `DONE`. |
| `WMS_SHIPMENT_RESULT` + `STATUS_COMPLETED` | После записи товарных результатов заявка без проверки полноты получает `DONE`; при успехе всё фиксируется одной транзакцией. |
| `VH_DEPARTURE` + `STATUS_COMPLETED` | Записываются фактическое время и `DONE`, если оба action проходят свои разные фильтры. |
| `TOS_SHIPMENT_RESULT` + `STATUS_COMPLETED`, TOS уже поставил `DONE` | Поздний `STATUS_COMPLETED` отвергает терминальную заявку; транзакция откатывает TOS-изменения, журнал получает `FAILED`. |
| `TOS_SHIPMENT_RESULT` + `STATUS_COMPLETED`, TOS не поставил `DONE` | Поздний action ставит `DONE` без проверки того условия, из-за которого TOS оставил прежний статус. |

Для actions с одинаковым priority `0` явный порядок в запросе к `INBOUND_EVENT_CONFIG` не задан. Unit test подтверждает только сортировку `priority 0` перед `STATUS_COMPLETED priority 1` и остановку цепочки на первой ошибке.

## Повторы, ошибки и конкурентность

| Action | Повтор того же сообщения | Блокировки / риск |
|---|---|---|
| `TOS_SHIPMENT_RESULT` | Может повторно добавить movements/вагоны/КТК/строки содержимого; для create-веток вероятны constraint errors. | КТК в `ALL` не блокируется; услуги блокируются; завершение заявки не защищает от повторного запуска. |
| `WMS_SHIPMENT_RESULT` | Повторно увеличивает количества и добавляет `GoodMovement`. | Явной блокировки товара/грузового места перед read-modify-write нет; возможна потеря обновления при конкуренции. |
| `VH_DEPARTURE` | Повторно перезаписывает фактическое время значением последнего обработанного события. | Заявка блокируется перед update, но объект был прочитан до блокировки и после lock не перечитывается явно. |
| `STATUS_COMPLETED` | Первый вызов может поставить `DONE`, повтор получает `FAILED`. | Заявка блокируется перед update, но проверка статуса выполнена до lock; нет явной повторной проверки после блокировки. |

Общий журнал не имеет подтверждённого unique constraint на `_id`; подробнее — [повторы и дедупликация](shipping-railway-empty-completion.md#повторы-и-дедупликация). Ошибки actions поглощаются сервисом, поэтому `InboundEvent=FAILED/INVALID` обычно возвращается вызывающему как HTTP `200`.

## Тестовая трассировка

- `TosShipmentResultActionTest` покрывает пять `fillingType`; проверки `DONE` есть для `ALL`, `CONTAINER` и `NONE_CONTAINER`, создание данных — для всех веток.
- `InboundEventDatareonServiceTest` проверяет обновление услуг/КТК и `ContainerMovement` для TOS, WMS-товары/партии/услуги и `GoodMovement`, дату `VH_DEPARTURE`, а также `STATUS_COMPLETED` и его failure для терминального статуса.
- `ActionsProcessorTest` проверяет priority и остановку после ошибки.
- Найденные тесты в этом подэтапе просмотрены, но не запускались.

Ключевые реализации: [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java), [`WmsShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsShipmentResultAction.java), [`VhDepartureAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/VhDepartureAction.java), [`StatusCompletedResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/StatusCompletedResultAction.java), [`BaseChangeStatusResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseChangeStatusResultAction.java), [`ActionsProcessor`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessor.java), [production config `VH_DEPARTURE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250218_KIS-147_add_vh_departure_action_inbound_event_config.sql), [integration tests](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonServiceTest.java), [TOS unit tests](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultActionTest.java).

## Повлиявшие изменения Git

| Commit | Подтверждённое влияние |
|---|---|
| `f2734e15e74330c056349da6d301461cf182b97c` (`KIS-147`, 20.02.2025) | Добавил `VH_DEPARTURE`, поле фактического времени и единственный найденный production config из четырёх actions. |
| `e0c7a14d0324428ff23126378677d9cb11c3ca47` (`KIS-3231`, 17.02.2026) | Изменил проверку перехода TOS-сценария в `DONE`. |
| `b90c74e82f1d0c3d722208e9e1e90340a1059a93` (`KIS-3366`, 22.04.2026) | Изменил обработку `fillingType=CONTAINER`. |
| `3a283b5af12cdde196f78960c60ac9a62c604048` (`KIS-4271`, 20.07.2026) | Добавил TOS-ветку `NONE_CONTAINER`. |

## Неподтверждённое

Не проверены применённые строки `INBOUND_EVENT_CONFIG`, внешний mapping событий Datareon, порядок строк одинакового priority в production DB, runtime security/gateway, применённая схема БД и фактическое состояние внешних остатков. Названия `LOAD_FINISH`, `SHIP_FINISH` и `VH_ARRIVED` вне явно найденной миграции нельзя считать гарантированными production mappings только по тестам.
