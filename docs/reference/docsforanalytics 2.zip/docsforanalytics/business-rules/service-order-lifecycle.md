# Lifecycle заявки на услугу

Документ фиксирует **AS-IS** полного контура `ServiceOrder` на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 11.09.2026): HTTP endpoints, DTO, выбор КТК, `accept`, смену владельцев и экспорт `SERVICE_ORDER_CHAIN_PACKAGE`. Реализация не изменялась.

## Граница процесса

Сейчас существуют ровно один тип услуги `CHANGE_OWNER` и два статуса `DRAFT`, `DONE`. Заявка не является `TransportOrder`: у неё нет площадки, транспорта, review/reject и промежуточного статуса.

```mermaid
flowchart TD
    C[POST /service-order/] --> D[ServiceOrder DRAFT]
    D --> U[PUT корня: service/comment]
    D --> S[PUT /container: заменить выбор КТК]
    S --> V{Есть минимум один ServiceOrderContainer?}
    V -->|нет| E400[accept: HTTP 400, остаётся DRAFT]
    V -->|да| A[POST /accept; lock ServiceOrder]
    A --> O[Сменить владельцев КТК на клиента заявки]
    O --> H[Создать ContainerOwnerHistory при фактической смене]
    H --> X[status DONE; completionAt now]
    X --> Q[Создать OutboundData SERVICE_ORDER_CHAIN_PACKAGE]
    Q --> K[Commit одной транзакции]
    K --> SCH[Планировщик выбирает outbound]
    SCH --> P[POST Datareon /serviceOrder]
```

## API и права

Корневой controller: [ServiceOrderController](../api/endpoints-generated.md#serviceordercontroller). Контейнеры: [ServiceOrderContainerController](../api/endpoints-generated.md#serviceordercontainercontroller).

| Endpoint | Request → response | Permission | Серверная логика |
|---|---|---|---|
| `POST /service-order/page` | `FilterWithPaging<ServiceOrderFilter>` → page [ServiceOrderDto](../dto/service-order/ServiceOrderDto.md) | `SERVICE_ORDER`, `READ` | Применяет ограничение пользователя, фильтрует заявки и отдельным запросом обогащает страницу `containerQuantity`. |
| `POST /service-order/meta/{fieldName}` | optional filter → `IdsCodeDto[]` | `SERVICE_ORDER`, `READ` | Для `containerQuantity` выполняет специальную группировку; остальные поля обрабатывает общий meta-механизм. |
| `GET /service-order/{id}` | без body → `ServiceOrderDto` | `SERVICE_ORDER`, `READ` | Читает заявку по ID; `containerQuantity` этим методом отдельно не обогащается. |
| `POST /service-order/` | [ServiceOrderCreationDto](../dto/service-order/ServiceOrderCreationDto.md) → `ServiceOrderDto` | `SERVICE_ORDER`, `CREATE` | Создаёт UUID и общий номер заявки, сохраняет клиента/услугу/комментарий, устанавливает `DRAFT`. |
| `PUT /service-order/{id}` | [ServiceOrderUpdateDto](../dto/service-order/ServiceOrderUpdateDto.md) → `ServiceOrderDto` | `SERVICE_ORDER`, `WRITE` | Требует равенство path ID и `body.id`, статус `DRAFT`; меняет только услугу и комментарий. |
| `DELETE /service-order/{id}` | без body → снимок `ServiceOrderDto` | `SERVICE_ORDER`, `DELETE` | Только `DRAFT`; физически удаляет связи с КТК, затем саму заявку. Физические КТК и владельцы не удаляются. |
| `POST /service-order/{id}/accept` | без body → `ServiceOrderDto` | отдельный `SERVICE_ORDER_ACCEPT` | Блокирует заявку, валидирует состав, меняет владельцев, ставит `DONE`, задаёт время и создаёт outbound. |
| `POST .../container/page` | `FilterWithPaging<ServiceOrderContainerFilter>` → page [ServiceOrderContainerDto](../dto/catalog/serviceordercontainer/ServiceOrderContainerDto.md) | `SERVICE_ORDER`, `READ` | Возвращает только выбранные связи и текущих владельцев КТК. |
| `POST .../container/edit/page` | `FilterWithPaging<ContainerOwnerFilter>` → page `ServiceOrderContainerDto` | `SERVICE_ORDER`, `READ` | Только для `DRAFT`; показывает выбранные первыми и доступные для добавления записи текущих владельцев. |
| `POST .../container/edit/meta/{fieldName}` | owner filter → `IdsCodeDto[]` | `SERVICE_ORDER`, `READ` | Только `DRAFT`; поддерживает meta `client` и `container`. |
| `POST .../container/meta/{fieldName}` | owner filter → `IdsCodeDto[]` | `SERVICE_ORDER`, `READ` | Проверяет существование заявки; поддерживает только `client` среди уже выбранных КТК. |
| `PUT /service-order/{serviceOrderId}/container` | список [ServiceOrderContainerSaveDto](../dto/catalog/serviceordercontainer/ServiceOrderContainerSaveDto.md) → список `ServiceOrderContainerDto` | `SERVICE_ORDER`, `WRITE` | Только `DRAFT`; под блокировкой заявки полностью синхронизирует выбранный набор. |

Миграция создаёт permission paths `ServiceOrder` как `FORM` и `ServiceOrderAccept` как `BUTTON`. Как эти paths назначены конкретным ролям в развернутой среде, исходники не подтверждают.

## Обязательность DTO

### Создание

| JSON-поле | Обязательность | Значение |
|---|---|---|
| `client` | `@NotNull`, вложенная `@Valid`; `client.id` имеет `@NotNull` | Клиент, который станет новым владельцем выбранных КТК. |
| `service` | `@NotNull` | Только `CHANGE_OWNER`; другое enum-значение не десериализуется. |
| `comment` | необязательное, nullable | В DTO нет ограничения длины; в миграции колонка ограничена `VARCHAR(1000)`. |

`id`, `number`, `status`, `completionAt` и контейнеры в create request отсутствуют. UUID задаётся при сохранении, номер — общим sequence-механизмом `ORDER`, статус — конструктором `ServiceOrder`.

### Обновление

`body.id` и `service` имеют `@NotNull`; `comment` допускает `null`. Path ID обязан совпасть с `body.id`. Клиент, номер, статус, время выполнения и контейнеры этим endpoint не меняются.

### Состав контейнеров

Тело `PUT .../container` и каждый элемент списка имеют `@NotNull`. Пустой список допустим и удаляет весь текущий выбор. Каждый `ServiceOrderContainerSaveDto` проходит property-validation `@AssertTrue`: должен быть задан `id` существующей связи **или** `containerOwnerId` добавляемого КТК.

Если заданы оба поля, реализация рассматривает элемент как существующую связь по `id`, а `containerOwnerId` не использует. Повторяющиеся IDs и owner IDs сворачиваются множествами; один физический КТК добавляется не более одного раза в заявку.

## Замена выбранных КТК

```mermaid
flowchart TD
    R[PUT список selected] --> L[findAndLock ServiceOrder]
    L --> D{status = DRAFT?}
    D -->|нет| F403[HTTP 403]
    D -->|да| OLD[Загрузить существующие связи]
    OLD --> IDS[Проверить все переданные id]
    IDS --> REM[Удалить связи, которых нет в selected]
    REM --> OWN[Загрузить новые ContainerOwner по containerOwnerId]
    OWN --> AV{Владельцы доступны?}
    AV -->|нет| BAD[HTTP 400; rollback удаления]
    AV -->|да| ADD[Добавить новые уникальные ServiceOrderContainer]
    ADD --> OUT[Вернуть полный актуальный выбор]
```

КТК доступен для выбора, когда:

1. существует текущая строка `ContainerOwner`;
2. текущий владелец отличается от клиента заявки — то есть операция действительно изменит владельца;
3. тот же КТК не включён в другую сервисную заявку со статусом `DRAFT`.

Связь с другой заявкой `DONE` не блокирует новый выбор: это позволяет последующую смену владельца. Уже выбранные в текущей заявке строки возвращаются первыми на edit-page, если также проходят owner-фильтр доступности.

Проверка и изменения набора находятся в одной транзакции. Если новый owner ID отсутствует или недоступен, ранее выполненное внутри метода удаление невыбранных связей откатывается.

## Выполнение `accept`

`accept` выполняется одной транзакцией и начинает с `findAndLock(id)`:

1. требует точный текущий статус `DRAFT`;
2. загружает все `ServiceOrderContainer`; пустой набор даёт `ValidationException`;
3. для каждого физического `Container` вызывает смену владельца на `ServiceOrder.client`;
4. если владельца нет — создаёт `ContainerOwner`; если он другой — обновляет и создаёт [ContainerOwnerHistory](../entities/catalog/entities/containerownerhistory/ContainerOwnerHistory.md); если уже совпадает — ничего не меняет и историю не создаёт;
5. устанавливает `status=DONE` и `completionAt=Instant.now()`;
6. добавляет одну строку [OutboundData](../entities/catalog/entities/outbounddata/OutboundData.md) для `SERVICE_ORDER_CHAIN_PACKAGE` с `entityType=SERVICE_ORDER` и `rootObjectId=id`.

Владелец, история, статус, время и outbound фиксируются атомарно: исключение в любой из этих операций откатывает всю транзакцию. Повторный accept сериализуется блокировкой и после первого commit получает ошибку из-за `DONE`; второй outbound штатно не создаётся.

## Outbound-пакет

Конфигурация пары `SERVICE_ORDER → SERVICE_ORDER_CHAIN_PACKAGE` хранится в Java-коде, а не в таблице config. Планировщик с delay `${datareon.cron.serviceOrderChainPackage}` (в общем application config — `5000` мс) вызывает экспорт, который отправляет JSON Basic-authenticated `POST` на `${datareon.base.url}/serviceOrder`.

Payload строится **в момент экспорта**, а не сохраняется снимком при accept:

- один `ServiceOrder`: ID, номер, client ID, service, comment, status, `completionAt`;
- все `ServiceOrderContainer`: ID связи, service order ID, container ID;
- уникальные физические `Container` со справочными полями;
- клиент заявки с реквизитами.

После HTTP 2xx response body обязан содержать UUID сообщения. Тогда outbound получает `success=true`, `responseCode`, `messageId` и увеличенный `attempts`. Ошибка преобразования, отправки, не-2xx, пустое или не-UUID тело дают `success=false`, `errorMessage` и увеличенный `attempts`.

Экспорт выполняется в отдельной `REQUIRES_NEW` транзакции, выбирает строки через `SKIP LOCKED`, делает до пяти попыток и увеличивает интервал примерно на `5 × attempts` минут. Если внешний сервис фактически принял пакет, но вернул потерянный/некорректный ответ, повтор может отправить бизнес-пакет снова: отдельный внешний idempotency key в DTO не найден.

`ServiceOrderChainPackageExportService` не имеет `postExport`: успешная доставка не меняет заявку, контейнеры или владельцев.

## Ошибки HTTP

| Условие | Исключение AS-IS | HTTP по `ExceptionAdvice` |
|---|---|---:|
| Невалидный request DTO/enum/UUID | Bean/Jackson validation | `400` |
| Заявка, связь или owner ID не найдены | `NotFoundException` | `404` |
| Нет permission либо изменение после `DONE` | `AccessDeniedException` | `403` |
| Accept без КТК | `ValidationException` | `400` |
| Owner недоступен для добавления | `ValidationException` | `400` |
| Повторный accept или accept не из `DRAFT` | `IllegalStateException` | `500` |
| Path ID update не совпадает с `body.id` | `IllegalArgumentException` | `500` |
| Unique violation пары заявка + КТК | `DataIntegrityViolationException` с SQLSTATE `23505` | `409` |

Таким образом, OpenAPI-описание accept (`400`, `404`) не перечисляет фактический `500` повторного вызова. Ошибка бизнес-состояния update/delete оформлена как `403`, а аналогичная ошибка accept — как `500`.

## Конкурентность и границы доверия

- `accept` и `saveSelected` блокируют одну строку сервисной заявки, поэтому для **одной** заявки они сериализованы.
- `update` и `remove` используют обычное чтение без `findAndLock`; у сущностей нет `@Version`. Их гонки с accept отдельно не защищены optimistic locking.
- Два разных черновика блокируют разные строки. Проверка «КТК не занят другой DRAFT-заявкой» и вставка связи не защищены общей блокировкой владельца/КТК или unique constraint только по `container_id`; конкурентный выбор одного КТК в разные DRAFT-заявки возможен.
- `accept` повторно не вызывает проверку доступности owner и не блокирует `ContainerOwner` явно. Между выбором и выполнением текущий владелец и участие КТК в другом черновике могут измениться.
- DB unique constraint запрещает только повтор пары `(service_order_id, container_id)`, а `ContainerOwner.container_id` уникален глобально.
- Сервер доверяет сохранённому составу агрегата: accept request не содержит списка КТК или ожидаемого старого владельца.
- Пользовательское ограничение `FilterEnrichService` явно применяется к странице и meta корня, но не вызывается в `GET /{id}` и scoped container-методах. Доступ к конкретному ID в этих путях опирается на `@Secure` и доступность объекта в DAO; отдельная row-level проверка клиента в просмотренной цепочке не найдена.

## Тестовая трассировка

Активные integration tests подтверждают:

- обогащение страницы количеством КТК;
- создание одной outbound-строки и `DONE` после accept;
- отказ `400` и отсутствие outbound для заявки без КТК;
- выборку выбранных/доступных контейнеров, исключение КТК клиента заявки и другого `DRAFT`, но доступность после другого `DONE`;
- смену владельца по сервисной заявке и создание истории в отдельном тесте `ContainerOwnerService`.

В просмотренных тестах не найдены отдельные проверки create/update/delete controllers, фактического `completionAt`, повторного accept, path/body mismatch, `saveSelected` add/remove/rollback, конкурентного выбора, сборки/HTTP-отправки `ServiceOrderChainPackageDto` и retry после неоднозначного внешнего ответа. Найденные тесты не запускались.

Источники: [ServiceOrderController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/serviceorder/ServiceOrderController.java), [ServiceOrderContainerController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/serviceordercontainer/ServiceOrderContainerController.java), [ServiceOrderService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/serviceorder/ServiceOrderService.java), [ServiceOrderContainerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/serviceordercontainer/ServiceOrderContainerService.java), [ContainerOwnerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerowner/ContainerOwnerService.java), [outbound exporter](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ServiceOrderChainPackageExportService.java), [outbound DTO](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ServiceOrderChainPackageDto.java), [service tests](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/serviceorder/ServiceOrderServiceIntegrationTest.java), [container tests](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/serviceordercontainer/ServiceOrderContainerServiceIntegrationTest.java).

## Физические ограничения миграции

Миграция создаёт:

- `service_order.number UNIQUE` и `CHECK number > 0`;
- `service IN ('CHANGE_OWNER')`, `status IN ('DRAFT','DONE')`;
- обязательные client/service/status/audit поля;
- `UNIQUE(service_order_id, container_id)` у связей;
- `UNIQUE(container_id)` у текущих владельцев;
- историю с discriminator `SERVICE_ORDER`, но без внешнего FK от polymorphic `order_id` к `service_order`.

Применённая схема БД не проверялась. Источник: [миграция таблиц](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260707_add_service_order_and_container_owner_tables.sql), [миграция permissions](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260708_add_service_order_and_container_owner_permissions.sql).

## Повлиявшие изменения Git

| Commit | Подтверждённое влияние |
|---|---|
| `ef43207b62de21dae5215559fdd29ff64ae76a70` (`KIS-4269`, 14.07.2026) | Добавил ServiceOrder, владельцев/историю, controllers, DTO, lifecycle, outbound, permissions, миграции и основные integration tests. |
| `9f6068389f73b2daf99c25c27060ae991ee75c19` (`KIS-4269`, 14.07.2026) | Исправил sorting/meta инфраструктуру, используемую страницей сервисных заявок. |
| `1fa0a7834875d13b4fe95c1207794f854121e61a` (06.08.2026) | Перевёл автоматическое назначение общего номера заявки на аннотацию `@EntitySequence(EntitySequenceType.ORDER)`. |
| `f9b367dfd3a003bfaa80c4f06869abb6e6c7e060` (`KIS-4269`, 12.08.2026) | Добавил meta уже выбранных контейнеров. |
| `ab2480a253dfaf932224e49bbfe901d7e3646c2f` (`KIS-4483`, 12.08.2026) | Добавил и исправил edit-meta выбора контейнеров. |

## Неподтверждённое

Не проверены runtime-роли, применённая схема, значения secrets/base URL, реальный планировщик, внешний Datareon `/serviceOrder`, формат его UUID-ответа и идемпотентность потребителя. Документ описывает реализацию, а не гарантирует доступность endpoint в развернутой среде.
