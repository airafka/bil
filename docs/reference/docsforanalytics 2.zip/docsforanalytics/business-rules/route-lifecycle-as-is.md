# Рейсы: основной lifecycle AS-IS

Документ фиксирует серверное поведение основного контура `Route` на commit `22fac945e8116d04972ccc87b06b2303acf7a561`: чтение, создание, изменение, удаление, копирование, назначение заявок и переходы `review/accept/reject`. Это описание фактического кода, а не целевой контракт.

Плановые и фактические shipping-таблицы рейса, их meta endpoints и SQL views разобраны отдельно: [план, факт и meta по заявкам на вывоз](route-shipping-plan-fact-as-is.md). Пять PDF/Excel endpoints `ReportController`, их permissions, collectors и templates описаны в [отчётном контуре рейса](route-reports-as-is.md).

Основные источники: [RouteController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/route/RouteController.java), [RouteService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java), [Route](../entities/catalog/entities/route/Route.md), [полный endpoint-каталог](../api/endpoints-generated.md#routecontroller).

## Назначение и агрегат

Рейс группирует транспортные заявки только одного направления:

- `SHIPPING` — заявки на вывоз;
- `RECEIVING` — заявки на поставку.

Тип транспорта (`RAILWAY` или `VEHICLE`) и терминальная площадка задаются при создании и через обычный update не меняются. Для автотранспортного рейса дополнительно используются перевозчик, водитель и транспортное средство. Связь хранится на стороне `shipping_order.route_id` или `receiving_order.route_id`, а не в отдельной link-table.

Как эти правила выглядят для пользователя (какие кнопки, права и фильтры проверяет интерфейс) — в [UI-правилах рейсов](route-ui-rules-as-is.md).

Ключевые правила для ссылок из ТЗ:

| ID | Правило AS-IS |
|---|---|
| `BR-ROUTE-001` | Новый рейс создаётся в `DRAFT`; public create требует type/date/area/transport |
| `BR-ROUTE-002` | `VEHICLE` требует carrier/driver/vehicle, `RAILWAY` разрешён только для `CONTAINER` |
| `BR-ROUTE-003` | Update разрешён только в `DRAFT`/`ON_REVIEW` и адресует запись по `body.id` |
| `BR-ROUTE-004` | Назначать можно найденные совместимые заявки `DRAFT`/`ON_REVIEW`; принадлежность другому рейсу не защищена |
| `BR-ROUTE-005` | Unassign не проверяет, что заявка принадлежит рейсу из URL, и не восстанавливает `needTransport` |
| `BR-ROUTE-006` | Review/accept требуют дату и хотя бы одну заявку; операция атомарна по рейсу и заявкам |
| `BR-ROUTE-007` | Reject блокирует рейс и каскадно отклоняет заявки; пустой рейс допустим |
| `BR-ROUTE-008` | Автоматический status sync выводит статус из заявок без проверки transition map |
| `BR-ROUTE-009` | При `ACCEPTED` в той же транзакции создаётся route outbound или chain package |
| `BR-ROUTE-010` | Soft delete скрывает рейс в filtered reads, но direct-ID lifecycle явно `deleted` не проверяет |

```mermaid
erDiagram
    ROUTE ||--o{ SHIPPING_ORDER : "route_id, если SHIPPING"
    ROUTE ||--o{ RECEIVING_ORDER : "route_id, если RECEIVING"
    ROUTE }o--|| TERMINAL_AREA_CATALOG : terminal_area_catalog_id
    ROUTE }o--o| CLIENT_RELATED_ENTITY : carrier
    ROUTE }o--o| CLIENT_DRIVER : driver
    ROUTE }o--o| CLIENT_VEHICLE : vehicle

    ROUTE {
      uuid id PK
      integer number identity
      varchar route_type
      timestamp data_time nullable
      varchar transport_type
      varchar status
      boolean deleted
    }
```

## HTTP endpoints и DTO

| Метод и путь | Permission | Request | Response | Фактическая роль |
|---|---|---|---|---|
| `POST /routes/all` | `ROUTE/READ` | тела нет | `List<RouteDto>` | Все доступные неудалённые рейсы; сервис создаёт пустой `RouteFilter` и предельный `PageInfo` |
| `POST /routes/page` | `ROUTE/READ` | [RoutePageRequest](../dto/catalog/route/RoutePageRequest.md) | `Page<RouteDto>` | Фильтр, сортировка и paging; принимается новый wrapper и legacy flat JSON |
| `POST /routes/meta/{fieldName}` | `ROUTE/READ` | `FilterWithPaging<RouteMetaFilter>` | `List<IdsCodeDto>` | Уникальные значения поля в области текущего фильтра |
| `GET /routes/{id}` | `ROUTE/READ` | path UUID | [RouteDetailedDto](../dto/catalog/route/RouteDetailedDto.md) | Прямой поиск рейса по UUID |
| `POST /routes/{id}/orders/page` | `ROUTE/READ` | `FilterWithPaging<RouteOrderFilter>` | `Page<OrderRouteDetailDto>` | Deprecated-страница заявок рейса |
| `POST /routes/{routeId}/orders` | `ROUTE/READ` | optional `BaseIdFilter` | [RouteClientOrderReportDto](../dto/catalog/route/RouteClientOrderReportDto.md) | Группировка заявок рейса по клиенту |
| `POST /routes/{routeId}/orders/meta/{fieldName}` | `ROUTE/READ` | `FilterWithPaging<RouteClientOrderFilter>` | `List<IdsCodeDto>` | Meta заявок, принудительно ограниченное `routeId` из path |
| `POST /routes` | `ROUTE/CREATE` | [RouteCreationDto](../dto/catalog/route/RouteCreationDto.md) | `RouteDetailedDto` | Создание `DRAFT`-рейса |
| `PUT /routes/{id}` | `ROUTE/WRITE` | [RouteUpdateDto](../dto/catalog/route/RouteUpdateDto.md) | `RouteDetailedDto` | Изменение по `body.id`; path `{id}` handler не читает |
| `DELETE /routes/{id}` | `ROUTE/DELETE` | path UUID | [RouteDto](../dto/catalog/route/RouteDto.md) | Soft delete допустимого пустого рейса |
| `POST /routes/{id}/assign` | `ROUTE/CREATE` | [AssignOrderDto](../dto/catalog/route/AssignOrderDto.md) | без тела | Назначение заявок рейсу |
| `DELETE /routes/{id}/assign` | `ROUTE/DELETE` | `AssignOrderDto` | без тела | Снятие связи заявок с рейсом |
| `GET /routes/{id}/assign` | `ROUTE/READ` | path UUID | `AssignOrderDto` | UUID назначенных заявок |
| `POST /routes/{id}/change-status/review` | `ROUTE_SEND_REVIEW/DELETE` | path UUID | `RouteDetailedDto` | Перевод рейса и всех заявок в `ON_REVIEW` |
| `POST /routes/{id}/change-status/accept` | `ROUTE_SEND_ACCEPT/DELETE` | path UUID | `RouteDetailedDto` | Приём рейса и всех заявок, постановка outbound |
| `PUT /routes/{id}/reject` | `ROUTE_REJECT/DELETE` | path UUID | `RouteDetailedDto` | Блокирующее отклонение рейса и всех заявок |
| `GET /routes/{id}/cargo-chain` | `ROUTE/READ` | path UUID | [RouteToCargoChainPackageDto](../dto/catalog/routetocargochainpackage/RouteToCargoChainPackageDto.md) | Cargo-chain, фактически наполненный только для shipping |
| `POST /routes/{id}/partial-copy` | `ROUTE_COPY/READ` | path UUID | `RouteDetailedDto` | Новый пустой `DRAFT`-рейс по части полей исходного |

Необычные пары permission/access level (`ROUTE_SEND_*` и `ROUTE_REJECT` с `DELETE`, `ROUTE_COPY` с `READ`) являются фактом текущих annotations, а не смысловой рекомендацией.

### Детали read-контрактов

[RoutePageRequest](../dto/catalog/route/RoutePageRequest.md) имеет custom deserializer: он принимает как wrapper с `filter`/`pageInfo`, так и исторический flat body. Отсутствующие части заменяются пустым фильтром и paging по умолчанию. `/all` создаёт paging с предельными integer-значениями, после чего общая paging-логика нормализует страницу и размер.

Route meta поддерживает aliases `dateTime`/`dateTimeSlot → dataTime`, `carrier`/`clientRelatedEntity → clientRelatedEntity.code`, `vehicleNumber`/`clientVehicle → clientVehicle.code`, `driverName`/`clientDriver → clientDriver.code`; номера заявок обрабатываются специальными ветками. Неизвестное поле даёт not-found категорию.

`/{routeId}/orders` группирует найденные заявки по `Client`; заявки без клиента в результат не попадают. Это read-model для экрана/отчёта, а не проверка возможности assign.

## Контракт создания

### Декларативно обязательные поля

| Поле | Bean Validation | Серверная/physical семантика |
|---|---|---|
| `routeType` | `@NotNull` | Выбирает набор заявок и DAO: `SHIPPING` либо `RECEIVING` |
| `dataTime` | `@NotNull` | Обязательно именно для публичного create, хотя колонка БД теперь nullable |
| `terminalArea` | `@NotNull` | Должен ссылаться на существующую `TerminalAreaCatalog` |
| `transportType` | `@NotNull` | `RAILWAY` либо `VEHICLE`; участвует в совместимости |
| `clientRelatedEntity` | нет | Условно обязателен для `VEHICLE` |
| `clientDriver` | нет | Условно обязателен для `VEHICLE` |
| `clientVehicle` | нет | Условно обязателен для `VEHICLE` |
| `comment` | нет | Optional, physical `VARCHAR(200)`. **Обновлено KIS-4357** (коммит `78d692a3`, 24 сентября 2026): на `RouteCreationDto` добавлен `@Size(max=200)`, теперь совпадающий с физическим ограничением. На `RouteUpdateDto` такого ограничения по-прежнему нет — асимметрия между create и update сохраняется, слишком длинный `comment` на update по-прежнему полагается только на SQL-уровневый truncate/error, а не на Bean Validation `400`. |

На вложенных `IdDto` нет каскадного `@Valid`. Поэтому JSON-объект ссылки с `id=null` проходит controller validation; ошибка возникает позже при mapping/lookup либо на physical constraint. Это отличается от отсутствия самого `terminalArea`, которое ловит `@NotNull`.

### Предметная валидация и сохранение

`RouteCreateValidator` применяет комбинационные правила:

- `RAILWAY` допустим только на площадке с кодом `CONTAINER`;
- `VEHICLE` допустим только на разрешённых площадках;
- для `VEHICLE` должны быть заданы перевозчик, водитель и ТС (`RouteTransportFieldsValidator`, общий для create/update с 15 сентября 2026, KIS-4667, коммит `6d9b50e2`).
- **новое в KIS-4667:** для `RAILWAY` теперь явно запрещено задавать перевозчик/водителя/ТС (`Route.InvalidVehicleFields`) — раньше на create для `RAILWAY` эти поля просто не проверялись (могли быть заданы без последствий).

Проверок принадлежности всех трёх автомобильных справочников одному клиенту, их `active` или связи водитель/ТС/перевозчик друг с другом в этом validator нет. После проверки сервис устанавливает `status=DRAFT`; UUID создаётся mapper-ом, `number` — identity БД.

```mermaid
flowchart TD
    A[POST /routes + RouteCreationDto] --> B[Bean Validation]
    B -->|нет 4 обязательных полей| E400[HTTP 400]
    B --> C[Mapping и разрешение ссылок]
    C --> D{Комбинация площадка + транспорт}
    D -->|не разрешена| E400
    D -->|VEHICLE без carrier/driver/vehicle| E400
    D --> F[status = DRAFT]
    F --> G[INSERT route]
    G --> H[RouteDetailedDto]
```

## Изменение и копирование

### `PUT /routes/{id}`

Единственное декларативно обязательное поле [RouteUpdateDto](../dto/catalog/route/RouteUpdateDto.md) — `id`. Однако endpoint имеет критичную особенность: controller не объявляет `@PathVariable`, поэтому URL `{id}` игнорируется, поиск и изменение выполняются по `body.id`. Равенство path/body не проверяется.

Изменение разрешено только когда существующий рейс находится в `DRAFT` или `ON_REVIEW`. Через DTO можно менять `dataTime`, три автомобильные ссылки и `comment`; `routeType`, `terminalArea`, `transportType` и `status` неизменяемы этим endpoint.

Фактическая null-семантика неоднородна:

- `dataTime=null` означает «не менять», поэтому очистить дату нельзя;
- `comment` записывается всегда, поэтому его можно очистить;
- **изменено KIS-4667** (коммит `6d9b50e2`, 15 сентября 2026): для существующего автомобильного (`VEHICLE`) рейса `preUpdate` теперь **до** merge-кода вызывает `RouteTransportFieldsValidator.getErrors(updateModel, existingModel.getTransportType())`. Если клиент прислал `clientDriver`/`clientVehicle`/`clientRelatedEntity` как полностью отсутствующее поле (`null`), это ловится `ValidationException`/HTTP `400` **до** того, как merge-код дойдёт до `updateModel.<ref>.id` — ранее задокументированный необработанный `NullPointerException`/HTTP `500` для этого случая (полностью пропущенная ссылка) больше не воспроизводится. Риск остаётся только для `IdDto{id: null}` (объект без вложенного `id`, но сам не `null`) — `RouteTransportFieldsValidator` проверяет `route.getClientDriver() == null`, а не `.getId() == null`, и на вложенных `IdDto` нет каскадного `@Valid` (см. ранее в документе); такая форма запроса всё ещё может дойти до NPE. То же на `RAILWAY` теперь ловит `Route.InvalidVehicleFields`, если `updateModel` содержит любую из трёх ссылок (раньше на update таких проверок не было вовсе — этой ветки валидации не существовало до KIS-4667);
- ссылки нельзя штатно очистить (для `VEHICLE` это теперь явно предотвращается валидацией выше, а не только «получается» из-за NPE); изменённые UUID повторно разрешаются через DAO;
- **устарело:** validator (`RouteUpdateValidator`, теперь `BiConsumer<Route existingRoute, Route updateRoute>`) с KIS-4667 проверяет комбинацию именно **вновь вычисленного `updateRoute`** (то есть присланного DTO), а не только существующего персистентного рейса — предыдущее утверждение было верно до 15 сентября 2026.

Оптимистической версии у `Route` нет, блокировка строки для update не применяется: два параллельных изменения могут перезаписать результат друг друга.

### `POST /routes/{id}/partial-copy`

Копируются тип рейса, площадка, транспорт, комментарий и автомобильные ссылки. Заявки не копируются; создаётся новый UUID/number и статус `DRAFT`. `dataTime` не переносится и не задаётся.

Копирование вызывает `add()` внутри сервиса, а не проходит controller Bean Validation. Поэтому отсутствие обязательной для обычного create даты принимается сервисом и разрешено изменённой physical схемой. Перед `review/accept` дату придётся установить update-запросом.

На это повлияли commits `52668052` (`KIS-3897 add route and orders copying`) и `f01ca620` (permissions copy), а physical nullable-дата закреплена миграцией `v.1.34.0_20260517_KIS-3897_make_route_data_time_nullable.sql`.

## Назначение и снятие заявок

`AssignOrderDto.orderIds` имеет только `@NotNull`. Пустой `Set` валиден и приводит к операции без заявок; повторяющиеся UUID схлопываются при JSON-deserialization/создании множества.

### Назначение

Для каждой найденной заявки validator требует:

- рейс не в `REJECTED`;
- заявка в `DRAFT` или `ON_REVIEW`;
- совпадение площадки и типа транспорта;
- для shipping заполненного грузополучателя, для receiving — грузоотправителя.

После этого `order.route` меняется на указанный рейс, `needTransport` сбрасывается в `false`. Для `VEHICLE` создаётся или заменяется transport-запись с тем же UUID, carrier/driver/vehicle рейса и адресными данными заявки. В receiving-сценарии грузоотправитель для transport выбирается как первая найденная `ClientRelatedEntity` клиента с `isShipper=true`, без явной сортировки.

Существуют два важных пробела:

1. Unknown UUID или UUID заявки другого направления не попадает в найденный набор. Проверка строит сообщение через map `id → number`, получает `null` и затем отбрасывает его — такой ID фактически молча игнорируется.
2. Не проверяется, что заявка свободна или уже принадлежит именно этому рейсу. Назначение может перенести её из другого рейса; статус старого рейса после этого не синхронизируется.

### Снятие

Unassign проверяет только то, что указанный в URL рейс не `REJECTED`. Он не применяет assign-validator и не проверяет принадлежность найденной заявки этому рейсу. Поэтому запрос к рейсу A способен обнулить `route_id` заявки рейса B. Для `VEHICLE` transport-запись удаляется по UUID заявки, включая запись, созданную другим рейсом или ручным сценарием.

`needTransport` обратно в `true` не устанавливается. После операции пересчитывается только рейс из URL, а не фактический прежний рейс заявки.

```mermaid
flowchart TD
    A[POST /routes/A/assign: order X] --> B{X найден в DAO типа A?}
    B -->|нет| I[ID молча игнорируется]
    B -->|да| C{status, area, transport, party валидны?}
    C -->|нет| E400[400 и rollback]
    C -->|да| D[X.route = A; needTransport = false]
    D --> E[VEHICLE: create/replace OrderTransport]
    E --> F[Синхронизировать статус A]

    U[DELETE /routes/A/assign: order Y] --> V[Найти Y по типу A]
    V --> W[Y.route = null без проверки Y.route == A]
    W --> X[VEHICLE: удалить OrderTransport Y]
    X --> Z[Синхронизировать только A]
```

Assign/unassign выполняются транзакционно, но route/order row locks в этом пути не используются. Возможны гонки переназначения и устаревшие статусы агрегатов.

## Статусы рейса

### Разрешённые переходы enum

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> ON_REVIEW
    DRAFT --> ACCEPTED
    DRAFT --> REJECTED
    ON_REVIEW --> ACCEPTED
    ON_REVIEW --> REJECTED
    ACCEPTED --> IN_PROGRESS
    ACCEPTED --> REJECTED
    IN_PROGRESS --> DONE
    IN_PROGRESS --> REJECTED
    DONE --> REJECTED
```

Тот же статус разрешён для любого состояния. Публично напрямую доступны только `ON_REVIEW`, `ACCEPTED` и `REJECTED`; `IN_PROGRESS`/`DONE` появляются при синхронизации по статусам заявок.

### Review и accept

Обе операции:

1. Проверяют переход enum.
2. Требуют непустой `dataTime` для целевого `ON_REVIEW`/`ACCEPTED`.
3. Загружают все назначенные заявки соответствующего направления.
4. Отклоняют пустой рейс ошибкой `Route.IsEmpty`.
5. Вызывают `review` или `accept` каждой заявки; ошибки агрегируются.
6. Только после успешных заявок меняют статус рейса.

Операция целиком транзакционна: если одна заявка не прошла проверку, изменения ранее обработанных заявок откатываются. Сами order-сервисы блокируют свои строки, но `changeStatus` не блокирует строку рейса.

Повтор `ACCEPTED → ACCEPTED` допустим. Валидация и обработка заявок запускаются снова, а outbound может быть поставлен повторно; endpoint нельзя считать идемпотентным.

### Reject

Reject использует `findAndLock` для строки рейса, проверяет transition map, последовательно отклоняет все заявки и затем ставит `REJECTED` рейсу. Для receiving order отклонение также снимает связи Waybill. Пустой рейс отклонять можно, а `DONE → REJECTED` разрешён.

Недопустимый переход выбрасывает `IllegalArgumentException`; общий exception advice превращает неразобранное исключение в HTTP `500`, хотя OpenAPI endpoint декларирует validation `400`.

### Автоматическая синхронизация

`syncRouteStatus` вызывается после assign/unassign и из listeners изменений receiving/shipping order перед commit. Алгоритм:

- `REJECTED`-рейс не меняется;
- нет заявок → `DRAFT`;
- все заявки `REJECTED` → `REJECTED`;
- есть `DRAFT` → `DRAFT`;
- иначе берётся минимальный по priority активный статус заявок и переводится в status рейса.

Transition map здесь не проверяется. Поэтому нерjected рейс способен двигаться назад: например, назначение `DRAFT`-заявки рейсу `DONE` вернёт `DRAFT`, а снятие всех заявок также установит `DRAFT`. При вычисленном `ON_REVIEW`/`ACCEPTED` дополнительно требуется дата.

Listeners подавляют исключение синхронизации. В результате изменение заявки может зафиксироваться, а статус рейса остаться прежним.

## Outbound после accept

При установке `ACCEPTED` создаётся `OutboundData` в той же транзакции. Выбор сообщения:

| Условие | MessageType рейса |
|---|---|
| Route chain package выключен либо неприменим | `ROUTE_TASK` |
| `CONTAINER` + `SHIPPING` + chain package | `SHIPPING_ROUTE_CHAIN_PACKAGE` |
| `CONTAINER` + `RECEIVING` + `RAILWAY` + chain package | `RECEIVING_RAILWAY_ROUTE_CHAIN_PACKAGE` |
| `CONTAINER` + `RECEIVING` + `VEHICLE` + feature | `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE` |

При выключенном chain package accept отдельных заявок также может сформировать их собственные outbound-строки. При включённом package эти одиночные сообщения подавляются в order-сервисах.

Для `ROUTE_TASK` отдельный scheduler по `${datareon.cron.route}` формирует payload рейса и отправляет его в Datareon. В него входят площадка, номер рейса и данные заявок/КТК; Java-контракт задан в [RouteOrderDto](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/route/RouteOrderDto.java). Повторный accept способен создать повторную очередь; отдельного business idempotency key этого endpoint не видно.

Базовый route outbound появился в commit `478fbaf8` (`KIS-1758`), перенос конфигурации из БД в код — `57c7ca6c`, receiving auto chain package — `e86d8d50`.

Содержимое всех четырёх пакетов (что собирает каждый export-сервис, планировщики, endpoint'ы, известные дефекты) — в отдельном [route-chain-package-export-as-is.md](route-chain-package-export-as-is.md).

## Чтение, client restriction и cargo-chain

`RouteFilter` реализует `ClientRestrictionFilter`, а list/page/meta проходят обогащение фильтра текущим пользователем и по умолчанию используют `deleted=false`. Однако прямые операции по UUID (`GET /{id}`, assign/unassign, статусы, reject, copy и cargo-chain) читают сущность напрямую; явная проверка клиентской области в рассмотренном RouteService не найдена. Пользователь с method-level permission и известным UUID может выйти за ожидаемую клиентскую область — это риск, требующий runtime/security-теста.

`GET /routes/{id}/cargo-chain` всегда выбирает `ShippingOrder` по route ID. Для shipping он собирает route → orders → order-carriages/carriages → order-containers/containers → items. Для `RECEIVING` список shipping orders пуст, поэтому возвращается оболочка рейса без receiving cargo hierarchy. Коллекции вагонов и контейнеров явно не дедуплицируются; items дедуплицируются после mapping.

## Удаление и deleted-семантика

Удаление разрешено только для `DRAFT`/`ON_REVIEW` и при полном отсутствии назначенных receiving/shipping orders. Проверка не исключает отклонённые заявки: любая оставшаяся связь блокирует удаление. `Route` реализует `Deletable`, поэтому BaseService устанавливает `deleted=true`, физическую строку не удаляет.

Списки скрывают deleted по умолчанию, но прямой `findById` не накладывает этот filter. Lifecycle-методы также явно не проверяют `deleted`, поэтому известный UUID soft-deleted рейса остаётся доступен для detail, update, assign, status, reject, copy и cargo-chain, если остальные проверки проходят.

## Физическая модель

| Колонка `route` | Ограничение из Liquibase | Комментарий |
|---|---|---|
| `id UUID` | PK, NOT NULL | Генерируется приложением |
| `number INTEGER` | identity, NOT NULL | Явного UNIQUE в найденной цепочке нет |
| `route_type VARCHAR(100)` | NOT NULL | DB CHECK по enum не найден |
| `data_time TIMESTAMP` | nullable после KIS-3897 | Отличается от публичного create `@NotNull` |
| `terminal_area_catalog_id UUID` | NOT NULL, FK | Заменил прежний enum/string terminal area |
| `transport_type VARCHAR(100)` | NOT NULL | DB CHECK по enum не найден |
| `client_related_entity_id`, `client_driver_id`, `client_vehicle_id` | nullable FK | Условная обязательность только в create validator |
| `comment VARCHAR(200)` | nullable | Ограничение длины приходит из БД, DTO его не объявляет |
| `status VARCHAR(100)` | NOT NULL | DB CHECK по transition/status не найден |
| `deleted BOOLEAN` | NOT NULL, default false | Soft delete |

В `shipping_order` и `receiving_order` находятся nullable FK `route_id` и `need_transport`; индексы на route FK добавлены миграцией KIS-2332. У `Route` нет version-column для optimistic locking.

## Ошибки и фактические статусы HTTP

| Сценарий | Ожидаемый источник | Наблюдаемая категория |
|---|---|---|
| Нет обязательного top-level поля create/update/assign | Bean Validation | `400` |
| Неверная комбинация, пустой рейс, ошибки заявок | validation aggregation | `400` |
| UUID сущности/ссылки не найден | DAO not found | обычно `404` |
| Недопустимый status transition (`IllegalArgumentException`) | route status logic | общий `500` |
| Null автомобильной ссылки при partial update | dereference/NPE | общий `500` |
| Physical length/FK/NOT NULL/unique conflict | persistence/advice | зависит от exception; OpenAPI `406` не доказывает фактический код |

Для unique violation общий advice сейчас использует conflict-семантику, при этом явного business UNIQUE для Route кроме PK не найдено. Поэтому OpenAPI `406 Unique violation` у create/update/delete нельзя считать подтверждённым route-сценарием.

## Транзакции, повторы и конкурентность

```mermaid
flowchart LR
    R[Route request] --> T[Одна service transaction]
    T --> O1[Изменения Route]
    T --> O2[Изменения всех Orders]
    T --> O3[OrderTransport / Waybill links]
    T --> O4[OutboundData]
    O1 --> C{Все проверки успешны?}
    O2 --> C
    O3 --> C
    O4 --> C
    C -->|да| COMMIT[COMMIT]
    C -->|нет| ROLLBACK[ROLLBACK]
```

Атомарность одной операции обеспечивается Spring transaction. Но защита от повторов и гонок неполна:

- reject блокирует route, review/accept/update/assign/unassign — нет;
- optimistic version отсутствует;
- assign может перетянуть заявку, unassign — снять чужую;
- два конкурентных assign могут оставить несогласованные route status;
- повторный accept может повторно создать outbound;
- listener может подавить ошибку синхронизации.

## Покрытие тестами

Просмотренные тесты подтверждают:

- создание railway/vehicle рейса и `DRAFT`;
- обязательность автомобильных ссылок;
- partial copy автомобильного рейса без заявок;
- допустимость/запрет soft delete по status и наличию заявок;
- reject пустого рейса и рейса с заявками;
- часть автоматической синхронизации после reject;
- mapping payload `RouteExportService` на mocks;
- базовые DAO page/get/add/update/remove.

Не найдены прямые проверки assign/unassign, чужого route ID, неизвестного order ID, path/body mismatch update, null-ссылок partial update, действий с deleted route, review/accept rollback, повторного outbound, client restriction прямых UUID и конкурентных операций. Тесты в рамках подготовки документа не запускались.

## История изменений, влияющая на правила

| Commit | Влияние |
|---|---|
| `bc3b0253`, `e9274902`, `21205c94`, `dc967139` | Таблица и основной API управления рейсами (`KIS-1751`/`KIS-1752`) |
| `df58d149` | Permissions рейсов (`KIS-1753`) |
| `478fbaf8` | Исходящая интеграция рейса (`KIS-1758`) |
| `4f27582d` | Запрет review/accept пустого рейса (`KIS-1898`) |
| `6be797d0`, `038b3ee9` | Синхронизация статуса рейса со статусами заявок (`KIS-1914`/`KIS-1906`) |
| `e58cd9ab` | Данные назначенных заявок на route page (`KIS-2332`) |
| `20f1bdd5` | Cargo-chain endpoint (`KIS-3301`) |
| `be70d83c` | Reject заявок и рейсов (`KIS-3559`) |
| `99beb122` | Возможность снимать отклонённые заявки (`KIS-3873`) |
| `52668052`, `f01ca620` | Partial copy и permission (`KIS-3897`) |
| `3b299749` | Разделение meta endpoints (`KIS-3945`) |
| `3256b8f0` | Новый `PageInfo` и актуальный request paging |
| `49ce562d`, `6557b9e8` | Meta endpoints route tables (`KIS-4450`) |

## Правила для проверки нового ТЗ

1. Указать направление рейса, площадку и транспорт, а для `VEHICLE` — источник и принадлежность carrier/driver/vehicle.
2. Явно определить, совпадают ли path ID и body ID и какой из них является источником истины.
3. Для assign/unassign задать правила unknown ID, уже назначенной заявки, переноса между рейсами и восстановления `needTransport`.
4. Разделить ручные переходы рейса и автоматическую агрегацию статусов заявок; определить, допустим ли обратный переход.
5. Определить идемпотентность accept и ключ дедупликации outbound.
6. Зафиксировать поведение soft-deleted рейса и row-level client access для каждого UUID endpoint.
7. Для receiving cargo-chain либо описать отсутствие и запретить ожидания клиента, либо добавить отдельный контракт.
8. Добавить тесты rollback, repeat и concurrent assign/accept до признания сценария завершённым.

## Границы достоверности

Проверены исходники, migrations и имеющиеся tests текущего checkout. Не проверялись runtime-регистрация Spring mappings, реальные роли, reverse proxy, применённая production schema, содержимое live `outbound_data`, Datareon и фактический рендер Mermaid. Shipping fact/view/meta endpoints и отчёты будут разобраны отдельно.
