# Занятость складских ячеек и Datareon: AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026): ручной запуск актуализации, входной `POST /datareon/cell-occupancy`, сохранение [CellOccupancy](../entities/catalog/entities/cell_occupancy/CellOccupancy.md), состояние загрузки и аналитическое представление. Бизнес-код, миграции и конфигурация не изменялись; работающие ALIS/Datareon, production payload, единицы измерения и применённая схема БД не проверялись.

## Контур и HTTP-контракты

| Метод и путь | Request | Response | Доступ AS-IS |
|---|---|---|---|
| `GET /cell-occupancy/update` | — | `{"success": true\|false}` | Аутентификация + `CellOccupancy/WRITE` |
| `GET /cell-occupancy/state` | — | map с `loading` и `last_update` | Аутентификация + `CellOccupancy/READ` |
| `POST /datareon/cell-occupancy` | [CellOccupancyUpdateDto](../dto/catalog/cell_occupancy/CellOccupancyUpdateDto.md) | `200` без тела при полном успехе | `/datareon/**` разрешён security-конфигурацией без аутентификации |

Все три метода перечислены в [generated endpoint-каталоге](../api/endpoints-generated.md#celloccupancycontroller) и [DatareonController](../api/endpoints-generated.md#datareoncontroller). `GET /update` изменяет состояние, несмотря на HTTP-метод `GET`.

## Двухшаговая актуализация

```mermaid
sequenceDiagram
    actor U as Пользователь
    participant A as ALIS
    participant D as Datareon /reportbi
    participant DB as cell_occupancy
    U->>A: GET /cell-occupancy/update
    A->>D: POST {eventCode: getReportsCellOccupancy}<br/>Basic Auth
    alt HTTP-вызов завершился без исключения
        D-->>A: HTTP response
        A->>DB: DELETE all
        A-->>U: {success: true}
        D->>A: POST /datareon/cell-occupancy
        loop module → tier → vgh
            A->>DB: INSERT новой строки
        end
        A-->>D: 200 без тела
    else исключение при вызове Datareon
        A-->>U: {success: false}
        Note over A,DB: старые строки не удаляются
    end
```

[CellOccupancyTriggerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/cell_occupancy/CellOccupancyTriggerService.java) синхронно отправляет на `${datareon.base.url}/reportbi` отдельный outbound DTO `{"eventCode":"getReportsCellOccupancy"}` с Basic Auth. Полученный response body используется только для best-effort мониторинга. Любое исключение перехватывается и превращается в `success=false`; при отсутствии исключения `success=true`, даже если response body пуст.

После `success=true` [CellOccupancyController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/cell_occupancy/CellOccupancyController.java) сразу вызывает `deleteAll()`. Он не ждёт и не связывает транзакцией будущий inbound callback. Поэтому между очисткой и первой входной строкой таблица пуста, а ошибка/пустой пакет после очистки оставляет её пустой. Внешний способ и момент доставки callback репозиторием не подтверждены.

## Входной DTO и обязательность

На body стоит `@Valid`, но ни root DTO, ни вложенные DTO не имеют Bean Validation-аннотаций; на вложенных списках также нет каскадного `@Valid`. Декларативно обязательных JSON-полей нет.

| JSON-путь | Java-тип | Фактическая семантика AS-IS |
|---|---|---|
| `MessageID` | String | Только ключ best-effort мониторинга; не сохраняется, не дедуплицируется и не связывает trigger с callback. `null`/blank Bean Validation не отклоняет. |
| `CellOccupancy` | List<[CellOccupancyDto](../dto/catalog/cell_occupancy/CellOccupancyDto.md)> | Корневой список. Пустой список даёт `200` без insert; `null` приводит к `500`. |
| `CellOccupancy[].module` | String | Копируется в `cell_occupancy.name`; DB требует non-null, но blank допустим. Нормализации нет. |
| `CellOccupancy[].tier` | List<[TierDto](../dto/catalog/cell_occupancy/TierDto.md)> | `null` или null-элемент приводит к `500`; пустой список не создаёт строк. |
| `...tier[].tierNo` | Integer | Копируется в `tier`; DB требует non-null. Диапазон/знак не проверяются. |
| `...tier[].vgh` | List<[TierVghDto](../dto/catalog/cell_occupancy/TierVghDto.md)> | Каждая запись создаёт отдельную physical строку. `null`/null-элемент приводит к `500`; пустой список ничего не создаёт. |
| `...vgh[].total` | Integer | Копируется в `total`, DB non-null; арифметических проверок нет. |
| `...vgh[].busy` | Integer | Копируется в `busy`, DB non-null; не проверяется относительно total/free/blocked. |
| `...vgh[].blocked` | Integer | Копируется в nullable `blocked`; первоначально колонка была Boolean, затем преобразована в Integer. |
| `...vgh[].free` | Integer | Копируется в `free`, DB non-null; баланс не проверяется. |
| `...vgh[].weight` | BigDecimal | Копируется в `NUMERIC(8,3) NOT NULL`; смысл и единица в Java/OpenAPI/миграции не определены. |
| `...vgh[].height` | BigDecimal | Копируется в `NUMERIC(8,3) NOT NULL`; смысл и единица не определены. |

Формула `total = busy + blocked + free`, неотрицательность, уникальность VGH внутри яруса, допустимые границы высоты/веса и единицы измерения кодом не заданы. Их нельзя добавлять в ТЗ как подтверждённые правила ALIS без внешнего контракта.

## Серверный алгоритм inbound

```mermaid
flowchart TD
    A[POST /datareon/cell-occupancy] --> J[Десериализация JSON]
    J --> M[Best-effort monitor по MessageID]
    M --> C{Следующий module}
    C --> T{Следующий tier}
    T --> V{Следующий vgh}
    V --> N[Создать новый CellOccupancy]
    N --> F[Скопировать module, tierNo,<br/>blocked/free/busy/total/weight/height]
    F --> S[repository.save: отдельный INSERT]
    S --> V
    C -->|списки закончились| OK[HTTP 200 без тела]
    J -->|невалидный JSON/тип| E400[HTTP 400]
    C -->|null или runtime ошибка| E500[HTTP 500]
    S -->|DB constraint| EDB[HTTP 409 для duplicate SQLSTATE;<br/>иначе HTTP 500]
```

[CellOccupancyService.update](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/cell_occupancy/CellOccupancyService.java) не ищет существующую строку и не выполняет update: для каждой комбинации `module → tier → vgh` создаётся новая entity без business key. После удаления DB-ограничения `(name, tier)` несколько VGH одного яруса и точные дубли разрешены.

На service/controller нет `@Transactional`. Каждый `repository.save` выполняется отдельно; при ошибке поздней строки уже завершённые insert не откатываются. Ошибка выходит из циклов, дальнейшие элементы пакета не обрабатываются. Возвращаемый сервисом `boolean=true` controller игнорирует.

## Replace, повторы и конкурентность

| Ситуация | Результат AS-IS |
|---|---|
| Нормальный `GET /update`, затем один callback | Старый снимок удаляется до callback, новый добавляется строками. Это процедурный replace, не атомарная замена. |
| Прямой callback без `GET /update` | Строки добавляются к текущим; удаления или merge нет. |
| Повтор `MessageID` или payload | Повторные insert; idempotency отсутствует. |
| Два callback одновременно | Insert перемешиваются; блокировки снимка/version нет. |
| Два `GET /update` | Оба могут запросить отчёт и очищать таблицу; поздняя очистка способна удалить строки от первого callback. |
| Ошибка в середине callback | Ранние строки остаются, поздние не обрабатываются; HTTP error не означает rollback всего пакета. |
| Пустой callback после очистки | HTTP `200`, таблица остаётся пустой. |

Таким образом endpoint не реализует patch по ключу и не гарантирует цельный replace. `MessageID` — наблюдаемость, а не ключ операции.

## Хранение, состояние и чтение

Текущая Liquibase-цепочка задаёт `cell_occupancy`:

- `id SERIAL PRIMARY KEY`;
- `name`, `tier`, `total`, `busy`, `free`, `weight NUMERIC(8,3)`, `height NUMERIC(8,3)`, `created_at` — `NOT NULL`;
- `blocked INTEGER` остаётся nullable;
- первоначальный unique `(name, tier)` удалён, других business unique/index/check/FK нет;
- `created_at` устанавливается JPA auditing при insert; входной DTO его не задаёт;
- `analytics.cell_occupancy` — `SELECT *` без фильтрации и агрегации.

Источники: [создание таблицы](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250321_KIS-754_add_table_cell_occupancy.sql), [blocked Boolean → Integer](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250326_KIS-754_alter_table_cell_occupancy.sql), [VGH/дата и удаление unique](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250407_KIS-866_alter_table_cell_occupancy.sql), [analytics view](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_cell_occupancy.sql).

Пользовательского endpoint для чтения самих строк нет. `GET /state` возвращает:

- `loading = repository.count() == 0`: это признак пустой таблицы, а не активного запроса/future;
- `last_update = createdAt` строки с **минимальным id**, а не максимальная дата. После штатной очистки это время первой строки нового снимка; после прямого повторного callback оно остаётся временем старейшей сохранившейся строки;
- после первой строки частичного callback `loading=false`, хотя весь пакет ещё не гарантирован.

## Ошибки и мониторинг

| Условие | Внешний результат |
|---|---|
| Отсутствует body, неверный JSON или числовой тип | Spring/Jackson → `400`. |
| Нет root/nested списка или встречен null-элемент | Неперехваченный NPE → `500`; ранние insert сохраняются. |
| DB `NOT NULL`, numeric overflow или иная integrity ошибка | Обычно `500`; поздняя строка и дальнейший хвост не сохраняются. |
| Duplicate SQLSTATE `21000`/`23505` | Глобальный advice вернул бы `409`, но текущая таблица не имеет business unique. |
| Ошибка inbound-мониторинга | MonitorClient логирует её, предметная загрузка продолжается. |
| Ошибка outbound `/reportbi` | `GET /update` возвращает `{"success":false}`, старый снимок сохраняется. |

OpenAPI для inbound заявляет `400` и `406`, но текущий [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) отображает duplicate в `409`, прочую `DataIntegrityViolationException` и NPE — в `500`. Поэтому заявленный `406 Unique violation problems` не соответствует просмотренному runtime advice.

## Влияющие commits

| Commit | Влияние на текущий AS-IS |
|---|---|
| `48218b0d16e140bd73be0d52d42e250ab1e90aa8` (`feat/KIS-754`, 26.03.2025) | Создал таблицу/entity, DTO, оба controller, trigger и inbound insert-flow. |
| `00014368187b5e12f4e0b66b6485a59027e37795` (`feat/KIS-754`, 27.03.2025) | Изменил `blocked` с Boolean на Integer и уточнил DTO/controller/view. |
| `5cbaa7e4f4f50bef36c1304b2264e268fc293724` (`feat/KIS-754`, 27.03.2025) | Закрепил JSON-имя `MessageID` и форму tier DTO. |
| `0a6c9a11b43f400019d992bce76865219ec19d31` (`feat/KIS-866`, 08.04.2025) | Добавил VGH, weight/height/createdAt, state endpoint и удалил unique `(name, tier)`. |
| `d3e370db11453f73e21ebead0eabcb89b9dd584a` (`KIS-1503`, 03.09.2025) | Добавил inbound/outbound мониторинг пакетов. |
| `5b45baf1941eff3349f5203c0c4c4b67681e50f8` (`KIS-1645`, 11.09.2025) | Скорректировал мониторинг Datareon для вызовов без пользователя; предметный алгоритм не менял. |
| `84204c4bb53ca9567beccfccee3797cee8559d2d` (15.07.2026) | Удалил неиспользуемые logging/validation annotations с trigger service; алгоритм не изменился. |

## Тестовая доказательность и границы

Прямых unit/integration тестов `CellOccupancyController`, `DatareonController.cellOccupancy`, DTO, trigger/service/repository и migration edge cases поиском не найдено. Тесты не запускались. Не подтверждены production payload, порядок callback, единицы weight/height, фактический gateway, runtime permissions, Datareon `/reportbi`, мониторинг и live schema.

Для проверки нового ТЗ необходимо отдельно определить как минимум: атомарность снимка, correlation/idempotency key, допустимость пустого результата, business key строки/VGH, формулу количеств, единицы и диапазоны weight/height, статус жизненного цикла загрузки и контракт ошибок. Это список пробелов AS-IS, а не спроектированное TO-BE.
