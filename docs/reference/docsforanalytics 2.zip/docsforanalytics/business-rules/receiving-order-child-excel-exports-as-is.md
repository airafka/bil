# Дочерние Excel-выгрузки поставки, часть 1 AS-IS

Документ фиксирует на commit `22fac945e8116d04972ccc87b06b2303acf7a561` восемь Excel endpoints для четырёх дочерних ресурсов `ReceivingOrder`: blackbox, детальные грузовые места, КТК и содержимое КТК. Выгрузки товаров, услуг, Waybill и вагонов вынесены в последующие подэтапы.

Корневые Excel-выгрузки заявок описаны отдельно в [V1/V2 AS-IS](order-excel-exports-as-is.md). Бизнес-состав поставки и общая обязательность полей приведены в [правилах поставки](receiving-orders.md) и [карте валидации](order-validation.md). Полный декларативный inventory доступен в секциях [ReportController](../api/endpoints-generated.md#reportcontroller) и [ReportControllerV2](../api/endpoints-generated.md#reportcontrollerv2).

## HTTP-контур

| Ресурс | V1 endpoint | V2 endpoint | Permission V1/V2 | Result file |
|---|---|---|---|---|
| Blackbox | `POST /report/receiving-order-blackbox/{receivingOrderId}/download` | `POST /v2/report/receiving-order-blackbox/download` | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER:READ` | `receiving_order_blackbox.xlsx` |
| Cargo | `POST /report/receiving-order-cargo/{receivingOrderId}/download` | `POST /v2/report/receiving-order-cargo/download` | `RECEIVING_ORDER_RECEIVING_ORDER_CARGO:READ` | `receiving_order_cargo.xlsx` |
| Container | `POST /report/receiving-order-container/{receivingOrderId}/download` | `POST /v2/report/receiving-order-container/download` | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER:READ` | `receiving_order_container.xlsx` |
| Container item | `POST /report/receiving-order-container-item/{receivingOrderId}/download` | `POST /v2/report/receiving-order-container-item/download` | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER_ITEM:READ` | `receiving_order_container_item.xlsx` |

V1 принимает обязательный UUID корневой заявки в path и не принимает body. У всех четырёх методов method-level `consumes = */*`, переопределяющий class-level JSON. V2 принимает optional `@Valid` body соответствующего filter и не задаёт `consumes`. Все методы объявляют XLSX `produces` и возвращают `StreamingResponseBody`.

У Blackbox используется permission контейнера, хотя этот ресурс представляет недетализированный складской груз `BY_CARGO`, а не `ReceivingOrderContainer`. Это фактическое имя права обеих версий, а не исправленное бизнес-наименование.

V1 OpenAPI перечисляет `200` и `400 Validation problems` без схем ответа. V2 явных `@ApiResponse` не содержит. [`PageReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java) хранит result filenames, но контроллер не устанавливает `Content-Disposition`.

```mermaid
flowchart LR
    V1[V1: path receivingOrderId] --> RS[ReportService]
    V2[V2: optional child filter] --> RS2[ReportServiceV2]
    RS --> REG[Collector registry]
    RS2 --> REG
    REG --> B[Blackbox collector]
    REG --> C[Cargo collector]
    REG --> K[Container collector]
    REG --> I[Container item collector]
    B --> J[JXLS template fill]
    C --> J
    K --> J
    I --> J
    J --> X[XLSX stream]
```

## Семантика V1 и V2

Все четыре collectors имеют две ветки:

- V1 строит child filter `receivingOrder.id = path UUID AND deleted = false`;
- V2 приводит optional `BaseFilter` к конкретному child filter без дополнительной нормализации;
- обе ветки принудительно используют `PageInfo(page=0, size=Integer.MAX_VALUE)`;
- entities преобразуются обычным API mapper через `parallelStream`, затем передаются в JXLS.

| Случай | Результат AS-IS |
|---|---|
| V1 UUID существующей заявки | Все неудалённые дочерние строки выбранного вида |
| V1 неизвестный UUID | Пустой XLSX с заголовками; existence check и `404` отсутствуют |
| V1 UUID заявки другого клиента | Отдельной root/client access проверки нет; child permission остаётся единственным controller gate |
| V2 body отсутствует | `filter=null`: выбираются все строки ресурса, включая soft-deleted |
| V2 body `{}` | Создаётся filter, default `deleted=false`: выбираются все неудалённые строки ресурса |
| V2 `"deleted": null` | Deleted predicate отсутствует: возвращаются активные и soft-deleted строки |
| V2 с `receivingOrder` | Результат ограничивается вложенным order predicate, но client IDs пользователя автоматически не подмешиваются |

В отличие от корневых `ReceivingOrderFilter`, четыре child filters не реализуют `ClientRestrictionFilter`. [`BaseService.getAllEntities`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) вызывает enrichment, но [`FilterEnrichServiceImpl`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/rls/FilterEnrichServiceImpl.java) игнорирует тип, который не является `ClientRestrictionFilter`. Наличие вложенного `receivingOrder.client` не меняет этого: caller может сам задать client condition, но сервер не пересекает его с разрешёнными IDs.

```mermaid
flowchart TD
    A[Child export request] --> B{Версия}
    B -- V1 --> P[Создать filter:<br/>receivingOrder.id + deleted=false]
    B -- V2 --> D{Body}
    D -- отсутствует --> N[null filter]
    D -- объект --> F[Переданный child filter]
    P --> E[addUserRestriction]
    N --> E
    F --> E
    E --> R{Root filter implements<br/>ClientRestrictionFilter?}
    R -- нет для всех 4 --> S[Client scope не добавляется]
    S --> Q[Query page 0 / MAX_VALUE]
    Q --> X[XLSX]
```

Таким образом, V1 ограничивает данные UUID заявки, но не подтверждает право пользователя на эту заявку. V2 без body выгружает ресурс глобально и также включает удалённые строки. Это source-level access gap; runtime roles, gateway и другие внешние ограничения не проверялись.

## Контракты фильтров V2

Body — сам filter, не `FilterWithPaging`; клиентская pagination не поддерживается. Все filters наследуют `id`, `anyOfId`, audit-условия и sorting fields. Собственных Bean Validation constraints и nested `@Valid` в этих классах нет.

### Blackbox

[`ReceivingOrderBlackboxFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingorderblackbox/ReceivingOrderBlackboxFilter.java):

- `receivingOrder` — вложенный order filter;
- `cargo` — фильтр справочника грузовых мест, JSON alias `container`;
- `deleted` — default `false`.

### Cargo

[`ReceivingOrderCargoFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingordercargo/ReceivingOrderCargoFilter.java) поддерживает:

| Поле | AS-IS / alias |
|---|---|
| `receivingOrder`, `receivingOrderGood` | Корневая заявка и товарная строка |
| `clientGood`, `batch`, `goodPackage` | Номенклатура, партия, упаковка |
| `cargo` | Грузовое место; aliases `container`, `cargoNumber` |
| `item` | Артикул номенклатуры; alias `article` |
| `clientGoodName` | Наименование; aliases `name`, `nomenclature` |
| `unitOfMeasure` | Код единицы измерения |
| `packageQuantity` | Количество упаковок |
| `totalQuantity` | Общее/плановое количество; alias `plannedQuantity` |
| `conversionQuantity` | Числовой range |
| `deleted` | Default `false` |

Для `item`, `clientGoodName`, `unitOfMeasure`, `packageQuantity` и `totalQuantity` учитывается `byOr`; остальные условия добавляются через AND.

### Container

[`ReceivingOrderContainerFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingordercontainer/ReceivingOrderContainerFilter.java) содержит `receivingOrder`, физический `container`, `deleted`, `empty`, `customsClearance`, `dangerClass`, `ownerContainer`, `weight`, `sealType`, `sealNumbers`, `ktkNumberUnknown` и `waybillRailwayCarriageId`.

Особенности:

- `waybillRailwayCarriageId` выбирает КТК через subquery `WaybillContainer → WaybillRailwayCarriage`;
- `sealNumbers` принимает либо массив строк для PostgreSQL `array_overlaps`, либо объект `SearchString`, преобразуемый в поиск по `array_to_string`; scalar JSON-типы не создают условия;
- `sealType` с одним/несколькими ID обрабатывается напрямую, остальные поля — через nested predicate;
- поле `weight` объявлено и участвует в `isNotEmpty`, но [`ReceivingOrderContainerPredicate`](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/receivingordercontainer/ReceivingOrderContainerPredicate.java) не добавляет по нему условие: в этой выгрузке фильтр веса фактически игнорируется;
- поле `empty` работает в корневом V2 filter, хотя ошибочно не включено в `isNotEmpty`; это влияет на использование ContainerFilter как вложенного условия в других filters.

### Container item

[`ReceivingOrderContainerItemFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingordercontainer/ReceivingOrderContainerItemFilter.java): `receivingOrder`, `receivingOrderContainer`, строковые `container`/`containerType`, `etsngCode`, `description`, числовые `price`, `wightGross`, `wightNet`, `quantityPlace` и default `deleted=false`.

Орфография `wightGross`/`wightNet` является текущим JSON/Java contract. Только `description` поддерживает перенос условия в OR через `byOr`; остальные собственные поля применяются через AND.

## Сбор данных и порядок

[`BaseReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) выполняет сбор в `REPEATABLE_READ`. Default `checkCanExport` всегда разрешает экспорт: статус заявки, площадка, delivery type, наличие корня и непустота строк не проверяются.

[`BaseDaoService.getPage`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseDaoService.java) выполняет data query и отдельный count query. При `Integer.MAX_VALUE` весь результат загружается в entity list, затем в DTO list; JXLS `sheetStreaming` начинается только после этого. Server-side max rows отсутствует.

V1 использует default sort дочернего filter — `id ASC`. V2 сохраняет sorting fields request; при null body [`Paging`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/Paging.java) также использует `id ASC`. После mapping дополнительной сортировки нет.

```mermaid
flowchart TD
    F[V1/V2 child filter] --> P[Page 0, size Integer.MAX_VALUE]
    P --> Q[Data query + count query]
    Q --> L[Все entities в памяти]
    L --> M[parallelStream API mapper]
    M --> D[Все DTO в памяти]
    D --> T[REPEATABLE_READ завершён]
    T --> J[JXLS sheetStreaming fill]
    J --> O[HTTP output stream]
```

Parallel mapping JPA entities внутри transaction использует common pool. Это создаёт риск доступа к lazy associations из потоков, не владеющих persistence context; фактическое проявление зависит от fetch/runtime и тестами не подтверждено.

## DTO и фактические XLSX-колонки

Collectors используют обычные response DTO, а не специальные report DTO.

### Blackbox

[`ReceivingOrderBlackboxDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxDto.md) содержит inherited audit/id и `cargo`. Шаблон [`receiving_order_blackbox.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_blackbox.xlsx) имеет JXLS area `A1:H2`, но заполняет только `A = cargo.code` под заголовком «Номер контейнера». Колонки B–E пусты; F–H содержат заголовки «Вид товара клиента», «Класс опасности», «Активный» без expressions и поэтому не получают значения DTO.

### Cargo

[`ReceivingOrderCargoDto`](../dto/catalog/receivingordercargo/ReceivingOrderCargoDto.md) содержит 14 собственных полей, включая вложенный [`ReceivingOrderGoodInCargoDto`](../dto/catalog/receivingordercargo/ReceivingOrderGoodInCargoDto.md). Шаблон [`receiving_order_cargo.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_cargo.xlsx) объявляет area `A1:L2`, но использует только пять колонок:

1. `cargo.code` — «Контейнер»;
2. `receivingOrderGood.name` — «Номенклатура»;
3. `receivingOrderGood.batch.code` — «Партия»;
4. `goodPackage.code` — «Упаковка»;
5. `packageQuantity` — «Кол-во уп.».

Колонки F–L остаются пустыми. `clientGood`, barcode, conversion/total quantity, dimensions, volume и weight в текущий XLSX не выводятся. Null `receivingOrderGood`, batch, cargo или goodPackage способен привести к ошибке JEXL при вычислении nested getter.

### Container

[`ReceivingOrderContainerDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerDto.md) передаётся в [`receiving_order_container.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_container.xlsx). Area — `A1:R2`, фактически используются A–L: номер КТК, ЗПУ, грузоподъёмность, порожность, расчёт `weight - container.weight`, таможенная очистка, опасный груз, danger class, container type, рефрижератор, тара и общий weight.

Текущий template не соответствует DTO:

| Expression шаблона | Текущий DTO | Следствие |
|---|---|---|
| `s.getCustomClearance()` | Есть `getCustomsClearance()` | Getter отсутствует |
| `s.getDangerousCargo()` | Поле удалено из DTO коммитом `3ea221c0` | Getter отсутствует |
| `s.getRefrigerator()` | Поле находится в `s.getContainer().getRefrigerator()` | Getter отсутствует на root DTO |

[`JxlsReportGenerator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/JxlsReportGenerator.java) работает в strict mode с exception thrower. Поэтому non-empty Container export ожидаемо падает на отсутствующем getter и оборачивается в `JxlsReportProcessingException`; runtime-вызов отдельно не выполнялся. Ранее могут упасть `container=null`, `weight=null`, `container.weight=null` или `dangerClass=null`. Пустая выборка не вычисляет row expressions и способна вернуть только шаблон.

### Container item

[`ReceivingOrderContainerItemDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemDto.md) содержит receiving order/container, ЕТСНГ, description, price и три количественных поля. Шаблон [`receiving_order_container_item.xlsx`](../../../web-layer/src/main/resources/reports/receiving_order_container_item.xlsx) имеет area `A1:E2`, но выводит только A–D: container code, ЕТСНГ, comment и price. `wightGross`, `wightNet`, `quantityPlace` не выводятся.

Expression ЕТСНГ после коммита `29283833` имеет вид:

```text
${s.getEtsngCode().getCode()} на ${s.getEtsngCode().getCode() += ' ' += s.getEtsngCode().getName()}
```

Вторая часть использует compound assignment к результату getter вместо обычной конкатенации. Корректность такого JEXL-выражения не подтверждена тестом или запуском; при strict exception thrower это риск `500`. Кроме того, `etsngCode=null` напрямую разыменовывается.

## Ошибки

| Случай | AS-IS до начала stream |
|---|---|
| Недостаточно child permission | Ожидаемо `403` |
| Некорректный UUID path | Spring conversion → `400` |
| V1 unknown order UUID | Пустой `200` XLSX, не `404` |
| Malformed V2 body/enum | `HttpMessageNotReadableException` → `400` |
| Null nested mapping, invalid filter predicate | Catch-all → `500` |
| Template getter/expression/write failure | Локальный `JxlsReportProcessingException` → catch-all `500` |
| Failure после начала `StreamingResponseBody` | Возможен частичный XLSX; смена status и JSON `ApiErrorDto` не гарантированы |

Локальный JXLS exception не входит в специальный handler одноимённой report-библиотеки; [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) обрабатывает его общим `Exception` handler.

## Тестовое покрытие

Source-wide поиск в `web-layer/src/test` и `web-layer/src/integrationTest` не нашёл прямых тестов восьми controller mappings, четырёх export collectors, соответствующих `PageReportType` или четырёх XLSX templates.

Имеющиеся DAO/service/parser tests дочерних сущностей проверяют другие сценарии и не подтверждают export pipeline. Не покрыты:

- V1 unknown/foreign-client UUID и V2 global/null/deleted выборки;
- обязательность client scope и permissions;
- aliases, OR semantics, container weight gap и sealNumbers dual format;
- sorting, большие наборы, count query и parallel lazy mapping;
- фактические заголовки/пустые колонки и null nested fields;
- отсутствующие Container DTO getters и compound-assignment ЕТСНГ;
- Content-Type/Disposition и сбой после начала stream.

Тесты при документировании не запускались.

## История изменений

| Commit | Влияние на текущий AS-IS |
|---|---|
| `bd4ec3d3`, `576e8787` (2025-08-18, KIS-47) | Добавили V1 child endpoints, collectors, permissions и первые templates |
| `2e41bd43`, `c2d41a09`, `4d870bdd`, `1b0c4917` (2025-08-21…27, KIS-47) | Меняли поля, collectors и XLSX templates |
| `905ef6e4` (2025-09-08, KIS-1336) | Добавил V2 optional-filter endpoints и изменил templates |
| `969e2059` (2025-09-11, KIS-1673) | Исправлял blackbox/cargo/item templates; Container template после него не менялся |
| `3ea221c0` (2025-11-19, KIS-2003) | Удалил `dangerousCargo` из `ReceivingOrderContainerDto`, не обновив старый Container report template |
| `443ae69a` (2026-04-14, KIS-3631 и др.) | Перевёл container/railway-carriage связь на Waybill model и обновил DTO/filter/controller descriptions |
| `29283833` (2026-04-15) | Изменил ЕТСНГ expression Container Item XLSX на текущую compound-assignment форму |
| `3256b8f0` (2026-06-18) | Перевёл collectors на новый `PageInfo`, сохранив `Integer.MAX_VALUE` |
| `bf358e4e`, `978f0601` (2026-06-12 / 2026-08-25) | Расширили Container filter seal type, owner и dual-form sealNumbers; V2 export получил их автоматически |

V2 напрямую переиспользует UI filters. Поэтому изменения фильтра или predicate автоматически расширяют/меняют export contract без правки `ReportControllerV2` или collector.

## Чек-лист для ТЗ

Для изменения дочерней Excel-выгрузки следует явно определить:

1. V1 UUID scope или V2 filter scope и обязательность `receivingOrder`;
2. проверку существования/доступности корневой заявки и client RLS;
3. включение soft-deleted данных и различие отсутствующего body, `{}` и `deleted=null`;
4. допустимые поля/aliases/operators и соответствие filter predicate;
5. лимит строк, timeout и необходимость async export;
6. стабильный порядок строк;
7. специальный report DTO либо допустимость reuse обычного API DTO;
8. точные колонки и null-policy каждой template expression;
9. `Content-Disposition`, имя файла и формат ошибок streaming;
10. HTTP, permission, RLS, filter и XLSX-content tests.
