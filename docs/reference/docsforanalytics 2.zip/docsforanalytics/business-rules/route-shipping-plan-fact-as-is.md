# Рейс: план, факт и meta по заявкам на вывоз AS-IS

Документ фиксирует оставшуюся read-часть `RouteController` на commit `22fac945e8116d04972ccc87b06b2303acf7a561`: плановые вагоны/КТК, ЖД- и АВТО-факт и четыре группы meta-полей. Основной lifecycle рейса описан отдельно: [создание, назначение заявок и статусы](route-lifecycle-as-is.md). PDF/Excel строятся другим путём и разобраны в [отчётном контуре рейса](route-reports-as-is.md).

Это AS-IS текущего backend. Термины «план» и «факт» ниже означают конкретный выбор таблиц и статусов в коде, а не подтверждённую бизнес-семантику внешних систем.

Основные источники: [RouteController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/route/RouteController.java), [RouteService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java), [RouteDaoService](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteDaoService.java), [generated endpoint-каталог](../api/endpoints-generated.md#routecontroller).

## Граница сценария

Все восемь endpoints:

- имеют префикс `/routes/{routeId}/shipping-order`;
- требуют `ROUTE/READ`;
- работают только с `ShippingOrder` и не строят аналогичные представления для `ReceivingOrder`;
- ничего не изменяют, несмотря на HTTP `POST`;
- не выполняют отдельный lookup/валидацию существования, `RouteType`, `TransportType` или status указанного рейса. Data-path косвенно применяет `RouteFilter.deleted=false` при поиске заявок; meta-path хранит только `route_id` и deleted рейса не проверяет.

Неизвестный UUID рейса и UUID receiving-рейса поэтому обычно дают пустой `200`, а не `404` или ошибку типа. Для soft-deleted рейса data и meta расходятся: data обычно пуст, а SQL-view meta продолжает видеть связанные строки.

Ключевые правила для ссылок из ТЗ:

| ID | Правило AS-IS |
|---|---|
| `BR-ROUTE-VIEW-001` | Data endpoints выбирают источник по `ShippingOrder.fillingType`; meta views этот switch не повторяют |
| `BR-ROUTE-VIEW-002` | Optional `BaseIdFilter` ограничивает дочерние row UUID, а не order/route UUID |
| `BR-ROUTE-VIEW-003` | ЖД-факт — КТК, привязанные к именованной вагонной задаче, без требования `FINISHED` |
| `BR-ROUTE-VIEW-004` | АВТО-факт — только `ShippingOrderContainer.status=FINISHED`, сгруппированный по заявке |
| `BR-ROUTE-VIEW-005` | Meta строится четырьмя SQL views и может расходиться с соответствующим data response |
| `BR-ROUTE-VIEW-006` | Ни data, ни meta endpoint явно не применяют client restriction для известного `routeId` |
| `BR-ROUTE-VIEW-007` | Ответ собирается несколькими read-запросами без единого snapshot, поэтому конкурентные изменения могут смешаться |
| `BR-ROUTE-VIEW-008` | Data скрывает soft-deleted route через вложенный filter, meta view не соединяется с Route и продолжает видеть route_id |

## HTTP-контракты

| Метод и путь | Request | Response | Источник основного ответа |
|---|---|---|---|
| `POST /routes/{routeId}/shipping-order/railway-carriage` | optional `BaseIdFilter` | [RouteShippingOrderRailwayCarriageDto](../dto/catalog/route/RouteShippingOrderRailwayCarriageDto.md)[] | Именованные `ShippingOrderRailwayCarriage` либо `ShippingOrderRailwayCarriageQty` |
| `POST /routes/{routeId}/shipping-order/railway-carriage/meta/{fieldName}` | `FilterWithPaging<ShippingRouteRailwayCarriageFilter>` | `IdsCodeDto[]` | `shipping_route_railway_carriage_view` |
| `POST /routes/{routeId}/shipping-order/container` | optional `BaseIdFilter` | [RouteShippingOrderContainerDto](../dto/catalog/route/RouteShippingOrderContainerDto.md)[] | Именованные `ShippingOrderContainer` либо `ShippingOrderContainerQty` |
| `POST /routes/{routeId}/shipping-order/container/meta/{fieldName}` | `FilterWithPaging<ShippingRouteContainerFilter>` | `IdsCodeDto[]` | `shipping_route_container_view` |
| `POST /routes/{routeId}/shipping-order/fact` | optional `BaseIdFilter` | [RouteShippingOrderContainerFactDto](../dto/catalog/route/RouteShippingOrderContainerFactDto.md)[] | Именованные вагонные задачи → связанные КТК |
| `POST /routes/{routeId}/shipping-order/fact/meta/{fieldName}` | `FilterWithPaging<ShippingRouteFactContainerFilter>` | `IdsCodeDto[]` | `shipping_route_fact_container_view` |
| `POST /routes/{routeId}/shipping-order/auto/fact` | optional `BaseIdFilter` | [RouteShippingOrderContainerFactByOrderDto](../dto/catalog/route/RouteShippingOrderContainerFactByOrderDto.md)[] | `ShippingOrderContainer` со status `FINISHED` |
| `POST /routes/{routeId}/shipping-order/auto/fact/meta/{fieldName}` | `FilterWithPaging<ShippingRouteAutoFactContainerFilter>` | `IdsCodeDto[]` | `shipping_route_auto_fact_container_view` |

У data endpoints тело optional, но class-level mapping декларирует `consumes=application/json`. Совместимость запроса без тела и без `Content-Type` зависит от Spring request matching и должна проверяться HTTP-тестом. Meta endpoints требуют JSON body; `{}` допустим, потому что controller создаёт пустой filter, если `filter=null`.

## Как `fillingType` выбирает плановую модель

[ShippingOrderFillingType](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingorder/ShippingOrderFillingType.java) описывает, какие номера известны. Data endpoints используют следующую матрицу:

| `fillingType` | Вагонный endpoint | Контейнерный endpoint |
|---|---|---|
| `ALL` | Именованные вагонные задачи, `quantity=1` | Именованные контейнерные задачи, `quantity=1` |
| `RAILWAY_CARRIAGE` | Именованные вагонные задачи | Строки количества КТК |
| `CONTAINER` | Строки количества вагонов | Именованные контейнерные задачи |
| `NONE` | Строки количества вагонов | Строки количества КТК |
| `NONE_CONTAINER` | Всегда пустой список вагонов | Строки количества КТК |

```mermaid
flowchart TD
    R[routeId] --> SO[Найти ShippingOrder с route_id]
    SO --> FT{fillingType}
    FT -->|ALL| WA[Именованные вагоны]
    FT -->|RAILWAY_CARRIAGE| WA
    FT -->|CONTAINER или NONE| WQ[Количество вагонов]
    FT -->|NONE_CONTAINER| WE[Пустой список вагонов]
    FT -->|ALL или CONTAINER| CA[Именованные КТК]
    FT -->|RAILWAY_CARRIAGE / NONE / NONE_CONTAINER| CQ[Количество КТК]
```

Оба endpoint возвращают wrapper для каждой найденной заявки, даже если выбранный дочерний список пуст. Сортировка по умолчанию идёт по UUID (`id`), а не по business number или порядку ввода.

## Плановые вагоны

Ответ группируется по shipping order и содержит `id`, `number`, `fillingType`, затем список вагонов:

- именованная строка: UUID `ShippingOrderRailwayCarriage`, код вагона, `quantity=1`, type, model и lifting capacity справочного `RailwayCarriage`;
- количественная строка: UUID `ShippingOrderRailwayCarriageQty`, `code=null`, заданное quantity/type, `model=null`, `liftingCapacity=null`;
- связь `ShippingOrderRailwayCarriage` без `railwayCarriage` отбрасывается;
- default filter дочернего DAO исключает `deleted=true` для именованных задач.

Response-аннотация `@Min(0)` на `quantity` не валидирует уже построенный серверный ответ. Physical qty создаётся с `CHECK quantity > 0`; отрицательное значение не должно появляться из корректно применённой схемы.

Optional `BaseIdFilter.id/anyOfId` относится к UUID выбранной именованной задачи либо qty-строки. Если ID относится к другой заявке или к противоположной модели, заявка всё равно останется в ответе с пустым дочерним списком.

## Плановые/заданные КТК и груз

Контейнерный endpoint также группируется по shipping order:

- для именованной модели UUID находится внутри `container`; quantity всегда `1`; `empty` и список item берутся из `ShippingOrderContainer` и `ShippingOrderContainerItem`;
- если номер КТК неизвестен и `container_id=null`, поле `container` в JSON может быть `null`, но quantity/empty/items сохраняются;
- для qty-модели `container` строится из `ShippingOrderContainerQty`: кода и справочного UUID нет, доступны type, quantity и empty;
- items qty-модели берутся из `ShippingOrderEtsngCode`, масса `weight` отображается как `grossWeight`;
- default filters исключают soft-deleted именованные container/item rows.

`grossWeight` имеет документированную единицу «кг» в response DTO. Endpoint не суммирует строки ЕТСНГ и не проверяет равенство веса агрегату заявки/КТК.

## ЖД-факт

`POST .../fact` не проверяет `route.transportType=RAILWAY`. Для каждой shipping order он выбирает неудалённые `ShippingOrderRailwayCarriage` с непустой ссылкой на `RailwayCarriage`, затем строит один root DTO на каждую вагонную задачу:

```text
railwayCarriage { id, code, shippingOrder, containers[] }
containers[] { container, items[] }
items[] { etsngCodes, grossWeight, netWeight }
```

В containers попадают неудалённые `ShippingOrderContainer`, у которых `shipping_order_railway_carriage_id` равен текущей задаче. Проверки `ShippingOrderContainer.status=FINISHED` здесь нет. Следовательно, название «fact» означает наличие фактической связи КТК с именованным вагоном, а не подтверждённое завершение контейнерной задачи.

Order без именованной вагонной задачи полностью отсутствует в ответе. Optional `BaseIdFilter` ограничивает UUID контейнерных задач внутри каждого вагона, а не UUID вагона; сам вагонный wrapper остаётся с пустым containers.

## АВТО-факт

`POST .../auto/fact` не проверяет `route.transportType=VEHICLE`. Он возвращает wrapper каждой shipping order и выбирает только неудалённые контейнерные задачи со status `FINISHED`. Контейнеру добавляются только неудалённые items.

В отличие от ЖД-факта:

- группировка выполняется по заявке, а не по вагону;
- status `FINISHED` обязателен;
- заявка без завершённых КТК остаётся в ответе с пустым `shippingOrderContainers`;
- наличие/отсутствие `ShippingOrderRailwayCarriage` не учитывается.

```mermaid
flowchart LR
    SO[ShippingOrder рейса] --> RF{ЖД /fact}
    RF --> SORC[Неудалённая именованная вагонная задача]
    SORC --> SOC1[Неудалённые привязанные КТК<br/>любой status]
    SO --> AF{АВТО /auto/fact}
    AF --> SOC2[Неудалённые КТК<br/>status = FINISHED]
```

## Meta endpoints

Meta не вызывает соответствующий data builder. Controller записывает `routeId` из path в filter, после чего `MetaFieldQueryService` делает один grouped query по immutable JPA-view.

| Meta-группа | Допустимые simple `fieldName` | Filter-поля |
|---|---|---|
| railway carriage | `id`, `routeId`, `code`, `quantity`, `type`, `model`, `liftingCapacity` | те же business-поля + `id/anyOfId` |
| container | `id`, `routeId`, `code`, `quantity`, `containerType`, `empty`, `etsngCode`, `grossWeight` | те же business-поля + `id/anyOfId` |
| railway fact | `id`, `routeId`, `code`, `containerType`, `etsngCode`, `grossWeight`, `netWeight` | те же business-поля + `id/anyOfId` |
| auto fact | `id`, `routeId`, `code`, `containerType`, `etsngCode`, `grossWeight`, `netWeight` | те же business-поля + `id/anyOfId` |

Имя поля очищается от символов кроме латинских букв/цифр и сравнивается без учёта регистра. Поле должно быть basic JPA attribute; неизвестное поле даёт not-found, collection/association — validation error. У этих view associations нет.

Результат группируется по значению выбранного поля. `IdsCodeDto.ids` — `array_agg` UUID строк view для этого значения, `code` — строковое представление значения. Для decimal применяется `trim_scale`, null сохраняется отдельной meta-группой. Сортировка выполняется по выбранному значению в `filter.sortingDirection`; `sortingColumn(s)` не выбирает другое поле meta.

`pageInfo` ограничивает уже сгруппированные значения. Если `pageInfo=null`, результат не ограничен. Для `pageInfo.page/size` нет Bean Validation; явные null/отрицательные значения могут привести к runtime/query error.

## SQL views и lineage

```mermaid
flowchart TD
    subgraph Data_endpoints
      D1[ShippingOrder.fillingType switch]
      D1 --> T1[Рабочие entity DAO]
      T1 --> DTO[Вложенные response DTO]
    end

    subgraph Meta_endpoints
      M1[Filter + routeId из path]
      M1 --> V[Одна из 4 SQL VIEW]
      V --> G[GROUP BY fieldName<br/>array_agg ids]
      G --> META[IdsCodeDto]
    end

    DB[(shipping_order + child tables)] --> T1
    DB --> V
```

Все четыре представления подключены как rerunnable `CREATE OR REPLACE VIEW`:

| View / JPA-паспорт | SQL-источники и условия |
|---|---|
| [ShippingRouteRailwayCarriageView](../entities/catalog/entities/route/ShippingRouteRailwayCarriageView.md) | `UNION` именованных задач и qty; inner join RailwayCarriage/type/model; deleted не фильтруется |
| [ShippingRouteContainerView](../entities/catalog/entities/route/ShippingRouteContainerView.md) | `UNION` именованных container tasks и qty; именованный Container — inner join; deleted не фильтруется |
| [ShippingRouteFactContainerView](../entities/catalog/entities/route/ShippingRouteFactContainerView.md) | КТК, связанные с именованной вагонной задачей; `sorc.deleted=false`, `soc.deleted=false`, item deleted=false; status КТК не проверяется |
| [ShippingRouteAutoFactContainerView](../entities/catalog/entities/route/ShippingRouteAutoFactContainerView.md) | `soc.status='FINISHED'`, `soc.deleted=false`, item deleted=false; Container — left join |

SQL-источники: [railway carriage view](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_railway_carriage.sql), [container view](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_containers.sql), [railway fact view](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_fact_containers.sql), [auto fact view](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_auto_fact_containers.sql).

Это обычные views, не materialized views: отдельного refresh нет, данные вычисляются запросом к текущим строкам.

## Почему data и meta могут различаться

| Сценарий | Data endpoint | Meta view |
|---|---|---|
| Текущий `fillingType` | Выбирает ровно одну модель через switch | Объединяет обе модели без проверки filling type |
| Deleted именованный вагон | Исключается default DAO filter | Railway view не фильтрует deleted |
| Deleted именованный КТК/item | Исключается default DAO filter | Container plan view не фильтрует deleted ни у КТК, ни у item |
| Безномерный КТК (`container_id=null`) | Возвращает `container=null` | Container plan view теряет строку из-за inner join `container` |
| Вагон без model | Data возвращает `model=null` | Railway view теряет строку из-за inner join model |
| Qty вагонов с `type_id=null` | Data возвращает `type=null` | Railway view теряет строку из-за inner join type |
| Несколько items одного КТК | Один container с nested items | View создаёт несколько строк с одинаковым `id`; `array_agg` может повторить UUID |
| ЖД container status не `FINISHED` | `/fact` включает | Railway fact view также включает |
| АВТО container status не `FINISHED` | `/auto/fact` исключает | Auto fact view исключает |
| Сам Route имеет `deleted=true` | Вложенный `RouteFilter` не находит его заявки | View не join-ит Route и продолжает возвращать meta по `route_id` |

`UNION`, а не `UNION ALL`, удаляет только полностью одинаковые строки. Он не устраняет несколько ЕТСНГ/весов одного container task. При этом JPA считает `id` идентификатором view entity, хотя SQL-view может вернуть несколько строк с тем же id; текущий meta query проецирует поля напрямую, но уникальность entity identity физически не обеспечена view.

## Physical dependencies

| Модель | Существенные constraints |
|---|---|
| `shipping_order.filling_type` | NOT NULL + CHECK; `NONE_CONTAINER` добавлен поздней миграцией |
| [ShippingOrderRailwayCarriage](../entities/catalog/entities/shippingorderrailwaycarriage/ShippingOrderRailwayCarriage.md) | soft-deleted task; `railway_carriage_id` может быть null |
| [ShippingOrderRailwayCarriageQty](../entities/catalog/entities/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQty.md) | quantity `>0`; type стал nullable; UNIQUE NULLS NOT DISTINCT по order+type |
| [ShippingOrderContainer](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainer.md) | soft-deleted task; `container_id` nullable; status nullable |
| [ShippingOrderContainerQty](../entities/catalog/entities/shippingordercontainerqty/ShippingOrderContainerQty.md) | quantity `>0`, type/empty NOT NULL; partial unique order+type только для `empty=true` |
| [ShippingOrderContainerItem](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainerItem.md) | soft delete; ETSNG и net weight nullable |
| [ShippingOrderEtsngCode](../entities/catalog/entities/shippingorderetsngcode/ShippingOrderEtsngCode.md) | qty-модель груза; unique containerQty+ETSNG+weight |

Views не имеют собственных PK/FK/UNIQUE/CHECK. Их `id` наследуется от разных child tables, а в union-view UUID из двух таблиц теоретически могут совпасть.

## Доступ, ошибки и консистентность

Method permission проверяет только `ROUTE/READ`. Data path вызывает `ShippingOrderDaoService.findAllByRoute` напрямую; хотя `ShippingOrderFilter` реализует `ClientRestrictionFilter`, controller/service не вызывают `FilterEnrichService`. Вложенный `RouteFilter` применяет только построенные значения, включая default `deleted=false`, но client filter не обогащён текущим пользователем. Meta filters вообще не являются client-restriction filters. Явной row-level проверки клиента рейса в этих восьми сценариях не найдено.

| Условие | Фактическое поведение по коду |
|---|---|
| route отсутствует / это receiving route | пустой `200` при валидном поле/body |
| route soft-deleted | data обычно пуст; meta может продолжить возвращать значения |
| body отсутствует у data endpoint | request body optional; возможна отдельная проблема `Content-Type` из-за `consumes` |
| body отсутствует у meta | Spring `400` |
| `filter=null` внутри meta wrapper | controller создаёт пустой filter и принудительно ставит routeId |
| неизвестный `fieldName` | not-found категория, OpenAPI декларирует `404` |
| не-simple `fieldName` | validation category, OpenAPI декларирует `400` |
| битая/nullable связь, которую data mapping допускает | null-поле либо исключение зависит от конкретной mapper/association ветки |

Data response строится несколькими DAO-вызовами. Каждый DAO read имеет собственную `readOnly` transaction, но общий метод RouteService транзакцией не охвачен. Между чтением списка заявок, child tasks и items конкурентное изменение может дать смешанный snapshot. Meta выполняет единый SQL query, но его данные всё равно семантически не идентичны data builder.

Endpoints не имеют кеша и собственной дедупликации. Повтор без изменения БД логически read-only, но порядок/состав способен измениться из-за concurrent writes и дефолтной сортировки UUID.

## Покрытие тестами

Прямых controller/service tests восьми endpoints, filling-type matrix, optional body, route existence/type, data/meta parity, deleted/null joins, repeated ids и client access не найдено. `EntityInfoConsistencyTest` только исключает четыре view-типа из общей проверки entity metadata и не проверяет их SQL-содержимое.

Имеющиеся Route lifecycle/DAO/export tests не вызывают эти methods. Тесты в рамках подготовки документа не запускались.

Минимальный регрессионный набор должен включать:

1. Все пять `fillingType` для обоих plan endpoints.
2. ЖД-факт с task status до/после `FINISHED` и АВТО-факт только `FINISHED`.
3. `container_id=null`, `model_id=null`, qty `type_id=null` и deleted rows.
4. Одинаковое поле data/meta с несколькими items и проверкой duplicate IDs.
5. Unknown/receiving/deleted/cross-client route UUID и различие data/meta для deleted route.
6. Параллельное изменение children во время построения nested response.

## История изменений

| Commit | Влияние |
|---|---|
| `d29256da` | Physical qty tables и исходный filling-type (`KIS-3352`) |
| `2f91bc07` | API plan/fact для безномерных заявок (`KIS-3359`) |
| `e23a644f` | Исправление сбора route fact (`KIS-3359`) |
| `4b61d802`, `fc6003c0` | Constraints/валидация numberless rows (`KIS-3663`/`KIS-3356`) |
| `6ec772f5` | Удаление неиспользуемых полей route shipping DTO (`KIS-3750`) |
| `3a283b5a` | `NONE_CONTAINER` и grouped-by-order АВТО-факт (`KIS-4271`) |
| `1e46c564` | Нормализация типов вагонов (`KIS-4321`) |
| `49ce562d` | Четыре meta endpoints, filters, JPA/SQL views и переработка data методов (`KIS-4450`) |
| `6557b9e8` | LEFT JOIN ЕТСНГ qty в container view и fixes meta (`KIS-4450`) |

## Правила для проверки нового ТЗ

1. Определить «план» и «факт» через business event/status, а не только через используемую таблицу.
2. Для каждого filling type задать единственный источник вагонов, КТК и грузов, включая stale rows другой модели.
3. Потребовать одинаковую область данных у таблицы и её meta либо явно документировать различия.
4. Определить отображение безномерного КТК, вагона без model и qty без type.
5. Зафиксировать, к какой сущности относится `BaseIdFilter.id` на каждом уровне.
6. Решить, должен ли unknown/wrong-type/deleted route давать `404`, `400` или пустой `200`.
7. Добавить client row-level правило поверх method permission.
8. Определить distinct-семантику `IdsCodeDto.ids` при нескольких item rows.
9. Если нужен согласованный snapshot, выполнять nested read в одной read-only transaction либо одним запросом/read model.

## Границы достоверности

Проверены Java, JPA, filters/predicates, rerunnable SQL views, связанные migrations, Git history и найденные tests текущего checkout. Не проверялись runtime Spring mappings, реальные роли, применённая production schema/views, PostgreSQL execution plans, live data, UI-потребитель и внешний смысл статусов. PDF/Excel endpoints `ReportController` и шаблоны выгрузок в этот подэтап не входят.
