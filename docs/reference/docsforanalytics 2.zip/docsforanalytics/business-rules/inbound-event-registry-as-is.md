# Реестр входящих событий Datareon: `eventCode → action` AS-IS

Проверено по checkout `22fac945e8116d04972ccc87b06b2303acf7a561`: controller/DTO/converter/dispatcher/action classes, SQL/cumulative migrations и исходники тестов. Это **source-level реестр**, не подтверждение применённой БД. Он закрывает пробел, зафиксированный в [матрице покрытия](../_meta/coverage-matrix.md): «нет общего реестра `eventCode → actions`». Детальное поведение конкретных actions уже описано отдельно в [inbound actions вывоза](shipping-inbound-actions.md), [inbound actions поставки](receiving-inbound-actions.md) и [завершении порожнего ЖД-вывоза](shipping-railway-empty-completion.md) — здесь эти документы не переписываются, а сводятся в одну картину диспетчеризации, конфигурации и её реального состояния в репозитории.

## HTTP-вход

[`DatareonController.handleEvent`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java) — единственная точка входа для всех actions этого реестра:

```java
@PostMapping(path = "/event", consumes = MediaType.APPLICATION_JSON_VALUE)
public void handleEvent(
        @RequestHeader(value = "External-ID", required = false) String guid,
        @RequestBody @Valid InboundEventDto inboundEventDto)
```

т.е. `POST /datareon/event`, опциональный header `External-ID`, возврат `void` (`200` с пустым телом при любом исходе, включая внутренний сбой обработки — см. ниже). [`InboundEventDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/inbound/InboundEventDto.java) задаёт `taskId` (`_id`, `@NotBlank`) — идентификатор конкретного сообщения, `order` (`_order`, `@NotBlank`) и **`eventCode`** (`@NotBlank String`) — ключ диспетчеризации. Специального enum для `eventCode` в кодовой базе нет: это свободная строка от входа до записи в лог и до поиска конфигурации.

Endpoint принимает один плоский event, а не envelope `MessageID + EventData[]`. Из-за `@JsonIgnoreProperties(ignoreUnknown=true)` такой envelope превращается в DTO с пустыми обязательными полями и даёт `400 NotBlank`; полный разбор причины, корректной формы, времени `Instant` и вариантов fan-out/batch приведён в [заполненном кейсе проверки ошибки](../traceability/tz-example-datareon-event-envelope.md).

## Таблица конфигурации `INBOUND_EVENT_CONFIG`

Первоначальный [`ALG-694 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_30240822_ALG-694_add_table_incoming_event_config.sql):

```sql
CREATE TABLE IF NOT EXISTS INBOUND_EVENT_CONFIG
(
    id             UUID PRIMARY KEY NOT NULL,
    event_code     VARCHAR(20)      NOT NULL,
    event_name     VARCHAR(50),
    action_code    VARCHAR(21)      NOT NULL,
    order_type     VARCHAR(100)[],
    transport_type VARCHAR(100)[],
    terminal_area  VARCHAR(100)[],
    ...
);
CREATE UNIQUE INDEX IF NOT EXISTS inbound_event_config_event_code_action_code_idx
    ON INBOUND_EVENT_CONFIG (event_code, action_code);
```

Ключевое: у таблицы **нет колонки `active` и нет колонки `priority`**. «Активность» строки — просто её физическое присутствие; порядок выполнения задаётся исключительно Java-константой (см. ниже). Уникальность — только по паре `(event_code, action_code)`, что допускает несколько разных actions на один и тот же `eventCode`.

[`InboundEventConfig`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/datareoninbound/InboundEventConfig.java) хранит `orderType`/`transportType`/`terminalArea` как `List<Enum>`; геттеры явно подменяют `null` на `Collections.emptyList()`. [`BaseInboundEventAction.hasSuitableOrderType/TerminalArea/TransportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseInboundEventAction.java) трактуют пустой список как «подходит любое значение» — то есть **пустой массив в конфиге означает wildcard**, а не «ничего не подходит».

### Все миграции, когда-либо трогавшие эту таблицу

| Миграция | Операция | Что именно | Commit |
|---|---|---|---|
| [`ALG-694 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_30240822_ALG-694_add_table_incoming_event_config.sql) | DDL | Таблица + `UNIQUE(event_code, action_code)` | `b67b2971` |
| [`ALG-694 ALTER`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240912_ALG-694_alter_table_incoming_event_config.sql) | DDL | `event_code` `VARCHAR(20)→150`; `event_name` `50→255` | `5de66acd` |
| [`KIS-147`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250218_KIS-147_add_vh_departure_action_inbound_event_config.sql) | **INSERT** | Единственная строка данных, вставленная миграцией репозитория (см. ниже) | `f2734e15` |
| [`KIS-599/815`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250328_KIS-599_add_config_for_warehouse_428.sql) | UPDATE | `terminal_area = array_append(..., 'WAREHOUSE_428')` для строк с `'WAREHOUSE' = ANY(terminal_area)` | `df966329` (сообщение коммита ссылается на `KIS-815`, имя файла — на `KIS-599`) |
| [`KIS-3355`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260311_KIS-3355_remove_action_status_in_work_for_vh_arrived_event.sql) | **DELETE** | `DELETE ... WHERE event_code='VH_ARRIVED' AND action_code='STATUS_IN_WORK'` | `3a1f0027` |
| [`KIS-3543`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260317_KIS-3543_remove_warehouse_428.sql) | UPDATE | `array_remove(..., 'WAREHOUSE_428')` — откат KIS-599/815 | `ec84d091` |

**Главная находка.** За всю историю репозитория в эту таблицу выполнена ровно **одна** `INSERT`-миграция:

```sql
INSERT INTO inbound_event_config(id, event_code, event_name, action_code, order_type, transport_type, terminal_area, created_at, created_by)
VALUES (gen_random_uuid(), 'VH_DEPARTURE', 'Выезд транспорта', 'VH_DEPARTURE',
        '{RECEIVING, SHIPMENT}', '{VEHICLE, RAILWAY}', '{WAREHOUSE, CONTAINER}', now(), 'system');
```

При этом `KIS-3355` **удаляет** строку `('VH_ARRIVED', 'STATUS_IN_WORK')`, которую ни одна миграция репозитория не вставляла. Единственное объяснение — эта и все остальные строки конфигурации (`VH_ARRIVED`/`CARRIAGE_ARRIVED`/`STATUS_COMPLETED`/`REC_START`/`REC_FINISH`/`WMS_*`/`TOS_*` и т.д., упомянутые в других AS-IS документах и тестах) заведены **вне Liquibase** — вручную или отдельным неучтённым в этом репозитории скриптом на конкретной среде. **Из исходников репозитория нельзя восстановить production-реестр `eventCode → action` целиком**; миграции доказывают присутствие только `VH_DEPARTURE → VH_DEPARTURE` и факт, что `VH_ARRIVED → STATUS_IN_WORK` когда-то существовал и был снят.

## Диспетчер: `ActionsProcessor`

Полный код [`ActionsProcessor`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessor.java):

```java
@Transactional(propagation = Propagation.REQUIRES_NEW)
public void processEventActions(InboundEventData inboundEventData, List<InboundEventConfig> inboundEventConfig) {
    inboundEventConfig.stream()
            .sorted(Comparator.comparing(config -> config.getActionCode().getPriority()))
            .map(config -> inboundEventActionFactory.makeInboundEventAction(inboundEventData, config))
            .forEach(BaseInboundEventAction::execute);
}
```

[`InboundEventDatareonService.handleInboundEvent`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonService.java) — вызывающий метод:

1. Ищет строки конфигурации точным `eventCode.eq(...)` ([`InboundEventConfigPredicate`](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/datareoninbound/InboundEventConfigPredicate.java) — case-sensitive equality, без сортировки, без фильтра активности).
2. Если строк нет — создаёт `INBOUND_EVENT` со статусом `SKIPPED`, actions не выполняются.
3. Иначе сохраняет `INBOUND_EVENT` с `action_codes` = список найденных `actionCode`, затем вызывает `processEventActions` для **всех** найденных строк сразу.
4. По результату — статус `DONE`/`INVALID`(при `IllegalArgumentException`)/`FAILED`(любое другое исключение), с деталями до 1000 символов. Контроллер не видит ни одно из этих исключений: `handleEvent` всегда возвращает `200`, если только не упадёт сам insert `INBOUND_EVENT` (см. дедупликацию ниже).

**Порядок выполнения.** Единственный сортировочный ключ — `InboundEventActionHandlingCode.getPriority()`, Java-константа, не колонка БД:

```java
public enum InboundEventActionHandlingCode {
    STATUS_COMPLETED(1),
    STATUS_IN_WORK(1),
    WMS_RECEIVING_RESULT, WMS_SHIPMENT_RESULT,
    TOS_RECEIVING_RESULT, TOS_SHIPMENT_RESULT,
    CARRIAGE_ARRIVED, VH_DEPARTURE;   // все — приоритет 0 (default конструктор)
}
```

Только смена статуса (`STATUS_COMPLETED`/`STATUS_IN_WORK`, приоритет 1) гарантированно выполняется **последней**; между действиями одного приоритета (все остальные — приоритет 0) порядок — то, что вернула БД по `Stream.sorted` (stable sort), явного tie-break нет. [`ActionsProcessorTest.processEventActionsAccordingToPriority`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessorTest.java) подтверждает именно это: из трёх сконфигурированных actions `STATUS_COMPLETED` выполняется третьим, хотя во входном списке стоял вторым.

**Частичный сбой — fail-fast, не best-effort.** `forEach` не оборачивает вызовы: первое брошенное исключение останавливает весь `Stream`, и actions с более низким/равным приоритетом, которые должны были выполниться позже, **не запускаются вовсе**. [`ActionsProcessorTest.processEventActionsStopsAfterError`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessorTest.java) подтверждает: при падении второго по порядку action (`CARRIAGE_ARRIVED`) третий (`STATUS_COMPLETED`, приоритет 1) даже не запрашивается у фабрики (`makeInboundEventAction` вызван 2 раза из 3 сконфигурированных). Поскольку `processEventActions` — `REQUIRES_NEW`, изменения БД всего батча actions коммитятся или откатываются одной транзакцией. Частичный эффект после rollback возможен только для внешнего нетранзакционного побочного действия либо для операции, явно вынесенной в отдельную транзакцию; наличие такого эффекта для конкретного action нужно проверять отдельно.

## Дедупликация: задуманный механизм физически недоступен

[`InboundEventDatareonService.handleInboundEvent`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonService.java) явно ловит `DataIntegrityViolationException` при вставке `INBOUND_EVENT` и превращает её в `UniqueViolationException`, которую [`ExceptionAdvice.handleDuplicate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) маппит на HTTP `409 Conflict`. Задумано это как защита от повторной доставки одного и того же `taskId`. Но:

- Первоначальный [`ALG-694 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_30240822_ALG-694_add_table_incoming_event.sql) (таблица-лог `INBOUND_EVENT`) создавал `message_id UUID NOT NULL` с `CREATE UNIQUE INDEX inbound_event_message_id_unique_idx`.
- [`ALG-694 alter`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240913_ALG-694_alter_table_incoming_event.sql) переименовал колонку в `task_id` и **тем же changeset удалил этот unique index** (`DROP INDEX IF EXISTS inbound_event_message_id_unique_idx`).
- Ни одна последующая миграция не создаёт unique index/constraint заново на `task_id`. Java-сущность `InboundEvent` тоже не объявляет `@UniqueConstraint`.

Следствие: повторный `taskId` сам по себе больше не вызывает `DataIntegrityViolationException`, поэтому общий механизм дедупликации не работает: повторно доставленное корректное сообщение создаёт новую строку лога и **выполняет actions заново**. Однако путь `DataIntegrityViolationException → UniqueViolationException → 409` нельзя считать полностью недостижимым: INSERT всё ещё может нарушить PK, `NOT NULL`, длину или иное ограничение применённой схемы. Текущий обработчик ошибочно классифицирует любое такое нарушение целостности как дубликат, хотя уникальность `task_id` схемой не обеспечена. Фактическая идемпотентность держится только на defensive-проверках внутри отдельных actions ([`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) пропускает уже `FINISHED` задачу; [`BaseChangeStatusResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseChangeStatusResultAction.java) пропускает заявки, уже находящиеся в терминальном статусе `DONE`/`REJECTED`) — не на общем контракте уровня события.

Дополнительно: OpenAPI-аннотация `handleEvent` документирует `406` («Unique violation problems»), а фактический обработчик `UniqueViolationException` возвращает `409`.

## Полный реестр `eventCode`

Единственный источник для eventCode, доказанный **в этом репозитории**, — Java-константы тестовых фабрик и config-миграции; enum для eventCode отсутствует.

| `eventCode` | Источник в коде | Actions, привязанные тестами/миграциями | Подтверждено production-миграцией? |
|---|---|---|---|
| `VH_DEPARTURE` | `TestEntityFactory`; [`KIS-147`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250218_KIS-147_add_vh_departure_action_inbound_event_config.sql) | `VH_DEPARTURE` → `VhDepartureAction` | **Да** — единственная строка, вставленная миграцией |
| `VH_ARRIVED` | `TestEntityFactory`; `DatareonControllerTest`; `InboundEventConverterTest` | `STATUS_IN_WORK` → `StatusInWorkResultAction` (удалено `KIS-3355`); тестами также упоминаются `CARRIAGE_ARRIVED`, `STATUS_COMPLETED`, `WMS_SHIPMENT_RESULT` | Косвенно — `KIS-3355` доказывает, что строка `(VH_ARRIVED, STATUS_IN_WORK)` существовала на момент удаления, но не откуда она взялась |
| `LOAD_FINISH` | `TestEntityFactory`; `ContainerMovementMapper`; `ContainerMovementReportDataCollectorService` | `TOS_SHIPMENT_RESULT` → `TosShipmentResultAction` (только в тестах) | Нет |
| `UNLOAD_FINISH` | `TestEntityFactory`; `ContainerMovementMapper` | `TOS_RECEIVING_RESULT` → `TosReceivingResultAction` (только в тестах) | Нет — соответствующий integration-тест по `TosReceivingResultAction` отключён с пометкой про `KIS-3631`/переход на `WaybillRailwayCarriage` |
| `REC_START` | `TestEntityFactory`; `M7ReportDataCollectorService` | `STATUS_IN_WORK` → `StatusInWorkResultAction` (только в тестах) | Нет |
| `REC_FINISH` | `TestEntityFactory`; `M7ReportDataCollectorService` | `WMS_RECEIVING_RESULT` → `WmsReceivingResultAction` (только в тестах) | Нет |
| `SHIP_FINISH` | `TestEntityFactory`; `InboundEventDatareonServiceTest` | `WMS_SHIPMENT_RESULT` → `WmsShipmentResultAction` (только в тестах) | Нет |
| `SHIP_START` | `TestEntityFactory` | Не встречается больше нигде — ни в config, ни в других тестах | Нет — **мёртвая константа** |

(`CONFIRM_DOCS` и код-триггер `getReportsCellOccupancy` — исходящие/триггерные коды, не входящий диспетчер этого реестра; здесь не перечислены.)

## Коды actions и статусы обработки

`InboundEventActionHandlingCode` (`action_code` в конфиге) — восемь значений, семь классов-обработчиков плюс сам `VH_DEPARTURE`:

| Action code | Priority | Класс |
|---|---|---|
| `STATUS_COMPLETED` | 1 | [`StatusCompletedResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/StatusCompletedResultAction.java) → `OrderStatus.DONE` |
| `STATUS_IN_WORK` | 1 | [`StatusInWorkResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/StatusInWorkResultAction.java) → `OrderStatus.IN_PROGRESS` |
| `WMS_RECEIVING_RESULT` | 0 | [`WmsReceivingResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsReceivingResultAction.java) |
| `WMS_SHIPMENT_RESULT` | 0 | [`WmsShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsShipmentResultAction.java) |
| `TOS_RECEIVING_RESULT` | 0 | [`TosReceivingResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosReceivingResultAction.java) |
| `TOS_SHIPMENT_RESULT` | 0 | [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) |
| `CARRIAGE_ARRIVED` | 0 | [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) |
| `VH_DEPARTURE` | 0 | [`VhDepartureAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/VhDepartureAction.java) |

`InboundEventProcessingStatus` (`INBOUND_EVENT.status`): `NEW, SKIPPED, INVALID, FAILED, DONE`. Каждая из восьми констант `action_code` имеет живую реализацию `@Component`; несуществующий код в конфиге дал бы `IllegalArgumentException` из [`InboundEventActionFactory`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/InboundEventActionFactory.java) («No action found for code») и статус `INVALID` — осиротевших config-строк без класса не найдено.

## Мёртвый код и не закрытые разрывы

- **`SHIP_START`** — константа тестовой фабрики без единого потребителя (ни config, ни другой тест, ни production Java) — мёртвый код.
- **`InboundEventDaoService.getUnprocessedEvents()`** ([`db-layer`](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/datareoninbound/InboundEventDaoService.java)) вызывается только одним тестом; в production-коде нет ни одного вызова. Метод выбирает `NEW`-события для повторной обработки, но **планировщика/ретрая, который бы его использовал, не существует** — `NEW` и `FAILED` строки автоматически не пересматриваются.
- **Асимметрия длины `event_code`.** `ALG-694 alter` расширил `event_code` **только у `INBOUND_EVENT_CONFIG`** (до 150 символов), но у лог-таблицы `INBOUND_EVENT` эта колонка осталась `VARCHAR(20)` во всех просмотренных миграциях. Конфигурация с кодом длиннее 20 символов пройдёт в `INBOUND_EVENT_CONFIG`, но обработка того же кода упадёт при попытке записать лог-строку `INBOUND_EVENT`.
- **`406` в OpenAPI vs `409` в рантайме** — расхождение задокументировано в разделе выше.
- Дедупликация по `task_id` — мёртвый код (раздел выше).

```mermaid
flowchart TD
    H["POST /datareon/event: InboundEventDto"] --> LOG["INBOUND_EVENT insert (dedup index dropped — never fails on repeat)"]
    LOG --> CFG["INBOUND_EVENT_CONFIG lookup: eventCode.eq exact, no active flag"]
    CFG -->|empty| SKIP["status=SKIPPED"]
    CFG -->|found rows| SORT["sort by InboundEventActionHandlingCode.priority (Java const, not DB)"]
    SORT --> EXEC["forEach execute() — fail-fast, REQUIRES_NEW"]
    EXEC -->|success| DONE["status=DONE"]
    EXEC -->|IllegalArgumentException| INVALID["status=INVALID"]
    EXEC -->|other Exception| FAILED["status=FAILED, never retried"]
    DONE --> HTTP200["controller always returns 200"]
    INVALID --> HTTP200
    FAILED --> HTTP200
```

## Что подтверждают тесты

- [`ActionsProcessorTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/datareon/inbound/ActionsProcessorTest.java) — единственный прямой тест диспетчера; оба метода (`processEventActionsAccordingToPriority`, `processEventActionsStopsAfterError`) напрямую подтверждают приоритетный порядок и fail-fast поведение, разобранные выше.
- `InboundEventConverterTest`, `DatareonControllerTest`, `InboundEventDatareonServiceTest`, `InboundEventDaoServiceTest` покрывают отдельные звенья цепочки (конвертация DTO, HTTP-контракт, статусы `SKIPPED/INVALID/FAILED/DONE`, DAO-запросы), но не собраны здесь заново — они уже разобраны в частных AS-IS документах по конкретным actions.
- Тесты в этом документе **не запускались повторно** — их содержимое прочитано и процитировано как источник утверждений о поведении, а не как результат прогона в этом подэтапе.

## Неподтверждённое и вопросы для ТЗ

1. Из репозитория нельзя получить полный список production-строк `INBOUND_EVENT_CONFIG` — нужен прямой снимок `pg_catalog`/таблицы на реальной среде, чтобы подтвердить, какие `eventCode` действительно подключены и с какими фильтрами `order_type`/`transport_type`/`terminal_area`.
2. Нужно решить, где заводится изменение этой таблицы вне Liquibase (админ-панель? ручной SQL? отдельный репозиторий конфигурации?) — сейчас это не задокументировано нигде в кодовой базе.
3. Нужен явный ответ, ожидается ли повторная доставка одного `taskId` от Datareon в проде, и если да — восстановить unique-индекс на `task_id` либо явно принять на себя ответственность за at-least-once без дедупликации на уровне лога.
4. Нужно решить судьбу `getUnprocessedEvents()` — либо построить ретрай `NEW`/`FAILED` событий, либо задокументировать, что реобработка не предусмотрена и оператору нужно вручную реагировать на `FAILED`.
5. Нужно расширить `event_code` в `INBOUND_EVENT` до той же длины, что и в `INBOUND_EVENT_CONFIG`, либо сознательно ограничить длину кодов в конфиге.
6. Нужно решить, действительно ли частичный fail-fast (более поздние actions не выполняются вовсе) — желаемое поведение, или для независимых actions одного `eventCode` нужна изоляция сбоев.
7. `KIS-3355` убрал `STATUS_IN_WORK` для `VH_ARRIVED` в пользу перевода статуса внутри `CarriageArrivedAction` — нужно подтвердить, что это не создаёт двойного перехода при событиях, где обе строки конфигурации ещё существовали в переходный период.

## Чек-лист при добавлении нового `eventCode`/action

1. Завести строку в `INBOUND_EVENT_CONFIG` явной миграцией репозитория (а не только на среде вручную) — иначе следующий аудит снова не сможет восстановить реестр из кода.
2. Явно указать `order_type`/`transport_type`/`terminal_area` или осознанно оставить пустым (wildcard) — задокументировать выбор в migration comment.
3. Проверить `InboundEventActionHandlingCode.priority`: обычные actions — 0, действия смены статуса заявки — 1 (выполняются последними).
4. Проверить, что actions с тем же `eventCode`, которые могут быть сконфигурированы одновременно, переносят частичный сбой предсказуемо, зная про fail-fast `forEach`.
5. Не полагаться на `INBOUND_EVENT.task_id` unique index как на дедупликацию, пока он не восстановлен — реализовать идемпотентность внутри `processAction()`.
6. Если новый `eventCode` длиннее существующих, свериться с `VARCHAR(20)` в `INBOUND_EVENT` — расширить обе таблицы синхронно.

## Связанные документы

- [Входящие действия вывоза](shipping-inbound-actions.md)
- [Входящие действия поставки](receiving-inbound-actions.md)
- [Завершение порожнего ЖД-вывоза без КТК](shipping-railway-empty-completion.md)
- [Эффекты интеграций заявок](order-integrations.md)
- [API заявок](../api/order-api.md)
