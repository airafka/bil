# Статусная модель заявок

> Сверено с checkout `22fac945e8116d04972ccc87b06b2303acf7a561` 18.09.2026 в рамках повторного аудита базовых документов этапа 3. Ниже закрыты два из трёх пунктов раздела «Вопросы для будущего проектирования» — оба подтверждены прямым чтением исходников, а не предположением.

## Общие правила транспортной заявки

Применяются к [ReceivingOrder](receiving-orders.md) и [ShippingOrder](shipping-orders.md).

| ID | Правило |
|---|---|
| `BR-ORDER-010` | При создании сервер всегда устанавливает `DRAFT`, независимо от `orderStatus` в request DTO. |
| `BR-ORDER-011` | Переход в тот же статус считается допустимым. |
| `BR-ORDER-012` | Операция статуса блокирует строку заявки через `findAndLock`. |
| `BR-ORDER-013` | Редактирование разрешено в `DRAFT`; в `ON_REVIEW` — только с дополнительным permission; в остальных статусах запрещено. |
| `BR-ORDER-014` | Изменение статуса заявки с маршрутом публикует событие синхронизации статуса маршрута. Ошибка listener логируется и не пробрасывается. |

## Допустимые переходы `OrderStatus`

| Из | В | Типичный инициатор |
|---|---|---|
| `DRAFT` | `ON_REVIEW` | Пользовательская операция review |
| `DRAFT` | `ACCEPTED` | Реализовано в сервисе, но **не достижимо ни одним найденным вызовом**: ни `ShippingOrderService.accept(UUID)`, ни `ReceivingOrderService.accept(UUID)` не вызываются ни из одного controller, inbound action или планировщика — единственный найденный вызов находится в юнит-тесте (`ShippingOrderServiceIntegrationTest`, прямой service-level вызов). Закрывает вопрос №1 ниже. |
| `DRAFT` | `REJECTED` | Пользовательская отмена |
| `ON_REVIEW` | `ACCEPTED` | Подтверждение |
| `ON_REVIEW` | `REJECTED` | Отклонение |
| `ACCEPTED` | `DRAFT` | Разрешено enum-моделью; вызывающий сценарий надо уточнить |
| `ACCEPTED` | `IN_PROGRESS` | Обычно входящее событие TOS/WMS |
| `ACCEPTED` | `DONE` | Внешний/служебный переход |
| `ACCEPTED` | `REJECTED` | Отмена |
| `IN_PROGRESS` | `DONE` | Завершение обработки |
| `IN_PROGRESS` | `REJECTED` | Отмена |
| `DONE` | `REJECTED` | Поздняя отмена, разрешена моделью |

**Пользовательский путь в UI (frontend `971288126`, 07.10.2026).** С KIS-4735 карточки поставки и вывоза не отправляют заявку на review; статус меняется кнопкой рейса `POST /routes/{id}/change-status/accept` прямо из `DRAFT`. `ON_REVIEW` из UI не достигается. Это противоречит строке `DRAFT → ACCEPTED` выше («недостижимо») и требует перепроверки на текущем backend — см. [`UI-ORDER-003`](order-ui-rules-as-is.md#общие-правила) и [`UI-DIFF-17`](order-ui-rules-as-is.md#реестр-расхождений-ui--backend).

`REJECTED` терминален. Для проверки занятости остатков активны `ON_REVIEW`, `ACCEPTED`, `IN_PROGRESS`. Для переходов от TOS допустимыми исходными статусами считаются `ACCEPTED`, `IN_PROGRESS`.

Для порожнего ЖД-вывоза действие `CARRIAGE_ARRIVED` реализует только переход заявки в `IN_PROGRESS` и завершение вагонной задачи. Переход заявки в `DONE` после последнего вагона отсутствует; см. [сквозной AS-IS и подтверждённый дефект](shipping-railway-empty-completion.md).

`STATUS_IN_WORK` и `STATUS_COMPLETED` являются исключениями из таблицы допустимых переходов: реализация не вызывает `OrderStatus.isStatusChangeAllowed` и заменяет любой нетерминальный статус соответственно на `IN_PROGRESS` или `DONE`. Статусы дочерних задач не проверяются; повтор после `DONE` завершается ошибкой action. См. сравнение действий [вывоза](shipping-inbound-actions.md) и [поставки](receiving-inbound-actions.md).

## Review и accept

Эти операции не принимают DTO с полями заявки: они читают уже сохранённый агрегат. Последовательность и различие между Bean Validation request DTO и агрегатной проверкой описаны в [карте валидации](order-validation.md#review-и-accept-проверяют-агрегат-а-не-request-dto). Логика `accept` (столбец ниже) реализована, но, как зафиксировано выше, не достижима ни одним production-вызовом на `22fac945…` — таблицу следует читать как «что делает код метода `accept`», а не как «что происходит в проде сегодня».

| Проверка | Review | Accept |
|---|---:|---:|
| Допустимость перехода | да | да |
| Общие обязательные поля | да | да |
| Матрица площадка × транспорт | да | да |
| Содержимое агрегата | да | да |
| Запрет `ktkNumberUnknown` | нет | да, только `CONTAINER + VEHICLE` |
| Неопределённый тип вагона поставки | нет | да |
| Исходящая интеграция | нет | да, если не включён route chain package |

## Сервисная заявка

`ServiceOrderStatus` не наследует `OrderStatus`.

```mermaid
flowchart LR
    A[Создание] --> B[DRAFT]
    B -->|update состава| B
    B -->|accept: есть хотя бы один контейнер| C[DONE]
    B -->|delete| D[Заявка удалена]
```

- В `DRAFT` разрешены update и delete.
- Accept требует хотя бы один `ServiceOrderContainer`.
- При accept устанавливаются `DONE` и `completionAt=now`.
- Возврат из `DONE` кодом не предусмотрен.

## Вопросы для будущего проектирования

1. ~~Где находится внешний API/consumer для `ReceivingOrderService.accept` и `ShippingOrderService.accept`?~~ **Закрыто 18.09.2026**: такого consumer'а нет. `grep` по всем controller/service/action классам не находит ни одного production-вызова `.accept(` этих двух методов — только упоминания в TODO-комментариях («Outbound-интеграция покрыта через ShippingOrderService.accept()») у семи shipping- и пяти receiving-дочерних сервисов, которые сами ссылаются на код, который никто не вызывает. `ShippingOrderService.accept`/`ReceivingOrderService.accept` — **мёртвый код**, покрытый только прямым service-level тестом. Если этот метод должен быть частью реального flow, нужен либо HTTP endpoint, либо явный вызов из существующего перехода статуса (например, из `STATUS_COMPLETED`-семейства).
2. Нужны ли реально переходы `ACCEPTED → DRAFT` и `DONE → REJECTED`, либо это избыточно широкая enum-модель? Открыто — это решение владельца процесса, не вопрос к исходникам.
3. ~~`OrderServiceUtils` проверяет permission `RECEIVING_ORDER_SEND_TO_ACCEPT` и для общего алгоритма обновления; для вывоза ожидается отдельное `SHIPPING_ORDER_SEND_TO_ACCEPT`.~~ **Закрыто 18.09.2026, подтверждён дефект**: `OrderServiceUtils.checkOrderStatusForUpdate` жёстко проверяет `Permission.RECEIVING_ORDER_SEND_TO_ACCEPT` без ветвления по стороне вызова; метод используется ~12 дочерними сервисами обеих сторон (`ShippingOrderTransportService`, `ShippingOrderGoodService`, `ShippingOrderCargoService`, `ShippingOrderContainerService`, `ShippingOrderContainerItemService`, `ShippingOrderRequestedServiceService`, `ShippingOrderBlackboxService` и receiving-аналоги). Подробности и точная сигнатура — в [физической модели транспорта вывоза](../database/shipping-order-transport-as-is.md#проверка-статуса-при-update-разделяемая-и-потенциально-неточная-проверка). Нужно решение: либо параметризовать проверку правом вызывающей стороны, либо подтвердить, что единое право задумано намеренно.
