# Рейсы: PDF/Excel-отчёты AS-IS

Документ фиксирует отчётный контур рейса на commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Он охватывает только пять методов [`ReportController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/report/ReportController.java), относящихся к рейсам: доступность и скачивание ТН в PDF, карточку рейса, реестр рейсов и список заявок рейса в Excel. Отчёты самих заявок и `ReportControllerV2` в этот разбор не входят.

Основной lifecycle рейса описан в [отдельном документе](route-lifecycle-as-is.md), а плановые и фактические shipping read-модели — в [трассировке plan/fact/meta](route-shipping-plan-fact-as-is.md). Полный декларативный HTTP-контракт доступен в [generated-каталоге](../api/endpoints-generated.md#reportcontroller).

## Карта endpoints

У всех методов базовый путь `/report`. Request DTO отсутствуют: тело запроса ни один из пяти методов не принимает. Четыре `POST` наследуют class-level `consumes = application/json`, хотя Java-параметра `@RequestBody` у них нет; `GET .../available` явно принимает любой media type.

| Endpoint | Ответ | Защита контроллера | Стратегия / шаблон | Назначение |
|---|---|---|---|---|
| `GET /report/route/{id}/available` | JSON-массив [`RouteReportType`](../dto/catalog/report/RouteReportType.md) | `ROUTE_REPORT:READ` | проверка `RouteReportType.ContainerTN` | Узнать, доступен ли PDF ТН |
| `POST /report/route/{id}/th/download` | `application/pdf` | `ROUTE_REPORT_TH:READ` | `ContainerTN` / `reports/ContainerTN.jrxml` | Сформировать ТН для единственной заявки на вывоз рейса |
| `POST /report/route/{id}/download` | XLSX | `ROUTE:READ` | `ROUTE_DETAIL_EXPORT` / `reports/route_detail.xlsx` | Карточка одного рейса |
| `POST /report/route/download` | XLSX | `ROUTE:READ` | `ROUTE_EXPORT` / `reports/routes.xlsx` | Реестр всех доступных активных рейсов |
| `POST /report/route/{id}/orders/download` | XLSX | `ROUTE:READ` | `ROUTE_ORDERS_EXPORT` / `reports/route_orders.xlsx` | Заявки одного рейса |

XLSX-методы возвращают `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`. Имена `ContainerTN.pdf`, `route_detail.xlsx`, `routes.xlsx` и `route_orders.xlsx` хранятся в [`RouteReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/RouteReportType.java) и [`PageReportType`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java), но контроллер не устанавливает `Content-Disposition`. Следовательно, backend-код не гарантирует браузеру именно это имя скачиваемого файла.

```mermaid
flowchart LR
    C[ReportController] --> RS[ReportService]
    RS --> REG[OrderReportDataCollectorService<br/>выбор стратегии по ReportType]
    REG --> TN[RouteTNContainerReportDataCollectorService]
    REG --> RD[RouteDetailsExportReportDataCollectorService]
    REG --> RA[RoutesExportReportDataCollectorService]
    REG --> RO[RouteOrdersExportReportDataCollectorService]
    TN --> JP[Jasper + ContainerTN.jrxml]
    RD --> JX[JXLS + route_detail.xlsx]
    RA --> JX2[JXLS + routes.xlsx]
    RO --> JX3[JXLS + route_orders.xlsx]
```

## Общий серверный pipeline

[`ReportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ReportService.java) получает collector по значению `ReportType`. [`BaseReportDataCollectorService.collectReportData`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/BaseReportDataCollectorService.java) внутри транзакции `REPEATABLE_READ` повторно вызывает `checkCanExport`, собирает `Map<String,Object>` и добавляет Jasper locale `ru_RU`.

После возврата собранного набора данных PDF формирует `JasperReportGenerator`, а XLSX — `JxlsReportGenerator`. Рендер выполняется уже после завершения транзакционного сбора данных. Это означает:

- данные одного collector собираются в repeatable-read snapshot;
- генератор работает с уже собранной картой/DTO, а не удерживает транзакцию на всё время отдачи файла;
- `GET .../available` является предварительной подсказкой, а не резервированием состояния: download снова проверяет доступность;
- два параллельных запроса либо изменение рейса между `available` и `download` могут дать разные результаты.

Каждый download возвращает `StreamingResponseBody`: фактическая сборка и запись файла происходят при обработке потока. Если ошибка возникла до фиксации HTTP-заголовков, [`ExceptionAdvice`](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java) сопоставляет `NotFoundException` с `404`, Jasper-ошибку с `500`, а `IllegalArgumentException`, локальную `JxlsReportProcessingException` и прочие необработанные исключения — с catch-all `500`. Если ответ уже начал передаваться, стандартный JSON `ApiErrorDto` и даже смена статуса не гарантированы; это требуется проверять runtime-тестом контейнера сервлетов.

OpenAPI-аннотации этих download-методов декларируют только `200` и `400`. Текущая реализация недоступного ТН выбрасывает `IllegalArgumentException`, для которого отдельного `400` handler нет, поэтому ожидаемый до начала streaming статус по текущему advice — `500`. Это расхождение декларации и AS-IS реализации.

## Доступность ТН рейса

`GET /report/route/{id}/available` проверяет единственное значение — `ContainerTN`. Недоступность не возвращается как ошибка с причиной: тип просто исключается из массива, и клиент получает `[]`. Причина остаётся только в debug log `ReportService`.

[`RouteTNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/RouteTNContainerReportDataCollectorService.java) применяет проверки последовательно:

| № | Условие | Результат при нарушении |
|---|---|---|
| 1 | У текущего пользователя есть `ROUTE_REPORT_TH:READ` | Тип отсутствует в `available`; direct download блокируется также controller security |
| 2 | Рейс существует | `NotFoundException`; для `available` это не превращается в `[]` |
| 3 | `routeType = SHIPPING` | Недоступно |
| 4 | Код площадки преобразуется в `TerminalAreaEnum.CONTAINER` | Другая известная площадка — недоступно; неизвестный enum-код способен дать `IllegalArgumentException` |
| 5 | `transportType = VEHICLE` | Недоступно |
| 6 | Найдена ровно одна неудалённая `ShippingOrder`, связанная с рейсом | И ноль, и несколько заявок дают одну причину: `doesn't have exactly one shipping order` |
| 7 | У найденной заявки площадка не `WAREHOUSE` и транспорт `VEHICLE` | Недоступно |

Статус рейса и статус заявки в правила доступности не входят. Наличие контейнера также не требуется: ноль контейнеров допустим на этапе проверки и при формировании превращается в пустые/default-поля. Более одного неудалённого `ShippingOrderContainer` приводит уже при сборе данных к `TNContainerReportException`, то есть availability этого случая заранее не отражает.

```mermaid
flowchart TD
    A[ContainerTN для routeId] --> P{Есть ROUTE_REPORT_TH READ?}
    P -- нет --> N[Недоступно]
    P -- да --> R[Загрузить Route по UUID]
    R --> T{SHIPPING?}
    T -- нет --> N
    T -- да --> A1{Площадка CONTAINER?}
    A1 -- нет --> N
    A1 -- да --> V{Транспорт VEHICLE?}
    V -- нет --> N
    V -- да --> O{Ровно одна ShippingOrder?}
    O -- нет --> N
    O -- да --> SO{Заявка: не WAREHOUSE<br/>и VEHICLE?}
    SO -- нет --> N
    SO -- да --> Y[ContainerTN доступен]
```

Есть асимметрия permissions:

- endpoint доступности требует `ROUTE_REPORT:READ`, а collector внутри дополнительно проверяет `ROUTE_REPORT_TH:READ`;
- пользователь только с базовым `ROUTE_REPORT` увидит пустой массив;
- direct PDF endpoint требует `ROUTE_REPORT_TH:READ`, но не требует `ROUTE_REPORT:READ`.

## Данные PDF `ContainerTN`

После разрешения рейса collector повторно находит его единственную заявку и делегирует [`TNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/TNContainerReportDataCollectorService.java). **Обновлено KIS-4583** (коммит `e1968e56`, 21 сентября 2026, до удаления `ShippingOrderTransport` коммитом `d30d77ad` 24 сентября — см. [DEPRECATED-заметку](../database/shipping-order-transport-as-is.md)): источник перевозчика/водителя/ТС теперь `Route route = shippingOrder.getRoute()` (методы `getOwnershipTransportCode`, `getTrailerNumber`, `getClientVehicleData`, `getDriverData`, `getDriverCode`, `getTransporter`, `getRouteDate` принимают `Route`, не `ShippingOrderTransport`), а не отдельная (уже удалённая) transport-строка заявки. Источники: `ShippingOrder`, связанный `Route`, текущий `UserInfo`, optional один `ShippingOrderContainer` и все `ShippingOrderContainerItem` заявки.

В отчёт передаются, в частности:

- номер заявки, договор, клиент/заказчик услуги, грузополучатель и адрес;
- дата рейса (`route.getDataTime()`), перевозчик, водитель, паспорт/удостоверение/телефон — все из `Route`;
- автомобиль, прицеп, марка/тип и признак собственности транспорта — из `Route`;
- код и TOS-тип контейнера;
- массы, стоимость, количество мест, плановая дата и дата создания;
- оператор из данных текущего пользователя;
- **добавлено KIS-4583** (коммит `5274443e`, 24 сентября 2026): `CurrentPrintDate` — текущая дата на момент формирования PDF (`Instant.now()`, а не дата в БД); `FacticalArriveDate` — `ShippingOrderContainer.updatedAt`, но **только если** контейнер непуст и его `status == TaskStatus.FINISHED` (иначе `null`) — то есть не отдельное поле «дата фактического прибытия», а момент последнего обновления строки при завершении TOS-задачи; `sealNumbers` — номера пломб контейнера через `", "`, если список непуст, иначе `null`.

Большинство отсутствующих строковых значений заменяется пустой строкой. Массы `grossWeight` и `totalWeight` перед передачей в шаблон умножаются на `1000`; единица хранения и единица печати должны учитываться в ТЗ отдельно. Итоговая модель не является отдельным HTTP DTO: collector формирует именованные параметры для `ContainerTN.jrxml`.

Этот PDF не строится по четырём SQL views из [shipping plan/fact](route-shipping-plan-fact-as-is.md). Он читает operational entities заявки, транспорта, контейнера и items напрямую.

## Excel: карточка одного рейса

[`RouteDetailsExportReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/route/RouteDetailsExportReportDataCollectorService.java) вызывает `RouteService.findById(id)`, преобразует `RouteDetailedDto` в [`RouteDetailsReportDto`](../dto/catalog/route/RouteDetailsReportDto.md) и кладёт его в параметр шаблона `route`.

DTO содержит 15 полей: номер, тип, дата/время, площадка, транспорт, водитель/телефон/доверенность, перевозчик, автомобиль/страховка/признак прицепа/номер прицепа, комментарий и статус. Enum/date/boolean форматируются [`ExcelReportDtoMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/client/ExcelReportDtoMapper.java).

У collector нет дополнительной бизнес-валидации: базовый `checkCanExport` всегда успешен. Прямой `findById` не использует list-filter enrichment и default `deleted=false`; поэтому по известному UUID возможна выгрузка soft-deleted рейса. По той же причине из кода не подтверждается client row-level restriction для этого direct endpoint.

## Excel: общий реестр рейсов

[`RoutesExportReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/route/RoutesExportReportDataCollectorService.java) не принимает UI-фильтр. Он создаёт пустой `RouteFilter` и страницу с предельным размером, вызывает `RouteService.getAllShort`, преобразует строки в тот же `RouteDetailsReportDto` и сортирует номер по убыванию в памяти. В параметр `routes` передаётся список.

В отличие от direct-выгрузок этот путь проходит через стандартное обогащение фильтра: применяется доступ клиента текущего пользователя и default `deleted=false`. Поэтому результат — все доступные активные рейсы, а не текущая отфильтрованная страница UI.

Mapper реестра заполняет только поля краткого `RouteDto`: номер, тип, дата/время, площадка, транспорт, перевозчик, водитель, автомобиль и статус. Остальные поля общего 15-полевого DTO остаются `null`. Загрузка всего набора одной страницей, mapping и сортировка в памяти создают риск времени и памяти на большом объёме; серверного лимита, пользовательской пагинации или фильтра в этом endpoint нет.

## Excel: заявки рейса

[`RouteOrdersExportReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/route/RouteOrdersExportReportDataCollectorService.java) вызывает deprecated `RouteService.getOrdersDetail(id, null)`. Сервис загружает рейс по UUID, выбирает receiving- либо shipping-ветку по `RouteType`, затем получает страницу всех связанных заявок.

Каждая строка преобразуется из [`OrderRouteDetailDto`](../dto/catalog/route/OrderRouteDetailDto.md) в [`RouteOrdersReportDto`](../dto/catalog/route/RouteOrdersReportDto.md): номер, клиент, плановая дата, плановое время, дата создания и статус. Список передаётся в шаблон как `routeOrders`; отдельная шапка рейса в parameter map отсутствует. При отсутствии пользовательской сортировки заявки читаются по номеру по возрастанию.

Загрузка корневого рейса здесь direct, но запрос дочерних receiving/shipping orders проходит через стандартные order filters и ограничения текущего пользователя. Поэтому известный UUID чужого рейса может подтвердить существование рейса, но вернуть пустой/ограниченный список заявок. Soft-deleted рейс также может быть найден напрямую, тогда вложенный route-filter с default `deleted=false` способен вернуть пустой Excel.

```mermaid
flowchart TB
    subgraph Direct_UUID[Выгрузки по UUID]
      D1[route detail] --> DR[Route direct findById]
      D2[route orders] --> DR2[Route direct findById]
      D3[ContainerTN] --> DR3[Route direct findById]
    end
    subgraph List_export[Общий реестр]
      L[route/download] --> F[RouteFilter enrichment<br/>client scope + deleted=false]
    end
    DR2 --> OF[Order filter enrichment]
    DR --> X1[Нет подтверждённого client/deleted filter]
    DR3 --> X1
    OF --> X2[Строки заявок могут быть отфильтрованы]
```

## Ошибки и граничные случаи

| Случай | AS-IS результат |
|---|---|
| Нет controller permission | Security layer, ожидаемо `403`; runtime chain отдельно не проверялся |
| Рейс не найден | `NotFoundException`, до начала streaming ожидаемо `404` |
| ТН неприменим по type/area/transport/order count | В `available` тип отсутствует; direct download выбрасывает `IllegalArgumentException`, до streaming ожидаемо `500` |
| Неизвестный динамический код площадки | `TerminalAreaEnum.valueOf` способен выбросить `IllegalArgumentException`, ожидаемо `500` |
| У единственной заявки более одного контейнера | `TNContainerReportException`, catch-all `500` |
| Jasper compile/fill/export failure | `JasperReportProcessingException`, `500` |
| JXLS template/write failure | локальная `JxlsReportProcessingException`, catch-all `500` |
| Ошибка после начала записи потока | Возможен частичный файл; JSON error/status не гарантированы |

Причины недоступности ТН написаны на английском и не образуют стабильный машинный error code. Клиенту endpoint `available` их не отдаёт.

## Доступ, deleted и граница достоверности

Сравнение путей чтения важно для ТЗ:

| Операция | Client restriction | `deleted=false` | Дополнительное правило |
|---|---|---|---|
| Общий Excel реестр | Да, через `getAllShort`/filter enrichment | Да | Нет входного UI-фильтра |
| Excel карточка | В direct `findById` не подтверждено | Нет | Только `ROUTE:READ` |
| Excel заявок | Для корня не подтверждено; для строк заявок применяется | Корень — нет; вложенный filter — да | Route type выбирает receiving/shipping service |
| PDF ТН / availability | Для direct route/order lookup не подтверждено | Route — нет; поиск связанной заявки использует default filter | Type/area/transport/ровно одна заявка и отдельная permission |

Это описание поведения исходного кода, а не утверждение о фактической доступности в production: Spring security chain, runtime RLS, reverse proxy, применённая БД и шаблоны на развернутом экземпляре не проверялись.

## Тестовое покрытие

В [`ReportServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/report/ReportServiceIntegrationTest.java) есть два включённых route-сценария: ноль и более одной заявки на вывоз приводят к `IllegalArgumentException`, выходной поток остаётся пустым. Успешный тест ТН помечен `@Disabled` и проверяет `OrderReportType.ContainerTN` по ID `ShippingOrder`, а не `RouteReportType.ContainerTN` по ID рейса; успешный route-PDF им не подтверждается.

Не найдены прямые тесты:

- `GET /route/{id}/available`, permission-комбинаций и HTTP status/body;
- положительного route-TN с ровно одной заявкой;
- условий route type, terminal area, transport type и количества контейнеров;
- streaming failure после начала ответа и `Content-Disposition`;
- трёх route Excel collectors, их templates, client/deleted semantics и большого реестра.

Тесты в рамках документирования не запускались.

## История изменений

| Commit | Влияние на текущий AS-IS |
|---|---|
| `2cb29574` (2025-10-30, KIS-1816) | Добавил три route Excel endpoint, collectors, DTO/mapping и templates |
| `14d6f159` (2025-12-01, KIS-1966) | Исправил поля/templates отчётов и сортировку реестра рейсов |
| `c89a8281` (2026-03-11, KIS-2954) | Добавил сортировку detail-page заявок рейса, которую использует orders export |
| `6611ec27` (2026-06-09, KIS-3965) | Добавил available reports, route report type/collector, permissions и первые route-TN tests |
| `b2392502` (2026-06-17, KIS-3964) | Переработал форму транспортной накладной и закрепил текущий `ContainerTN` contour |
| `49b109ed` (2026-06-24, KIS-4113) | Перенёс значительную часть вычислений `ContainerTN` из JRXML в Java collector |
| `84a9e5eb` (2026-06-26, KIS-4177) | Изменил вычисление `weightGross` в `ContainerTN` |

Последующие template-only изменения влияли на внешний вид PDF, но не добавили новые route endpoints или проверки доступности. Commit выше — происхождение соответствующего поведения, а не гарантия, что изменение развернуто в конкретной среде.

## Чек-лист для ТЗ на отчёт рейса

В требовании нужно явно указать:

1. какой файл формируется: ТН, карточка, реестр или заявки рейса;
2. нужны ли `ROUTE_REPORT`, `ROUTE_REPORT_TH` и/или `ROUTE` и как должен вести себя `available`;
3. допустимы ли deleted и чужие по client scope рейсы при обращении по UUID;
4. для ТН — type, area, transport, статусы, точное количество заявок и контейнеров;
5. должен ли общий Excel учитывать UI-фильтр, сортировку, пагинацию и лимит;
6. точные имена/единицы полей и правила для `null`;
7. HTTP status и стабильный error code для каждого отказа;
8. имя файла и обязательный `Content-Disposition`;
9. поведение при ошибке streaming и допустимость частичного файла;
10. контрольный fixture/template и автотест содержимого PDF/XLSX.
