# Остатки КТК и вагонов: inbound AS-IS

Документ фиксирует **backend AS-IS** на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026). Он описывает входящие снимки остатков через Datareon, ручную полную синхронизацию, хранение и чтение. Внешние правила 1С/Datareon, фактическая конфигурация среды и применённая схема БД не проверялись.

Это отдельный процесс от [импорта справочников ЭТРАН](etran-reference-imports-as-is.md): тот меняет физические `Container`/`RailwayCarriage`, а этот хранит принадлежность и доступность объекта у клиента. Для КТК строковый номер в остатке не является FK на физический контейнер.

Остатки номенклатуры имеют другой DTO, ключ и read model; они описаны отдельно в [GoodRemain inbound AS-IS](good-remain-inbound-as-is.md).

Это также отдельная модель от внутреннего регистра владельца/статуса физического КТК (`EXPECTED`/`ON_TERMINAL`/`RESERVED_OUT`/`DEPARTED`, сущность `ContainerOwner`, FK на `Container`), который заявки на поставку/вывоз ведут сами через `accept`/`reject` и inbound-события TOS — см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md). Оба «остатка» называются похоже, но не связаны источником и физической моделью.

## Карта моделей и потоков

```mermaid
flowchart LR
    DR[Datareon] -->|POST /datareon/container-remain| CI[Инкрементальный upsert КТК]
    DR -->|POST /datareon/railway-carriage-remain| RI[Инкрементальный upsert вагонов]
    UI[Ручной запуск] -->|POST /remain/container/synchronize| CF[Полный reload КТК]
    UI -->|GET /remain/railway-carriage/synchronize| RF[Полный reload вагонов]
    CF --> EXT1[Внешний GET] --> CS[(alis.container_remain)]
    RF --> EXT2[Внешний GET] --> RS[(railway_carriage_remain)]
    CI --> CS
    RI --> RS
    CS --> CV[analytics.container_remain_view]
    RS --> RV[analytics.railway_carriage_remain_view<br/>только active=true]
    MOV[(container_movement)] -. другая модель .-> MR[/containerremains/*]
```

| Понятие | Модель | Физическое хранение | Ключевое отличие |
|---|---|---|---|
| Импортируемый остаток КТК | [ContainerRemain](../entities/catalog/entities/containerremain/ContainerRemain.md) | `alis.container_remain` | Снимок `клиент + строковый номер КТК + ЕТСНГ`; не FK на `Container`. |
| Остаток вагона | [RailwayCarriageRemain](../entities/catalog/entities/railwaycarriageremain/RailwayCarriageRemain.md) | `railway_carriage_remain` | Ссылается FK на физический `RailwayCarriage` и `Client`. |
| Движение КТК | [ContainerMovement](../entities/catalog/entities/containermovement/ContainerMovement.md) / [ContainerRemains](../entities/catalog/entities/containerremains/ContainerRemains.md) | `container_movement` | История событий движения и отдельное API `/containerremains/*`; inbound-остатки её не создают. |
| История снимка КТК | SQL `container_remain_history` | analytics history table | Trigger пишет INSERT/UPDATE `container_remain`; это не `ContainerMovement`. |

## HTTP-контракт Datareon

Оба метода находятся в [DatareonController](../api/endpoints-generated.md#datareoncontroller), принимают JSON, при штатном возврате метода дают `200` без тела и входят в `permitAll`-зону `/datareon/**`. Перед предметным сервисом вызывается мониторинг входного пакета; ошибка мониторинга перехватывается самим `MonitorClient` и не должна отменять обработку остатка.

`@Valid` на request body **не делает поля обязательными**: ни корневые DTO, ни их вложенные классы не содержат Bean Validation-аннотаций. В частности, `MessageID`, список и все поля строки допускают `null` на декларативном уровне.

### Остатки КТК

`POST /datareon/container-remain` принимает [ContainerRemainSyncDto](../dto/catalog/containerremain/ContainerRemainSyncDto.md), элементы — [ContainerRemainSyncDto.Leftover](../dto/catalog/containerremain/ContainerRemainSyncDto.Leftover.md).

| JSON | Java-тип | Использование AS-IS |
|---|---|---|
| `MessageID` | String | Только аргумент мониторинга; предметный сервис не хранит и не проверяет повтор. |
| `leftoversktk` | array | Параллельная обработка каждой строки; `null` приводит к общей runtime-ошибке. |
| `number` | Integer | В инкрементальном upsert не используется. |
| `timestamp` | String | `LocalDateTime.parse` и системная timezone сервера; `null` сохраняется как `null`. |
| `item` | String | Код ЕТСНГ и третья часть unique key. |
| `container_number` | String | Строковый номер КТК и вторая часть unique key; физический `Container` не ищется. |
| `actual_quantity` | BigDecimal | `actual_quantity`; SQL-комментарий называет величину массой нетто в кг. Сервер единицы не преобразует. |
| `client` | UUID | Ищется как `Client.syncId`, а не как PK клиента. |
| `zone` | String | Ищется как id [ContainerRemainStatus](../entities/catalog/entities/containerremainstatus/ContainerRemainStatus.md); неизвестное ненулевое значение создаёт status с `code=ERROR`. |
| `active`, `event_code`, `yacheika`, `stock` | Boolean/String | Полностью перезаписываются при update; `null` также перезаписывает прежнее значение. |

### Остатки вагонов

`POST /datareon/railway-carriage-remain` принимает [RailwayCarriageRemainSyncDto](../dto/catalog/railwaycarriageremain/RailwayCarriageRemainSyncDto.md), элементы — [RailwayCarriageRemainSyncDto.Leftover](../dto/catalog/railwaycarriageremain/RailwayCarriageRemainSyncDto.Leftover.md).

| JSON | Java-тип | Использование AS-IS |
|---|---|---|
| `MessageID` | String | Только мониторинг; не idempotency key. |
| `leftoversPlat` | array | Сначала группируется по `(client, main_Plate)`. |
| `number` | Integer | В каждой группе побеждает максимальный `number`; timestamp для выбора не сравнивается. |
| `timestamp` | String | Обязателен фактически: парсится без проверки `null`, через системную timezone. |
| `client` | UUID | Поиск `Client.syncId`. |
| `main_Plate` | String | Поиск физического вагона без учёта регистра. |
| `available` | Boolean | Записывается в `active`. |
| `event_code` | String | Записывается как есть. |

## Инкрементальная обработка Datareon

```mermaid
flowchart TD
    A[HTTP body десериализован] --> M[Best-effort MonitorClient]
    M --> L[Создать ACTIVE log]
    L --> K{Тип остатка}
    K -->|КТК| P[parallelStream по всем строкам]
    P --> U[find by client + container + ETSNG]
    U --> S[create или полный update]
    K -->|Вагон| G[group client + main_Plate]
    G --> N[Сортировать по number; взять последний]
    N --> W[Найти Client и RailwayCarriage]
    W --> R[findFirst/create и save]
    S --> C[Записать ошибки строк и завершить log]
    R --> C
    C --> OK[HTTP 200 даже при частичных ошибках]
```

### КТК

Ключ update закреплён DB unique constraint: `(client_id, container, etsng_code)`. Найденная строка получает новые `eventCode`, `active`, `time`, `zone`, `actualQuantity`, `cell`, `stock` и `updatedBy=DATAREON`; новая — `createdBy=DATAREON`. Отсутствующие в пакете строки не удаляются: это инкрементальный upsert.

Исключение одной строки записывается в [ContainerRemainLogDetails](../entities/catalog/entities/containerremainlogdetails/ContainerRemainLogDetails.md), счётчик failure увеличивается, остальные строки продолжаются. Поле `container` в error detail при этом заполняется значением `item` (ЕТСНГ), а не `container_number`. После частичных ошибок HTTP всё равно `200`; вызывающая сторона должна смотреть журнал.

Строки выполняются через `parallelStream`. Транзакция метода привязана к вызывающему HTTP-потоку и не переносится автоматически в worker threads; поэтому аннотацию `@Transactional` нельзя трактовать как атомарность всего пакета. Повтор одного ключа в пакете не схлопывается заранее: возможны гонка create, DB unique error либо недетерминированный последний update.

`leftoversktk=null` падает до построчного `catch`, а `null`-элемент способен повторно упасть уже при формировании error detail. В этих случаях HTTP будет `500`, а созданный ACTIVE log может остаться незавершённым, потому что завершение не находится в `finally`.

### Вагоны

Строки сначала группируются по `(client syncId, main_Plate)`, внутри группы сортируются по `number`, затем применяется последняя. Таким образом статистика считает группы, а не входные строки. Нет сравнения времени события и нет защиты от старого события с большим `number`.

Вагон ищется без учёта регистра, остаток — через `findFirst` по `(railwayCarriage.id, client.id)`. DB unique constraint для этой пары в найденных миграциях отсутствует, поэтому код не исключает несколько строк и выбор одной из них не детерминирован. Для найденной или новой записи задаются time, eventCode, active и `createdBy=DATAREON`; отсутствующие ключи не удаляются.

Ошибка группы попадает в [RailwayCarriageRemainLogDetails](../entities/catalog/entities/railwaycarriageremainlogdetails/RailwayCarriageRemainLogDetails.md), другие группы продолжаются и HTTP остаётся `200`. Но `null` списка/элемента/`number` может сломать предварительную группировку или сортировку до group-level `catch`, вернуть `500` и оставить ACTIVE log. `@Transactional` на перегруженном методе вызывается self-call из того же bean и потому не создаёт Spring proxy-транзакцию для прямого Datareon пути.

## Полная ручная синхронизация

| Endpoint | Поведение HTTP | Фоновый алгоритм |
|---|---|---|
| `POST /remain/container/synchronize` | Сразу `200`: «запущена» | `@Async`; active-log check; очистка caches; ACTIVE log; удалить все КТК-остатки; внешний GET; Jackson parse; собрать и сохранить новый снимок; завершить log в `finally`. |
| `GET /remain/railway-carriage/synchronize` | Сразу `200`: текст ошибочно говорит «выполнена» | `@Async`; active-log check; ACTIVE log; удалить все остатки вагонов; внешний GET; parse; применить тот же grouped алгоритм с source `API`; завершить log. |
| `GET .../status` | Boolean | Проверяет наличие ACTIVE log, но не состояние фонового thread/future. |
| `POST /remain/container/force-complete-logs` | Hidden | Принудительно завершает активные container logs; данные не восстанавливает. |

Оба режима являются **delete-and-reload**, а не атомарной заменой снимка. Удаление коммитится отдельно от внешнего GET/парсинга/сохранения. Если внешний источник недоступен или новый пакет ошибочен, таблица может остаться пустой либо частично заполненной.

Для КТК full sync параллельно собирает map по `client + item + container`. При повторе только `actualQuantity` заменяется, а прочие поля остаются от строки, которая первой создала объект; из-за параллельности итог при дублях не детерминирован. Ошибочные строки пропускаются, валидные сохраняются с `createdBy=API`.

Для вагонов delete выполняется до `try`: ошибка удаления способна оставить ACTIVE log без `finally`. Проверка «активный процесс уже есть» выполняется внутри async-метода и не сообщается инициирующему HTTP-вызову. Check-then-create log не защищён блокировкой/unique constraint, поэтому два почти одновременных запуска теоретически могут пройти проверку.

На `/remain/**` methods нет `@Secure`; однако этот факт сам по себе не доказывает публичный доступ. В отличие от `/datareon/**`, runtime-правила security chain и gateway для этих endpoints не проверялись. Credentials и адреса внешних GET задаются конфигурацией и здесь намеренно не воспроизводятся.

## Чтение и ограничения доступа

- `POST /remain/container/view` и `GET /remain/container/view-all` читают [ContainerRemainView](../entities/catalog/entities/containerremainview/ContainerRemainView.md) из `analytics.container_remain_view`.
- `POST /remain/railway-carriage/view` и `GET /remain/railway-carriage/view-all` читают [RailwayCarriageRemainView](../entities/catalog/entities/railwaycarriageremainview/RailwayCarriageRemainView.md); SQL view содержит только `active=true`.
- Фильтры этих view не реализуют `ClientRestrictionFilter`, а query services не вызывают `FilterEnrichService`. Для ContainerRemain commit `f080820…` исторически добавлял client restriction в старый query path, а `1f6193ba…` заменил его на текущий общий DAO-вызов без этого обогащения. Для railway view аналогичного ограничения в просмотренном текущем пути не найдено. Фактическую видимость может дополнительно ограничивать общий security/gateway; runtime не проверялся.
- `/containerremains/all` и `/containerremains/page` читают другую, movement-derived модель из `container_movement` и не показывают импортируемый `container_remain`.
- Отдельный выбор физических Container «по остаткам» использует client restriction и distinct строковые номера из `container_remain`; аналогичный список RailwayCarriage берёт distinct physical ids без такого обогащения в remain service.

## Повторы, удаления и ошибки

| Ситуация | Datareon КТК | Datareon вагон | Full sync |
|---|---|---|---|
| Повтор `MessageID` | Новый upsert | Новый upsert | `MessageID` также не дедуплицирует |
| Дубль бизнес-ключа | Параллельная гонка | Схлопывание: max `number` | КТК — недетерминированное merge; вагон — max `number` |
| Строки нет в пакете | Остаётся | Остаётся | Удаляется общей предварительной очисткой |
| Ошибка одной строки/группы | Частичный success, обычно HTTP `200` | Частичный success, обычно HTTP `200` | КТК пропускает строку; вагон пропускает группу |
| Ошибка списка/подготовки | HTTP `500`, log может зависнуть | HTTP `500`, log может зависнуть | Async caller уже получил `200`; снимок может быть пуст |
| Конкурентные запросы | Package-wide atomicity не гарантирована | Нет гарантии unique пары | Нет lock на запуск/replace |

OpenAPI обоих Datareon endpoints заявляет только `200`/`400` без error schema. Из-за отсутствия Bean Validation типичный содержательный дефект строки не становится HTTP `400`: он либо журналируется с HTTP `200`, либо проявляется runtime `500`. Формат глобальной ошибки задаёт [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java).

## Физические ограничения и история

- `alis.container_remain`: обязательны `client_id`, `container`, `etsng_code`, `actual_quantity`, `active`; исходная SQL допускает nullable `zone`, хотя JPA объявляет связь обязательной. Unique key — `(client_id, container, etsng_code)`.
- `actual_quantity NUMERIC(16,3)`; DTO не содержит `@Digits`, поэтому precision/scale проверяет БД.
- `cell` и `stock` добавлены позже; trigger `container_remain_history` пишет историю после INSERT/UPDATE и внутри себя перехватывает ошибку, не отменяя основную запись. DELETE в эту history не попадает.
- `railway_carriage_remain` хранит FK на client и railway carriage; unique для пары в просмотренной цепочке миграций не найден.

Источники: [создание container remain](../../../db-layer/src/main/resources/db/changelog/v.1.27.0/v.1.27.0_20250908_KIS-1661_Added_new_tables_for_container_remains.sql), [создание railway remain](../../../db-layer/src/main/resources/db/changelog/v.1.29.0/v.1.29.0_20251003_KIS-1606_add_railway_carriage_remain.sql), [railway reload](../../../db-layer/src/main/resources/db/changelog/v.1.29.0/v.1.29.0_20251104_KIS-1934_add_railway_carriage_remains_for_29_release.sql), [container history](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260618_KIS-4139_add_permission_for_reports.sql).

## Влияющие commits

| Commit | Влияние на текущее поведение |
|---|---|
| `61b0fa01adddff2a1c201bf46d53f40ed92e2182`, 11.09.2025, `KIS-1661 Container remains` | Создал основной поток, таблицу, DTO, logs, view и синхронизацию КТК. |
| `a6bf0bb8555b48c898e9bba5082ba9aae084c014`, 20.10.2025, `KIS-1606 Реализован процесс актуализации остатков вагонов` | Добавил модель и процесс остатков вагонов. |
| `3981f5c9583047a3c4c0b6f2d9e5c416bcd6eb4c`, 04.11.2025, `KIS-1934 add logging of railway-carriage remains` | Добавил журналы и построчную/group error фиксацию. |
| `60f814576dee9e07b45cb391e44191185a54c7e3`, 04.11.2025, `KIS-1934 add deletion of all records in railway-carriage remains` | Превратил ручную railway-синхронизацию в delete-and-reload. |
| `f08082096e5bc9b09906057dc285150940675db9`, 11.11.2025, `KIS-1869 add client restriction for remain views` | Исторически добавил ограничение клиентов в старый ContainerRemain query path. |
| `1f6193bae9540e9ab0b7095d65956aeac4fd8e5c`, 17.11.2025, `KIS-1869 change type of request from get to post for ContainerRemainViewController.java` | Перевёл ContainerRemain view на общий filter/DAO path, в котором прежний client restriction отсутствует. |
| `fa8dc53e367e95e87b2d45c72f9c90ccfde5ca92`, 17.06.2026, `KIS-4122 add cell and stock fields to container remains` | Добавил `yacheika/cell` и `stock` во вход и хранение. |
| `6f2abb524dc380f526371ae4661f8c6574d17e20`, 18.06.2026, `KIS-4139 add permission for reports` | Добавил append-only history trigger для INSERT/UPDATE container snapshot. |

## Проверки и граница доверия

Прямых тестов `POST /datareon/container-remain`, `POST /datareon/railway-carriage-remain`, двух delete-and-reload сценариев и их конкурентности не найдено. `ContainerRemainCacheServiceTest` подтверждает поиск существующего status и создание неизвестной зоны с `code=ERROR`. `ContainerRemainsDaoServiceTest` относится к другой модели `container_movement` и не является тестом этого inbound-процесса. Тесты на этом подэтапе не запускались.

Для ТЗ нельзя без отдельного решения утверждать, что `MessageID` обеспечивает идемпотентность, timestamp выбирает самое новое событие, пакет атомарен, отсутствие строки означает удаление в Datareon-режиме, view всегда ограничен клиентами пользователя или что импорт остатка создаёт движение КТК. Всё перечисленное текущим backend AS-IS не гарантируется.
