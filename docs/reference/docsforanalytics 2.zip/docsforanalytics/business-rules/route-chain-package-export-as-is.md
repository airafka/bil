# Route chain package export: 4 пакета в Datareon AS-IS

Проверено по checkout `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026): Java export/scheduler/DTO source, `application.yaml`. **Source-level реконструкция**, тесты не прогонялись, применённая среда не проверялась. Документ закрывает пробел, явно обозначенный как открытый вопрос в [order-integrations.md](order-integrations.md) («взаимодействие обычного outbound с route chain package») и в разделе «Outbound после accept» [route-lifecycle-as-is.md](route-lifecycle-as-is.md#outbound-после-accept), который описывает только *логику выбора* пакета, но не его содержимое.

**Каталожный пробел:** все четыре DTO (`ShippingRouteChainPackageDto`, `ReceivingAutoRouteChainPackageDto`, `ReceivingRailwayRouteChainPackageDto`, `ServiceOrderChainPackageDto`) находятся в пакете `ru.korusconsulting.alis.datareon.dto.*`, а не `ru.korusconsulting.alis.dto.*`. Генератор [`generate_dto_docs.py`](../scripts/generate_dto_docs.py) сканирует только `DTO_ROOTS = web-layer/.../ru/korusconsulting/alis/dto` — весь пакет `datareon.dto` (включая эти четыре DTO и другие outbound-контракты Datareon) исключён из автогенерируемого каталога `dto/catalog/`. Это касается не только route chain package — стоит сообщить мейнтейнеру генератора отдельно.

## Общий движок: `BaseExportService` + `OutboundData`

Все четыре типа (и вообще все outbound-сообщения Datareon, не только route chain package) используют один [`BaseExportService.exportNextEntity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseExportService.java):

1. Выбирается **одна** строка `OutboundData` с `success != TRUE`, `attempts < 5`, сортировка `createdAt DESC` — то есть **сначала обрабатывается самая новая** неотправленная строка, а не FIFO. При постоянном потоке новых строк одного `messageType` старая застрявшая строка теоретически может годами не доходить до головы очереди — открытый вопрос, а не подтверждённый инцидент.
2. Для найденной строки ищутся **все прочие** строки с тем же `(messageType, rootObjectId)` и `success != TRUE` — то есть все ещё не отправленные сообщения того же корневого объекта того же типа схлопываются в одну попытку.
3. Все найденные строки блокируются через `findAndLockSkipLocked` (SQL `SKIP LOCKED` — конкурентный вызов просто получает пустой список и не блокируется).
4. Строится DTO **только** из первой строки (`toDto(outboundData)` — но сам метод не читает payload из `outboundData`, а заново запрашивает текущее состояние из DAO по `rootObjectId`, поэтому какая именно из slibling-строк «первая», не влияет на содержимое сообщения).
5. Один HTTP POST в Datareon (`entityDatareonRestService.getContent(entityDto)`); ответ ожидается как **голый UUID** в теле (`UUID.fromString(response.getBody())`) — записывается как `messageId`.
6. При успехе — **все** найденные в п.2 строки помечаются `success=true` одним UPDATE (даже те, что не участвовали в построении DTO напрямую). При любом исключении — все помечаются `success=false`, `errorMessage=e.getMessage()`, `attempts++`.
7. Backoff линейный: [`ExpiredCondition`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/outbounddata/ExpiredCondition.java) — строка становится «просроченной» (готовой к retry), когда `(минут с last_attempt_at) > 5 × attempts`. Максимум 5 попыток (`MAX_ATTEMPT_NUMBER`), дальше строка навсегда остаётся `success=false` без дальнейших попыток и без отдельного алертинга (см. также снятый в этом периоде datareon-мониторинг, [integrations/README.md](../integrations/README.md#обновление-29-сентября-2026-мониторинг-datareon-удалён-появился-stub-контур)).

Модель — [`OutboundData`](../entities/catalog/entities/outbounddata/OutboundData.md): `messageType`, `entityType`, `rootObjectId`, `success`, `messageId`, `responseCode`, `errorMessage`, `attempts`, `lastAttemptAt`.

## Планировщики: fixed delay 5 секунд, drain-цикл

Каждый из четырёх типов запускается собственным `Scheduled*ExportService` с `@Scheduled(fixedDelayString = ...)` (не cron-выражение, а простой fixed delay — следующий запуск через N мс **после завершения** предыдущего, не по расписанию). Все четыре интервала в [`application.yaml`](../../../web-layer/src/main/resources/application.yaml) одинаковы — **5000 мс**:

```yaml
datareon:
  cron:
    shippingRouteChainPackage: 5000
    receivingRailwayRouteChainPackage: 5000
    receivingAutoRouteChainPackage: 5000
    serviceOrderChainPackage: 5000
```

Каждый тик — `while (exportNextEntity(type) != null) {}` (с комментарием `// todo` в трёх из четырёх файлов) — то есть один тик вычерпывает **всю** очередь данного `MessageType` до пустого результата, а не одну строку за раз.

## Четыре типа: root-объект, endpoint, что собирается

| Тип | `MessageType` | Root-объект | REST endpoint (`${datareon.base.url}` + …) | Условие срабатывания |
|---|---|---|---|---|
| Shipping | `SHIPPING_ROUTE_CHAIN_PACKAGE` | `Route` | `/shippingOrderContainer` | `CONTAINER` + `SHIPPING` + `receivingAndShippingRailwayRouteChainPackageEnabled` |
| Receiving Railway | `RECEIVING_RAILWAY_ROUTE_CHAIN_PACKAGE` | `Route` | `/receivingOrderContainer` | `CONTAINER` + `RECEIVING` + `RAILWAY` + `receivingAndShippingRailwayRouteChainPackageEnabled` |
| Receiving Auto | `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE` | `Route` | `/receivingOrderAutoContainer` | `CONTAINER` + `RECEIVING` + `VEHICLE` + `receivingAutoRouteChainPackageEnabled` |
| Service order | `SERVICE_ORDER_CHAIN_PACKAGE` | **`ServiceOrder`**, не `Route` | `/serviceOrder` | после успешной смены владельцев (см. [lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет)) |

**Название endpoint'а не соответствует имени Java-класса**: `ShippingRouteChainPackageDatareonRestService` шлёт на `/shippingOrderContainer`, `ReceivingRailwayRouteChainPackageDatareonRestService` — на `/receivingOrderContainer` (без «Railway» в пути), `ReceivingAutoRouteChainPackageDatareonRestService` — на `/receivingOrderAutoContainer`. При чтении access/error логов Datareon по URL это стоит держать в уме — путь не подсказывает, какой из трёх «receiving/shipping»-вариантов это был.

Условия срабатывания (feature flags, `TerminalArea`/`RouteType`/`TransportType`) подробно разобраны в [route-lifecycle-as-is.md](route-lifecycle-as-is.md#outbound-после-accept) — здесь не дублируются.

### Shipping (`ShippingRouteChainPackageExportService`)

Собирает **все** `ShippingOrder` рейса (`shippingOrderDaoService.findAllByRoute`) и по каждой — `ShippingOrderRailwayCarriageQty`, `ShippingOrderRailwayCarriage`, `ShippingOrderContainerQty`, `ShippingOrderContainer`, `ShippingOrderContainerItem`, `ShippingOrderEtsngCode` (через `ShippingOrderContainerQty`, не напрямую от заявки). Справочники (Client/Contract/RailwayCarriage/Container/EtsngCode/RailwayCarriageType/VehicleType) собираются `distinctById` по всем найденным дочерним строкам. `clientDriver`/`clientVehicle` пакета берутся **только с `Route`** (не с отдельных заявок) — согласуется с переносом транспорта в `Route` по KIS-4093.

`postExport`: **все** `ShippingOrderRailwayCarriage` и `ShippingOrderContainer` **всех** заявок рейса переводятся в `TaskStatus.UPLOADED` одним циклом — включая те, что физически не изменились с прошлой отправки и уже были `UPLOADED`. Точечного различения «что реально нового в этом пакете» нет: `postExport` не сверяется с содержимым `toDto`.

**Владелец КТК (`ownerContainerId`).** С 22.09 по 08.10.2026 поле в `ShippingOrderContainerDto` этого пакета было всегда `null`. KIS-4830 (`401bbea3`, 08.10.2026) это исправил: поле заполняется снимком владельца из registry `ContainerOwner`, сделанным при добавлении КТК в заявку или смене КТК в строке. У строк, созданных в период дефекта, значение остаётся `null`, пока КТК в строке не сменят. Подробности — в [регистре остатков и владельца КТК](container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).

#### Поля (JSON-контракт `ShippingRouteChainPackageDto`)

Источник: [`ShippingRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ShippingRouteChainPackageDto.java). Корневые поля сериализуются с `@JsonProperty` в PascalCase (`Route`, `ShippingOrder`, `ShippingOrderContainer` и т.д.) — это буквальные ключи JSON, который получает Datareon; вложенные поля — как есть (camelCase), кроме отдельно отмеченных.

| `Route` (объект, 1) | Тип | |
|---|---|---|
| `id` | UUID | |
| `number` | Long | |
| `routeType` | enum `RouteType` | |
| `dataTime` | Instant | |
| `terminalArea` | String | код площадки |
| `transportType` | enum `TransportType` | |
| `clientRelatedEntityId` | UUID | перевозчик |
| `clientDriverId` | UUID | |
| `clientVehicleId` | UUID | |
| `comment` | String | |
| `status` | enum `RouteStatus` | |

| `ShippingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus` | UUID, Long, enum `OrderStatus` | |
| `clientId`, `contractId`, `currencyId` | UUID | |
| `terminalArea` | String | |
| `transportType` | enum `TransportType` | |
| `plannedShippingDateTime`, `actualShippingDateTime` | Instant | |
| `contactName`, `contactPhone`, `contactEmail` | String | из `shippingOrder.getContact()`, `null` если контакт не задан |
| `comment` | String | |
| `totalSKUQuantity` | Long | `@JsonProperty("totalSKUQuantity")` — единственное поле пакета с нестандартным casing (капс `SKU`) |
| `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRequestedServiceQuantity`, `totalContainerQuantity` | Long | |
| `deliveryType` | enum `ShippingOrderDeliveryType` | |
| `routeId` | UUID | |
| `needTransport` | Boolean | |
| `consigneeAddress` | String | |
| `ktkNumberUnknown` | Boolean | |
| `fillingType` | enum `ShippingOrderFillingType` | |

| `ShippingOrderRailwayCarriageQty[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `typeId` | UUID |
| `quantity` | Integer |

| `ShippingOrderRailwayCarriage[]` | Тип |
|---|---|
| `id`, `etranInvoiceId`, `railwayCarriageId`, `shippingOrderId`, `customerServiceId`, `ownerRailwayCarriageId` | UUID |
| `status` | enum `TaskStatus` |
| `dataTimeKrugloyePole` | Instant |

| `ShippingOrderContainerQty[]` | Тип |
|---|---|
| `id`, `shippingOrderId` | UUID |
| `quantity` | Integer |
| `type` | String (`.name()` enum'а типа контейнера) |
| `empty` | Boolean |

| `ShippingOrderContainer[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `containerId`, `shippingOrderRailwayCarriageId`, `sealTypeId`, `dangerClassId`, `customerServiceId`, `ownerRailwayCarriageId` | UUID |
| `ownerContainerId` | UUID | снимок владельца КТК из registry (с 08.10.2026, KIS-4830); `null` — КТК не указан, нет записи в registry или строка создана 22.09–08.10.2026 |
| `empty`, `customsClearance`, `random`, `ktkNumberUnknown` | Boolean |
| `weight`, `actualQuantity` | BigDecimal |
| `status` | enum `TaskStatus` |
| `dataTimeKrugloyePole` | Instant |

| `ShippingOrderContainerItem[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `shippingOrderContainerId`, `etsngCodeId` | UUID |
| `description` | String |
| `price`, `weightGross`, `weightNet`, `quantityPlace` | BigDecimal |

| `ShippingOrderEtsngCode[]` | Тип |
|---|---|
| `id`, `shippingOrderContainerQtyId`, `etsngCodeId` | UUID |
| `weight` | BigDecimal |

| `Client[]` | Тип |
|---|---|
| `id`, `syncId` | UUID |
| `code`, `name`, `inn`, `kpp`, `okpo`, `ogrn`, `edoId`, `addressLegal`, `addressFact`, `signatoryName`, `signatoryPosition`, `email`, `phoneNumber` | String |
| `active` | Boolean |

| `Contract[]` | Тип |
|---|---|
| `id`, `syncId`, `clientId`, `companyId`, `currencyId` | UUID |
| `code`, `name`, `edoId`, `contractNumber` | String |
| `active` | Boolean |
| `contractDate`, `validFrom`, `validTo` | Instant |
| `contractType` | enum `ContractType` |

| `RailwayCarriage[]` | Тип |
|---|---|
| `id`, `typeId`, `modelId` | UUID |
| `code` | String |
| `active` | Boolean |
| `liftingCapacity` | BigDecimal |
| `dateDepotRepair` | Instant |

| `Container[]` | Тип |
|---|---|
| `id`, `standardSizeId` | UUID |
| `code` | String |
| `active`, `refrigerator` | Boolean |
| `containerType` | String (`.name()`) |
| `weight`, `liftingCapacity` | BigDecimal |

| `EtsngCode[]` | Тип |
|---|---|
| `id` | UUID |
| `code`, `name` | String |
| `active` | Boolean |

| `RailwayCarriageType[]` | Тип |
|---|---|
| `id` | UUID |
| `code` | String |
| `active` | Boolean |
| `teu` | Integer |

| `ClientDriver[]` (0 или 1 элемент, только с `Route`) | Тип |
|---|---|
| `id`, `syncId`, `clientId` | UUID |
| `code`, `phoneNumber`, `passportNumber`, `passportIssuedBy`, `drivingLicenseNumber` | String |
| `active` | Boolean |
| `passportIssuedDate`, `drivingLicenseIssuedDate` | Instant |
| `POANumber` | String | `@JsonProperty("POANumber")`, не `poaNumber` |
| `POAValidTo` | Instant | `@JsonProperty("POAValidTo")` |

| `ClientVehicle[]` (0 или 1, только с `Route`) | Тип |
|---|---|
| `id`, `syncId`, `clientId`, `vehicleBrandId`, `vehicleTypeId`, `loadingTypeId` | UUID |
| `code`, `trailerNumber`, `insuranceNumber` | String |
| `active`, `refrigerator`, `withTrailer` | Boolean |
| `typeOwnershipTransport` | enum `OwnershipType` |

| `VehicleType[]` | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `codeVehicleType` | String |
| `active` | Boolean |

### Receiving Auto (`ReceivingAutoRouteChainPackageExportService`)

Собирает `ReceivingOrder` рейса (`ReceivingOrderFilter.route`), по каждой — `ReceivingOrderContainer` и `ReceivingOrderContainerItem`. `Waybill`/ЖД-сущности в пакет не входят вовсе — это чисто автомобильный контур. Клиенты-справочники собираются из трёх источников сразу: заявки, `ClientDriver.client`, `ClientVehicle.client` **и** `ReceivingOrderContainer.ownerContainer` — то есть владелец КТК явно учтён как участник справочника `client[]` пакета.

`postExport`: все `ReceivingOrderContainer` заявок рейса → `TaskStatus.UPLOADED`.

`ownerContainerId` в `ReceivingOrderContainerDto` берётся из `ReceivingOrderContainer.getOwnerContainer()` — это поле **мигрировано и корректно заполняется** (в отличие от shipping-стороны), дефекта здесь не найдено.

#### Поля (JSON-контракт `ReceivingAutoRouteChainPackageDto`)

Источник: [`ReceivingAutoRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ReceivingAutoRouteChainPackageDto.java). `Client`/`ClientDriver`/`ClientVehicle`/`VehicleType`/`EtsngCode` структурно идентичны Shipping-варианту (см. таблицы выше), кроме `RouteDto` (здесь `terminalAreaId: UUID`, а не `terminalArea: String`, и добавлено `deleted: Boolean`) и отсутствия `RailwayCarriage*`/`Contract`/`ShippingOrderEtsngCode`-аналогов — это чисто автомобильный пакет без ЖД-сущностей.

| `Route` (объект, 1) | Тип | Отличие от Shipping |
|---|---|---|
| `terminalAreaId` | UUID | здесь ID, не код-строка |
| `deleted` | Boolean | есть только в этом варианте |
| остальные поля | — | как в Shipping |

| `ReceivingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus`, `clientId`, `contractId`, `terminalAreaId`, `currencyId` | UUID/Long/enum | |
| `transportType` | enum `TransportType` | |
| `contactName`, `contactPhone`, `contactEmail` | String | |
| `planReceivingDateTime`, `actualReceivingDateTime` | Instant | |
| `storagePeriod`, `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `comment`, `waybill` | String | |
| `totalSKUQuantity`, `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRailwayCarriageQuantity`, `totalContainerQuantity`, `totalRequestedServiceQuantity` | Long | |
| `deliveryType` | enum `ReceivingOrderDeliveryType` | |
| `routeId`, `shipperId` | UUID | |
| `needTransport`, `documentConfirmed`, `ktkNumberUnknown` | Boolean | |

| `ReceivingOrderContainer[]` | Тип | |
|---|---|---|
| `id`, `receivingOrderId`, `containerId`, `dangerClassId`, `sealTypeId` | UUID | |
| `ownerContainerId` | UUID | заполняется корректно |
| `ktkNumberUnknown`, `empty`, `customsClearance` | Boolean | |
| `sealNumbers` | `List<String>` | |
| `weight`, `actualQuantity` | BigDecimal | |
| `status` | enum `TaskStatus` | |

| `ReceivingOrderContainerItem[]` | Тип |
|---|---|
| `id`, `receivingOrderId`, `receivingOrderContainerId`, `etsngCodeId` | UUID |
| `description` | String |
| `price`, `weightGross`, `weightNet`, `quantityPlace` | BigDecimal |

| `VehicleBrand[]` (нет в Shipping-варианте) | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `codeVehicleBrand` | String |
| `active` | Boolean |

| `DangerClass[]` (нет в Shipping-варианте) | Тип |
|---|---|
| `id` | UUID |
| `code`, `codeDangerClass`, `groupName` | String |
| `active` | Boolean |

| `Container[]` | Тип | |
|---|---|---|
| `containerType` | Java-тип поля — enum `ContainerType` напрямую (у Shipping/ReceivingRailway то же значение приходит уже как `String` через `.name()` в export-сервисе); итоговый JSON, вероятно, одинаков (Jackson по умолчанию сериализует enum через `.name()`), не проверялось отдельно | |
| остальные поля | — | как в Shipping |

### Receiving Railway (`ReceivingRailwayRouteChainPackageExportService`)

Собирает `ReceivingOrder` рейса и по каждой — `Waybill`, `WaybillRailwayCarriage`, `WaybillContainer`, `WaybillProduct`, `WaybillZpu` (ЗПУ — по `WaybillContainer.id`). Дополнительно `RailwayStation` — департура/дестинация **заявки** (`receivingOrder.getDepartureStation/getDestinationStation`), а не станции самой накладной.

`ownerContainerId` — из `WaybillContainer.getOwnerContainer()`, тоже мигрированное и корректно заполняемое поле; дефекта нет.

**Найденная особенность сборки `WaybillProductDto` (не задокументирована больше нигде):** `toWaybillProductDtos` строит по одной строке продукта на каждый **`WaybillContainer`**, а не по одной на `WaybillProduct`, с асимметричной логикой:

- если у накладной **2 и более** `WaybillProduct` — каждый продукт даёт одну DTO-строку, но `waybillContainerId` у **всех** них — ID **первого** (по порядку выборки, без сортировки) `WaybillContainer` накладной (`containers.get(0)`), вес берётся из `WaybillProduct.weight`;
- если у накладной **ровно 1** `WaybillProduct` — этот продукт **дублируется** на каждый `WaybillContainer` накладной (по одной DTO-строке на контейнер), вес берётся из `WaybillContainer.netWeight`, а не из продукта.

То есть при нескольких товарах в накладной с несколькими КТК исходящий пакет физически не различает, какой товар в каком контейнере — все продукты «привязываются» к одному произвольному первому контейнеру. Это тот же класс проблемы, что уже описан для `grouped_waybill`/ЕТСНГ в [DEPRECATED-заметке](../database/grouped-waybill-as-is.md) и [repository-change-log](../traceability/repository-change-log.md) про ЕТСНГ накладной — не проверено, совпадает ли это ровно с той же бизнес-логикой или это независимая реализация с тем же классом неточности.

`postExport`: `WaybillRailwayCarriage` и `WaybillContainer` заявок рейса → `TaskStatus.UPLOADED` (не `ReceivingOrderContainer` — для railway-варианта контейнеры живут в `WaybillContainer`).

#### Поля (JSON-контракт `ReceivingRailwayRouteChainPackageDto`)

Источник: [`ReceivingRailwayRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ReceivingRailwayRouteChainPackageDto.java). `ClientDriver`/`ClientVehicle`/`VehicleType`/`Client`/`Contract`/`EtsngCode`/`RailwayCarriageType` структурно идентичны Shipping-варианту. `RouteDto` здесь ближе к Shipping (`terminalArea: String`, а не `terminalAreaId`), но с добавленным `deleted: Boolean` и **`clientRelatedEntity: String`** (имя перевозчика текстом, а не `clientRelatedEntityId: UUID`, как у двух других вариантов) — единственный из трёх пакетов, отдающий перевозчика по имени, а не по ID.

| `ReceivingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus`, `clientId`, `contractId` | UUID/Long/enum | |
| `terminalArea` | String | |
| `transportType` | enum `TransportType` | |
| `currencyId` | UUID | **`@JsonProperty("currencyID")`** — заглавные `ID`, единственное поле среди всех трёх пакетов с такой capitalization (у Shipping/ReceivingAuto — `currencyId`, обычный casing) |
| `contactName`, `contactPhone`, `contactEmail` | String | |
| `planReceivingDateTime`, `actualReceivingDateTime` | Instant | |
| `storagePeriod`, `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `comment` | String | |
| `totalSKUQuantity`, `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRailwayCarriageQuantity`, `totalContainerQuantity`, `totalRequestedServiceQuantity` | Long | |
| `deliveryType` | enum `ReceivingOrderDeliveryType` | |
| `routeId`, `shipperId`, `departureStationId`, `destinationStationId` | UUID | |
| `needTransport`, `documentConfirmed`, `ktkNumberUnknown` | Boolean | |
| `waybill` | — | **отсутствует** в этой версии (в отличие от ReceivingAuto) — номер накладной здесь не дублируется на уровне заявки, так как есть отдельный блок `WaybillProduct`/`WaybillContainer` |

| `WaybillRailwayCarriage[]` | Тип |
|---|---|
| `id`, `receivingOrderId`, `railwayCarriageId` | UUID |
| `ownership`, `renter`, `previouslyTransported` | String |
| `grossWeight`, `netWeight` | BigDecimal |
| `placeCount` | Integer |

| `WaybillContainer[]` | Тип |
|---|---|
| `id`, `waybillRailwayCarriageId`, `containerId` | UUID |
| `ownerContainerId` | UUID | заполняется корректно |
| `supplyRequestNumber`, `sendingRequestNumber` | Integer |
| `owner` | String | строковый «владелец» с самой накладной (не FK, дублирует смысл `ownerContainerId`) |
| `length`, `netWeight` | BigDecimal |

| `WaybillProduct[]` | Тип | |
|---|---|---|
| `id`, `receivingOrderId`, `waybillContainerId`, `etsngCodeId` | UUID | `waybillContainerId` — см. находку про «первый контейнер» выше |
| `gngCode`, `packagesCount`, `placesCount` | Integer | |
| `cargoFullName`, `additional`, `packagingType`, `marksStampsShipper`, `isDangerous`, `emergencyCardNumber`, `customsDeclarationNumber`, `customsDeclarationProductNumber` | String | `isDangerous` — именно `String`, не `Boolean` |
| `signDanger` | String | |
| `volume`, `weight`, `weightLoaded`, `netWeight`, `grossWeight`, `length`, `width`, `height` | BigDecimal | `weight` — либо из продукта (2+ товаров), либо из `WaybillContainer.netWeight` (1 товар), см. находку выше |

| `WaybillZpu[]` | Тип |
|---|---|
| `id`, `waybillContainerId` | UUID |
| `zpu` | String |

| `RailwayStation[]` (нет в двух других вариантах) | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `esrCode` | String |
| `active` | Boolean |

| `RailwayCarriage[]` | Тип | Отличие от Shipping |
|---|---|---|
| `model` | String (код модели) | у Shipping — `modelId: UUID`; здесь сразу код, без ID |
| остальные поля | — | как в Shipping |

| `Container[]` | Тип | Отличие от Shipping |
|---|---|---|
| `standardSize` | String (код типоразмера) | у Shipping/ReceivingAuto — `standardSizeId: UUID` |
| остальные поля | — | как в Shipping |

### Service order (`ServiceOrderChainPackageExportService`)

Самый простой из четырёх: root — **`ServiceOrder`** (не `Route`), без `postExport`-переопределения (наследует no-op базового класса — здесь нет собственного статуса КТК/вагона, который нужно было бы перевести в `UPLOADED`). Пакет — сама заявка на услугу, её `ServiceOrderContainer[]`, связанные `Container[]` и `Client` (единственный, из `serviceOrder.getClient()`). Триггер — не route accept, а **смена владельцев КТК** в рамках сервисной заявки (транзакционно вместе с историей и `DONE`/`completionAt`) — подробности в [lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет).

#### Поля (JSON-контракт `ServiceOrderChainPackageDto`)

Источник: [`ServiceOrderChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ServiceOrderChainPackageDto.java) — самый маленький из четырёх (93 строки), четыре корневых ключа: `ServiceOrder` (объект), `ServiceOrderContainer[]`, `Container[]`, `Client[]`.

| `ServiceOrder` (объект, 1) | Тип |
|---|---|
| `id`, `clientId` | UUID |
| `number` | Long |
| `service` | enum `ServiceOrderType` |
| `comment` | String |
| `status` | enum `ServiceOrderStatus` |
| `completionAt` | Instant |

| `ServiceOrderContainer[]` | Тип |
|---|---|
| `id`, `serviceOrderId`, `containerId` | UUID |

| `Container[]` | Тип | |
|---|---|---|
| `id`, `standardSizeId` | UUID | |
| `code` | String | |
| `active`, `refrigerator` | **примитив `boolean`**, не `Boolean` | единственный из четырёх пакетов, где эти поля не boxed-типы (несущественно для JSON, но отличается на уровне Java-контракта) |
| `containerType` | enum `ContainerType` | |
| `weight`, `liftingCapacity` | BigDecimal | |

| `Client[]` | Тип |
|---|---|
| структура идентична `Client[]` остальных трёх пакетов (16 полей: id/code/name/active/syncId/inn/kpp/okpo/ogrn/edoId/addressLegal/addressFact/signatoryName/signatoryPosition/email/phoneNumber) | — |

## Отдельно: `GET /routes/{id}/cargo-chain` — не то же самое

Синхронный read-only endpoint `RouteService.getCargoChainByRouteId` → [`RouteToCargoChainPackageDto`](../dto/catalog/routetocargochainpackage/RouteToCargoChainPackageDto.md) (упомянут в [route-lifecycle-as-is.md](route-lifecycle-as-is.md)) — это **не** тот же механизм, что четыре export-сервиса выше. Он не создаёт `OutboundData`, не шлёт ничего в Datareon и не имеет `postExport`-побочных эффектов; это HTTP-запрос по требованию для показа состава рейса в UI. DTO лежит в `ru.korusconsulting.alis.dto` (не `datareon.dto`) и присутствует в автогенерируемом каталоге. Глубокий разбор этого read-пути не входит в объём данного документа.

## Открытые вопросы

1. «Newest-first» порядок обработки очереди (`createdAt DESC`) — осознанное решение (приоритет свежих операций) или недосмотр, из-за которого старые застрявшие строки могут никогда не дойти до retry при постоянном потоке новых сообщений того же `messageType`.
2. ~~Дефект `ownerContainerId=null` для shipping~~ — закрыт KIS-4830 (08.10.2026). Открыто: дозаполнение строк 22.09–08.10.2026 и обновление снимка при смене владельца до отгрузки.
3. Логика «первый контейнер накладной» в `ReceivingRailwayRouteChainPackageExportService.toWaybillProductDtos` — уточнить у разработчиков/аналитиков, действительно ли распределение товаров по контейнерам в общем случае не имеет смысла для 1С/Datareon-потребителя, или это потерянная точность.
4. `getContent`/`response.getBody()` в `BaseExportService` не проверяет `null` явно (`Objects.requireNonNull` бросит NPE, которое будет проглочено общим `catch (Throwable)` и осядет как малоинформативный `errorMessage`) — не проверено, возвращает ли Datareon когда-либо пустое тело при `2xx`.
5. Постоянный список `datareon.cron.*` = 5000 мс для всех четырёх типов не проверялся на предмет реальной нагрузки на Datareon при одновременном срабатывании всех четырёх сразу (совпадающие по времени тик и drain-цикл).
6. Не проверены production-значения feature flags (`receivingAndShippingRailwayRouteChainPackageEnabled`, `receivingAutoRouteChainPackageEnabled`) на конкретной среде — этот документ реконструирует только code-level поведение при включённом флаге.

## Граница охвата: сторона Datareon — отдельный документ

Этот документ и весь репозиторий `backend` содержат только **отправляющую** сторону (ALIS → Datareon); source-level здесь зафиксирована исключительно она. Как именно Datareon разбирает `PascalCase`-ключи JSON выше, сопоставляет их со своей моделью и валидирует — задокументировано (не source-level, а по предоставленному аналитиком материалу — скриптам трансформации Datareon) в отдельном документе: [route-chain-package-datareon-processing.md](../integrations/route-chain-package-datareon-processing.md). Покрыты 3 из 4 пакетов (`SERVICE_ORDER_CHAIN_PACKAGE` не предоставлен), shipping-скрипт получен не полностью.

## Связанные документы

- [Собственник КТК в исходящих пакетах — справка для 1С](../integrations/container-owner-outbound-contract.md)
- [Обработка на стороне Datareon (внешний материал)](../integrations/route-chain-package-datareon-processing.md)
- [Регистр остатков и владельца КТК](container-remains-and-owner-as-is.md)
- [Интеграционные эффекты заявок](order-integrations.md)
- [AS-IS рейсов](route-lifecycle-as-is.md#outbound-после-accept)
- [Lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет)
- [database/shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md#outbound-route-chain-package-и-ownercontainerid)
- [Журнал сверки документации](../traceability/repository-change-log.md)
