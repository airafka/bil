# Справочники ЭТРАН: вагоны и КТК

Документ фиксирует **backend AS-IS** двух пакетных импортов на ветке `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` (проверено 13.09.2026): `POST /datareon/etran_railway` и `POST /datareon/etran_container`. Реализация, конфигурация и миграции не изменялись.

Импорт клиентских снимков остатков через `/datareon/container-remain` и `/datareon/railway-carriage-remain` является другим процессом и описан в [отдельном inbound AS-IS](remain-inbound-as-is.md).

Исторические материалы [по вагонам](../../integrations/etran-railway.md) и [по КТК](../../integrations/etran-container.md) не содержат commit. Их описание Java-backend сверено здесь заново. Описанные в них скрипты 1С/Datareon, таблицы соответствий `sort`, вычисление `remaining_mileage`, замена кода контейнера и вычисление ISO отсутствуют в этом backend-репозитории и остаются **неподтверждённой внешней частью**, а не правилами ALIS.

## Общий контракт

Оба метода находятся в [DatareonController](../api/endpoints-generated.md#datareoncontroller), принимают `application/json`, при успехе возвращают `200` без тела и не имеют `@Secure`. Они входят в разрешённую Spring Security зону `/datareon/**`.

```mermaid
flowchart LR
    EXT[1С / Datareon<br/>внешняя граница] --> HTTP[POST /datareon/etran_*]
    HTTP --> BV[Jackson + Bean Validation]
    BV --> DUP[Последняя запись<br/>на точный code]
    DUP --> REF[Разрешить локальные справочники]
    REF --> FIND[Найти объект по точному code]
    FIND --> UPS{Найден?}
    UPS -->|нет| CREATE[Полное создание]
    UPS -->|да| UPDATE[Полное обновление]
    CREATE --> TX[Commit всего пакета]
    UPDATE --> TX
```

Общие свойства:

- `MessageID` обязателен как UUID, но используется только в warning о повторе кода **внутри одного пакета**;
- `MessageID` не сохраняется, не проверяется на повтор и не передаётся в `MonitorClient`;
- одинаковый точный `code` внутри пакета схлопывается, побеждает последняя запись; порядок уникальных ключей соответствует первому появлению;
- пробелы и регистр не нормализуются;
- create/update выполняются последовательно в одной транзакции пакета; ошибка любого элемента откатывает все предыдущие изменения этого HTTP-вызова;
- обновление полное, не patch: отсутствующие optional-поля очищают прежние значения;
- каждый upsert устанавливает `active=true`;
- row lock, optimistic `@Version` и DB-native upsert не используются.

## Импорт справочника вагонов

### HTTP и входной DTO

`POST /datareon/etran_railway` принимает [`EtranRailwayCarriageIntegrationDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/railwaycarriage/EtranRailwayCarriageIntegrationDto.java). Корневой `@Valid` каскадирует на каждый элемент благодаря type-use `@Valid`; `null`-элементы отдельно запрещены `@NotNull`.

| JSON | Java-тип | Bean Validation | Семантика backend |
|---|---|---|---|
| `MessageID` | UUID | `@NotNull` | Только контекст warning; не idempotency key. |
| `etran_railway` | array | `@NotEmpty`; элементы `@NotNull @Valid` | Минимум один вагон. |
| `code` | String | `@NotBlank` | Номер вагона, точный ключ схлопывания и поиска. |
| `lifting_capacity` | BigDecimal | `@NotNull` | Сохраняется без преобразования; знак не ограничен. |
| `type_id` | String | `@NotBlank` | Это код `RailwayCarriageType`, не UUID. |
| `model` | String | nullable | `null` очищает модель; пустая строка считается кодом и обычно даёт `404`. |
| `date_depot_repair` | Instant | nullable | Требует Jackson-совместимый instant. |
| `sort`, `owner`, `proxy_operator` | String | nullable | Сохраняются как есть, включая пробелы. |
| `volume`, `weight`, `length`, `mileage_rate`, `mileage`, `remaining_mileage` | BigDecimal | nullable, знак не ограничен | Сохраняются без вычисления и смены единиц. |
| `axles_count` | Integer | nullable | Сохраняется как есть. |
| `noworking_parking` | Boolean | nullable | Сохраняется как есть. |

В JPA-комментарии [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) грузоподъёмность обозначена в тоннах. Для прочих чисел сервер не фиксирует единицы и ничего не пересчитывает. Поэтому внешнее утверждение о вычислении или единицах нельзя доказать этим endpoint.

### Серверный алгоритм

```mermaid
flowchart TD
    A[Валидный railway package] --> M[LinkedHashMap code → last DTO]
    M --> N[Следующий уникальный вагон]
    N --> F[find RailwayCarriage by exact code]
    F --> T[find RailwayCarriageType by exact type_id]
    T --> MD{model == null?}
    MD -->|да| NM[model = null]
    MD -->|нет| FM[find model by exact code]
    NM --> U{Вагон найден?}
    FM --> U
    U -->|нет| C[Проверить контрольную цифру; create]
    U -->|да| E[Полностью перезаписать; code повторно не валидировать]
    C --> MORE{Есть ещё?}
    E --> MORE
    MORE -->|да| N
    MORE -->|нет| COMMIT[Commit]
```

На каждый уникальный элемент выполняются отдельные поиски вагона, типа и, если `model != null`, модели. Пакетного чтения этих трёх наборов нет.

Тип и модель ищутся точным регистрозависимым `code`; отсутствующий справочник даёт `NotFoundException`. Только при **создании** `RailwayCarriageService.preAdd` проверяет, что номер состоит из восьми цифр и имеет корректную контрольную цифру. При обновлении номер не проходит эту проверку повторно.

Mapper формирует [RailwayCarriageCreationDto](../dto/catalog/railway/RailwayCarriageCreationDto.md) или [RailwayCarriageUpdateDto](../dto/catalog/railway/RailwayCarriageUpdateDto.md), подставляет UUID найденных type/model и `active=true`. `RailwayCarriageService` при update перезаписывает code, type, capacity, model, repair date, sort, volume, axles, tare, length, owner/operator и три поля пробега, включая `null`.

Предварительный `findByCode` точный и регистрозависимый. Проверка уникальности при create использует `EXACTLY_MATCHES_IGNORE_CASE`, а физический unique constraint БД — обычный регистрозависимый `UNIQUE(code)`. Поэтому пакет с вариантом регистра существующего номера идёт в ветку create, но штатно отклоняется прикладной проверкой как дубликат.

## Импорт справочника КТК

### HTTP и входной DTO

`POST /datareon/etran_container` принимает [`EtranContainerIntegrationDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/container/EtranContainerIntegrationDto.java). `@Valid` стоит на списке, но у generic-элемента нет `@NotNull`: вложенные поля непустого элемента проверяются, а literal `null` проходит Bean Validation и позже приводит к runtime `500` при чтении `getCode()`.

| JSON | Java-тип | Bean Validation | Семантика backend |
|---|---|---|---|
| `MessageID` | UUID | `@NotNull` | Только warning; не idempotency key. |
| `etran_container` | array | `@NotEmpty @Valid` | Минимум один элемент; сам элемент `null` явно не запрещён. |
| `code` | String | `@NotBlank` | Номер КТК, точный ключ схлопывания и поиска. |
| `container_type` | String | `@NotBlank` | Точное enum-имя либо точное русское `tosType`. |
| `weight` | BigDecimal | `@NotNull @Positive` | Масса тары, сохраняется без преобразования. |
| `lifting_capacity` | BigDecimal | `@NotNull @Positive` | Грузоподъёмность, сохраняется без преобразования. |
| `ISO` | Long | `@NotNull @Positive` | Identifier строки `ContainerTypeISO`, не её UUID/код. |
| `height`, `length` | BigDecimal | nullable; при наличии `@Positive` | Сохраняются без преобразования. |
| `owner`, `owner_name`, `renter`, `renter_name` | String | nullable | Полностью перезаписывают справочные реквизиты. |

JPA-комментарии [Container](../entities/catalog/entities/container/Container.md) называют `weight` и `liftingCapacity` тоннами, но endpoint не умножает и не делит значения. Известные внешние преобразования `×1000`, length/height и ISO относятся к Datareon-документу, а не к Java-сервису; единицы фактического входного payload требуют внешнего подтверждения.

`container_type` принимает без нормализации одно из enum-имён `REFRIGERATOR_20`, `REFRIGERATOR_40`, `STANDARD_20`, `STANDARD_40`, `TANK_20`, `TANK_40` либо соответствующий точный русский текст `Рефрижератор 20/40`, `Стандартный 20/40`, `Танк 20/40`. Другое значение даёт `IllegalArgumentException`.

### Серверный алгоритм

```mermaid
flowchart TD
    A[Валидный container package] --> M[LinkedHashMap code → last DTO]
    M --> ISOS[Собрать уникальные ISO]
    ISOS --> IR[Одним запросом найти все ContainerTypeISO]
    IR --> OK{Все ISO найдены?}
    OK -->|нет| E500[EntityNotFoundException; rollback]
    OK -->|да| CR[Одним exact code IN запросом найти Container]
    CR --> N[Следующий DTO]
    N --> CT[Преобразовать container_type]
    CT --> U{Container exact-code найден?}
    U -->|нет| C[Проверить номер/unique; create]
    U -->|да| UP[Полностью перезаписать]
    C --> MORE{Есть ещё?}
    UP --> MORE
    MORE -->|да| N
    MORE -->|нет| COMMIT[Commit]
```

Справочник `container_type_iso` и существующие контейнеры читаются по одному пакетному запросу до изменений. Если хотя бы один положительный ISO отсутствует, `ContainerTypeISOService` бросает `EntityNotFoundException` и ни один контейнер не меняется.

Mapper формирует [ContainerCreationDto](../dto/catalog/container/ContainerCreationDto.md) или [ContainerUpdateDto](../dto/catalog/container/ContainerUpdateDto.md). Помимо входных полей он всегда устанавливает:

- `active=true`;
- `refrigerator=false`, даже для `REFRIGERATOR_20/40`;
- `standardSize=null`;
- `containerTypeISO` как локальный `IdCodeDto` найденной строки.

При update эти значения и все optional owner/renter/height/length поля перезаписывают существующий [Container](../entities/catalog/entities/container/Container.md). Импорт может тем самым повторно активировать КТК, снять признак холодильного КТК и очистить стандартный размер/непереданные реквизиты.

Только ветка create вызывает проверку 11-символьного контейнерного номера и контрольной цифры. Латинские буквы допускаются в любом регистре. Из-за реализации validator неизвестный символ среди первых четырёх позиций может привести к `NullPointerException`, а не к ожидаемому `ValidationException`.

Как и для вагонов, предварительный пакетный поиск точный и регистрозависимый, прикладная uniqueness-проверка create — без учёта регистра, DB `UNIQUE(code)` — регистрозависимый.

## Повторная загрузка и конкурентность

| Ситуация | Вагон | КТК |
|---|---|---|
| Повтор того же `MessageID` | Полный новый upsert | Полный новый upsert |
| Точный дубль code в одном пакете | Последний DTO | Последний DTO |
| Отличие регистра/пробелов | Другой map key и exact lookup | Другой map key и exact lookup |
| Объект уже существует | Полное update, optional null очищает поля | Полное update, плюс active/refrigerator/standardSize defaults |
| Два параллельных первых пакета | Оба могут не найти строку; конфликт на проверке/DB unique | То же |
| Ошибка позднего элемента | Rollback всего пакета | Rollback всего пакета |

Ни один сервис не блокирует строку при update. Параллельные обновления одного объекта имеют поведение last-commit-wins по всему набору полей. Предварительная проверка уникальности не заменяет constraint и не делает create атомарным.

Эти импорты изменяют глобальные справочные [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) и [Container](../entities/catalog/entities/container/Container.md), на которые уже могут ссылаться Waybill, заявки и остатки. Проверок статуса связанных заявок или занятости объекта нет. Отличие от [импорта Waybill](waybill-etran-as-is.md): специализированные endpoints используют общие `RailwayCarriageService`/`ContainerService`, но также выполняют полный справочный update; они не являются lookup-only.

## Ошибки HTTP

| Условие | Исключение AS-IS | HTTP |
|---|---|---:|
| Некорректный JSON/UUID/Instant/число, пустой пакет, нарушение `@Not*`/`@Positive` | Jackson или Bean Validation | `400` |
| Невалидный новый номер вагона/большинство невалидных номеров КТК | `ValidationException` | `400` |
| Не найден type/model вагона | `NotFoundException` | `404` |
| Unknown `container_type` | `IllegalArgumentException` | `500` |
| ISO отсутствует в `ContainerTypeISO` | `EntityNotFoundException` | `500` |
| `null`-элемент container list либо неизвестная буква/символ в префиксе нового code | `NullPointerException` | `500` |
| Прикладной/DB duplicate | `DuplicateEntityException`, `UniqueViolationException` или SQLSTATE `23505` | `409` |
| Иная DB integrity/runtime error | catch-all | `500` |

OpenAPI обоих методов заявляет только `200` и `400` без content/schema. Фактические `404`, `409` и `500` в декларативном контракте не отражены. Формат ответа задаёт общий [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java).

## Физические ограничения и seed

- `container.code` имеет `UNIQUE`; колонка обязательна через базовую исходную миграцию.
- `railway_carriage.code` после удаления `client_id` имеет `UNIQUE`; type и lifting capacity обязательны в исходной таблице.
- `container_type_iso.identifier` имеет `NOT NULL UNIQUE`, `code` — `NOT NULL`; миграция seed создаёт identifiers `1–6`, `8`, `10`, `12`, `18`, `20`, `50–52`, `54–56`, `66`, `67`, `69`, `70`, `72`, `73`, `80`, `81`.
- Миграция вагонов создаёт тип `Не определено`, переводит на него три старых неопределённых типа и удаляет их.
- Числовые колонки обычно `NUMERIC(15,3)`; container lifting capacity создана как `NUMERIC(15,6)`. Входной DTO не задаёт `@Digits`, поэтому переполнение precision/scale проявится на БД и откатит пакет.

Применённая схема среды не проверялась. Источники: [container ISO migration](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260727_KIS-4432_edit_container_table_and_create_container_iso_dictionary.sql), [railway fields/type migration](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260729_KIS-4321_edit_railway_carriage_table.sql), [container unique](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250213_KIS-151_drop_column_client_id_and_make_code_unique_in_table_container.sql) и [railway unique](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260306_KIS-3234_remove_client_id_from_railway_carriage.sql).

## Влияющие commits

| Commit | Изменение |
|---|---|
| `0fed0cd23a15e23fd331899336afc3cc103556df`, 06.08.2026, `KIS-4432 add datareon integration for container dictionary` | Добавил container endpoint/DTO/service/mapper, ISO-справочник, поля Container и миграцию seed. |
| `1e46c564852d88d4bb13acb579a20479b4350e97`, 06.08.2026, `KIS-4321 Railway carriage datareon synchronization` | Добавил railway endpoint/DTO/service/mapper, новые поля вагона, тип `Не определено` и проверки update-полей. |
| `b133cd12098021e4414db148d9da429f7b8c5d7c`, 12.08.2026, `KIS-4432 remove redundant etranType mapper for container type` | Перевёл container mapper на общий `ContainerType.fromTosType`: принимаются enum-name и точный русский `tosType`. |
| `cd8ab54287495f1d40cc1e6b1acef831712c0252`, 20.08.2026, `KIS-4365 add scoped meta support for nested shipping order fields` | Перенёс/адаптировал DTO и сервисы в текущую структуру и сохранил показанный upsert-контракт; основной смысл commit шире этих интеграций. |

## Тестовая трассировка

Отдельных unit/integration/controller tests для `EtranRailwayCarriageDatareonService`, `EtranContainerDatareonService`, `/etran_railway` или `/etran_container` в найденном test tree нет.

Связанные проверки покрывают только части цепочки:

- [RailwayCarriageServiceTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/railway/RailwayCarriageServiceTest.java) подтверждает полное копирование синхронизируемых полей при update;
- [RailwayCarriageValidatorUtilTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/utils/RailwayCarriageValidatorUtilTest.java) проверяет алгоритм номера вагона;
- [ContainerValidatorUtilTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/utils/ContainerValidatorUtilTest.java) проверяет примеры контрольной цифры КТК.

Не покрыты endpoint validation, last-duplicate-wins, packet rollback, lookup type/model/ISO, create/update выбор, case mismatch, full null-clearing, принудительные defaults КТК, повтор `MessageID`, конкурентность и фактические HTTP errors. Найденные тесты не запускались.

Основные Java-источники: [railway service](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/railwaycarriage/EtranRailwayCarriageDatareonService.java), [railway mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/mapper/railwaycarriage/EtranRailwayCarriageMapper.java), [container service](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/container/EtranContainerDatareonService.java), [container mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/mapper/container/EtranContainerMapper.java), [RailwayCarriageService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/railway/RailwayCarriageService.java), [ContainerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/container/ContainerService.java) и [ContainerTypeISOService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containertypeiso/ContainerTypeISOService.java).
