# Бизнес-правила заявки на поставку

`ReceivingOrder` специализирует транспортную заявку. Перед чтением этого раздела применяются общие [типы](order-types.md) и [статусные правила](order-statuses.md).

## Контракты и модель

- Сущность: [ReceivingOrder](../entities/catalog/entities/receivingorder/ReceivingOrder.md)
- Входные DTO: [create](../dto/receiving-order/ReceivingOrderCreationDto.md), [update](../dto/receiving-order/ReceivingOrderUpdateDto.md)
- Выходные DTO: [основной](../dto/receiving-order/ReceivingOrderDto.md), [карточка](../dto/receiving-order/ReceivingOrderDetailedDto.md)
- Таблицы: [модель БД заявок](../database/orders.md)
- Копирование: [общие правила копирования](order-copying.md#поставка)
- Интеграции: [исходящие сообщения поставки](order-integrations.md#поставка)
- Входящие результаты и завершение: [сравнение пяти Datareon actions](receiving-inbound-actions.md)
- Накладные ЭТРАН: [актуальный импорт, read API и связь с поставкой](waybill-etran-as-is.md)
- Ошибки: [каталог бизнес-ошибок](order-errors.md#только-поставка)
- Обязательные поля и порядок проверок: [карта валидации поставки](order-validation.md#поставка-корневой-request)
- PDF-отчёты: [MX-1, M-7 и общий availability AS-IS](order-pdf-reports-as-is.md)
- Excel-реестр: [корневые выгрузки V1/V2, фильтры и client scope](order-excel-exports-as-is.md)
- Дочерний Excel, часть 1: [blackbox, cargo, container и container-item V1/V2](receiving-order-child-excel-exports-as-is.md)
- Дочерний Excel, часть 2: [good, requested-service, Waybill и railway-carriage V1/V2](receiving-order-child-excel-exports-part2-as-is.md)

## Создание и редактирование

`POST /receivingorder/` использует [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md), `PUT /receivingorder/{id}` — [ReceivingOrderUpdateDto](../dto/receiving-order/ReceivingOrderUpdateDto.md). Оба наследуют поля [ReceivingOrderBaseDto](../dto/receiving-order/ReceivingOrderBaseDto.md). Полная таблица обязательности create/update и условных требований приведена в [карте валидации](order-validation.md#поставка-корневой-request).

| ID | Правило |
|---|---|
| `BR-RO-001` | Новый объект всегда получает `DRAFT`; номер и UUID генерирует сервер. |
| `BR-RO-002` | Проверяется и нормализуется комбинация площадки, транспорта и `deliveryType` по [матрице](order-types.md#матрица-реализованных-комбинаций). |
| `BR-RO-003` | После создания из условий договора добавляются обязательные `ReceivingOrderRequestedService`; при методе расчёта `REQUEST` плановое количество равно 1, иначе 0. |
| `BR-RO-004` | Цена обязательной операции без НДС = `plannedQuantity × rate`; цена с НДС вычисляется `VatCalculator`; операция помечается `systemManaged=true`. |
| `BR-RO-005` | При update меняются договор, валюта, контакт (только если request contact не `null`), плановая дата, срок хранения, комментарий, грузоотправитель, маршрут и накладная. |
| `BR-RO-006` | Клиент, площадка, транспорт и номер на уровне JPA неизменяемы после создания. |

Для `CONTAINER + RAILWAY` create DTO условно требует `payerId`, `departureStationId`, `destinationStationId`. Проверка включается только при буквальном `RAILWAY_FIELDS_REQUIRED=true`; отсутствие переменной фактически её отключает.

## Общая валидация review и accept

Независимо от типа поставки обязательны:

| Условие | Ошибка |
|---|---|
| Задана валюта | `ReceivingOrder.MissingCurrency` |
| Задана `planReceivingDateTime` | `ReceivingOrder.MissingPlannedReceivingDateTime` |
| Для контейнерной площадки задан `shipper` | `ReceivingOrder.MissingShipper` |

## Матрица содержательной валидации

Это не повторная валидация `ReceivingOrderCreationDto`. Review/accept читает корень и дочерние сущности из БД. Конкретные DTO, которыми предварительно заполняются транспорт, товары, грузы и КТК, перечислены в [карте DTO дочерних частей](order-validation.md#dto-дочерних-частей-агрегата).

| Площадка | Транспорт | Проверяемые части агрегата |
|---|---|---|
| `WAREHOUSE` | `VEHICLE` | транспорт; товары по `deliveryType`; детальные грузовые места; blackbox/общее количество |
| `CONTAINER` | `VEHICLE` | транспорт; наличие контейнеров; вес и владелец КТК; согласованность empty/items; занятость КТК |
| `CONTAINER` | `RAILWAY` | наличие накладной; наличие вагона в накладной; вес и владелец имеющихся КТК; согласованность empty/items; занятость КТК |

### Склад + автомобиль

- `BY_GOOD`: должна быть хотя бы одна `ReceivingOrderGood`.
- `BY_CARGO`: товарные строки не требуются, но должен существовать `ReceivingOrderBlackbox`.
- `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`: нужны товары и `totalCargoQuantity != 0`.
- `BY_GOOD_WITH_CARGO_WITH_DETAILS`: нужны товары и хотя бы один `ReceivingOrderCargo`.
- Для каждой требуемой товарной строки `plannedQuantity`, `price`, `totalPrice` должны быть больше 0.
- В детальном грузе обязательна ссылка `cargo`; код отклоняет отрицательные `packageQuantity`, `conversionQuantity`, `totalQuantity`, но допускает 0 и `null` как 0 — название ошибок `Missing*` шире фактической проверки.
- Должна существовать строка `ReceivingOrderTransport` с shared ID заявки.

### Контейнерная площадка + автомобиль

- Нужен минимум один `ReceivingOrderContainer`, иначе `ReceivingOrder.MissingContainers`.
- Для КТК с известным номером нужны вес > 0 и `ownerContainer`.
- Порожний КТК не может иметь items; непорожний должен иметь хотя бы один item.
- При включённом feature flag КТК не должен уже участвовать в другой поставке со статусом `ACCEPTED` или `IN_PROGRESS`.
- Только при accept запрещён `ktkNumberUnknown=true`; review это допускает.

### Контейнерная площадка + ЖД

- Нужна хотя бы одна связанная [Waybill](../entities/catalog/entities/waybill/Waybill.md), иначе `ReceivingOrder.MissingEtranInvoice`.
- Нужен хотя бы один `WaybillRailwayCarriage`, иначе `ReceivingOrder.MissingRailwayCarriages`.
- Для имеющихся КТК выполняются проверки веса, владельца, items и занятости.
- В текущей карте валидаторов отдельная проверка наличия хотя бы одного КТК не вызывается. Это **вопрос/возможный пробел** для будущего ТЗ.

## Дополнительные проверки accept

- Для `RAILWAY` и `VEHICLE` наличие вагона накладной с типом `UNDEFINED` даёт `ReceivingOrder.UndefinedRailwayCarriageType`.
- Для `CONTAINER + VEHICLE` неизвестный номер КТК даёт `<номер заявки>.ReceivingOrderContainer.KtkNumberUnknown`.
- Метод `containerItemChecks`, проверяющий пустой `description` item, существует, но не включён в карту валидаторов. Нельзя заявлять это правило действующим без исправления вызова.

## Отклонение и документы

`reject` переводит заявку в `REJECTED` и удаляет все связи заявки с накладными.

`confirm-document` и `unconfirm-document` доступны только в `ACCEPTED` или `IN_PROGRESS`. Они однократно переводят `documentConfirmed` из `null` в `true` либо `false`; повторная смена запрещена. Для каждого контейнера создаётся исходящее сообщение `CONFIRM_DOCS`.

## Накладные

Контроллер позволяет получить и заменить набор связанных накладных, а также читать сгруппированные по накладным вагоны, контейнеры и товары. Эти данные являются частью карточки поставки, но физически принадлежат агрегату `Waybill`.

Полный актуальный AS-IS, включая `POST /datareon/waybill`, DTO, частичное повторное обновление только статуса, bulk link/unlink, legacy endpoints, транзакции и ошибки, вынесен в [документ Waybill/ЭТРАН](waybill-etran-as-is.md). В частности, bulk-замена не проверяет статус заявки и может перепривязать накладную от другой поставки.

После коммита `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18` поле фильтра `railwayCarriageType` означает код справочника `railwayCarriage.type.code` и принимает alias `type`. Ранее alias `sort` и фильтрация были связаны с `railwayCarriage.sort`. Теперь `sort` остаётся отдельным полем сортности вагона. Изменение одинаково применено к фильтрации, meta values и сортировке накладных.

## Риски проектирования

1. Публичный endpoint accept в `ReceivingOrderController` не найден, хотя сервисная операция существует.
2. `PUT /receivingorder/{id}` фактически использует `body.id`, не path ID.
3. Update DTO не содержит ЖД-полей payer/станций: менять их через общий update нельзя.
4. `contact=null` не очищает текущий контакт из-за условного присваивания.
5. Вагонная ветка `CARRIAGE_ARRIVED` проверяет отсутствие контейнеров только в `receiving_order_container`, хотя контейнеры ЖД-поставки находятся в `waybill_container`; возможен преждевременный `DONE`.
6. `STATUS_COMPLETED` завершает поставку без проверки вагонов, КТК, товаров и услуг; `WMS_RECEIVING_RESULT` вообще не меняет статус заявки.

Условия, эффекты, конфликты и тестовое покрытие этих веток разобраны в [карте входящих действий поставки](receiving-inbound-actions.md).
