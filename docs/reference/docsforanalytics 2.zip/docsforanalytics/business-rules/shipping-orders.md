# Бизнес-правила заявки на вывоз

`ShippingOrder` специализирует транспортную заявку и наследует [общие типы](order-types.md) и [статусную модель](order-statuses.md).

## Контракты и модель

- Сущность: [ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md)
- DTO: [create](../dto/shipping-order/ShippingOrderCreationDto.md), [update](../dto/shipping-order/ShippingOrderUpdateDto.md), [response](../dto/shipping-order/ShippingOrderDto.md), [карточка](../dto/shipping-order/ShippingOrderDetailedDto.md)
- БД: [таблицы заявок](../database/orders.md)
- Физическая целостность: [полная ER/integrity-карта 13 таблиц](../database/shipping-order-integrity-map.md) — FK/UNIQUE/delete, plan/fact по `fillingType`, ETRAN membership, каскады, totals и route/outbound
- Копирование: [правила вывоза](order-copying.md#вывоз)
- Интеграции: [сообщения вывоза](order-integrations.md#вывоз)
- Входящее завершение вагонной задачи: [AS-IS порожнего ЖД-вывоза без КТК](shipping-railway-empty-completion.md)
- Остальные входящие результаты: [сравнение TOS, WMS, выезда и прямого завершения](shipping-inbound-actions.md)
- Ошибки: [каталог бизнес-ошибок](order-errors.md#только-вывоз)
- Обязательные поля и порядок проверок: [карта валидации вывоза](order-validation.md#вывоз-корневой-request)
- PDF-отчёты: [MX-3, ContainerTN, Packing List и общий availability AS-IS](order-pdf-reports-as-is.md)
- Excel-реестр: [корневые выгрузки V1/V2, фильтры и client scope](order-excel-exports-as-is.md)
- Дочерний Excel, часть 1: [blackbox, cargo, КТК и содержимое КТК V1/V2](shipping-order-child-excel-exports-as-is.md)
- Дочерний Excel, часть 2: [товары, услуги, связанные накладные ЭТРАН и вагоны V1/V2](shipping-order-child-excel-exports-part2-as-is.md)

## Создание и редактирование

`POST /shippingorder/` использует [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md), `PUT /shippingorder/{id}` — [ShippingOrderUpdateDto](../dto/shipping-order/ShippingOrderUpdateDto.md). Update DTO наследует creation DTO и добавляет обязательный `id`. Полная таблица обязательности приведена в [карте валидации](order-validation.md#вывоз-корневой-request).

| ID | Правило |
|---|---|
| `BR-SO-002` | Новый объект получает `DRAFT`, серверные UUID и номер. |
| `BR-SO-003` | Проверяется сочетание площадки/транспорта/вида вывоза/типа заполнения. |
| `BR-SO-004` | Для `CONTAINER + RAILWAY` отсутствующий `fillingType` нормализуется в `ALL`; `@PrePersist` также подставляет `ALL` при `null`. |
| `BR-SO-005` | Грузополучатель разыменовывается только в контексте клиента заявки. |
| `BR-SO-006` | После создания добавляются обязательные услуги договора по тем же формулам, что у поставки. |
| `BR-SO-007` | Клиент, площадка, транспорт и номер являются неизменяемыми JPA-полями. |

## Общая валидация review и accept

| Условие | Ошибка |
|---|---|
| Валюта задана | `ShippingOrder.MissingCurrency` |
| `plannedShippingDateTime` задана | `ShippingOrder.MissingPlannedShippingDateTime` |
| Для `CONTAINER` задан `consignee` | `ShippingOrder.MissingConsignee` |

## Матрица содержательной валидации

Review/accept не принимает `ShippingOrderCreationDto` или `ShippingOrderUpdateDto`: валидатор читает сохранённый агрегат. Конкретные DTO отдельных ресурсов — транспорта, товаров, грузов, КТК, вагонов и ЭТРАН — перечислены в [карте DTO дочерних частей](order-validation.md#dto-дочерних-частей-агрегата).

Физический выбор между номерными строками и плановыми количествами, а также ограничения, которые не обеспечивает БД, сведены в [plan/fact-разделе ER/integrity-карты](../database/shipping-order-integrity-map.md#planfact-развилка-по-fillingtype). Бизнес-валидация ниже описывает требуемый состав для review/accept, но не означает автоматическую очистку строк другой модели при смене `fillingType`.

| Площадка | Транспорт | Проверяемые части |
|---|---|---|
| `WAREHOUSE` | `VEHICLE` | транспорт, товары, детальный груз, blackbox |
| `CONTAINER` | `VEHICLE` | транспорт, контейнеры/quantity для `NONE_CONTAINER`, свойства и занятость КТК |
| `CONTAINER` | `RAILWAY` | ЭТРАН, конкретные или количественные вагоны, свойства и занятость КТК |

### Склад + автомобиль

- `BY_GOOD`: нужна хотя бы одна `ShippingOrderGood`.
- `BY_CARGO`: нужен `ShippingOrderBlackbox`, товарные строки не требуются.
- `BY_GOOD_WITH_CARGO_WITH_DETAILS`: нужны товары и `ShippingOrderCargo`.
- `plannedQuantity`, `price`, `totalPrice` товара должны быть > 0.
- Для детального груза нужна ссылка `cargo`; отрицательные количества отклоняются, но 0/`null` текущей реализацией допускаются.
- Нужна строка `ShippingOrderTransport` (проверяется только факт существования; физическая модель, включая отдельный от root `consignee`/`consigneeAddress`, — в [transport as-is](../database/shipping-order-transport-as-is.md)).

### Контейнерная площадка + автомобиль

- Обычно требуется минимум один `ShippingOrderContainer`.
- Исключение `fillingType=NONE_CONTAINER`: должна быть ровно одна `ShippingOrderContainerQty` с `quantity=1`, `empty=true` и без связанных `ShippingOrderEtsngCode`.
- Для КТК с известным номером нужен вес > 0. Владелец КТК на вывозе пользователем не вводится и не проверяется (с KIS-4716, 25.09.2026): с 08.10.2026 (KIS-4830) сервер сам записывает в `ownerContainer` снимок владельца из registry `ContainerOwner`, значение из API и Excel игнорируется. Наличие КТК в остатках проверяется при accept через `ContainerStatusService.reserveForShippingOrder` — см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).
- Порожний КТК не может иметь items, непорожний обязан иметь items.
- При feature flag нельзя использовать КТК, уже находящийся в другой заявке вывоза `ACCEPTED`/`IN_PROGRESS`.
- При accept запрещён `ktkNumberUnknown=true`; review его допускает.

### Контейнерная площадка + ЖД

- При `fillingType=ALL` нужна хотя бы одна `ShippingOrderEtranInvoice`.
- При `ALL` или `RAILWAY_CARRIAGE` нужны конкретные `ShippingOrderRailwayCarriage`.
- При `CONTAINER` или `NONE` нужны строки `ShippingOrderRailwayCarriageQty`.
- При `ALL` каждый конкретный вагон должен иметь `etranInvoice`, иначе `ShippingOrder.MissingRailwayCarriageEtranInvoice`.
- Контейнеры проверяются на вес, владельца, согласованность items и занятость.
- Отдельная проверка наличия хотя бы одного конкретного КТК для ЖД в карте валидаторов не вызывается; допустимость заявки без КТК требует решения.

## Отклонение

`reject` переводит заявку в `REJECTED`. В отличие от поставки, дополнительных действий с накладными в методе нет.

## Preview-meta содержимого контейнеров

Коммит `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18` добавил `POST /shipping-order/{shippingOrderId}/shipping-order-container-item/preview/meta/{fieldName}`. Сервер независимо от body:

1. подставляет `shippingOrderId` из path;
2. создаёт отсутствующие wrapper, основной и вложенный фильтры;
3. устанавливает `shippingOrderContainer.hasShippingOrderRailwayCarriage = true`;
4. возвращает meta values только для items контейнеров, связанных с вагоном заявки.

Для этого фрейма `grossweight` разрешается в поле `wightGross`, `netweight` — в `wightNet`. Орфография `wight*` соответствует фактическим Java-полям и должна сохраняться в технических требованиях, пока модель не переименована.

## Известные расхождения

1. Сервис реализует accept, но HTTP endpoint в `ShippingOrderController` не найден.
2. `PUT /shippingorder/{id}` использует `body.id`; path ID не принимается методом.
3. `ShippingOrderDto.documentConfirmed` не имеет соответствующего поля в `ShippingOrder` и явного mapping; ожидаемое происхождение значения не определено.
4. Swagger allowable values для `fillingType` не содержит `NONE_CONTAINER`, хотя enum и логика его поддерживают.
5. Метод проверки `description` container item отсутствует в фактически вызываемом наборе валидаторов.
6. `CARRIAGE_ARRIVED` завершает `ShippingOrderRailwayCarriage`, но не проверяет завершение всех вагонов и не переводит порожнюю ЖД-заявку без КТК в `DONE`; полный flow и негативные ветки описаны в [отдельном AS-IS](shipping-railway-empty-completion.md).
7. `STATUS_COMPLETED` обходит общую матрицу переходов и переводит любую нетерминальную заявку, включая `DRAFT` и `ON_REVIEW`, прямо в `DONE`; дочерние задачи и владельцы КТК не проверяются. Сопоставление со специализированными TOS/WMS actions приведено в [карте входящих действий](shipping-inbound-actions.md).
