# Журнал развития документации ALIS

Этот файл хранит компактное состояние работ. Перед следующим подэтапом нужно проверить текущий Git commit, затем читать только этот журнал, матрицу покрытия и материалы выбранного контура.

## Проверенная база

| Параметр | Значение |
|---|---|
| Репозиторий | `/Users/ilnur/Documents/backend` |
| Ветка | `dev` |
| Commit | `22fac945e8116d04972ccc87b06b2303acf7a561` |
| Дата последней проверки | 2026-09-22 |
| Рабочее дерево | Бизнес-код без локальных изменений; `docs/docsforanalytics` и перечисленные дополнительные материалы находятся в untracked-файлах пользователя |
| Работающее приложение / БД | Не запускались и не проверялись |
| Внешние системы | Datareon, 1С, ЭТРАН и Figma не проверялись |

Commit — версия текущего checkout, а не подтверждение развернутой среды.

## Входные материалы

Все указанные источники доступны на момент проверки:

- `/Users/ilnur/Documents/backend/docs/integrations`;
- `/Users/ilnur/Documents/backend/docs/alis-container-stuffing-unstuffing-as-is.md`;
- `/Users/ilnur/Documents/backend/docs/alis-empty-railway-shipping-order-event-analysis.md`;
- `/Users/ilnur/Documents/backend/docs/alis-waybill-railway-as-is.md`;
- `/Users/ilnur/Downloads/AnalitikDoc_Product_Vision_v1.md`;
- `/Users/ilnur/Downloads/докум.docx` — snapshot интерфейса ALIS от 22.09.2026, версия приложения/стенд/роль пользователя не указаны;
- `/Users/ilnur/Documents/Codex/2026-09-09/new-chat/outputs/AnalitikDoc_Documentation_Review_2026-09-09.md`.

Product Vision используется только как направление развития документации. Старые исследования и предыдущее ревью не считаются источниками истины без сверки с текущим кодом.

## Состояние этапов

| Этап | Состояние | Результат |
|---|---|---|
| 0. Актуальная карта состояния | Завершён | Создана [матрица покрытия](coverage-matrix.md), проверены входные материалы, Git, структура, генераторы и замечания предыдущего ревью |
| 1. Достоверность генерации | Завершён | `1.1a–1.4`: DTO, JPA, область API и полнота декларативных HTTP-контрактов исправлены и защищены проверками |
| 2. Навигация и существующие исследования | Завершён | `2.1–2.2`: три верхнеуровневых исследования и шесть интеграционных материалов подключены с версиями, AS-IS/TO-BE и внешними пробелами |
| 3. Бизнес-процессы | В работе | `3.1–3.29`: inbound actions, заявки, Waybill, справочники/остатки, рейсы, отчёты, роли/группы, настройки, профиль/сводка прав, сводный реестр eventCode → action и повторный аудит шести базовых документов |
| 4. Физическая модель и связи полей | В работе | `4.1–4.31`: source-level трассировка ReceivingOrder↔Waybill-контура и единая ER/integrity-карта всех 13 таблиц shipping-контура, связанная с business/database overview; applied schema не проверена |
| 5. Интеграционные сценарии | В работе | `5.1–5.2`: lifecycle вывоза и сквозной контур ЖД-накладной 1С ЭТРАН → Datareon → ALIS с внешним контрактом и межслойными расхождениями |
| 6. Трассировка и проверка ТЗ | В работе | `6.1–6.4`: два заполненных кейса, GPT-карточка и traceability-index с минимальными пакетами контекста и границами source/runtime |
| 7. Поддержка актуальности и итоговое ревью | В работе | `7.1`: добавлена локальная read-only проверка структуры Markdown; подключение к CI не выполнялось |
| 8. Глобальный бизнес-слой | В работе | `8.1–8.5`: созданы основы бизнес-слоя, словарь, карта систем, матрица источников истины и предварительная ролевая/RACI-модель |
| 9. Пользовательский интерфейс | В работе | `9.1`: создан UI-index, карта видимой навигации и первый паспорт экрана «Группы пользователей» с candidate API-трассировкой |

Текущий подэтап отсутствует: `9.1` завершён, продолжение ожидает отдельного разрешения пользователя.

## Изменённые файлы

### Этап 0

- [`_meta/PROGRESS.md`](PROGRESS.md) — этот журнал.
- [`_meta/coverage-matrix.md`](coverage-matrix.md) — карта покрытия по предметным областям и видам документации.

Существующие каталоги, генераторы и бизнес-документы на этапе 0 не изменялись.

### Подэтап 1.1a

- [`scripts/generate_dto_docs.py`](../scripts/generate_dto_docs.py) — исправлен разбор `extends` после generic-параметров, добавлено разрешение родителя по FQCN/package/import, защита от циклов и выбор наиболее конкретного повторно объявленного поля.
- [`scripts/test_generate_dto_docs.py`](../scripts/test_generate_dto_docs.py) — четыре регрессионные проверки наследования.
- Перегенерированы [`dto/catalog/README.md`](../dto/catalog/README.md) и 9 паспортов: [HierarchyDto](../dto/catalog/base/HierarchyDto.md), [ClientGoodHierarchyDto](../dto/catalog/clientgood/ClientGoodHierarchyDto.md), [ClientRelatedEntityDto](../dto/catalog/clientrelatedentity/ClientRelatedEntityDto.md), [OutboundDataDto](../dto/catalog/outbounddata/OutboundDataDto.md), [ReceivingOrderRequestedServiceUpdateDto](../dto/catalog/receivingorderrequestedservice/ReceivingOrderRequestedServiceUpdateDto.md), [OrderRouteDetailDto](../dto/catalog/route/OrderRouteDetailDto.md), [ShippingOrderRequestedServiceUpdateDto](../dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceUpdateDto.md), [BatchModificationDto](../dto/catalog/wms/BatchModificationDto.md), [DictionaryLineParameterUpdateDto](../dto/catalog/wms/dictionary/DictionaryLineParameterUpdateDto.md).
- [`_meta/coverage-matrix.md`](coverage-matrix.md) — статус дефекта `HierarchyDto` изменён на исправленный.

### Подэтап 1.1b

- [`scripts/generate_dto_docs.py`](../scripts/generate_dto_docs.py) — добавлены разбор member nested types, FQCN как идентификатор, контекстное разрешение ссылок, подстановка generic-параметров и отдельные пути страниц для одноимённых классов.
- [`scripts/test_generate_dto_docs.py`](../scripts/test_generate_dto_docs.py) — набор расширен до семи регрессионных проверок.
- Полностью перегенерирован [`dto/catalog`](../dto/catalog/README.md): 416 существующих файлов получили FQCN/размещение/точную строку Java-источника и обновлённое правило nested-ссылок; добавлено 46 страниц — 44 nested-типа и два ранее исключённых `BaseActivatedUpdateDto`.
- Контрольные результаты: [RailwayCarriageRemainSyncDto.Leftover](../dto/catalog/railwaycarriageremain/RailwayCarriageRemainSyncDto.Leftover.md), [ClientGoodHierarchyDto.ClientGoodDto](../dto/catalog/clientgood/ClientGoodHierarchyDto.ClientGoodDto.md), [ALIS BaseActivatedUpdateDto](../dto/catalog/base/BaseActivatedUpdateDto.md), [WMS BaseActivatedUpdateDto](../dto/catalog/wms/BaseActivatedUpdateDto.md).
- Обновлены [`dto/README.md`](../dto/README.md) и [`_meta/coverage-matrix.md`](coverage-matrix.md).

### Подэтап 1.1c

- [`scripts/generate_dto_docs.py`](../scripts/generate_dto_docs.py) — удалён смешанный вывод «Обязательно»; добавлены независимые колонки `Java null`, `JSON required`, `Jackson null-policy` и `Bean Validation`.
- [`scripts/test_generate_dto_docs.py`](../scripts/test_generate_dto_docs.py) — набор расширен до десяти проверок: `@NotBlank` не становится JSON required, `@JsonProperty(required = true)` распознаётся отдельно, primitive/`@Nullable`/`Optional`/`JsonSetter` не смешиваются.
- Полностью перегенерирован [`dto/catalog`](../dto/catalog/README.md): структура 461 паспорта не изменилась; обновлены таблицы полей и ограничения интерпретации.
- Обновлены [`dto/README.md`](../dto/README.md) и [`_meta/coverage-matrix.md`](coverage-matrix.md).

### Подэтап 1.2

- [`scripts/generate_entity_docs.py`](../scripts/generate_entity_docs.py) — добавлена явная классификация basic/owning/inverse/embedded/element collection/transient/`@Formula`; Java null, JPA nullable/optional и Bean Validation разделены.
- [`scripts/test_generate_entity_docs.py`](../scripts/test_generate_entity_docs.py) — добавлено шесть регрессионных проверок для `mappedBy`, owning FK, явных и отсутствующих имён, `@Column`, `@JoinColumn`, join/collection table, `@Transient`, `@Formula`, `@Embedded` и inherited `@AttributeOverride`.
- Полностью перегенерирован [`entities/catalog`](../entities/catalog/README.md): 114 entity-паспортов, 11 mapped-superclass-паспортов и индекс.
- [`entities/README.md`](../entities/README.md) — добавлены правила чтения категорий хранения и границы достоверности физических имён.
- Обновлена [`_meta/coverage-matrix.md`](coverage-matrix.md).

### Подэтап 1.3

- [`api/generate_endpoint_catalog.py`](../api/generate_endpoint_catalog.py) — области контроллеров извлекаются из `ComponentConfiguration.@ComponentScan`; добавлены ALIS/WMS provenance, FQCN, основание включения, class-level profile/condition и явный статус runtime-проверки.
- [`api/test_generate_endpoint_catalog.py`](../api/test_generate_endpoint_catalog.py) — добавлено шесть проверок конфигурационных областей, четырёх WMS-контроллеров, пустого `wms.controller.user`, FQCN, происхождения и class-level conditions.
- Перегенерирован [`api/endpoints-generated.md`](../api/endpoints-generated.md): каталог расширен со 119 контроллеров/654 mappings до 123 контроллеров/671 mappings.
- [`scripts/generate_dto_docs.py`](../scripts/generate_dto_docs.py) переведён на тот же перечень controller sources; в DTO-паспортах теперь указано происхождение контроллера. Полностью перегенерирован [`dto/catalog`](../dto/catalog/README.md).
- [`api/README.md`](../api/README.md) — описаны границы source/configuration/runtime и точный состав WMS-области.
- Обновлена [`_meta/coverage-matrix.md`](coverage-matrix.md).

### Подэтап 1.4

- [`api/generate_endpoint_catalog.py`](../api/generate_endpoint_catalog.py) — добавлены отдельные контракты path/query/header/cookie/body/request-part/model-form и нераспознанных параметров, Spring required/default, parameter-level validation, method/class/custom-annotation consumes/produces, Java response/status и декларации OpenAPI `@ApiResponse`.
- Тот же генератор теперь не принимает строки `consumes` за путь, ссылается на доступные DTO/Java-типы, раскрывает константы enum из endpoint-сигнатуры и явно показывает отсутствие OpenAPI content/schema.
- [`api/test_generate_endpoint_catalog.py`](../api/test_generate_endpoint_catalog.py) расширен с 6 до 14 проверок: синтетические варианты параметров, media type, status, errors и enum, а также реальные `DatareonController.handleEvent` и multipart `TemplateController.uploadShippingOrder`.
- Перегенерирован [`api/endpoints-generated.md`](../api/endpoints-generated.md): 123 контроллера/671 mapping сохранены; добавлены 829 параметров, 1 291 OpenAPI response declaration и 18 enum-типов из сигнатур.
- [`api/README.md`](../api/README.md) — описано, что именно входит в декларативный HTTP-контракт и почему required тела не равен обязательности JSON-полей.
- Обновлена [`_meta/coverage-matrix.md`](coverage-matrix.md): замечание о неполном generated endpoint переведено в исправленные, runtime/advice/business gaps сохранены.

### Подэтап 2.1

- Создан [`research/README.md`](../research/README.md) — единая точка входа в три верхнеуровневых исследования: затарка/растарка КТК, завершение порожнего ЖД-вывоза и ЖД-модель Waybill.
- Для каждого материала указаны предметная область, исходная дата/commit, статус относительно `22fac945…`, граница AS-IS/TO-BE, выборочно подтверждённые выводы и конкретные открытые вопросы.
- Добавлены Mermaid-карта выбора исследования, ссылки на актуальные API/DTO/JPA/бизнес-документы, правила загрузки в GPT и словарь неоднозначных терминов `Container`/`Cargo`, ownership/remain/movement, Waybill/WRC/WC/ROC и overlay.
- [`README.md`](../README.md) дополнен ссылкой на реестр и каталогом `research`; [`_meta/coverage-matrix.md`](coverage-matrix.md) теперь ведёт к реестру из трёх соответствующих предметных областей и сохраняет незакрытый пробел по `docs/integrations`.
- Исходные три исследования не переписывались и не выдавались за полностью актуализированные.

### Подэтап 2.2

- [`research/README.md`](../research/README.md) расширен навигацией по всем шести Markdown-материалам `docs/integrations`: два документа 1С:ДО, два справочных потока ЭТРАН, lifecycle КТК и дефект загрузки Waybill.
- Для каждого файла зафиксированы классификация AS-IS/TO-BE/Draft/смешанный документ, наличие версии, подтверждаемая backend-часть, внешние зависимости и то, что нельзя считать реализованным.
- Добавлены ссылки на четыре PlantUML-исходника и актуальные API/DTO/JPA-паспорта; материалы не копировались и исходные файлы `docs/integrations` не изменялись.
- Выявлена содержательная устарелость [`waybill-reference-lookup-bug.md`](../../integrations/waybill-reference-lookup-bug.md): описанная классификация по `sort`/длине была изменена commit `4e55d447eb554311d5d5e8dab8877011befccbfe`; временное решение из документа при этом также не реализовано.
- [`_meta/coverage-matrix.md`](coverage-matrix.md) обновлена для Waybill/ЭТРАН, КТК, вагонов и договоров 1С:ДО; пробел «исследования отсутствуют в навигации» закрыт, предметные и внешние пробелы сохранены.

### Подэтап 3.1

- Создан [`business-rules/shipping-railway-empty-completion.md`](../business-rules/shipping-railway-empty-completion.md) — сквозной AS-IS `POST /datareon/event` → config-driven `CARRIAGE_ARRIVED` → `ShippingOrderRailwayCarriage.status=FINISHED` с HTTP/DTO-контрактом, Mermaid flow, предусловиями, транзакциями, негативными ветками и границей доверия.
- Подтверждён `BR-SO-RAIL-003`: shipping-ветка не проверяет отсутствие КТК/завершение всех вагонов и не переводит `ShippingOrder` в `DONE`; integration test проверяет вагон и журнал, но не статус заявки.
- Уточнена идемпотентность: миграция создания `INBOUND_EVENT` добавила unique index на `message_id`, следующая миграция после rename в `task_id` удалила индекс; последующего восстановления и JPA uniqueness не найдено. Поэтому дедупликация по `_id` не гарантирована исходниками.
- По Git зафиксированы повлиявшие commits: `b2dd03a4…` добавил закрытие без контейнеров только receiving-ветке, `6398c0af…` позднее лишь переформатировал текущие строки, `5de66acd…` удалил unique index при rename поля события.
- Подтверждено, что `/datareon/**` имеет `permitAll`, а `_order` и `_id` разрешаются независимо без проверки принадлежности вагонной задачи заявке.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`shipping-orders.md`](../business-rules/shipping-orders.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`order-statuses.md`](../business-rules/order-statuses.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.2

- Создан [`business-rules/shipping-inbound-actions.md`](../business-rules/shipping-inbound-actions.md) — сравнительный AS-IS `TOS_SHIPMENT_RESULT`, `WMS_SHIPMENT_RESULT`, `VH_DEPARTURE` и `STATUS_COMPLETED` с DTO, данными, условиями `DONE`, повторами, конкурентностью и Mermaid flow.
- Для TOS зафиксированы пять разных веток `fillingType`, создание/завершение КТК и вагонов, строки ЕТСНГ, услуги, `ContainerMovement`, удаление владельцев и различающиеся критерии завершения заявки.
- Подтверждены исключения: `WMS_SHIPMENT_RESULT` игнорирует config-фильтры типа/площадки/транспорта; `VH_DEPARTURE` проверяет `WAREHOUSE` в config вместо площадки заявки; `STATUS_COMPLETED` обходит status transition map и допускает `DRAFT/ON_REVIEW → DONE` без проверки задач.
- Описаны конфликты нескольких actions: `STATUS_COMPLETED` выполняется последним; после уже успешного TOS-перехода в `DONE` он вызывает rollback всей цепочки, а после незавершившего заявку action способен поставить `DONE` без проверки полноты.
- Найден DTO/converter gap WMS: nullable `itemsResult[].batch` разыменовывается без null-check до создания журнала события.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`shipping-orders.md`](../business-rules/shipping-orders.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`order-statuses.md`](../business-rules/order-statuses.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.3

- Создан [`business-rules/receiving-inbound-actions.md`](../business-rules/receiving-inbound-actions.md) — сравнительный AS-IS `TOS_RECEIVING_RESULT`, `WMS_RECEIVING_RESULT`, `CARRIAGE_ARRIVED`, `STATUS_IN_WORK` и `STATUS_COMPLETED` с DTO, двумя моделями контейнерных задач, товарами/услугами, временем, владельцами, повторами и Mermaid-схемами.
- Подтверждено расхождение receiving `CARRIAGE_ARRIVED`: после завершения вагона отсутствие контейнеров проверяется только в старой `receiving_order_container`, хотя контейнеры ЖД-поставки находятся в `waybill_container`; возможен `DONE` при незавершённых WaybillContainer.
- Зафиксировано, что TOS объединяет WaybillContainer и ReceivingOrderContainer для собственного условия `DONE` и только в этой ветке передаёт владельцев КТК клиенту; `STATUS_COMPLETED` и вагонный `DONE` этого не делают.
- Указаны конфликты priority `0/1`: поздний status-action способен либо преждевременно завершить заявку, либо откатить успешный ранний action после уже установленного `DONE`; между двумя status-actions одинакового priority порядок не определён.
- Отмечены пробелы тестов: TOS complete-test отключён после удаления старой модели, WMS receiving integration block закомментирован, а CARRIAGE tests не проверяют `DONE` при незавершённых WaybillContainer.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`receiving-orders.md`](../business-rules/receiving-orders.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`order-statuses.md`](../business-rules/order-statuses.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.4

- Создан [`business-rules/service-order-lifecycle.md`](../business-rules/service-order-lifecycle.md) — полный AS-IS 12 endpoints сервисной заявки: DTO, permissions, выбор КТК, `accept`, владельцы/история, `DONE`, `completionAt`, outbound, HTTP errors, транзакции и конкурентность.
- Подтверждено, что `accept` блокирует заявку и атомарно сохраняет смену владельцев, историю, итоговый статус/время и строку `SERVICE_ORDER_CHAIN_PACKAGE`; фактический HTTP export выполняется позже отдельной `REQUIRES_NEW` транзакцией.
- Описан payload ServiceOrder/ServiceOrderContainer/Container/Client, endpoint Datareon `/serviceOrder`, `SKIP LOCKED`, максимум пять попыток и риск повторной внешней обработки при неоднозначном ответе без отдельного idempotency key.
- Уточнена полная синхронизация состава: пустой список очищает выбор, `id` сохраняет связь, `containerOwnerId` добавляет КТК, недоступный владелец откатывает весь вызов; владелец проверяется при выборе, но не повторно при `accept`.
- Зафиксированы неодинаковые HTTP-ошибки бизнес-состояния: изменение после `DONE` — `403`, accept не из `DRAFT` и path/body mismatch — общий `500`; OpenAPI accept последний случай не перечисляет.
- Выделен concurrency gap: разные черновики блокируют разные заявки, а схема не запрещает одному КТК одновременно оказаться в двух `DRAFT`; `update/remove` также не используют lock/version.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`service-orders.md`](../business-rules/service-orders.md), [`api/order-api.md`](../api/order-api.md), ручной [`ServiceOrderUpdateDto`](../dto/service-order/ServiceOrderUpdateDto.md), [`order-integrations.md`](../business-rules/order-integrations.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.5

- Создан [`business-rules/waybill-etran-as-is.md`](../business-rules/waybill-etran-as-is.md) — актуальный AS-IS `POST /datareon/waybill`, агрегата Waybill/WRC/WC/Product/ZPU/marks, справочных мутаций, read API, связи с ReceivingOrder, ошибок, повторов и конкурентности.
- Связаны корневой и шесть nested `WaybillIntegrationDto`, все 11 корневых `/waybill` endpoints, дочерние read controllers, пять scoped receiving-order endpoints и семь legacy `/receivingorderetraninvoice` операций.
- Разделена декларативная и фактическая обязательность: корневой `waybill` имеет `@NotNull`, но без `@Valid` вложенные ограничения не каскадируют; null списки/даты и некорректные числа часто дают `500`.
- Подтверждено частичное повторное поведение: существующий `waybill_identifier` меняет только status, хотя danger products разрешаются до этой ветки; `Version`/`MessageId` не используются и не обеспечивают дедупликацию.
- Зафиксированы create/update справочников RailwayCarriage/Container, find-or-create stations/payer/ETSNG, текущие готовые `type_id`/`container_type`/`ISO` после `4e55d447…` и filter/meta изменения `42eee4ee…`.
- Описан async `AFTER_COMMIT` refresh `grouped_waybill`, отсутствие lock/upsert для первого импорта, last-write-wins статуса и отсутствие status/access checks в bulk link накладных к поставке.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`receiving-orders.md`](../business-rules/receiving-orders.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`api/order-api.md`](../api/order-api.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.6

- Создан [`business-rules/etran-reference-imports-as-is.md`](../business-rules/etran-reference-imports-as-is.md) — единый backend AS-IS `POST /datareon/etran_railway` и `/etran_container`: DTO, обязательность, batch/upsert, справочники type/model/ISO, полная перезапись, транзакция, ошибки и конкурентность.
- Внешние правила из `docs/integrations` отделены от доказуемого backend: mapping `sort → type`, расчёт пробега, замена container code, умножение capacity и вычисление ISO не выданы за Java-логику или deployed truth.
- Подтверждено, что `MessageID` обязателен, но не сохраняется/не дедуплицируется/не журналируется; точный дубль code внутри пакета схлопывается по правилу last-wins.
- Для вагонов описаны поэлементные exact-lookups type/model/carriage, `active=true`, полный update, create-only проверка контрольной цифры и case-sensitive lookup при case-insensitive прикладной uniqueness.
- Для КТК описаны пакетные lookup ISO/Container, точное преобразование `ContainerType`, `active=true`, `refrigerator=false`, очистка `standardSize`/optional-полей и gap `null`-элемента списка.
- Связаны физические unique/seed constraints и влияющие commits `0fed0cd2…`, `1e46c564…`, `b133cd12…`, `cd8ab542…`; direct integration tests обоих импортов не найдены.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`waybill-etran-as-is.md`](../business-rules/waybill-etran-as-is.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.7

- Создан [`business-rules/remain-inbound-as-is.md`](../business-rules/remain-inbound-as-is.md) — актуальный backend AS-IS двух Datareon endpoints остатков, ручных full-sync endpoints, журналов, хранения и read views КТК/вагонов.
- DTO связаны с фактическим использованием полей; зафиксировано отсутствие Bean Validation для `MessageID`, списков и строк, поэтому `@Valid` не задаёт обязательность payload.
- Для КТК описаны unique key `(client, container, ETSNG)`, полный update, создание неизвестной zone, partial success, ошибка в поле error detail и parallel transaction/race ограничения.
- Для вагонов описаны grouping `(client, main_Plate)`, выбор максимального `number`, case-insensitive lookup физического вагона, отсутствие найденного DB unique для пары и self-call transaction gap.
- Ручные синхронизации отделены от incremental upsert: обе удаляют снимок до внешнего GET, выполняются async и могут оставить пустые/частичные данные; status отражает ACTIVE log, а не future.
- `container_remain`/history/read view явно отделены от `container_movement` и movement-derived `/containerremains/*`; рассмотрены отсутствие client restriction на текущем view path и границы runtime security.
- Связаны физические constraints/history и влияющие commits `61b0fa01…`, `a6bf0bb8…`, `3981f5c9…`, `60f81457…`, `f0808209…`, `1f6193ba…`, `fa8dc53e…`, `6f2abb52…`; прямых inbound/full-sync tests не найдено.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`etran-reference-imports-as-is.md`](../business-rules/etran-reference-imports-as-is.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.8

- Создан [`business-rules/good-remain-inbound-as-is.md`](../business-rules/good-remain-inbound-as-is.md) — актуальный backend AS-IS `POST /datareon/remain`, async full sync, status/force-complete, view/view-all и Excel-report остатков номенклатуры.
- Входной DTO связан с фактической серверной семантикой: `packageId`, `client`, `number`, `timestamp` игнорируются; ClientGood/Batch ищутся по syncId, client/package выводятся сервером, TerminalArea фиксирован, Cargo создаётся при отсутствии.
- Описаны ключ `(ClientGood, derived GoodPackage, Batch, goodStatus, Cargo)`, полный update без timestamp ordering, intended partial `200`, parallel transaction/race gaps, cross-thread error-detail FK риск и отсутствие вызовов processed-reset/zero методов.
- Full sync отделён от incremental: delete коммитится до внешнего GET, дубли map меняют только quantity, статистика считает входные строки, а Cargo side effects могут пережить ошибку финального save.
- Зафиксированы DB nullable/unique расхождения и package-null duplicate gap, `actual_quantity NUMERIC(16,3)`, обязательная fixed TerminalArea и существующая без Java-flow таблица barcodes.
- Read view описана с `quantity>0/active`, действующим ClientRestrictionFilter и аномалией `good_status`/`zone`: оба поля проецируются из `zone_status_catalog.status`.
- Связаны влияющие commits `36992927…`, `ab648083…`, `bd066904…`, `819c0f2a…`, `5a162c8c…`, `95551876…`, `2005834e…`; прямых tests контура не найдено.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`remain-inbound-as-is.md`](../business-rules/remain-inbound-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.9

- Создан [`business-rules/batch-datareon-as-is.md`](../business-rules/batch-datareon-as-is.md) — актуальный backend AS-IS `POST /datareon/batch` от Java DTO до per-item transaction, Batch и physical constraints, со связью на GoodRemain.
- Зафиксировано отсутствие Bean Validation: null/empty batch даёт тихий `200`; обязательность item/dates/syncId/type возникает только в lookup/parser/DAO/DB; unknown type custom deserializer превращает в `null`.
- Подтверждён lookup по `ClientGood.syncId`, затем `(ClientGood.id, case-insensitive code)`, а не по Batch.syncId; ненулевой новый syncId заменяет существующий integration ID.
- Поля type/code/dates/barcode полностью обновляются, `active` игнорируется; create получает active default true, update сохраняет старый active. Add accounting validation не применяется к update.
- Каждый элемент коммитится в отдельной `REQUIRES_NEW` transaction; ошибки скрываются за package HTTP `200` и остаются только в application log, а null element ломает сам catch после частичных commits.
- Связаны `sync_id NOT NULL UNIQUE`, composite `(code, client_good_id)`, nullable/code length/date constraints, case-sensitivity/concurrency gaps и зависимость GoodRemain от актуального Batch.syncId.
- Учтены commits `bd066904…`, `0d23560a…`, `82ff0e09…`, `962cffd8…`, `fe5e73c1…`/merge `528d650c…`, `62519396…` и единственный integration test partial processing.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`good-remain-inbound-as-is.md`](../business-rules/good-remain-inbound-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.10

- Создан [`business-rules/cell-occupancy-datareon-as-is.md`](../business-rules/cell-occupancy-datareon-as-is.md) — backend AS-IS ручного trigger, `POST /datareon/cell-occupancy`, состояния и physical/analytics `CellOccupancy`.
- Root/module/tier/VGH DTO связаны с каждой physical колонкой; подтверждено отсутствие Bean Validation, проверки количественного баланса, диапазонов и документированных единиц weight/height.
- `GET /cell-occupancy/update` прослежен до синхронного POST `${datareon.base.url}/reportbi` с `eventCode=getReportsCellOccupancy`: при успехе старый снимок удаляется до отдельного inbound callback, общей транзакции/correlation нет.
- Inbound метод фактически insert-only: lookup/update/business key отсутствуют, удалённый unique `(name,tier)` разрешает несколько VGH и точные дубли, а `MessageID` используется только для best-effort мониторинга.
- Описаны прямой callback без очистки, повтор, два trigger/callback, partial insert и пустой пакет; отсутствие общей `@Transactional` означает сохранение ранних `repository.save` при поздней ошибке.
- `state.loading` зафиксирован как `count()==0`, а `last_update` — createdAt строки с минимальным id; это не надёжный lifecycle status и не обязательно дата последнего callback.
- Связаны Liquibase chain, analytics view и commits `48218b0d…`, `00014368…`, `5cbaa7e4…`, `0a6c9a11…`, `d3e370db…`, `5b45baf1…`, `84204c4b…`; direct tests не найдены.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.11

- Создан [`business-rules/contractor-edo-datareon-as-is.md`](../business-rules/contractor-edo-datareon-as-is.md) — backend AS-IS `POST /datareon/contractor` от внешнего DTO до актуальной Client model/table, включая repeat/update, outbound side effect и пользовательский CRUD.
- Зафиксирована терминология после объединения: внешний Contractor сохраняется как Client; старая client table удалена, бывшая legal_entity переименована в physical client.
- Внешние `@NotNull` отделены от внутренних Client `@NotBlank`/regex: внутренние creation/update DTO создаются сервисом и не проходят Bean Validation, поэтому blank и нецифровые реквизиты могут дойти до БД.
- Подтверждён lookup по case-insensitive `edoId`, отсутствие physical unique/lock и empty-filter gap для blank `_id`; параллельный create способен породить дубли при разных INN/KPP.
- Выявлен актуальный update defect после `ef2ea5af…`: mapping не задаёт code/edoId/legal/signatory/email/phone, ClientService копирует null, а physical `code NOT NULL` откатывает обычный повтор существующего `_id` с HTTP `500`.
- Create выполняется вместе с OutboundData в одной ClientService transaction; active config ставит Client в очередь `CONTRACTOR`, где outbound `_id=Client.syncId`, а не входной `edoId`, и payload Client не содержит реквизиты.
- Связаны physical lengths/nullability, partial unique `(inn,kpp)`, JPA/Liquibase code-unique mismatch, errors и commits `b67b2971…`, `5de66acd…`, `4212247d…`, `a90b9076…`, `ef2ea5af…`, `22433aa6…`, `d3e370db…`/`5b45baf1…`, `84204c4b…`; direct contractor tests не найдены.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`api/client-contract-api.md`](../api/client-contract-api.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.12

- Создан [`business-rules/contract-edo-datareon-as-is.md`](../business-rules/contract-edo-datareon-as-is.md) — backend AS-IS `POST /datareon/contract` от `ContractEdoDatareonDto` через разрешение Client/Company/Currency до physical Contract.
- Все девять внешних полей имеют только `@NotNull`: blank значения допустимы, а внутренний `ContractCreationDto` строится программно без Bean Validation; обязательный для обычного CRUD `name` остаётся `null` и допускается physical схемой.
- Зафиксированы форматы дат: `date` разбирается как ISO instant с offset, `dateFrom/dateTo` — как ISO local date с переводом в UTC; проверяется только `validTo >= validFrom`, ошибки формата дают текущий HTTP `500`.
- Подтверждён create-only flow: lookup/update Contract по `_id`/`edoId`/code отсутствует, physical unique по этим полям не найден, поэтому последовательные и параллельные повторы способны создавать новые строки с новым `id/syncId`.
- Client/Company ищутся по case-insensitive `edoId`, Currency — по точному code; blank external reference снимает predicate и может выбрать произвольную строку, unknown Currency приводит к NPE, unknown Client/Company — к неперехваченной предметной ошибке, все три сценария дают HTTP `500`.
- Create transaction начинается только в `ContractService.add`: lookup и parsing происходят до неё, затем связи повторно загружаются по UUID; отдельного outbound-сообщения для Contract нет.
- Связаны physical constraints/nullability, пользовательские Contract endpoints, Contractor prerequisite, TO-BE `/contract-with-client`, ошибки, tests и commits `b67b2971…`, `5de66acd…`, `6dd2b106…`, `ca20a974…`, `bcc7b086…`, `4212247d…`/`a90b9076…`, `ef2ea5af…`, `7400c51c…`, `d3e370db…`/`5b45baf1…`/`84204c4b…`.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`contractor-edo-datareon-as-is.md`](../business-rules/contractor-edo-datareon-as-is.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`api/client-contract-api.md`](../api/client-contract-api.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.13

- Создан [`business-rules/company-currency-contract-prerequisites-as-is.md`](../business-rules/company-currency-contract-prerequisites-as-is.md) — read API, DTO, filters, permissions, services, physical Company/Currency и их роль в `POST /datareon/contract`.
- Подтверждены только три read endpoint на каждый справочник: `/all`, `/{id}`, `/meta/{fieldName}`; create/update/delete/synchronize/Datareon import отсутствуют, а вызовов Company/Currency DAO add/update из business source не найдено.
- Liquibase создаёт таблицы и permission paths, но не справочные строки. Поэтому источник `Company.edoId` и `Currency.code`, owner/transport/schedule загрузки и production source of truth остаются внешним пробелом.
- `/all` не имеет method-level permission, но требует authentication; detail/meta требуют `COMPANY/READ` или `CURRENCY/READ`. Декларативно optional body `/all` фактически разыменовывается вместе с pageInfo и способен дать HTTP `500`.
- Зафиксированы разные lookup semantics договора: Company — case-insensitive `findFirst` без active/sort, Currency — exact `findByCode` без active/trim/lowercase; blank Company может выбрать произвольную строку, unknown и duplicate cases приводят к текущим `500`.
- Physical Company имеет nullable `edo_id VARCHAR(46)` и `sync_id NOT NULL`; Currency — обязательный `code_okv_num VARCHAR(4)` без sync/edo ID. Unique/index business identifiers в Liquibase chain не найдены, а JPA `code unique=true` расходится с DDL.
- Связаны commits `11de1385…`, `0e530be7…`, `b67b2971…`/`5de66acd…`, `3b299749…`, generic DAO/meta/mapping tests и две Mermaid-схемы prerequisites/duplicates.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`contract-edo-datareon-as-is.md`](../business-rules/contract-edo-datareon-as-is.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`api/client-contract-api.md`](../api/client-contract-api.md), [`research/README.md`](../research/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.14

- Создан [`business-rules/route-lifecycle-as-is.md`](../business-rules/route-lifecycle-as-is.md) — основной backend AS-IS рейса: read/create/update/delete/copy, assign/unassign, review/accept/reject, автоматическая синхронизация статуса, outbound и cargo-chain.
- Все 17 lifecycle/read endpoints связаны с request/response DTO и permissions; shipping plan/fact/meta endpoints явно оставлены следующему самостоятельному подэтапу.
- Декларативная обязательность `RouteCreationDto`, `RouteUpdateDto` и `AssignOrderDto` отделена от условных validators и physical constraints. Зафиксированы отсутствие nested `@Valid`, nullable `data_time`, условные vehicle references и отсутствие optimistic version.
- Подтверждено, что update использует только `body.id` и игнорирует path ID; пропуск существующей vehicle-ссылки способен дать NPE, а partial copy создаёт пустой `DRAFT` без `dataTime`, обходя controller validation.
- Для assign/unassign выявлены silent ignore неизвестного/wrong-type UUID, перенос заявки из другого рейса без синхронизации старого рейса и возможность снять заявку чужого рейса; `needTransport` при снятии не восстанавливается.
- Review/accept атомарно обрабатывают непустой рейс и его заявки, reject блокирует route; повторный accept не идемпотентен. Автоматический sync обходит transition map, допускает обратные переходы и может быть подавлен listener-ом.
- Route outbound прослежен для `ROUTE_TASK` и трёх chain-package вариантов; cargo-chain фактически наполняется только shipping hierarchy. Описаны row-level access и soft-deleted direct-ID gaps.
- Physical Route/FK/indexes, errors, transactions, concurrency и имеющиеся route/export/DAO tests связаны с правилами; добавлены пять Mermaid-схем и история влияющих commits.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`order-integrations.md`](../business-rules/order-integrations.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.15

- Создан [`business-rules/route-shipping-plan-fact-as-is.md`](../business-rules/route-shipping-plan-fact-as-is.md) — восемь оставшихся `RouteController` endpoints для плановых вагонов/КТК, ЖД-/АВТО-факта и четырёх meta-групп.
- Каждый endpoint связан с request/filter, response/nested DTO, `ROUTE/READ`, service/DAO и фактическим источником данных; optional `BaseIdFilter` явно относится к UUID дочерней строки, не route/order.
- Описана полная матрица пяти `ShippingOrderFillingType`: именованные task-строки против qty-моделей, включая особенность `NONE_CONTAINER`.
- ЖД-факт определён как КТК, связанные с именованной вагонной задачей без требования `FINISHED`; АВТО-факт — только неудалённые контейнерные задачи `FINISHED`, сгруппированные по заявке.
- Четыре meta endpoint прослежены через `MetaFieldQueryService` до immutable JPA entities и rerunnable SQL views; перечислены field/filter contracts, group/array_agg/sort/paging/null semantics.
- Зафиксирован принципиальный разрыв data/meta: data использует filling-type switch и default deleted filters, views объединяют обе модели и имеют иной набор join/status/deleted условий. Безномерный КТК, вагон без model, qty без type и несколько items дают разные результаты.
- Уточнена deleted-семантика: data косвенно скрывает deleted Route через вложенный `RouteFilter`, а meta view не соединяется с Route и может продолжить возвращать значения по route_id.
- Описаны отсутствие route type/existence/client checks, пустой `200` для unknown/receiving route, несколько независимых read transactions, mixed-snapshot риск, physical constraints и отсутствие прямых endpoint/view tests.
- Добавлены три Mermaid lineage/flow-схемы, таблица истории commits и правила проверки нового ТЗ.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`route-lifecycle-as-is.md`](../business-rules/route-lifecycle-as-is.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.16

- Создан [`business-rules/route-reports-as-is.md`](../business-rules/route-reports-as-is.md) — AS-IS пяти route mappings `ReportController`: PDF `ContainerTN`, его availability и три Excel-выгрузки.
- Каждый endpoint связан с media type, controller permission, `RouteReportType`/`PageReportType`, collector, parameter map, DTO/mapping и Jasper/JXLS template.
- Для ТН описана полная последовательность проверок: отдельная permission, `SHIPPING`, площадка `CONTAINER`, транспорт `VEHICLE`, ровно одна неудалённая `ShippingOrder` и повторные ограничения заявки. Статусы и наличие контейнера availability не проверяет.
- Зафиксирована асимметрия `ROUTE_REPORT`/`ROUTE_REPORT_TH`: доступность и direct download требуют разные комбинации разрешений; причина недоступности скрывается за пустым JSON-массивом.
- Прослежены данные `ContainerTN`, repeatable-read сбор и streaming render. OpenAPI `400` расходится с текущим catch-all `500` для `IllegalArgumentException`, а после начала ответа JSON error/status не гарантированы.
- Сопоставлены access/deleted semantics: общий реестр использует client enrichment и `deleted=false`; direct detail/TN загружают рейс по UUID без этих filter-гарантий; orders export ограничивает дочерние строки, но не direct-загрузку корня.
- Описаны отсутствие входного UI-фильтра/лимита у общего Excel, частично заполненный общий DTO, memory risk и отсутствие server-side `Content-Disposition`.
- Связаны route report integration tests и commits `2cb29574`, `14d6f159`, `c89a8281`, `6611ec27`, `b2392502`, `49b109ed`, `84a9e5eb`; добавлены три Mermaid-схемы и чек-лист ТЗ.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`route-lifecycle-as-is.md`](../business-rules/route-lifecycle-as-is.md), [`route-shipping-plan-fact-as-is.md`](../business-rules/route-shipping-plan-fact-as-is.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.17

- Создан [`business-rules/order-pdf-reports-as-is.md`](../business-rules/order-pdf-reports-as-is.md) — реестр `OrderReportType`, общий availability и пять PDF download endpoints MX-1/M-7/MX-3/ContainerTN/Packing List.
- Все семь связанных mappings сопоставлены с path/response, permissions, enum, result filename, Jasper templates, collector и фактическими DTO/entities parameter map.
- Зафиксирована матрица eligibility по направлению, узкому праву, `DONE`, `WAREHOUSE`/`CONTAINER`, `VEHICLE`, delivery type и M-7 discrepancy; декларативная доступность отделена от неявных template dependencies.
- Описана permission-асимметрия: availability требует одно из двух общих прав, но не сверяет его с направлением; collector фильтрует типы по узким правам; direct download не требует общего report permission.
- Подтвержден raw lookup типа заявки с приоритетом ShippingOrder и отсутствие `FilterEnrichService`/client scope в direct UUID flow.
- Для M-7 выявлен разрыв: отсутствие `REC_START`/`REC_FINISH` только логируется, но JRXML разыменовывает null; при нескольких событиях выбирается default first по ID, а не по eventDateTime.
- Для MX-1/MX-3/Packing List/ContainerTN перечислены источники данных и поля, которые не проверяет availability, но разыменовывает collector/template; отдельно отмечены null price, transport/consignee, contract/company и >1 container failures.
- Зафиксированы `REPEATABLE_READ` только у download, отсутствие общего snapshot у availability, streaming/error semantics, OpenAPI `400` против текущего `500`, отсутствие Content-Disposition и `produces` у Packing List/M-7 mapping.
- Связаны существующие integration tests и история commits; добавлены три Mermaid-схемы и чек-лист ТЗ.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`receiving-orders.md`](../business-rules/receiving-orders.md), [`shipping-orders.md`](../business-rules/shipping-orders.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.18

- Создан [`business-rules/order-excel-exports-as-is.md`](../business-rules/order-excel-exports-as-is.md) — четыре корневые XLSX-выгрузки заявок: V1 `/report/...` без body и V2 `/v2/report/...` с optional order filter.
- Исправлен ранее предложенный путь V2: фактический prefix — `/v2/report`, а не `/report/v2`; все endpoints связаны с request filter, permission, `PageReportType`, collector, report DTO, mapper и XLSX template.
- Описана permission-асимметрия: V1 требует `*_ORDER_REPORT:READ`, V2 — обычное `*_ORDER:READ`; runtime-роли не проверены.
- Зафиксирован source-level client-scope gap V2: отсутствующий body оставляет `filter=null` и пропускает `FilterEnrichService`, тогда как `{}` создаёт filter и включает client restriction для non-admin с user ID. V1 всегда использует non-null filter.
- Раскрыты поля `ReceivingOrderFilter`/`ShippingOrderFilter`, aliases, exact enum semantics `transportType`, date rules, rejected-route OR и поля date/time, которые доступны для custom sorting, но не формируют predicate.
- Прослежены `REPEATABLE_READ`, `Integer.MAX_VALUE`, data + count queries, полный entity/DTO list, parallel mapping, итоговая сортировка и JXLS streaming после завершения сбора; V2 receiving сортирует String-номер лексикографически, в отличие от numeric V1.
- Сопоставлены девять receiving и восемь shipping XLSX-полей с report DTO/mapping, включая условный статус документов, system timezone, unknown terminal failure и отсутствие `Content-Disposition`.
- Описаны ошибки deserialization/mapping/JXLS/streaming, отсутствие прямых root-export tests и история commits `7e50a680`, `576e8787`, `bd4ec3d3`, `905ef6e4`, `969e2059`, `14d6f159`, `d2c385b6`, `3256b8f0` и `84204c4b`.
- Добавлены три Mermaid-схемы и чек-лист ТЗ; обновлены навигация, receiving/shipping специализации, [`api/order-api.md`](../api/order-api.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.19

- Создан [`business-rules/receiving-order-child-excel-exports-as-is.md`](../business-rules/receiving-order-child-excel-exports-as-is.md) — восемь V1/V2 Excel endpoints для receiving blackbox, cargo, container и container-item.
- Каждый endpoint связан с path/body contract, permission, `PageReportType`, collector, child filter/predicate, обычным response DTO/mapper, JXLS parameter и XLSX template.
- Описана разница scope: V1 принудительно задаёт `receivingOrder.id + deleted=false`, неизвестный UUID возвращает пустой XLSX; V2 optional filter без body выгружает все строки, включая soft-deleted.
- Подтверждено отсутствие автоматического client RLS: четыре child filters не реализуют `ClientRestrictionFilter`, а вложенный `ReceivingOrderFilter` не обогащается разрешёнными client IDs. V1 также не проверяет доступ к корневой заявке по UUID.
- Раскрыты поля и aliases четырёх V2 filters, OR-условия, dual-format `sealNumbers`, Waybill carriage subquery, `wight*` contract и два predicate gap: Container `weight` игнорируется, `empty` отсутствует в `isNotEmpty`.
- Прослежены `REPEATABLE_READ`, `Integer.MAX_VALUE`, data/count queries, полный entity/DTO list, parallel mapping, default/request sorting и post-transaction JXLS streaming.
- XLSX разобраны до cell expressions. Blackbox/Cargo/Item заполняют только часть объявленных template areas/DTO; Container template содержит три отсутствующих root DTO getter, а Item ЕТСНГ — compound-assignment expression.
- Template mismatch связан с историей: `3ea221c0` удалил `dangerousCargo` из DTO без изменения старого Container report template; `29283833` добавил текущую ЕТСНГ expression. Прямые export tests не найдены.
- Добавлены три Mermaid-схемы и чек-лист ТЗ; обновлены навигация, receiving specialization, [`api/order-api.md`](../api/order-api.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.20

- Создан [`business-rules/receiving-order-child-excel-exports-part2-as-is.md`](../business-rules/receiving-order-child-excel-exports-part2-as-is.md) — оставшиеся восемь V1/V2 Excel endpoints поставки: goods, requested services, Waybill под legacy URI `etran-invoice` и Waybill railway carriages.
- Каждый endpoint связан с path/body contract, permission, `PageReportType`, collector, filter/predicate, DTO/mapper, parameter map и фактическим XLSX resource.
- Зафиксирована миграция KIS-3631: URI и permission сохранили термин ЭТРАН, но backend уже использует `WaybillFilter`, `WaybillDetailedDto` и новый collector.
- Описана разница scope: V1 принудительно задаёт `receivingOrderId`, но не проверяет root/client ownership; V2 принимает optional filter и способен выгружать глобальный набор. Ни один из четырёх root filters не получает автоматический client RLS.
- Раскрыты поля, aliases и special semantics четырёх filters, включая dual JSON contract `plannedQuantity`/`price`, Waybill search priority и legacy carriage body `receivingOrder`.
- XLSX разобраны до parameter names, areas и expressions. Обнаружены три несовместимых getter expression в Requested Service и отсутствие `reports/receiving_order_waybill.xlsx`; оставшийся legacy ЭТРАН-шаблон имеет другой parameter key и старую DTO-структуру.
- Прослежены `REPEATABLE_READ`, paged `Integer.MAX_VALUE` с count query для трёх collectors, непагинированный Waybill DAO, parallel mapping, сортировка и post-transaction JXLS streaming.
- Описаны `400`/`403`/`500`, null nested dependencies, частичный streaming response, отсутствие прямых export tests и история commits, включая `443ae69a` KIS-3631.
- Добавлены три Mermaid-схемы и чек-лист ТЗ; обновлены навигация, receiving specialization, [`api/order-api.md`](../api/order-api.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.21

- Создан [`business-rules/shipping-order-child-excel-exports-as-is.md`](../business-rules/shipping-order-child-excel-exports-as-is.md) — восемь V1/V2 Excel endpoints shipping blackbox, cargo, container и container-item.
- Методы сопоставлены с permissions, V2 filters/predicates, `PageReportType`, четырьмя collectors, response DTO/mappers и XLSX templates.
- Описаны V1 path UUID/deleted scope, V2 absent body/`{}`/`deleted=null`, отсутствие client RLS и проверки ownership корневой заявки, `Integer.MAX_VALUE` и потоковая генерация.
- В ZIP/XML шаблонов выявлены несовместимые getters `getDangerousCargo`/`getRefrigerator` Container report DTO, нетипичное `sheetStreaming="D2"` Blackbox и сомнительная ЕТСНГ compound-assignment expression в Item; фактический runtime не проверялся.
- Добавлены три Mermaid-схемы, история commits и вопросы для ТЗ; обновлены [`business-rules/README.md`](../business-rules/README.md), [`shipping-orders.md`](../business-rules/shipping-orders.md), [`api/README.md`](../api/README.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.22

- Создан [`business-rules/shipping-order-child-excel-exports-part2-as-is.md`](../business-rules/shipping-order-child-excel-exports-part2-as-is.md) — последние восемь V1/V2 shipping child Excel endpoints для goods, requested services, ЭТРАН и вагонов.
- Все методы связаны с permissions, optional filter, `PageReportType`, collector, DTO/mapper и существующим XLSX template; shipping ЭТРАН отделён от receiving Waybill compatibility URI.
- Прослежены V1 ID заявки/default deleted, V2 absent body/`{}`/`deleted=null`, отсутствие root client RLS и owner-проверки, условия четырёх predicates, `byOr`, nested `EXISTS` и даты.
- XLSX разобраны до JXLS key/area и A–H expressions. Shipping Service getters согласованы с DTO; ЭТРАН и вагонный шаблоны имеют старые заголовки вне JXLS area без data expressions.
- Зафиксированы `REPEATABLE_READ`, `Integer.MAX_VALUE`, data/count, parallel mapping, streaming/error semantics, отсутствие direct tests, история commits и три Mermaid-схемы.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`shipping-orders.md`](../business-rules/shipping-orders.md), [`api/README.md`](../api/README.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.23

- Создан [`business-rules/order-report-access-as-is.md`](../business-rules/order-report-access-as-is.md) — общая permission matrix PDF и Excel отчётов заявок `ReceivingOrder`/`ShippingOrder` на commit `22fac945…`.
- Разделены HTTP authentication, method-level `@Secure`/`@Secures` и row/client ownership. Прослежены permission aspect, role forest, уровни доступа, parent propagation, admin role и `403` exception path.
- Сведены `Report:READ`, OR-availability по двум общим правам, пять узких PDF rights, V1/V2 root Excel asymmetry и все 16 child resource permission paths для обеих версий.
- Зафиксированы разные права availability/direct PDF, `IllegalArgumentException` → ожидаемый `500` при отрицательной eligibility, отсутствующий client owner gate прямых UUID, global/deleted child V2 и Waybill null-body exception.
- Связаны permission path migrations и tests. Миграции не объявлены production role grants; требуются live RolePermission/Keycloak данные для фактической матрицы ролей.
- Добавлены три Mermaid-схемы; обновлены [`business-rules/README.md`](../business-rules/README.md), [`api/README.md`](../api/README.md), [`api/order-api.md`](../api/order-api.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.24

- Создан [`business-rules/roles-permissions-as-is.md`](../business-rules/roles-permissions-as-is.md) — source-level модель ролей и разрешений для 17 WMS mappings на commit `22fac945…` с двумя Mermaid-схемами.
- Связаны конкретные request/response DTO, role/permission controllers, Keycloak facade, `RolePermission`/`PermissionPath`, WMS migration, permission aspect, JWT, service tests и история влияющих commits.
- Разделены Keycloak realm roles/назначения, persisted RolePermission rows и вычисленный permission forest; описаны inheritance, admin override, update descendants и event/round-robin cache refresh.
- Зафиксированы source-level gaps: несовпадение `Role.PermissionPath` с enum `PermissionPath` (ожидаемый `403`), отсутствие сверки path role ID с owner записью на update/delete, возможные orphan permissions после role deletion, недостаточная определённость duplicate path rows/cache visibility и unassign error mapping. Runtime выводы помечены как неподтверждённые.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.25

- Создан [`business-rules/user-groups-client-restriction-as-is.md`](../business-rules/user-groups-client-restriction-as-is.md) — четыре ALIS group controllers/17 mappings, их DTO, Keycloak group/user membership и клиентский restriction flow на commit `22fac945…`; добавлены две Mermaid-схемы.
- Показано, что group `userRoles` меняет прямые realm roles пользователей, а не хранит самостоятельные group-role rows; описаны replace-set клиентских связей, транзакция только ALIS части и отсутствие общей Keycloak+БД компенсации.
- Связаны `ClientUserGroup` JPA/migrations, UserGroup/ClientUserGroup DTO, `FilterEnrichServiceImpl`, `RestrictionFilter`, `BaseIdentifierPredicate`, JWT authorities, UserInfo и тестовые source files.
- Зафиксированы source-level gaps: path/body group ID mismatch, `POST .../role/all` без `@Secure`, возможный partial create/update, снятие чужих direct user roles, optional client/all body dereference и пустое пересечение `anyOfId` с available client IDs, способное снять client ID predicate. Runtime эффекты не объявлены проверенными.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.26

- Создан [`business-rules/user-settings-as-is.md`](../business-rules/user-settings-as-is.md) — три UserSetting mappings, raw Map request/DTO response, owner из JWT `sub`, личное/default значение, JSONB replace-by-key и две Mermaid-схемы на commit `22fac945…`.
- Связаны UserSetting controller/service/repository/predicate/entity, SQL create/JSONB/default migrations, runtime-config default UUID, `SecurityUtils`, `SearchString`, `ExceptionAdvice` и integration test source.
- Зафиксированы исходные риски: `GET all` не смешивает defaults; null `sub` не даёт owner predicate; case-insensitive GET расходится с буквальным POST delete и SQL unique; key/value не имеют предметной валидации; latest `1.35.0` migration удаляет все settings, затем вставляет 100 default rows. Применение миграции и live эффект не подтверждены.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.27

- Создан [`business-rules/user-profile-permissions-as-is.md`](../business-rules/user-profile-permissions-as-is.md) — четыре UserInfo mappings, конкретные DTO/filters, JWT/Keycloak profile, client group lookup, permission summary и две Mermaid-схемы на commit `22fac945…`.
- Сводка из роли JWT и cached forest отделена от реального method `@Secure`, `NO_ACCESS` path, owner/RLS и getter profile; username JWT может отличаться от Keycloak profile, client lookup читает актуальную Keycloak/БД связь.
- Зафиксирован source-level дефект: `GET /userInfo` при empty available client IDs вызывает DAO с empty `anyOfId`, который `BaseIdentifierPredicate` игнорирует, что способно вернуть все Client rows вместо пустого списка. Для page/meta описаны `Client:READ` и restriction enrichment, но не объявлена runtime безопасность.
- Связаны `UserInfoServiceIntegrationTest`, `PermissionCheckStrategyTest`, `MonitorClient`/feature flag, `ClientShortDto` и influencing commits; негативные тесты/применённые права отсутствуют.
- Обновлены [`business-rules/README.md`](../business-rules/README.md), [`api/README.md`](../api/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 3.28

- Создан [`business-rules/inbound-event-registry-as-is.md`](../business-rules/inbound-event-registry-as-is.md) — сводный реестр `eventCode → action`: `POST /datareon/event`, таблица `INBOUND_EVENT_CONFIG`, диспетчер `ActionsProcessor` и её полная миграционная история на commit `22fac945…`; одна Mermaid-схема. Закрывает пробел «нет общего реестра eventCode → actions», зафиксированный в матрице покрытия.
- **Главная находка**: за всю историю репозитория в `INBOUND_EVENT_CONFIG` выполнена ровно одна `INSERT`-миграция (`VH_DEPARTURE → VH_DEPARTURE`, KIS-147), но более поздняя `KIS-3355` удаляет строку `(VH_ARRIVED, STATUS_IN_WORK)`, которую ни одна миграция репозитория не вставляла — production-конфигурация заводится вне Liquibase, и репозиторий не является источником истины для полного реестра.
- Подтверждено (и лично перепроверено, не только по докладу агента): `ActionsProcessor` сортирует actions по Java-константе `InboundEventActionHandlingCode.priority` (не колонка БД), `forEach` — fail-fast (более поздние actions при ошибке не выполняются вовсе — подтверждено `ActionsProcessorTest`), а `REQUIRES_NEW` оборачивает весь батч одной транзакцией.
- Обнаружено, что задуманная дедупликация по `INBOUND_EVENT.task_id` физически недостижима: unique index на этой колонке был удалён миграцией `ALG-694 alter` (переименование `message_id → task_id`) и никогда не восстановлен. Повторный `task_id` не вызывает `DataIntegrityViolationException`; при этом общий catch всё ещё может сработать на другом нарушении целостности и ошибочно вернуть `409` как для дубликата. Дополнительно найдено расхождение OpenAPI (`406`) и фактического обработчика (`409`), мёртвая константа `SHIP_START`, невызываемый `getUnprocessedEvents()` (нет ретрая `FAILED`/`NEW`) и рассинхронизация длины `event_code` между `INBOUND_EVENT_CONFIG` (150) и `INBOUND_EVENT` (20).
- Историческая запись: задача выполнялась через фоновый Explore-агент с последующей самостоятельной проверкой. Это нарушило установленное пользователем правило «не запускать субагентов без отдельного запроса»; выводы сохранены только после повторной проверки по исходникам.
- Обновлены [`business-rules/README.md`](../business-rules/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 5.1

- Открыт этап 5: создан новый раздел [`scenarios/`](../scenarios/README.md) — сквозные сценарии, связывающие уже написанные детальные документы в один жизненный цикл заявки, вместо повторного описания одной операции/таблицы.
- Создан первый сценарий [`scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md`](../scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md): составная source-level цепочка заявки на вывоз со склада (`WAREHOUSE + VEHICLE`, `BY_GOOD_WITH_CARGO_WITH_DETAILS`) от `POST /shippingorder/` до возможного `DONE`. Ветка через `accept()` и outbound `SHIPMENT_TRANSPORT_MANIFEST`/`ITEM_SHIPMENT_TASK` подтверждена на уровне service-кода, но не как доступный production-маршрут; inbound-часть включает `VH_DEPARTURE`, `WMS_SHIPMENT_RESULT` и `STATUS_COMPLETED`; одна Mermaid sequence-диаграмма.
- **Новая находка, видимая только при сквозной трассировке**: `VhDepartureAction` — единственный inbound action во всей директории `service/datareon/inbound/action`, который проверяет площадку заявки по жёстко закодированной константе `WAREHOUSE`, а не по фактической `shippingOrder.getTerminalArea()`, как это делают `BaseChangeStatusResultAction`, `CarriageArrivedAction`, `TosShipmentResultAction` и `TosReceivingResultAction`. Подтверждено прямым сравнением всех вызовов `hasSuitableTerminalArea` в этих классах. Практическое следствие: `actualShippingDateTime` устанавливается по `VH_DEPARTURE` для любой заявки на вывоз подходящего `transportType`, независимо от реальной площадки.
- Подтверждено прямым чтением исходников (`BaseChangeStatusResultAction`, `StatusCompletedResultAction`, `StatusInWorkResultAction`, `OrderStatus`): `STATUS_COMPLETED` переводит заявку в `DONE`, минуя таблицу переходов `OrderStatus.ALLOWED_TO_USER_TRANSITIONS`, проверяя только «не терминальный статус» — согласуется с уже описанными в подэтапе 3.2 конфликтами нескольких actions одного `eventCode`.
- Ни один найденный тест не проходит весь сценарий целиком — существующие тесты покрывают шаги по отдельности; для дефекта `VhDepartureAction` теста не найдено.
- Обновлены [корневой README библиотеки](../README.md) (раздел «С чего начать» и структура каталогов).

### Подэтап 5.2

- Создан раздел [`integrations/`](../integrations/README.md) с принципом «один бизнес-процесс — отдельные системные слои» и реестром будущих контуров 1С ЭТРАН/WMS/TOS/CRM.
- Создан сквозной AS-IS [`1c-etran-waybill-gu27-as-is.md`](../integrations/1c-etran-waybill-gu27-as-is.md): зафиксированы синонимы «ГУ-27», «накладная ЭТРАН», «ЖДН», «СМГС 15/2015», формирование `акс_Накладная` в 1С, Datareon `Etran_27`, статусный фильтр, C#-преобразования, маршрут до `POST /datareon/waybill` и серверная граница ALIS.
- Создан полный паспорт [`Etran27`](../integrations/1c-etran-waybill-gu27-datareon-contract.md) по Excel: 124 строки модели, 6 массивов, null/fill semantics, типы всех полей и сопоставление с текущим `WaybillIntegrationDto`.
- Выявлены десять межслойных расхождений `INT-ETRAN-001…010`, включая `danger_identifier` против `danger_product`, двойное преобразование единиц в Datareon/ALIS, порядок вычисления `weight_net`, отсутствие outer fill-checks, nested validation и status-only replay.
- Добавлены Mermaid sequence/flow diagrams, вопросы владельцам 1С/Datareon/ALIS и минимальный пакет контекста для LLM; обновлены корневой README, business-rules index и Waybill AS-IS.

### Подэтап 3.29

- По запросу «закрыть вопросы этапа 3» проведён повторный аудит шести базовых навигационных документов заявок, которые (в отличие от всех 27+ AS-IS документов подэтапов 3.1–3.28) не имели штампа проверки по checkout: [`orders.md`](../business-rules/orders.md), [`order-types.md`](../business-rules/order-types.md), [`order-validation.md`](../business-rules/order-validation.md), [`order-statuses.md`](../business-rules/order-statuses.md), [`order-copying.md`](../business-rules/order-copying.md), [`order-errors.md`](../business-rules/order-errors.md). Всем шести добавлен штамп `22fac945…` от 18.09.2026.
- **Закрыт вопрос №1** из «Вопросы для будущего проектирования» в `order-statuses.md`: прямым `grep` по всем controller/service/action классам подтверждено, что `ShippingOrderService.accept(UUID)` и `ReceivingOrderService.accept(UUID)` не вызываются ни одним production-путём (controller, inbound action, планировщик) — только упоминаются в TODO-комментариях 12 дочерних сервисов и вызываются из одного service-level теста. Это мёртвый код, а не «endpoint не найден».
- **Закрыт вопрос №3** того же документа, подтверждён как реальный дефект: `OrderServiceUtils.checkOrderStatusForUpdate` жёстко проверяет `Permission.RECEIVING_ORDER_SEND_TO_ACCEPT` независимо от стороны вызова — уже задокументировано отдельно в подэтапе 4.17 ([физическая модель транспорта вывоза](../database/shipping-order-transport-as-is.md)), теперь связано с исходным вопросом.
- В `order-validation.md` добавлено отсутствовавшее упоминание дублирующегося `consignee`/`consigneeAddress` между root `shipping_order` и `shipping_order_transport` (найдено в подэтапе 4.17, но не было перенесено в этот более общий документ).
- `order-types.md`, `order-copying.md` (full copy вывоза — сверено напрямую по оркестрации `ShippingOrderService`, расхождений не найдено) и `order-errors.md` (коды, пересекающиеся с частями 16–23) перепроверены без содержательных изменений — только штамп.
- Прочие открытые пункты этапа 3 (PermissionPath mismatch, `GET /userInfo` empty-client, стирание настроек миграцией `1.35.0`, owner Company/Currency, идемпотентность Contractor/Contract, атомарность Datareon full-sync, data/meta parity рейсов) **не закрыты** этим подэтапом: они уже задокументированы как находки в соответствующих AS-IS документах и не могут быть закрыты дальше без изменения кода или доступа к runtime/применённой схеме — не путать с задачами, решаемыми чтением исходников.
- Обновлена [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.1

- Создан [`database/receiving-order-root-as-is.md`](../database/receiving-order-root-as-is.md) — source-level физическая трассировка корня `ReceivingOrder` от create/update DTO и mapper/service до JPA полей, SQL колонок и migration chain на commit `22fac945…`; одна Mermaid-схема.
- Разделены прямые request-поля, поля аудита/генерации, условно обязательные ЖД ссылки, stored totals и override detailed DTO из Waybill; зафиксированы nullable, PK/FK, найденный route index и отсутствие доказанного root `UNIQUE(number)`.
- Выделены двойной источник `number` (Java sequence и SQL `SERIAL`), update по body ID вместо path ID и миграционная коллизия `shipper_id`/нового `carrier_id`: поздний FK на `carrier_id` не доказывает FK для JPA `shipper`.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md). Применённая схема БД и полный набор runtime constraints не проверялись.

### Подэтап 4.2

- Создан [`database/receiving-order-transport-as-is.md`](../database/receiving-order-transport-as-is.md) — source-level физическая цепочка `receiving_order_transport` от create/update DTO и mapper/service до JPA, SQL/migrations, FK/NULL/audit и response projection на commit `22fac945…`; одна Mermaid-схема.
- Показан shared `id` как PK/FK на root, четыре обязательных справочных FK, nullable `waybill VARCHAR(50)`, удаление старых snapshot-колонок driver/vehicle и получение текущих сведений из ClientDriver/ClientVehicle.
- Зафиксированы `DELETE FROM RECEIVING_ORDER_TRANSPORT` в ALG-430 до новых NOT NULL FK, несовпадение URL/body/receivingOrder IDs без доказанной сверки на PUT, отсутствие owner reference check в transport service и различие одноимённых `shipper`/`carrier`/`waybill` в root и child.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md). Применённая схема/миграционная история и deployed права не проверялись.

### Подэтап 4.3

- Создан [`database/receiving-order-good-as-is.md`](../database/receiving-order-good-as-is.md) — source-level модель `receiving_order_good` от request DTO/controller/mapper/service до JPA, SQL migrations и двух stored totals корня на commit `22fac945…`; одна Mermaid-схема.
- Связаны три текущих FK, NUMERIC(16,3) количества/цены, nullable actual из WMS, soft-delete и удалённые исторические `good_variant_id`/snapshot-поля. Выделен `DELETE FROM RECEIVING_ORDER_GOOD` старой migration ALG-272 без утверждения о её применении.
- Показано, что DTO присылает обязательный `totalPrice`, service сохраняет его без formula check; SKU агрегируется по distinct `ClientGood.item`, goods price — по persisted active-row `totalPrice`. Зафиксированы null batch update dereference, path/body ID mismatch и **неподтверждённая атомарность** list API с внутренними `super.add/update` вызовами.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md). Cargo и WMS в полном объёме не анализировались в этом подэтапе.

### Подэтап 4.4

- Создан [`database/receiving-order-cargo-as-is.md`](../database/receiving-order-cargo-as-is.md) — source-level модель `receiving_order_cargo` от DTO/controller/mapper/service до JPA, SQL migrations и stored cargo/weight totals корня на commit `22fac945…`; одна Mermaid-схема.
- Связаны PK, root/good/package/barcode/cargo FK, меняющиеся NULL/DEFAULT для package/conversion/total и размеров/веса, soft-delete и исторический `DELETE FROM RECEIVING_ORDER_CARGO` в ALG-311. У cargo нет собственной WMS `actualQuantity`; goods actual — отдельное поле.
- Зафиксированы JPA `@OneToOne` root при SQL FK без найденного UNIQUE и нескольких cargo в source test; отсутствие cross-parent guard, различие request `totalQuantity` и server calculation, update по body ID, null goodPackage dereference, auto-cargo с `cargo=null` в service-side вызове.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md). Применённая DB schema и generated MapStruct не проверялись.

### Подэтап 4.5

- Создан [`database/receiving-order-container-as-is.md`](../database/receiving-order-container-as-is.md) — source-level физическая модель parent `receiving_order_container` от DTO/conditional validator/mapper/service до JPA, SQL migration chain, TOS actualQuantity и root totals на commit `22fac945…`; одна Mermaid-схема.
- Связаны UUID PK/FK, `seal_numbers VARCHAR(50)[]`, nullable Container/weight/danger/owner/seal type/unknown flag, root count/unknown flag, container index и история `UNIQUE(receiving_order_id,container_id)` с последующим удалением.
- Показаны два competing root `total_weight` writers: container service суммирует parent gross, item service суммирует child gross без tare; create parent weight получает только catalog tare, update/item пишут tare+items. JPA комментарий «WMS» для actualQuantity не совпадает с найденным TOS writer КП-АВТО; прямой carriage FK удалён при Waybill migration.
- Отмечены source-level gaps: duplicate check считает soft-deleted rows, HTTP conditional validation не доказывает service-side проверку, PUT идёт по body ID, owner не присваивается обычным update, фактическая schema/atomicity не проверены. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.6

- Создан [`database/receiving-order-container-item-as-is.md`](../database/receiving-order-container-item-as-is.md) — source-level модель `receiving_order_container_item` от request DTO/controller/mapper/service/JPA до SQL migrations, FK/NULL/DEFAULT и порядка root/parent calculations на commit `22fac945…`; одна Mermaid-схема.
- Связаны три текущих FK, nullable ETСНГ/description/price, обязательный `wight_gross NUMERIC(15,3) DEFAULT 0`, nullable net/place, soft-delete и ограниченная one-off миграция active item → WaybillProduct без переноса price/weights/places.
- Зафиксированы cross-parent gap двух независимых FK, update по body ID, перенос item на новый parent без пересчёта старого, null Container dereference при gross calculation и отсутствие positivity/net≤gross checks.
- Показано, что item service пишет root `total_goods_price` суммой item.price, `total_weight` суммой item.wightGross **без тары**, затем parent weight **с тарой**; это конкурирует с good/container service writers. Обновлены [`database/receiving-order-root-as-is.md`](../database/receiving-order-root-as-is.md), [`database/receiving-order-good-as-is.md`](../database/receiving-order-good-as-is.md), [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.7

- Создан [`database/receiving-order-requested-service-as-is.md`](../database/receiving-order-requested-service-as-is.md) — source-level модель `receiving_order_requested_service` от request DTO/controller/mapper/service до JPA, SQL migration chain и внешних WMS/TOS writers `actualQuantity` на commit `22fac945…`; одна Mermaid-схема.
- Связаны обязательные `receivingOrder.id`/`termOfRequestedService.id`, server-derived service measure, planned quantity, rate, prices, VAT source fallback, actual quantity, soft-delete и `systemManaged`; отдельно отмечены отсутствие source UNIQUE пары root+term и UPDATE по body ID без URL/body comparison.
- Разделены три write path: direct add/update/remove пересчитывает active root count и сумму `priceWithoutVAT`; создание required услуг пишет строки прямо через DAO; изменение cargo/container автоматически меняет CARGO_PLACE rows, но не вызывает пересчёт root service totals. Последние два случая требуют DB/API-проверки возможного отставания stored totals.
- Зафиксирована destructive история `DELETE` перед обязательным UOM FK, поздняя замена UOM на nullable enum string и influencing commits `11de1385`, `693c3cbf`, `6c02802e`. Обновлены [`database/receiving-order-root-as-is.md`](../database/receiving-order-root-as-is.md), [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.8

- Создан [`database/receiving-order-blackbox-as-is.md`](../database/receiving-order-blackbox-as-is.md) — source-level модель `receiving_order_blackbox` от HTTP DTO/controller/mapper/service и Excel parser до JPA, Cargo catalog, SQL/FK и downstream accept/outbound/remain view на commit `22fac945…`; одна Mermaid-схема.
- Зафиксировано, что row хранит только parent/Cargo FK и deleted/audit: количество, вес, размеры, товар, партия и упаковка отсутствуют. Direct create требует `BY_CARGO`, find-or-create глобального Cargo и инкрементирует root `totalCargoQuantity`; update меняет только Cargo, PUT использует body ID.
- Разделены direct/copy и Excel write paths: Excel parser пишет row через DAO без service delivery-type check и root increment. Повторный DELETE доступной по ID soft-deleted строки способен повторить decrement; SQL не запрещает duplicate root+Cargo, а nullable `deleted` без default расходится с Java default/filter.
- Связаны accept existence check и ItemReceivingTask: active rows формируют outbound items, но `cargoQty` берётся из root counter. Отмечен join remains→blackbox только по cargo без deleted/parent predicate. Обновлены [`database/receiving-order-root-as-is.md`](../database/receiving-order-root-as-is.md), [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.9

- Создан [`database/waybill-root-as-is.md`](../database/waybill-root-as-is.md) — source-level физическая модель корня `waybill` от `WaybillIntegrationDto`/Datareon partial upsert и receiving link APIs до JPA, SQL migration chain и read models на commit `22fac945…`; одна Mermaid-схема.
- Связаны обязательные SQL status/number/identifier/station FK, nullable snapshot/date/payer/receiving fields, UNIQUE identifier, отсутствие unique number/deleted/status CHECK и explicit indexes для root FK. Отмечено противоречие nullable SQL dates и фактически обязательного `atZone` при первом import.
- Разделены create и повтор: новая накладная сохраняет root+children транзакционно, существующая по identifier меняет только status; MessageId/Version не участвуют. Описаны single link/relink/unlink и bulk replace, которые не проверяют order/waybill status, client ownership и способны перепривязать Waybill другой заявки.
- Прослежены v1.34 payer migration, nullable receiving FK, перенос legacy связей по неуникальному `waybill.number` и последующий `DROP ... CASCADE` старых receiving ETRAN/railway tables. Обновлены [`database/receiving-order-root-as-is.md`](../database/receiving-order-root-as-is.md), [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.10

- Создан [`database/waybill-railway-carriage-as-is.md`](../database/waybill-railway-carriage-as-is.md) — source-level физическая модель `waybill_railway_carriage`: граница с глобальным RailwayCarriage, snapshot-поля, SQL/FK/index/audit, три create path, task status, read DTO/filter и физическое удаление на commit `22fac945…`; одна Mermaid-схема.
- Зафиксированы отсутствие `UNIQUE(waybill_id, railway_carriage_id)`, soft-delete и status CHECK/default; обычные list/detailed DTO не раскрывают status, compatibility `deleted` filter не влияет на predicate, а legacy `/all` не имеет method-level `@Secure`.
- Разделены Datareon first-create/status-only replay, Excel find-then-insert и KIS-3631 legacy migration. Выделены source-level mismatch manual Waybill без SQL-required identifier и null-семантика repository `allCarriagesFinished`, при которой null rows не блокируют завершение.
- Прослежены `UPLOADED`/`FINISHED`, схлопывание одинакового физического вагона, DB cascade WRC → WaybillContainer → WaybillZpu и postRemove cleanup ReceivingOrderContainer. Риск порядка flush/subquery явно оставлен неподтверждённым до integration test. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/waybill-root-as-is.md`](../database/waybill-root-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.11

- Создан [`database/waybill-container-as-is.md`](../database/waybill-container-as-is.md) — source-level физическая модель `waybill_container` и дочернего `waybill_zpu`: граница global Container/snapshot/ContainerOwner, SQL constraints, create paths, status lifecycle, DTO/filter/read projections и каскады на commit `22fac945…`; одна Mermaid-схема.
- Зафиксированы отсутствие unique пары и FK indexes WC, soft-delete/update audit/status CHECK, nullable ЗПУ без unique, repository `Optional` при допустимых дублях и inert `deleted`/`etsngCode` filters. `net_weight > 0` проверяет БД, но не DTO/service.
- Разделены Datareon global upsert+snapshot, Excel link-only и KIS-3631 restricted migration. Повтор Waybill обновляет только root status; duplicate Container в первом payload не блокируется, а ЗПУ связывается с первой строкой по номеру.
- Прослежены route package `UPLOADED`, TOS `FINISHED`/DONE/ContainerOwner, потеря входного actual quantity и read mismatch: grouped/legacy `netWeight` берётся из суммы WaybillProduct, а не persisted WC column. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/waybill-railway-carriage-as-is.md`](../database/waybill-railway-carriage-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.12

- Создан [`database/waybill-product-as-is.md`](../database/waybill-product-as-is.md) — source-level физическая модель `waybill_product`: все SQL snapshot-поля, ЕТСНГ/DangerProduct/DangerClass, import validation, migration, read DTO/totals и route-package projection на commit `22fac945…`; одна Mermaid-схема.
- Зафиксированы отсутствие product business key/UNIQUE/soft-delete/update audit и CHECK для чисел, обязательный SQL ЕТСНГ без отдельного FK index, nullable danger FK для старых строк и преобразование BigDecimal → Double в CRUD DTO.
- Разделены входные строки `signDanger`/`isDangerous` и authoritative seeded DangerProduct class; blank identifier даёт sentinel `-1`, unknown отклоняет даже status-only replay, а filter alias `isDangerous` фактически фильтрует class code, не одноимённую persisted строку.
- Прослежены migration item → product с потерей price/weights/places и риском nullable legacy ЕТСНГ; ReceivingOrder totalWeight из `product.weight`; outbound 1 product → N containers с WC netWeight и 2+ products → первый WC с product weight. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/waybill-container-as-is.md`](../database/waybill-container-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.13

- Создан [`database/waybill-marks-as-is.md`](../database/waybill-marks-as-is.md) — source-level физическая модель `waybill_special_mark` и `waybill_tariff_mark`: SQL/FK/nullable, inbound DTO/mapping, numeric tariff code, replay/cascade, page DTO/filter и тестовые пробелы на commit `22fac945…`; одна Mermaid-схема.
- Зафиксированы отсутствие business key/UNIQUE/content validation/soft-delete/update audit: точные дубли и полностью пустые содержательные строки допустимы, а порядок элементов отдельно не хранится.
- Установлен фактический first-import contract: оба nullable в DTO списка должны быть non-null из-за `.stream()`, пустые допустимы; blank tariff code становится null, nonnumeric/overflow падает, ведущие нули теряются при `String → Integer → String`.
- Подтверждено status-only replay без синхронизации marks, отсутствие иных writers/direct mutation endpoints и физический `ON DELETE CASCADE`. Выделен неподтверждённый runtime-риск: nested Waybill filter использует статический root path вместо связи mark row. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/waybill-root-as-is.md`](../database/waybill-root-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.14

- Создан [`database/grouped-waybill-as-is.md`](../database/grouped-waybill-as-is.md) — source-level модель materialized `grouped_waybill`: ключ route+payer, SQL membership/counts/arrays, physical index, async refresh, endpoints/DTO, filters/dropdowns и tests на commit `22fac945…`; одна Mermaid-схема.
- Разделены materialized membership/counts и live enrichment Waybill/Product: ответ не читается в едином snapshot, поэтому при stale IDs counts и списки способны расходиться. Marks/ZPU/status/receiving order/client в проекцию не входят.
- Зафиксирован eventual lifecycle: только успешный Datareon handler публикует async `AFTER_COMMIT` refresh; клиент не ждёт завершения, ошибка лишь логируется, retry/status/last-refresh отсутствуют, Excel и другие child writers event не публикуют.
- Выделены unstable random group ID/default pagination, отсутствие порядка UUID arrays и payer pages, ignored inherited ID-filter, потеря sorting при `WaybillTabFilter → GroupedWaybillFilter`, nullable payer mismatch и отсутствие client restriction. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/waybill-root-as-is.md`](../database/waybill-root-as-is.md), [`business-rules/waybill-etran-as-is.md`](../business-rules/waybill-etran-as-is.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.15

- Создан [`database/receiving-order-waybill-integrity-map.md`](../database/receiving-order-waybill-integrity-map.md) — единая source-level ER/integrity-карта `ReceivingOrder ↔ Waybill`: 15 physical tables вместе с root, materialized view, FK/UNIQUE/delete matrix, writers, competing aggregates и чек-лист проверки ТЗ; две Mermaid-схемы.
- Исправлена инвентаризация: части 1–13 охватывают `receiving_order` и 14 связанных физических таблиц, а не 13; `waybill_container` и `waybill_zpu` — разные таблицы, хотя описаны одним документом части 11.
- Зафиксирована асимметрия удаления: mutable receiving collections преимущественно soft-delete и FK без cascade; Waybill children физические и образуют cascade tree. Выделены отсутствующие composite parent guards Cargo/Item и почти полное отсутствие business UNIQUE.
- Сведены два независимых container-контура и competing root-total writers; сформулирован практический десятипунктный чек-лист для ТЗ. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), оба root-паспорта и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.16

- Создан [`database/shipping-order-root-as-is.md`](../database/shipping-order-root-as-is.md) — source-level физическая модель корня `shipping_order`: DTO → mapper/service/JPA → SQL, обязательность, FK/CHECK/индекс, status writers и stored totals на commit `22fac945…`; одна Mermaid-схема.
- Зафиксированы расхождения контрактов: request `orderStatus` обязателен, но create всегда сохраняет `DRAFT`; `PUT /shippingorder/{id}` выбирает запись по `body.id`; часть полей update DTO не переносится service; response `documentConfirmed` больше не имеет entity/SQL backing.
- Прослежена цепочка client/terminal-area/consignee migrations, включая отсутствие найденного source FK для `consignee_id`, derived `consigneeAddress`, nullable currency/planned datetime и filling-type CHECK с `NONE_CONTAINER`.
- Сведены конкурирующие writers `totalWeight`, `totalGoodsPrice`, `totalCargoQuantity`, `totalContainerQuantity` и прямой required-service insert без явного пересчёта root service totals. Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.17

- Создан [`database/shipping-order-transport-as-is.md`](../database/shipping-order-transport-as-is.md) — source-level физическая модель `shipping_order_transport`: shared PK/FK, DTO → mapper/service/JPA → SQL, обязательность, outbound-цепочка и статус-проверка на commit `22fac945…`; одна Mermaid-схема.
- Подтверждено, что transport необязателен для каждой заявки: `ShippingOrderAcceptValidator.transportChecks` требует строку только для `TransportType.VEHICLE`, ветка `CONTAINER+RAILWAY` её не проверяет.
- Прослежен bidirectional shared-key crutch в `prepareModelToAdd` (явный `update(shippingOrder)` после `setTransport`/`setShippingOrder`), введённый commit `dd22741c` (KIS-928) как исправление создания.
- Выявлено дублирование `consignee`/`consigneeAddress` между root `shipping_order` (валидируется по роли/клиенту, адрес выводится из `addressFact`) и `shipping_order_transport` (сохраняется без ownership-проверки, адрес — сырой ввод клиента); поиском по source не найдено потребителей transport-версии этих полей, кроме собственного ответа API — TN-отчёт, копирование в рейс и outbound manifest используют только root-значение.
- Сведена outbound-цепочка: `SHIPPING_ORDER_TRANSPORT` исключён из актуального `OutboundConfigService.CONFIGURATION` (закомментирован), из-за чего собственные `postAdd`/`prepareModelToUpdate` transport-сервиса — мёртвый код; реальная выгрузка идёт через root `ShippingOrder.accept()`, который подбирает sibling transport-строку под `SHIPMENT_TRANSPORT_MANIFEST` и передаёт её в `ShippingTransportManifestExportService`.
- Зафиксирован общий (не только transport) дефект: `OrderServiceUtils.checkOrderStatusForUpdate`, используемый ~12 дочерними сервисами обеих сторон, жёстко проверяет `Permission.RECEIVING_ORDER_SEND_TO_ACCEPT` вместо `SHIPPING_ORDER_SEND_TO_ACCEPT` при update дочерних строк заявки на вывоз в статусе `ON_REVIEW`.
- Обновлены [`database/README.md`](../database/README.md), [`business-rules/shipping-orders.md`](../business-rules/shipping-orders.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.18

- Создан [`database/shipping-order-good-as-is.md`](../database/shipping-order-good-as-is.md) — source-level физическая модель `shipping_order_good`: DTO → mapper/service/JPA → SQL, три bulk-контракта, stored root totals и outbound-цепочка на commit `22fac945…`; одна Mermaid-схема.
- Выявлена асимметрия `prepareModelToUpdate`: `clientGood` при отличии перезагружается через DAO, а `batch` присваивается напрямую из mapper-результата, который при `IdDto → Batch` заполняет только `id`; итоговый ответ `PUT` может содержать `batch.code = null` при корректном `batch.id` — не подтверждено HTTP-тестом. Та же асимметрия делает очистку `batch = null` рабочей без NPE-риска, известного по `receiving_order_good`.
- Сведены три независимых bulk-контракта товарных строк: `multipleaddition`/`multipleupdate` вызывают `super::add`/`super::update` в обход Spring-прокси (без гарантии `@Transactional`), тогда как `POST /{shippingOrderId}/batch` идёт через `BaseService.applyBatch`, явно аннотированный `@Transactional` на весь батч.
- Зафиксировано отличие precision денежных полей от receiving-контура: `price`/`total_price` — `NUMERIC(15,2)` у shipping с самого начала, `NUMERIC(16,3)` у receiving после отдельной type-миграции.
- Подтверждён тот же dead outbound config паттерн, что и у транспорта: `EntityType.SHIPPING_ORDER_GOOD` закомментирован в `OutboundConfigService.CONFIGURATION`, реальная интеграция товаров идёт через root `SHIPPING_ORDER`/`ITEM_SHIPMENT_TASK`.
- Отмечена неточная JPA cardinality: `ShippingOrderGood.shippingOrder` объявлен `@OneToOne` без `mappedBy`/unique constraint и без обратной коллекции на `ShippingOrder`, хотя физически строк на одну заявку может быть много.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.19

- Создан [`database/shipping-order-cargo-as-is.md`](../database/shipping-order-cargo-as-is.md) — source-level физическая модель `shipping_order_cargo`: DTO → mapper/service/JPA → SQL, четыре bulk/upsert-контракта, stored root totals и пересчёт `CARGO_PLACE`-услуг на commit `22fac945…`; одна Mermaid-схема.
- Выявлено мёртвое поле `batch` в `ShippingOrderCargoCreationDto`/`UpdateDto`: у entity нет соответствующего поля, mapper не содержит `@Mapping` для него, сервисные методы его не читают — значение проходит валидацию и молча отбрасывается.
- Зафиксирована асимметрия с receiving-контуром: `cargo` в shipping — обязательный `IdDto` на существующую каталожную запись, тогда как в receiving — строка с find-or-create по коду; одинаковое по смыслу поле ведёт себя по-разному в двух контурах.
- Подтверждено собственное WMS-поле `actualQuantity`/`executor` на уровне cargo (в отличие от receiving, где актуальное количество живёт только на уровне good); `WmsShipmentResultAction` пишет их кумулятивным сложением, а не перезаписью.
- Сведены четыре независимых bulk/upsert endpoint: `multipleaddition`/`multipleupdate` — self-invocation без `@Transactional` на весь список; `POST /{shippingOrderId}` — `@Deprecated`, но при этом `@Transactional` `upsertAndDelete(UUID, ...)` с replace-by-absence-delete семантикой; `POST /{shippingOrderId}/batch` — `@Transactional` `applyBatch` с явным diff и scope-проверкой.
- Подтверждён тот же dead outbound config паттерн, что и у транспорта/товаров.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.20

- Создан [`database/shipping-order-container-as-is.md`](../database/shipping-order-container-as-is.md) — source-level физическая модель родительской `shipping_order_container`: DTO → validator/service/JPA → SQL, stored totals, `ktkNumberUnknown`-флаг и merge-эндпоинты на commit `22fac945…`; одна Mermaid-схема.
- Выявлено расхождение область видимости: физический `UNIQUE(shipping_order_id, container_id)` из ALG-644 не отфильтрован по `deleted` и никогда не удалялся (в отличие от receiving-аналога), а app-level `checkIfAlreadyExists` считает только активные строки (`deleted=false` по умолчанию фильтра) — повторное создание ранее удалённого КТК должно упасть в физический constraint, минуя ожидаемый `DuplicateEntityException`.
- Найден конкретный NPE-риск: `ShippingOrderContainer.getCargoWeight()` разыменовывает `weight`/`container` без null-guard внутри метода; `TNContainerReportDataCollectorService` защищает вызов через `.filter(Objects::nonNull)` **после** `.map(...)`, что не спасает от исключения при `ktkNumberUnknown=true` контейнере в заявке.
- Подтверждено, что прямой FK на вагонную задачу (`shipping_order_railway_carriage_id`) сохранён у shipping в отличие от receiving, где аналогичный FK был удалён `KIS-3631` в пользу связи через WaybillContainer.
- Обнаружено устаревшее сообщение Bean Validation (`ValidShippingOrderContainer`), перечисляющее `weight`/`dangerousCargo` как обязательные поля, хотя ни то, ни другое валидатор не проверяет, а `dangerous_cargo` колонка уже удалена.
- Описаны два современных merge-эндпоинта (`PUT /merge`, `PUT /unnumbered/merge`) со scope замены на всю заявку, а не на отдельный вагон, и их использование корректного (не `@Deprecated`) `upsertAndDelete(filter, ...)` в отличие от deprecated V1 `POST /{shippingOrderId}`.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.21

- Создан [`database/shipping-order-container-item-as-is.md`](../database/shipping-order-container-item-as-is.md) — source-level физическая модель `shipping_order_container_item`: DTO → service/JPA → SQL, два независимых writer'а (root/parent) и их конфликт на commit `22fac945…`; одна Mermaid-схема.
- Подтверждён конкретный NPE-риск: `calculateAndSetShippingOrderContainerFields` разыменовывает `orderContainer.getContainer().getWeight()` без null-guard — при `container=null` (`ktkNumberUnknown=true`) любое add/update/remove item-строки должно падать. Контраст зафиксирован явно: `ShippingOrderContainerItemMapper.calculatePreviewNetWeight` (read-only) содержит полный null-guard для того же вычитания, то есть паттерн защиты в кодовой базе есть, но не применён в persistence-side пересчёте.
- Сведены три независимых writer'а root `total_weight` (cargo/container/container-item) с разными формулами и областью действия, и подтверждено повторное конкурирование `total_goods_price` между good- и container-item-сервисами.
- Отсутствие composite-проверки `item.shippingOrderContainer.shippingOrder.id == item.shippingOrder.id` подтверждено как зеркало уже задокументированного для receiving-контура cross-parent риска.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.22

- Создан [`database/shipping-order-requested-service-as-is.md`](../database/shipping-order-requested-service-as-is.md) — source-level физическая модель `shipping_order_requested_service`: DTO → service/JPA → SQL, terminal-area-aware `plannedQuantity`, required-строки и root totals на commit `22fac945…`; одна Mermaid-схема.
- Выявлено дублирование формулы пересчёта `CARGO_PLACE`-услуг: `ShippingOrderRequestedServiceService.updateCargoPlaceRequestedServices` (вызывается контейнерным сервисом, terminal-area-aware) и отдельная, независимо реализованная `ShippingOrderCargoService.updateShippingOrderRequestedService` (вызывается cargo-сервисом, всегда считает по числу cargo-строк) — на практике дают одинаковый результат для `WAREHOUSE`-заявок, но представляют собой не связанные друг с другом реализации одной формулы.
- Подтверждено, что required-строки (`ShippingOrderService.addRequiredServices`) вставляются прямым DAO insert, минуя `ShippingOrderRequestedServiceService.postAdd`, — тот же паттерн задержки root-агрегата, что уже описан для root в подэтапе 4.16.
- Зафиксирована более короткая и однотипная миграционная история по сравнению с receiving (таблица сразу создана под финальным именем и с финальными названиями price-колонок).
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.23

- Создан [`database/shipping-order-blackbox-as-is.md`](../database/shipping-order-blackbox-as-is.md) — source-level физическая модель `shipping_order_blackbox`: два независимых write-пути (прямой CRUD и Excel-импорт), root-счётчик как инкремент на commit `22fac945…`; одна Mermaid-схема. Этим документом закрыт выбранный набор частей 16–23; ЖД-ветка и таблицы количеств в него не входят.
- Выявлено конкретное расхождение с receiving-аналогом: `ShippingOrderAutoWarehouseContainerParser.buildBlackbox` требует уже существующий `Cargo` по коду и падает с необработанным `.orElseThrow()`, тогда как `ReceivingOrderAutoWarehouseContainerParser.buildBlackbox` создаёт отсутствующую запись каталога (`.orElseGet(() -> cargoDaoService.add(...))`) — при этом прямой API-путь на обеих сторонах создаёт Cargo при отсутствии, то есть для shipping Excel-путь и API-путь одной и той же таблицы ведут себя по-разному.
- Подтверждён отсутствующий тест для `ShippingOrderAutoWarehouseContainerParser` (расхождение с receiving, где такой тест есть) и повторяющийся паттерн: root `total_cargo_quantity` — инкремент/декремент отдельной операции, а не `COUNT(active rows)`, не пересчитываемый Excel-импортом.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.24

- Создан [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) — сводная ER/integrity-карта `shipping_order` по аналогии с [`ReceivingOrder ↔ Waybill`](../database/receiving-order-waybill-integrity-map.md): единая схема FK/UNIQUE/soft-delete всех восьми частей 16–23, матрица владельцев записи и Mermaid-диаграмма конкурирующих totals.
- Явная граница охвата зафиксирована: `shipping_order_railway_carriage`/`shipping_order_etran_invoice`/`shipping_order_etsng_code`/`shipping_order_container_qty`/`shipping_order_railway_carriage_qty` (ветка `CONTAINER+RAILWAY`) не входят в карту — только FK-разрывы на них.
- Сведены межтабличные конфликты, не видные при чтении одной таблицы: три writer'а `total_weight`, два writer'а `total_goods_price`, дублированная CARGO_PLACE-формула, root/transport дубль `consignee`/`consigneeAddress`, единственная во всём контуре физическая уникальность (`shipping_order_container`) без учёта `deleted`, и общий (не только shipping) дефект `OrderServiceUtils.checkOrderStatusForUpdate` с зашитым receiving-правом.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Корректирующий аудит после подэтапов 3.29/4.24/5.1

- Исправлена слишком широкая формулировка о дедупликации inbound events: уникальность `task_id` действительно отсутствует, но `DataIntegrityViolationException` остаётся возможным для других ограничений, а текущий catch ошибочно классифицирует их как duplicate/`409`.
- Уточнена общая транзакция `ActionsProcessor`: DB-изменения батча откатываются вместе; частичный эффект возможен только вне этой транзакции.
- В сценарии `WAREHOUSE + VEHICLE` исправлен список writer'ов `total_weight` (`Cargo`/`Container`/`ContainerItem`, без `Good`) и явно отделена подтверждённая source-level цепочка от неподтверждённого production-вызова `accept()`.
- Формулировка «полная дочерняя модель shipping_order» заменена на точный охват восьми таблиц; ЖД-ветка и таблицы количеств остаются отдельным пробелом.
- Зафиксировано нарушение процесса предыдущей работой: несколько подэтапов и Explore-агент без отдельного разрешения пользователя. Бизнес-код, конфигурация и миграции не изменялись.

### Подэтап 4.25

- Создан [`database/shipping-order-railway-carriage-as-is.md`](../database/shipping-order-railway-carriage-as-is.md) — физическая и серверная модель `shipping_order_railway_carriage`: V1/V2 endpoints, DTO/mapper/service/JPA → cumulative SQL, filling-type matrix, ETRAN/КТК-связи, inbound/outbound consumers, tests и влияющие commits на checkout `22fac945…`; одна Mermaid-схема.
- Уточнена условная обязательность: для `CONTAINER + RAILWAY` таблица требуется при `fillingType=ALL/RAILWAY_CARRIAGE`, а при `CONTAINER/NONE` accept-validator проверяет `shipping_order_railway_carriage_qty`; для `ALL` дополнительно обязателен ETRAN у каждой физической строки.
- Найдены integrity gaps: нет business UNIQUE; update duplicate-check пропускает конфликт с одной другой строкой; global `etran_invoice_id` не доказывает membership в заявке; схема и container-service не запрещают cross-order wagon↔container.
- Найдены API/service gaps: `PUT /{id}` игнорирует path ID; optional-body `/preview` разыменовывает null; owner-поля физически nullable, но их очистка приводит к NPE; merge — full-order replace с одним `DELETE` permission и без явного `findAvailableShippingOrder` write-scope.
- Зафиксирован конфликт nullable ETRAN: `fillingType=RAILWAY_CARRIAGE` допускает вагон без накладной, но transport-manifest exporter разыменовывает ETRAN без null-guard. Прямой child outbound отключён; root accept и route chain package остаются потребителями.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.26

- Создан [`database/shipping-order-etran-invoice-as-is.md`](../database/shipping-order-etran-invoice-as-is.md) — физическая и серверная модель membership глобальной `etran_invoice` в заявке: все V1/V2 endpoints, DTO/mapper/service/JPA → SQL, accept-условие, uniqueness, full-replace, каскад и outbound; одна Mermaid-схема.
- Зафиксирована неоднозначность ID: legacy `/all` через `ShortDto.id` возвращает UUID глобальной накладной, тогда как CRUD path, detailed/update/merge DTO используют UUID строки связи.
- Найдены integrity/API gaps: DB UNIQUE и FK-индексы не найдены; update duplicate-check пропускает одну занятую пару; PUT игнорирует path ID; update может перенести связь без проверки статуса новой заявки; V2 merge использует отличный base path и не имеет явного `@Secure`/client scope.
- Описана несимметричность cascade: delete/full-replace удаляет вагоны той же пары и далее КТК/items, а замена заявки/накладной через update оставляет физические wagon rows старой пары без membership.
- Уточнено участие в outbound: историческая DB-конфигурация существовала, но current code config не содержит child entity; прямой child enqueue отключён, root manifest использует прямую глобальную ETRAN-ссылку вагона.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.27

- Создан [`database/shipping-order-railway-carriage-qty-as-is.md`](../database/shipping-order-railway-carriage-qty-as-is.md) — физическая и серверная модель планового количества вагонов: scoped list/meta/merge, DTO/mapper/service/JPA → cumulative SQL, accept, route read/meta и route chain package; одна Mermaid-схема.
- Уточнена обязательность: хотя бы одна qty-строка нужна при accept для `CONTAINER/NONE`; service не разрешает запись для `ALL/RAILWAY_CARRIAGE`, но найденной очистки при смене filling type нет.
- Зафиксировано расхождение `quantity`: DTO принимает `0` через `@Min(0)`, тогда как DB CHECK требует `> 0`; тип nullable и защищён `UNIQUE NULLS NOT DISTINCT`, при этом старый обычный UNIQUE также остаётся.
- Найден transaction gap: merge без собственной `@Transactional` вызывает superclass-метод через self-invocation; удаления выполняются до add/update, поэтому поздняя ошибка способна оставить частично применённый full-replace.
- Найдены read/outbound gaps: nullable type виден в list/direct route read, но теряется в route meta из-за inner join; route chain package экспортирует все qty-строки без фильтра текущего filling type, включая потенциально stale.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.28

- Создан [`database/shipping-order-container-qty-as-is.md`](../database/shipping-order-container-qty-as-is.md) — физическая и серверная модель планового количества КТК: scoped list/meta/merge, nested ЕТСНГ boundary, DTO/service/JPA → SQL, accept, totals, route read/meta/export и route chain package; одна Mermaid-схема.
- Разделены filling types: qty разрешена для `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER`, но обычный accept не требует её для первых двух; `NONE_CONTAINER` требует ровно одну строку `quantity=1`, `empty=true`, без items.
- Зафиксированы validation gaps: `quantity` и nested `weight` допускают zero против SQL `>0`; на `items` отсутствует `@Valid`, поэтому nested Bean Validation не каскадирует с HTTP DTO.
- Описана уникальность: partial DB index запрещает второй порожний КТК того же типа; loaded lines сравниваются по type/empty/полному ETSNG+weight signature без quantity, но строки без items пропускаются и concurrency DB constraint'ом не закрыта.
- Подтверждён атомарный transactional full-replace parents/items и application-order delete без FK cascade; merge write lookup не использует явный client-restricted root filter.
- Найдены cross-model gaps: qty и physical services конкурируют за stored `total_container_quantity`; route view повторяет JPA ID на каждый item; chain package экспортирует stale qty/items без filling-type filter.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.29

- Создан [`database/shipping-order-etsng-code-as-is.md`](../database/shipping-order-etsng-code-as-is.md) — физическая и серверная модель груза планового КТК: nested DTO/service/JPA → SQL, weight/precision, exact uniqueness, empty-parent/filling-type/status checks, merge/cascade, meta/route/outbound; одна Mermaid-схема.
- Явно зафиксировано отсутствие самостоятельного controller: child читается и полностью заменяется только внутри `shipping-order-container-qty` list/merge; nested meta возвращает parent IDs, а не child IDs.
- Подтверждены validation gaps: parent `items` не имеет `@Valid`, child weight допускает zero против SQL `>0`, `@Digits`/единица/per-container semantics отсутствуют.
- Описаны physical delete и scoped ownership: ID другого parent отклоняется; parent delete сначала удаляет children application-кодом без FK cascade; update не переносит child между parents.
- Найден dead validation remnant: DAO/repository `existsDuplicateContainerLine` не вызывается; актуальная межстрочная проверка работает по полному parent signature, точный дубль внутри parent закрыт DB UNIQUE.
- Route/meta/outbound связаны с child: flattened view повторяет parent ID, accept проверяет отсутствие items только для `NONE_CONTAINER`, package экспортирует stale qty children без filling-type filter; production inbound writer не найден.
- Обновлены [`database/README.md`](../database/README.md), [`database/orders.md`](../database/orders.md), [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 4.30

- Расширена [`database/shipping-order-integrity-map.md`](../database/shipping-order-integrity-map.md): вместо восьми узлов частей 16–23 карта теперь сводит корень и все 12 дочерних таблиц частей 16–29.
- В общую ER-схему включены ETRAN membership, физические вагоны и КТК, плановые количества вагонов/КТК и nested ЕТСНГ; отдельно зафиксировано отсутствие FK между membership и вагоном.
- Добавлена plan/fact-матрица по `ALL`, `RAILWAY_CARRIAGE`, `CONTAINER`, `NONE`, `NONE_CONTAINER`, включая допустимые stale-строки и отсутствие DB-взаимоисключения моделей.
- Сведены FK/UNIQUE/delete, четыре DB-защиты от дублей, каскады, конкурирующие writers totals и границы route meta/read/package/outbound.
- Обновлены [`database/README.md`](../database/README.md) и [`coverage-matrix.md`](coverage-matrix.md); детальные паспорта не дублировались.

### Подэтап 4.31

- В [`business-rules/shipping-orders.md`](../business-rules/shipping-orders.md) добавлен прямой переход к полной 13-табличной ER/integrity-карте и её plan/fact-разделу.
- Разделена семантика двух слоёв: business rule задаёт состав агрегата при review/accept, но само по себе не доказывает очистку альтернативных физических строк при смене `fillingType`.
- В [`database/orders.md`](../database/orders.md) сводная ShippingOrder-карта обозначена как основной вход для анализа FK/UNIQUE/delete, каскадов, write ownership, totals и route/outbound; детализация остаётся в отдельных паспортах.
- Серверная логика и физические выводы не дублировались; изменена только навигация между уже сверенными материалами.

### Подэтап 6.1

- Создан [`traceability/tz-example-shipping-filling-type.md`](../traceability/tz-example-shipping-filling-type.md) — первый заполненный сквозной кейс проверки ТЗ по цепочке requirement → business rule → endpoint/DTO → service/entity → DB/read model → route/outbound → tests.
- На примере требования «изменить `fillingType` существующей заявки» вынесен вердикт ревью: однострочное ТЗ неполно, а текущий update path фактически не сохраняет новое значение.
- Зафиксирована новая source-level находка: поле наследуется `ShippingOrderUpdateDto` и попадает в update-модель MapStruct, но `ShippingOrderService.prepareModelToUpdate` не копирует его в existing entity; валидатор проверяет старое значение.
- Показано влияние на пять filling types и семь связанных plan/fact/ETRAN child-таблиц, competing totals, route data/meta и route chain package; добавлена Mermaid-схема фактического update flow.
- Сформированы восемь трассируемых требований `REQ-SO-FT-001…008`, вопросы для готового ТЗ и десять acceptance criteria, включая rollback, stale rows, permissions и concurrency.
- Пример подключён к [`traceability/tz-checklist.md`](../traceability/tz-checklist.md), [`coverage-matrix.md`](coverage-matrix.md) и [`analyst-open-items-registry.md`](../traceability/analyst-open-items-registry.md).

### Подэтап 6.2

- Создан [`traceability/tz-example-datareon-event-envelope.md`](../traceability/tz-example-datareon-event-envelope.md) — заполненный разбор ошибки `NotBlank.inboundEventDto.eventCode` для `POST /datareon/event`.
- Подтверждена причина: endpoint принимает один плоский `InboundEventDto`; неизвестные корневые `MessageID` и `EventData` игнорируются Jackson, после чего Bean Validation видит DTO с пустыми обязательными полями.
- Восстановлен error contract `MethodArgumentNotValidException → ExceptionAdviceUtils`: клиент получает только последний `ObjectError`, поэтому один `eventCode` не отражает полный набор отсутствующих полей.
- Приведён корректный flat JSON и зафиксирован второй потенциальный `400`: исходный `eventDateTime` без `Z`/offset несовместим с типом `Instant`.
- Описаны следующие runtime-границы: UUID parsing, case-insensitive exact lookup `TerminalArea.name`, отсутствующий `LOAD_FINISH` config → `SKIPPED`, action failure при HTTP `200`, а также потеря cargo `weight`/`height` в converter.
- Сформированы варианты upstream fan-out и нового batch endpoint, восемь требований `REQ-EVENT-001…008` и десять acceptance tests.
- Кейс связан с [`traceability/tz-checklist.md`](../traceability/tz-checklist.md), [`inbound-event-registry-as-is.md`](../business-rules/inbound-event-registry-as-is.md), [`analyst-open-items-registry.md`](../traceability/analyst-open-items-registry.md) и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 6.3

- Создан [`traceability/tz-review-template.md`](../traceability/tz-review-template.md) — переиспользуемая карточка ревью нового/изменённого ТЗ, ошибки или TO-BE-проектирования по загруженной документации ALIS.
- Добавлены полный и короткий prompts, запрещающие подменять source-level AS-IS runtime-фактом, считать generated DTO бизнес-правилом или молча заполнять пробелы.
- Зафиксирован единый формат ответа: вердикт, граница, доказанный AS-IS, P0–P3 gaps, сквозная трассировка, server flow, решения ТЗ, acceptance criteria, вопросы по владельцам, неподтверждённое и рекомендуемая редакция.
- Введены четыре метки доказательности (`ПОДТВЕРЖДЕНО AS-IS`, `ВЫВОД`, `НЕ ПОДТВЕРЖДЕНО`, `TO-BE`) и 14-балльная вспомогательная шкала готовности требования.
- Для экономии токенов описан минимальный порядок загрузки контекста: coverage/open items → ручное правило → нужные endpoint/DTO/DB-паспорта → integrations/research → change log.
- Шаблон связан с [`traceability/tz-checklist.md`](../traceability/tz-checklist.md), навигацией [`business-rules/orders.md`](../business-rules/orders.md), двумя эталонными кейсами и [`coverage-matrix.md`](coverage-matrix.md).

### Подэтап 6.4

- Создан [`traceability/README.md`](../traceability/README.md) — единая точка входа в проверку ТЗ и ошибок перед загрузкой контекста в GPT.
- Добавлена Mermaid-карта выбора между GPT-карточкой, ручным чек-листом, open-items registry, change log и двумя эталонными кейсами.
- Для заявок, Datareon/интеграций и изменений БД определены минимальные пакеты контекста; generated DTO/JPA предложено добавлять точечно, а не загружать всю библиотеку.
- Зафиксированы рабочий цикл повторного ревью, четыре уровня доказательности, условия обращения к репозиторию/окружению и процедура актуализации после pull.
- Корневой [`README.md`](../README.md) теперь ведёт сначала в traceability-index; [`tz-checklist.md`](../traceability/tz-checklist.md) получил обратную ссылку на индекс.
- [`coverage-matrix.md`](coverage-matrix.md) обновлена: наличие индекса и GPT-карточки не объявляет закрытым пробел полного реестра `правило → API → DB → integration → test`.

### Подэтап 7.1

- Создан [`scripts/check_docs.py`](../scripts/check_docs.py) — единая read-only проверка всей Markdown-библиотеки без перегенерации каталогов.
- Проверка считает Markdown-файлы и локальные ссылки, выявляет отсутствующие цели, незакрытые backtick/tilde fenced-блоки и trailing whitespace; при нарушениях процесс завершается ненулевым кодом.
- Поддержаны относительные и абсолютные локальные пути, URL-encoded имена, ссылки в угловых скобках, query/anchor suffix и исключение внешних URI/same-page anchors.
- Создан [`scripts/test_check_docs.py`](../scripts/test_check_docs.py) с четырьмя регрессионными сценариями: корректная библиотека, все поддержанные нарушения, пути с пробелами/URL encoding и ненулевой exit code CLI.
- В корневом [`README.md`](../README.md#локальная-проверка-документации) описаны команда запуска, read-only граница, состав проверок, exit code и параметр `--root`.

### Подэтап 8.1

- Создан [`business/README.md`](../business/README.md) — каноническая точка входа в бизнес-смысл для аналитика и LLM, отделённая от технических каталогов API, DTO, JPA и БД.
- Добавлена [`business/evidence-model.md`](../business/evidence-model.md) с двумя независимыми осями: состояние тезиса (`AS_IS`/`TO_BE`/`PROPOSAL`/`DEPRECATED`) и основание (`BUSINESS_CONFIRMED`, `SOURCE_CONFIRMED`, `RUNTIME_CONFIRMED`, `EXTERNAL_SNAPSHOT`, `INFERENCE`, `OPEN_QUESTION`).
- Создана [`business/coverage-map.md`](../business/coverage-map.md): для основных предметных областей отмечены наличие смысла, владельца, процессов, правил, событий, систем и технической трассировки; определены три волны наполнения.
- Добавлены шаблоны [бизнес-объекта](../business/templates/business-object.md) и [бизнес-процесса](../business/templates/business-process.md) со стабильными идентификаторами, Mermaid-схемами, критериями приёмки, GAP и LLM-пакетом.
- Корневой [`README.md`](../README.md) теперь предлагает бизнес-слой первой точкой входа, использует новую модель доказательности и ведёт к новым шаблонам.
- [`business-rules/README.md`](../business-rules/README.md) явно отделяет бизнес-определения и владельцев от подробного source-level поведения реализации; [`coverage-matrix.md`](coverage-matrix.md) фиксирует, что каркас создан, но паспорта областей ещё не заполнены.

### Подэтап 8.2

- Создан [`business/glossary.md`](../business/glossary.md) — канонический словарь первой волны для заявок, рейса, ЖД-накладной, КТК, грузового места, номенклатуры, партии, остатков и интеграционных систем.
- Для каждого термина добавлены стабильный `TERM-*`/`SYS-*`, определение, допустимые синонимы, явная колонка «Не путать» и основание по модели доказательности.
- Названия ГУ-27, накладная ЭТРАН, ЖДН и СМГС связаны с одним поисковым контекстом, но не объявлены юридически идентичными формами.
- Разграничены физический КТК `Container`, грузовое место `Cargo`, WRC, WC и ROC, а также снимок `container_remain`, движение `container_movement` и связь `ContainerOwner`.
- ALIS, Datareon, 1С ЭТРАН, ЭТРАН, WMS, TOS и CRM получили канонические обозначения; «1С WMS/TOS/CRM» сохранены только как неподтверждённые поисковые синонимы.
- В словарь добавлена таблица неоднозначных слов для проверки ТЗ и четыре `GAP-GLOSSARY-*`; [`business/README.md`](../business/README.md) и [`business/coverage-map.md`](../business/coverage-map.md) связаны с новым справочником.

### Подэтап 8.3

- Создан [`business/systems.md`](../business/systems.md) — карта систем, подтверждённых потоков и границ ответственности первой волны.
- Введено независимое разделение ролей: источник бизнес-факта, владелец правила, интеграционный посредник, операционное хранилище и внешний исполнитель/потребитель.
- Mermaid-ландшафт связывает ALIS, Datareon, 1С ЭТРАН, ЭТРАН, WMS, TOS и CRM; неподтверждённые связи показаны пунктиром.
- Для десяти потоков указаны источник факта, посредник, роль ALIS, предполагаемый внешний потребитель, основание и граница подтверждённого.
- Отдельно разобраны распределение ответственности ЖД-накладной и граница ALIS/Datareon; направление HTTP-вызова явно не считается доказательством source of truth.
- Добавлены правила описания новой интеграции и шесть `GAP-SYSTEM-*` по master-системам, WMS/TOS, eventCode, остаткам, runtime-маршрутам и CRM.
- Новый документ связан с [`business/README.md`](../business/README.md), [`business/glossary.md`](../business/glossary.md), [`business/coverage-map.md`](../business/coverage-map.md) и [`integrations/README.md`](../integrations/README.md).

### Подэтап 8.4

- Создан [`business/source-of-truth.md`](../business/source-of-truth.md) — предварительная матрица происхождения данных, преобразующего слоя, writers, роли хранения ALIS и бизнес-master.
- Разделены пять понятий: источник происхождения, преобразующий слой, authoritative writer реализации, операционная копия и бизнес-master.
- Сведены заявки, рейсы, Waybill, справочные КТК/вагоны, WRC/WC, заявочные контейнеры, ownership, ClientGood, Batch, три вида остатков, движения, занятость ячеек, Client/Contract и Company/Currency.
- Для заявок/рейсов ALIS отмечен только как кандидат operational master; для внешних снимков и справочников master оставлен `OPEN_QUESTION`.
- Явно описаны конфликты writers Waybill против справочных импортов, трёх путей Batch, incremental/full sync остатков и plan/fact/totals заявок.
- Добавлены десять обязательных решений source-of-truth для нового ТЗ и пакет из 12 вопросов `GAP-SOT-*` для предметного согласования без необходимости разбирать Java-классы.
- [`business/README.md`](../business/README.md), [`business/systems.md`](../business/systems.md) и [`business/coverage-map.md`](../business/coverage-map.md) связаны с матрицей.

### Подэтап 8.5

- Создан [`business/roles.md`](../business/roles.md) — предварительная бизнес-ролевая модель, отделённая от Keycloak roles, permission paths, групп и client scope.
- Определены 16 стабильных `ROLE-*`: владельцы продукта/процесса, операционные роли заявок/рейсов/WMS/TOS/ЖД, владельцы НСИ и интеграций, access admin, support, аналитик, разработка и QA.
- Для каждой роли указаны назначение, уровень подтверждения и сущности, с которыми её нельзя автоматически отождествлять.
- Добавлены предлагаемая RACI-матрица по типам решений и ответственность по предметным областям; обе явно маркированы как `PROPOSAL`, а не действующая оргструктура.
- Отдельно описано участие аналитика от AS-IS draft до `BUSINESS_CONFIRMED`, минимальный пакет предметной встречи и формат фиксации решения.
- Добавлена правильная цепочка business role → business actions → permissions/Keycloak + client scope; обратный вывод бизнес-роли из существующих grants запрещён.
- Зафиксированы десять `GAP-ROLE-*` для согласования владельцев, реальных должностей, replay/support и маппинга технического доступа; [`business/README.md`](../business/README.md) и [`business/coverage-map.md`](../business/coverage-map.md) обновлены.

### Подэтап 9.1

- Word-файл `/Users/ilnur/Downloads/докум.docx` отрендерен в две страницы и визуально проверен; отдельно просмотрены четыре исходных PNG из DOCX. Зафиксированы SHA-256, автор и временные метаданные файла.
- Создан [`ui/README.md`](../ui/README.md) — правила доказательности UI-слоя, обязательная трассировка screen → role/action → permission/scope → API/DTO/rule/data и пять базовых `UIR-DOC-*`.
- Создана [`ui/navigation-as-is.md`](../ui/navigation-as-is.md) с Mermaid-картой видимого меню, предметной классификацией, отдельной границей Superset и анализом будущего переноса «Накладных».
- Будущий перенос «Накладных» в справочники помечен `TO_BE/PROPOSAL`: релиз и реализация неизвестны, а Waybill предметно не равен ни обычной заявке, ни статическому НСИ.
- Создан [`ui/screens/user-groups.md`](../ui/screens/user-groups.md) — первый паспорт экрана: видимые элементы, классификация описаний групп, candidate mapping к четырём UserGroup controllers, модель Keycloak/roles/client scope и source-level риски.
- Добавлены 20 candidate UI requirements (`UIR-REPORT-*`, `UIR-NAV-*`, `UIR-GROUP-*`) и 17 вопросов `GAP-UI-*` по версии снимка, скрытию меню, Waybill, Superset, формам группы, partial failure, token refresh и audit.
- Корневой [`README.md`](../README.md), [`business/README.md`](../business/README.md) и [`coverage-matrix.md`](coverage-matrix.md) получили ссылки на UI-слой и явную границу отсутствующего frontend source/runtime trace.

### Подэтап 9.2

- Word-файл `/Users/ilnur/Downloads/ckfql.docx` отрендерен в четыре страницы; визуально проверены все страницы и семь исходных изображений. Зафиксированы SHA-256, автор и временные метаданные.
- Создан [`ui/screen-inventory.md`](../ui/screen-inventory.md): экраны сопоставлены с бизнес-объектами, кандидатными backend-контурами, наличием snapshot и приоритетом; персональные и транспортные значения не перенесены.
- Создан единый [`ui/templates/screen.md`](../ui/templates/screen.md) с полями, действиями, состояниями, permission/scope, API/DTO и уровнями доказательности.
- Добавлены паспорта [реестров поставки/вывоза](../ui/screens/order-lists.md), [карточки поставки](../ui/screens/receiving-order-card.md), [карточки рейса](../ui/screens/route-card.md), [клиентов](../ui/screens/clients.md) и [отчёта остатков КТК](../ui/screens/container-remains-report.md).
- UI-колонки связаны с `ReceivingOrderDto`, `ShippingOrderDto`, `RouteDetailedDto` и `ClientDto`; endpoint-связи оставлены `INFERENCE` без frontend source/network trace.
- Русские подписи статусов заявок подтверждены `OrderStatus`; отдельно зафиксированы `documentConfirmed`, неоднозначность `storagePeriod=0`, множественная вкладка «Рейсы», интервал времени Route при одном `dataTime` и технический `STANDARD_40` в Superset.
- Добавлены 23 кандидатных UI-требования и 22 вопроса `GAP-UI-*` для аналитика, владельцев процессов, frontend/backend, BI и доступа.

### Подэтап 9.3

- Подключён и просмотрен Figma-файл `ALIS Design System`, file key `raacbatCJFwk7hkvCGfBfa`, переданный node `3425:230612`; источник зафиксирован как внешний проектный материал от 23.09.2026.
- Инвентаризированы 27 страниц: три служебных и 24 группы компонентов от Badge/Button/Input до Table/Sidebar/Pop-up/Tooltip.
- Созданы [`ui/design-system/README.md`](../ui/design-system/README.md), [`component-inventory.md`](../ui/design-system/component-inventory.md) и [`screen-component-map.md`](../ui/design-system/screen-component-map.md).
- Компоненты классифицированы по foundations, input/selection, actions, navigation, data, feedback и brand; добавлены Mermaid-схемы типового реестра и карточки.
- Визуально подтверждены checkbox/radio states, status badges, button/tabs, date-time/calendar, dropdown/input, message, pagination, search suggestions, sidebar modes, popup examples, table compositions, tooltip positions и icon sizes.
- Зафиксированы границы: read-only просмотр не дал machine metadata component sets/properties, variables/styles/bindings, published keys и prototype reactions; component→frontend mapping остаётся `INFERENCE`.
- Добавлены 13 `UIR-DS-*` требований и 15 `GAP-UI-DS-*` вопросов/расхождений, включая отсутствующие описания, смешение Checkbox/Radio, `Pop-up/old`, semantic status colors и неполную матрицу экранных состояний.

### Подэтап 9.4

- Создана [`ui/screens/receiving-order-tabs-and-actions.md`](../ui/screens/receiving-order-tabs-and-actions.md): пять вкладок карточки поставки связаны с корневым и дочерними API, DTO, permissions, серверной валидацией и candidate-компонентами Figma.
- Для «Груза» зафиксирована зависимость UI от `deliveryType`; для «КТК» — scoped V2 list/batch и уровень `DELETE` на комбинированной пакетной операции; для «Рейсов» отделены одиночная связь `route` и транспортная строка.
- Review validation сопоставлена с целевыми вкладками и ожидаемой навигацией к полю/строке; отсутствие отдельной точки входа к Waybill на показанной карточке выделено как продуктовый пробел ЖД-сценария.
- Повторно подтверждены source-level риски: update использует `body.id`, публичный accept endpoint отсутствует, cargo preview защищён shipping permission и документирован неправильным OpenAPI response type, reject удаляет связи с Waybill.
- Добавлены 10 `UIR-REC-TRACE-*` требований и 10 `GAP-UI-REC-TRACE-*` вопросов. Связь screen/tab → HTTP request оставлена `INFERENCE`, потому что frontend repository и HAR в workspace отсутствуют.

### Дополнение 9.4a

- Подключён и просмотрен Figma-файл `Заявки на поставку`, file key `H9pcFGKBkZcIKXPH3O9W5H`, переданный node `1838:335356`; создана [`ui/figma/receiving-orders.md`](../ui/figma/receiving-orders.md).
- Инвентаризированы шесть страниц: служебная, склад/авто, КТК/авто, КТК/ЖД, накладные ЭТРАН и дополнительные состояния.
- Четыре складские группы сопоставлены как candidate mapping с четырьмя `ReceivingOrderDeliveryType`; термин «контейнер» в складской ветке отделён от КТК.
- Зафиксированы макеты create/view/edit, inline-создания контейнера, партии, рейса и типа ЗПУ, а также две группы ошибок смены статусов: `Черновик → Подтверждено` и `Выполнена → Отменена`.
- Страница ЭТРАН разделена на `Входящие`, `Исходящие`, `Архив` и `Дислокация`; их точные источники и правила оставлены открытыми до frontend/business trace.
- Добавлены 8 `UIR-FIG-RO-*` требований и 8 `GAP-UI-FIG-RO-*` вопросов. Figma хранится как `EXTERNAL_SNAPSHOT`, а frame→request — как `INFERENCE`.

### Подэтап 9.5

- Создана [`ui/screens/route-tabs-and-actions.md`](../ui/screens/route-tabs-and-actions.md): карточка рейса связана с detail/update/copy, актуальным grouped orders read-model, assign/unassign, lifecycle, shipping plan/fact, cargo-chain и пятью отчётными операциями.
- Поля снимка уточнены по `RouteDetailedDto`, `ClientDriverShortDto` и `ClientVehicleShortDto`; подтверждены phone/POA/insurance/trailer sources, а конец показанного временного интервала оставлен `OPEN_QUESTION` при единственном backend `dataTime`.
- Описана серверная последовательность create-from-order как две candidate-операции — создание Route и assign заявки — и риск частичного результата без атомарного endpoint.
- Validation/status errors сопоставлены с «Основным», «Заявками», plan/fact и меню отчётов; отдельно отмечены молчаливый пропуск unknown UUID, перенос между рейсами, чужой unassign, невосстановленный `needTransport` и удаление transport.
- Зафиксированы каскадный reject, снятие Waybill receiving-заявок, неидемпотентный повтор accept/outbound, обратная автоматическая синхронизация статуса, path/body ID mismatch и direct UUID scope/deleted risks.
- Добавлены 12 `UIR-ROUTE-TRACE-*` требований и 10 `GAP-UI-ROUTE-TRACE-*` вопросов. Frontend/HAR отсутствуют, поэтому screen→request и размещение plan/fact/report остаются `INFERENCE`/`OPEN_QUESTION`.

### Подэтап 9.6

- Создана [`ui/screens/receiving-order-create-edit.md`](../ui/screens/receiving-order-create-edit.md): шесть вариантов формы поставки связаны с root и дочерними DTO, conditional validators, permissions, lookup, inline-create и review errors.
- Четыре складских варианта разделены по `ReceivingOrderDeliveryType`; складские blackbox/cargo отделены от КТК, а авто-КТК — от ЖД-сценария на основании Waybill.
- Для корневых полей разделены create/update обязательность, фактическая изменяемость и review-required семантика; отдельно отмечены create-only payer/станции, `body.id`, nullable currency risk и различие строкового `waybill` со связью Waybill.
- Подтверждено отсутствие единого aggregate-save endpoint: root создаётся первым в `DRAFT`, транспорт/состав/Waybill сохраняются независимыми запросами, а review читает уже сохранённый агрегат. Partial success поэтому описан как нормальное промежуточное состояние, а не общий rollback.
- Дочерние редакторы прослежены до transport, good, blackbox, cargo, total cargo quantity, container, item и Waybill DTO; request validation отделена от более строгой review/accept validation.
- Зафиксировано расхождение источников: рабочий снимок показывает вкладки «Основное»/«Рейсы»/«КТК»/«Груз»/«Просмотр», а продуктовый Figma-холст — проектные зоны «Основное»/«Рейс»/«Номенклатура»/«Контейнеры»/«Просмотр»/«Документы».
- Добавлены 12 `UIR-REC-FORM-*` требований и 10 `GAP-UI-REC-FORM-*` вопросов по dirty/duplicate/partial states, retry/read-back, inline-create, immutable полям, structured errors и целевому batch API.

### Подэтап 9.7

- Создана [`ui/screens/shipping-order-create-edit.md`](../ui/screens/shipping-order-create-edit.md): форма вывоза прослежена от root create/update до товаров, cargo/blackbox, транспорта, ETRAN, номерных и количественных вагонов/КТК и items.
- `deliveryType` отделён от `fillingType`; складские варианты, авто-КТК `NONE_CONTAINER` и четыре ЖД plan/fact-модели сведены в единую матрицу состава и review validation.
- Для root-полей сопоставлены DTO-наличие и фактическая изменяемость. Подтверждено, что обычный update не переносит `deliveryType`, `fillingType` и `needTransport`, а path ID не сверяет с body ID.
- Смена `fillingType` описана как отсутствующая отдельная бизнес-операция, а не обычный UI-select: автоматической очистки plan/fact rows нет, БД не обеспечивает их взаимоисключение, route/outbound могут увидеть stale данные.
- Full-replace merge отделён от CRUD; зафиксированы `DELETE` permissions, семантика пустого списка, DTO `>=0` против SQL `>0`, транзакционный container qty merge и source-level неатомарный wagon qty merge.
- Отсутствие отдельного Figma/screenshot формы вывоза зафиксировано как evidence gap: UI-композиция не копировалась из поставки по аналогии.
- Добавлены 12 `UIR-SHIP-FORM-*` требований и 10 `GAP-UI-SHIP-FORM-*` вопросов о допустимой матрице, смене модели, qty-обязательности, source of truth consignee, aggregate save и accept API.

### Подэтап 9.8

- Создана [`ui/screens/service-order-create-edit.md`](../ui/screens/service-order-create-edit.md): форма заявки на услугу связана с root create/update/delete, выбором КТК, accept, owner history, `DONE` и outbound `SERVICE_ORDER_CHAIN_PACKAGE`.
- Зафиксирован бизнес-смысл `CHANGE_OWNER`: клиент заявки является будущим владельцем всех выбранных КТК; `ServiceOrder` отделён от транспортных заявок и имеет только `DRAFT → DONE`.
- Root-поля, permissions и изменяемость сопоставлены с creation/update/response DTO; отдельно отмечены DB limit комментария, page-only enrichment `containerQuantity` и отдельное право accept.
- Выбор КТК прослежен до `ServiceOrderContainerSaveDto`: существующая связь сохраняется по `id`, новый КТК добавляется по текущему `containerOwnerId`, оба значения имеют разную идентичность, а пустой список полностью очищает набор.
- Описаны транзакционные границы: saveSelected атомарно заменяет выбор под lock заявки; accept атомарно меняет владельцев, пишет историю, `DONE`, `completionAt` и outbound, но фактическая Datareon-доставка выполняется позже.
- Выделены partial/unknown accept, empty selection, `400/403/404/409/500`, direct-ID client scope, отсутствие optimistic version и race выбора одного КТК двумя разными DRAFT.
- Добавлены 12 `UIR-SERVICE-FORM-*` требований и 10 `GAP-UI-SERVICE-FORM-*` вопросов о preview смены владельца, expected owner, concurrency, компенсации, outbound status и отдельном макете.

## Выполненные проверки

- Доступны `docs/integrations`, три указанных AS-IS исследования, Product Vision и файл предыдущего ревью.
- В репозитории и родительском каталоге не найдены `AGENTS.md`, `CLAUDE.md` или `CONTRIBUTING*`. Корневой `README.md` описывает архитектуру, локальный запуск, Gradle/Spotless и Liquibase, но не задаёт отдельной процедуры для `docsforanalytics`.
- Текущий `HEAD` совпадает с базой предыдущего ревью: `22fac945e8116d04972ccc87b06b2303acf7a561`.
- Исходная инвентаризация: 584 Markdown-файла до добавления двух `_meta`-документов; после этапа 0 — 586. В составе каталогов: 415 generated DTO-паспортов, 114 JPA entity-паспортов, 11 mapped-superclass-паспортов, 119 контроллеров и 654 mapping-метода в текущем API-каталоге.
- Три генератора запущены в изолированной копии. Их результаты побайтно совпали с рабочими каталогами; рабочие каталоги не перезаписывались.
- Проверена разрешимость 4 506 локальных Markdown-ссылок во всех 586 документах, включая 41 ссылку в двух новых файлах: отсутствующих целей нет. Якоря визуально не рендерились.
- Перепроверены ключевые замечания предыдущего ревью: неправильное наследование `HierarchyDto`, ложные колонки для обратных JPA-коллекций, неполный nested DTO, конфликт простых имён DTO, пропуск подключённых WMS-контроллеров, неполнота HTTP-контрактов, отсутствие физического каталога БД и связей с тестами.
- Найдено дополнительное ограничение endpoint-генератора: запуск копии через `/tmp` на macOS завершается ошибкой `Path.relative_to` из-за канонизации пути в `/private/tmp`. Через канонический путь генерация проходит.

### Проверки подэтапа 1.1a

- Четыре unit-проверки: generic-bound не принимается за superclass; explicit import разрешает родителя при неоднозначном простом имени; same-package имеет однозначное разрешение; цикл и скрытое поле не создают повторов.
- На 415 текущих DTO: `HierarchyDto.superclass = BaseDto`, поля с наследованием — `id`, `code`, `parentId`, `totalElements`, `children`, `elements`; циклов разрешённого наследования не найдено.
- Две последовательные генерации дали одинаковые SHA-256 для всего DTO-каталога.
- Изменились только ожидаемые 10 generated-файлов: индекс и 9 паспортов. Количество типов осталось 415; один конфликт простого имени по-прежнему явно исключён.
- Во всех generated DTO-паспортах не найдено повторяющихся Java-полей; у `HierarchyDto` и `ClientGoodHierarchyDto` ровно одна строка `id`. Проверено 4 518 локальных Markdown-ссылок, отсутствующих целей нет.

### Проверки подэтапа 1.1b

- Семь unit-проверок проходят: четыре проверки `1.1a` и три проверки nested/FQCN/generic-resolution.
- По текущим исходникам найдено 417 top-level и 44 member nested-типа: 461 уникальный FQCN и 461 уникальный путь паспорта.
- Контекстно разрешены 14 групп совпадающих простых имён, включая три разных `Leftover`; неоднозначный глобальный fallback для них не применяется.
- `RailwayCarriageRemainSyncDto.Leftover` содержит шесть полей с фактическими `@JsonProperty`; `ClientGoodHierarchyDto.ClientGoodDto` содержит восемь собственных и четыре inherited-поля.
- В `ClientGoodHierarchyDto` generic-поля раскрыты как `List<ClientGoodHierarchyDto>` и `List<ClientGoodHierarchyDto.ClientGoodDto>` и ведут на правильные паспорта.
- Оба top-level `BaseActivatedUpdateDto` сохранены в разных package-путях. Потерянных или повторяющихся FQCN нет.
- Две последовательные генерации дали одинаковые SHA-256. В 461 паспорте нет повторных Java-полей; все 461 ссылки на Java-источник указывают на строку объявления типа.
- Проверено 4 771 локальное Markdown-ссылочное назначение во всех 632 документах: отсутствующих файлов нет. Визуальный рендер якорей не выполнялся.

### Проверки подэтапа 1.1c

- Десять unit-проверок проходят: семь проверок `1.1a–1.1b` и три проверки независимой семантики обязательности/null.
- В 3 025 строках полей с учётом наследования найдено: 28 primitive, 82 строки с `@Nullable`, 9 строк с явным Jackson null-policy и 556 строк с `@NotNull`/`@NotBlank`/`@NotEmpty`.
- В текущих DTO source roots не найдено ни одного `@JsonProperty(required = ...)`, поэтому generated-каталог честно показывает `JSON required: не задано`; распознавание конструкции защищено synthetic unit-тестом.
- [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md) показывает `eventCode` как reference с `@NotBlank`, но без декларации JSON required. [UserGroupCreationDto](../dto/catalog/usergroup/UserGroupCreationDto.md) отдельно показывает `Nulls.SKIP`, а [ContractCreationDto](../dto/catalog/contract/ContractCreationDto.md) — `@Nullable`.
- Две последовательные генерации дали одинаковый SHA-256 `1ab0f608…`; осталось 461 паспорт и один индекс, старой колонки «Обязательно» и значений `да (primitive)` нет.
- Проверено 4 779 локальных Markdown-ссылочных назначений во всех 632 документах: отсутствующих файлов нет. Визуальный рендер якорей не выполнялся.

### Проверки подэтапа 1.2

- Шесть unit-проверок генератора JPA проходят.
- По собственным полям 125 JPA-классов классифицировано: 544 basic column, 188 owning FK, 3 inverse association, 3 `@Formula`, 3 transient и 2 embedded. В текущем коде нет `@ManyToMany`, `@JoinTable`, `@ElementCollection` и `@CollectionTable`; их обработка проверена synthetic-тестом.
- [WaybillContainer.zpu](../entities/catalog/entities/waybillcontainer/WaybillContainer.md) и [Service.relatedServices](../entities/catalog/entities/service/Service.md) больше не показаны колонками: обе строки обозначены `inverse association` с конкретным owning side.
- Три вычисляемых поля `@Formula` не показаны физическими колонками; [ContainerTypeISO.code](../entities/catalog/entities/containertypeiso/ContainerTypeISO.md) учитывает inherited-поле и class-level `@AttributeOverride(name = "code", nullable = false)`.
- Для 25 сущностей без явного `@Table(name=...)` предполагаемое snake_case-имя удалено: паспорт показывает, что имя не задано в аннотации.
- Две последовательные генерации дали одинаковый SHA-256 `f8a4b595…`. В 125 паспортах проверено 1 367 строк таблиц, ошибок количества колонок нет.
- Проверено 4 786 локальных Markdown-ссылочных назначений во всех 632 документах: отсутствующих файлов нет. Визуальный рендер якорей не выполнялся.

### Проверки подэтапа 1.3

- Шесть unit-проверок endpoint-генератора и десять существующих DTO-проверок проходят.
- Из 124 файлов, совпавших с `*Controller*.java` в конфигурационных source scopes, один является аннотацией `ApiRestController`; mappings найдены у 123 классов: 119 ALIS и 4 WMS.
- Добавлено ровно 17 WMS mappings: `PermissionPathController` — 2, `RolePermissionController` — 5, `RoleController` — 7, `UserRoleController` — 3. Итого каталог содержит 671 mapping против прежних 654.
- `wms.controller.user` присутствует в `@ComponentScan`, но в текущем source tree не содержит controller classes; это отражено отдельной строкой с нулём. Не подключённые здесь `wms.controller.dictionary` и `wms.controller.uom` в каталог не добавлены.
- Непосредственные `@Profile`/`@Conditional*` на 123 включённых controller classes не найдены. Generated-паспорт не делает из этого вывод о безусловной runtime-доступности.
- Две последовательные генерации endpoint-каталога дали одинаковый SHA-256 `f4884016…`; две генерации DTO-каталога — одинаковый SHA-256 `ce358f04…`.
- Контрольные DTO-паспорта [RoleCreationDto](../dto/catalog/wms/role/RoleCreationDto.md), [RolePermissionCreationDto](../dto/catalog/wms/permission/RolePermissionCreationDto.md) и [InboundEventDto](../dto/catalog/datareon/inbound/InboundEventDto.md) показывают происхождение WMS/ALIS рядом с использованием в endpoint.
- В generated API проверено 123 FQCN-секции и 123 явных runtime-оговорки; WMS dictionary/uom controllers не попали в каталог. Проверено 4 853 локальных Markdown-ссылочных назначения во всех 632 документах, отсутствующих файлов нет.

### Проверки подэтапа 1.4

- Четырнадцать unit-проверок endpoint-генератора проходят. Из них восемь относятся к новому контрактному слою: путь не смешивается с `consumes`, семь категорий параметров имеют явную семантику, учитываются required/default/validation, наследование media type, explicit/default/dynamic status, OpenAPI error declarations, enum и два реальных controller-кейса.
- Состав 829 параметров: 460 body, 361 path, 2 query, 1 header, 3 model/form и 2 `other/unclassified`; в текущих контроллерах нет `@RequestPart`/cookie-параметров, но категории поддерживаются синтетической проверкой transport-аннотаций.
- В 671 mapping: 663 ответа имеют декларативный default `200 OK`, 8 возвращают `ResponseEntity` и помечены как определяемые handler; непосредственных `@ResponseStatus` в текущих controllers нет, его разбор проверен синтетически.
- Извлечено 1 291 `@ApiResponse`: 519×200, 3×204, 483×400, 2×403, 211×404, 71×406 и 2×409. У 827 деклараций content/schema не заданы — каталог теперь показывает это явно, не выводя error DTO по описанию.
- Найдено и раскрыто 18 enum-типов, непосредственно участвующих в сигнатурах включённых endpoints. Nested DTO продолжают вести на отдельные FQCN-паспорта этапа `1.1b`.
- Контрольные строки: [`DatareonController.handleEvent`](../api/endpoints-generated.md#datareoncontroller) показывает необязательный header и обязательное валидируемое тело `InboundEventDto`; [`TemplateController.uploadShippingOrder`](../api/endpoints-generated.md#templatecontroller) — `model/form`, `ExcelParsingFileDto`, multipart consumes и заявленную response schema.
- Две последовательные генерации дали одинаковый SHA-256 `23c077b…`; сохранились 123 контроллера и 671 mapping, пути не содержат ошибочно извлечённых media type.
- Проверено 5 300 локальных Markdown-ссылочных назначения во всех документах библиотеки: отсутствующих файлов нет. Якоря визуально не рендерились.

### Проверки подэтапа 2.1

- Текущий `HEAD` по-прежнему `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код не изменялся.
- У исследований затарки/растарки от 02.09.2026 и ЖД-завершения от 31.08.2026 отсутствует commit hash, поэтому они зарегистрированы как историческая база с частичной сверкой, а не как полностью актуальный AS-IS.
- На текущем коде выборочно подтверждены: состав `ContainerOwner` без status/order fields; отсутствие production enum `EXPECTED/ON_TERMINAL/RESERVED_OUT/DEPARTED`; раздельный same-order-type поиск занятости КТК обоими accept validators; `/datareon/event`; отсутствие shipping-вызова `tryMarkOrderDone()` после завершения wagon task при наличии такого вызова в receiving-ветке.
- Waybill-исследование выполнено на `3d8c8bb71a04fef2e9319d350ae7c0d1bfbaa318`, который является предком текущего commit. Между ними найден влияющий `42eee4ee`: изменены filter/sort для Waybill containers/railway carriages и `WaybillService`; ключевые entities/import/inbound/validator/parser из резюме исследования этим diff не менялись.
- В исследовании затарки/растарки проверена разрешимость всех 51 локальной Markdown-ссылки. Два ЖД-исследования не содержат Markdown-ссылок на исходники — только текстовые пути, поэтому автоматическая проверка их source references невозможна; это явно отмечено в реестре.
- В 633 Markdown-файлах библиотеки и трёх подключённых внешних исследованиях проверено 5 373 локальных ссылочных назначения: отсутствующих файлов нет. Mermaid проверен как исходный fenced-блок, визуальный renderer не запускался.

### Проверки подэтапа 2.2

- Просмотрены шесть Markdown-файлов `docs/integrations` общим объёмом 2 203 строки и четыре связанные PlantUML-схемы. Ни один Markdown-файл не содержит одновременно точную дату и commit; только Draft ТЗ имеет дату 31.08.2026, а lifecycle КТК — дату среза 25.08.2026.
- На `22fac945…` подтверждено наличие действующих `/datareon/contract`, `/contractor`, `/etran_railway`, `/etran_container` и `/waybill`; предлагаемый `/datareon/contract-with-client` отсутствует.
- Draft `tz-1c-edo-contract-with-client-api.md` отделён от реализации: BR-01–BR-11, TC-01–TC-17, новый error contract, миграции, идемпотентность и инфраструктурные требования зарегистрированы как TO-BE.
- Backend entrypoints/DTO справочных потоков ЭТРАН существуют, но описанные преобразования на Datareon не находятся в backend-репозитории и не подтверждались как deployed scripts.
- По Git установлено: commit `4e55d447eb554311d5d5e8dab8877011befccbfe` от 21.08.2026 изменил `WaybillIntegrationDto`, `WaybillDatareonService` и integration test; текущий `/waybill` принимает готовые `typeId`, `containerType` и ISO. Историческая причина из документа дефекта устарела, но текущий service всё ещё создаёт/обновляет справочные объекты.
- Локальные ссылки исходных интеграционных Markdown-файлов: 0/2/2/43/1/0 по шести документам, отсутствующих целей нет. Документы без ссылок используют текстовые имена классов и не имеют автоматической построчной трассировки.
- В 633 Markdown-файлах библиотеки, трёх верхнеуровневых исследованиях и шести интеграционных документах проверено 5 441 локальное ссылочное назначение: отсутствующих файлов нет. Четыре PlantUML-файла существуют; диаграммы визуально не рендерились.

### Проверки подэтапа 3.1

- `HEAD` перед работой совпал с зафиксированной базой `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, миграции и конфигурация не изменялись.
- По текущим controller/DTO/converter/service/action/security исходникам подтверждены прямой `InboundEventDto`, обязательность полей, преобразование UUID/site, config routing, `REQUIRES_NEW`, отдельное сохранение журнала, row lock вагона, HTTP `200` после action failure и публичность `/datareon/**` на уровне Spring Security.
- Полная найденная цепочка миграций `INBOUND_EVENT` содержит создание и последующее удаление unique index; других SQL/XML-определений uniqueness для `task_id` не найдено. Применённая схема БД не проверялась.
- Найденные integration tests просмотрены: shipping-сценарий утверждает `ShippingOrderRailwayCarriage=FINISHED` и `InboundEvent=DONE`, controller-сценарий — `SKIPPED` без config. Тесты не запускались.
- В новом документе есть один Mermaid flow; синтаксические fence-пары проверены как исходный Markdown, визуальный renderer не запускался.
- В 634 Markdown-файлах библиотеки проверено 5 371 локальное ссылочное назначение: отсутствующих файлов нет. Проверка whitespace ошибок изменений также замечаний не выдала.

### Проверки подэтапа 3.2

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; изменялась только документация.
- Сопоставлены четыре action-класса, два base action, converter, enum priority, config DAO, единственная найденная production-миграция и связанные unit/integration tests.
- В production changelog найден только `VH_DEPARTURE → VH_DEPARTURE`; остальные используемые тестами пары event/action не выданы за конфигурацию развернутой среды.
- По Git проверены влияющие commits `f2734e15…`, `e0c7a14d…`, `b90c74e8…` и `3a283b5a…`; документ фиксирует их конкретное влияние, а не только текущий HEAD.
- Найденные тесты просмотрены, но не запускались. Mermaid проверен как fenced source; визуальный renderer не запускался.
- В 635 Markdown-файлах библиотеки проверено 5 404 локальных ссылочных назначения: отсутствующих целей нет. Проверка whitespace ошибок изменений также замечаний не выдала.

### Проверки подэтапа 3.3

- `HEAD` перед работой совпал с базой `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, миграции и конфигурация не изменялись.
- Сопоставлены пять action-классов/общие base-классы, priority, обе контейнерные модели, Waybill export lifecycle, DAO-запросы завершения, converter и связанные unit/integration tests.
- По Git проверены полные commits `b2dd03a463b9b355b3f1c22004c5e6aeed619a8f`, `3a1f00279053ec55e0c666104e218bad4ea4c5a5`, `8b6244e696f3871c12e61b98cea901ff415e96b4`, `00629653ca7546e2c8163c8352d506e5b575a15b` и `ef43207b62de21dae5215559fdd29ff64ae76a70`.
- Production config для пяти receiving-actions в миграциях не найден; тестовые `eventCode → actionCode` не выданы за состояние применённой БД.
- Найденные тесты просмотрены, но не запускались. Две Mermaid-схемы проверены как fenced source; визуальный renderer не запускался.
- В 636 Markdown-файлах библиотеки проверено 5 434 локальных ссылочных назначения: отсутствующих целей нет. Проверка whitespace ошибок замечаний не выдала.

### Проверки подэтапа 3.4

- `HEAD` перед работой совпал с `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены оба controller, root/container services, BaseService, DTO/mapper, JPA/DAO/predicates, owner/history, outbound config/export/rest/scheduler, exception advice, миграции и доступные integration tests.
- По Git проверено влияние commits `ef43207b62de21dae5215559fdd29ff64ae76a70`, `9f6068389f73b2daf99c25c27060ae991ee75c19`, `1fa0a7834875d13b4fe95c1207794f854121e61a`, `f9b367dfd3a003bfaa80c4f06869abb6e6c7e060` и `ab2480a253dfaf932224e49bbfe901d7e3646c2f`.
- Тесты подтверждают page quantity, accept/outbound row, empty validation, availability query и owner history. Не найдены проверки CRUD controllers, `completionAt`, повторного accept, saveSelected mutations/concurrency и HTTP export/retry; тесты не запускались.
- Три Mermaid-схемы в двух сервисных документах проверены как fenced source; визуальный renderer не запускался.
- В 637 Markdown-файлах библиотеки проверено 5 473 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок в затронутых документах не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.5

- `HEAD` перед работой совпал с `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon/Waybill/receiving/legacy controllers, входной и пользовательские DTO, import/link services, JPA/DAO, grouped materialized view, initial constraints, exception advice и доступный integration test.
- По Git повторно учтено влияние `4e55d447eb554311d5d5e8dab8877011befccbfe` и `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18`; историческая классификация по sort/length явно помечена устаревшей.
- Integration test подтверждает создание агрегата, danger classifier, HTTP `400` неизвестного danger code и status-only update. Критические null/validation/concurrency/link/refresh ветки отдельными тестами не покрыты; тесты не запускались.
- Две Mermaid-схемы проверены как fenced source; визуальный renderer не запускался.
- В 638 Markdown-файлах библиотеки проверено 5 546 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок в документации не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.6

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены оба controller methods, входные DTO и cascade validation, integration services/mappers, общие Container/RailwayCarriage services, DAO/repositories, ISO service, enum converter, code validators, exception advice и Liquibase constraints/seed.
- По Git проверены commits `0fed0cd23a15e23fd331899336afc3cc103556df`, `1e46c564852d88d4bb13acb579a20479b4350e97`, `b133cd12098021e4414db148d9da429f7b8c5d7c` и `cd8ab54287495f1d40cc1e6b1acef831712c0252`.
- Direct tests endpoint/service import не найдены; просмотрены лишь RailwayCarriage update test и оба code-validator tests. Тесты не запускались.
- Три Mermaid-схемы проверены как fenced source; визуальный renderer не запускался.
- В 639 Markdown-файлах библиотеки проверено 5 590 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок в документации не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.7

- `HEAD` перед работой и после неё остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon и remain controllers, оба входных/nested DTO, incremental и async full-sync services, caches/loggers, DAO/repositories/predicates, JPA models/views, security configuration и Liquibase constraints/history.
- По Git проверено влияние commits `61b0fa01adddff2a1c201bf46d53f40ed92e2182`, `a6bf0bb8555b48c898e9bba5082ba9aae084c014`, `3981f5c9583047a3c4c0b6f2d9e5c416bcd6eb4c`, `60f814576dee9e07b45cb391e44191185a54c7e3`, `f08082096e5bc9b09906057dc285150940675db9`, `1f6193bae9540e9ab0b7095d65956aeac4fd8e5c`, `fa8dc53e367e95e87b2d45c72f9c90ccfde5ca92` и `6f2abb524dc380f526371ae4661f8c6574d17e20`.
- Прямых tests Datareon endpoints, incremental services и full-sync scenarios не найдено; просмотренный `ContainerRemainCacheServiceTest` покрывает только cache/unknown zone, а `ContainerRemainsDaoServiceTest` относится к `container_movement`. Тесты не запускались.
- Две Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 640 Markdown-файлах библиотеки проверено 5 621 локальное ссылочное назначение: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.8

- `HEAD` перед работой и после неё остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon/report/remain controllers, root/nested DTO, incremental/full-sync/cache/log/query services, repositories/predicates, ClientGood/GoodPackage/Batch/Cargo/Zone/TerminalArea/GoodRemain models, security/RLS и Liquibase table/view evolution.
- По Git проверено влияние commits `3699292728f15d4f953cee1c732f02eb0c1267e9`, `ab6480834c7bf6ee2bdf7ab8fc70a1c1ba578a80`, `bd0669045e469c1735ca65ee248cc23e62b011bf`, `819c0f2a7441cac668985ae9dff5d38db16ac916`, `5a162c8ca43be1646f7380f3a449b816bdc9d459`, `9555187618055d77837b34106f34c69d90fd9a1d` и `2005834e7d7189c8058d69a84c3034cfe96eff35`.
- Прямых tests transaction/synchronization/cache/query services, endpoints, DTO, DB edge cases, RLS и report не найдено. Тесты не запускались.
- Две Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 641 Markdown-файле библиотеки проверено 5 647 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.9

- `HEAD` перед работой и после неё остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon/Batch controllers, Datareon root/nested DTO, custom enum deserializer, BatchDatareon/Batch/ClientGood services, DAO/filter/predicate/repository, Base transaction/audit classes, GoodRemain dependency и Liquibase chain Batch.
- По Git проверено влияние commits `bd0669045e469c1735ca65ee248cc23e62b011bf`, `0d23560a8d924e6551206b79c2c6999584d5f041`, `82ff0e096eec05cdf69e16e89054f4461a8c0eea`, `962cffd827ea5142b84ba8aab457a76d67a9e4a7`, `fe5e73c1a275abc808041c4ffa4a5a51d6275f58`/merge `528d650c83865a33e279d13dbf220b7dff681ad9` и `625193966dc176a44095bdcc62dd4894be1de5c3`.
- Единственный `BatchDatareonServiceIntegrationTest` просмотрен: он подтверждает commit валидной строки и продолжение после unknown ClientGood, но не HTTP, поля update и edge/concurrency cases. Тест не запускался.
- Две Mermaid-схемы и один text fence проверены как закрытые Markdown blocks; визуальный renderer не запускался.
- В 642 Markdown-файлах библиотеки проверено 5 672 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.10

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены CellOccupancy/Datareon controllers, входные и outbound DTO, trigger/rest/inbound services, repository/JPA entity, security, exception advice и полная Liquibase chain таблицы/view.
- По Git проверено влияние commits `48218b0d16e140bd73be0d52d42e250ab1e90aa8`, `00014368187b5e12f4e0b66b6485a59027e37795`, `5cbaa7e4f4f50bef36c1304b2264e268fc293724`, `0a6c9a11b43f400019d992bce76865219ec19d31`, `d3e370db11453f73e21ebead0eabcb89b9dd584a`, `5b45baf1941eff3349f5203c0c4c4b67681e50f8` и `84204c4bb53ca9567beccfccee3797cee8559d2d`.
- Прямых tests trigger, inbound import, state, repository и DB edge cases не найдено; тесты не запускались.
- Две Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 643 Markdown-файлах библиотеки проверено 5 694 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.11

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon/Client controllers, Contractor/Client DTO, integration/Client services, MapStruct/base service update semantics, filters/predicates/DAO, JPA/BaseNamed, outbound config/export/scheduler, security, monitoring, exception advice и Liquibase evolution legal_entity → client.
- По Git проверено влияние commits `b67b2971707c0a1d8e296b8b50071776376722ac`, `5de66acd108609c94e123e3e2639a2ee025f613c`, `4212247da70d3ca69e7b3acd6a51f4a7f2bd68ef`, `a90b9076f153c8f9021b30e264bae782850505f1`, `ef2ea5afa102aa2b77f3f7cfc50a4181becadf05`, `22433aa6a97a944b2430122bbd79938ad8f73f3e`, `d3e370db11453f73e21ebead0eabcb89b9dd584a`, `5b45baf1941eff3349f5203c0c4c4b67681e50f8` и `84204c4bb53ca9567beccfccee3797cee8559d2d`.
- Прямых tests contractor endpoint/service/mapping/repeat/outbound не найдено; общий `ClientDaoServiceTest` и соседний contract test просмотрены, но не подтверждают Datareon contractor flow. Тесты не запускались.
- Две Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 644 Markdown-файлах библиотеки проверено 5 723 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.12

- `HEAD` перед работой и после неё остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Datareon/Contract controllers, внешний и внутренние Contract DTO, integration/Contract services и mapper, Client/Company/Currency lookup, filters/repositories, JPA/base models, security, monitoring, exception advice и Liquibase chain Contract.
- По Git проверено влияние commits `b67b2971707c0a1d8e296b8b50071776376722ac`, `5de66acd108609c94e123e3e2639a2ee025f613c`, `6dd2b1060cb1f6c6625692510ae8de045345c32d`, `ca20a974a6fc99ef40b2b675a250bfa7868eacfa`, `bcc7b08653f6c7896f4346ef404dce10989e4fb6`, `4212247da70d3ca69e7b3acd6a51f4a7f2bd68ef`, `a90b9076f153c8f9021b30e264bae782850505f1`, `ef2ea5afa102aa2b77f3f7cfc50a4181becadf05`, `7400c51cd27d3c07b48ad652c78ce5bcde7cee05`, `d3e370db11453f73e21ebead0eabcb89b9dd584a`, `5b45baf1941eff3349f5203c0c4c4b67681e50f8` и `84204c4bb53ca9567beccfccee3797cee8559d2d`.
- `ContractEdoDatareonServiceTest` проверяет только mapping с mocks, а `ContractDaoServiceTest` — generic DAO; controller/add/DB/repeat/errors/concurrency не покрыты. Тесты не запускались.
- Две Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 645 Markdown-файлах библиотеки проверено 5 760 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.13

- `HEAD` перед работой и после неё остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Company/Currency controllers, output DTO, filters/meta filters/predicates, generic and concrete services/mappers/DAO/repositories, JPA/base models, security, exception advice, Contract dependency и полные относящиеся Liquibase migrations.
- По source-wide write search не найдены production вызовы `CompanyDaoService.add/update`, `CurrencyDaoService.add/update`, repository save, seed INSERT либо другие controllers/imports; вывод ограничен текущим репозиторием и не переносится на live DB.
- По Git проверено влияние commits `11de138554ed6935c9906dd7f5716bef8f8c1889`, `0e530be7b92c4e0f03dc800f126a0c4fe2dbd4fb`, `b67b2971707c0a1d8e296b8b50071776376722ac`, `5de66acd108609c94e123e3e2639a2ee025f613c` и `3b299749ede9947a24dc618f0d9c182e708932be`.
- Company/Currency DAO tests, generic `MetaEndpointIntegrationTest` и mocked Contract mapping test просмотрены; собственные Company/Currency HTTP list/detail/meta, production import и duplicate/blank/inactive prerequisite cases не покрыты. Тесты не запускались.
- Две Mermaid-схемы и один JSON fence проверены как закрытые Markdown blocks; визуальный renderer не запускался.
- В 646 Markdown-файлах библиотеки проверено 5 790 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.14

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены Route controller/service/mapper/validators/listeners, status/filter/DAO/JPA, receiving/shipping order assignment and transition services, outbound config/export/chain packages, exception advice и Liquibase evolution Route/FK/permissions.
- По Git проверено влияние commits `bc3b0253`, `e9274902`, `21205c94`, `dc967139`, `df58d149`, `478fbaf8`, `4f27582d`, `6be797d0`, `038b3ee9`, `e58cd9ab`, `20f1bdd5`, `be70d83c`, `99beb122`, `52668052`, `f01ca620`, `3b299749`, `3256b8f0`, `49ce562d`, `6557b9e8`, `57c7ca6c` и `e86d8d50`.
- Route controller/integration/DAO и RouteExport tests просмотрены. Не найдены прямые tests assign/unassign ownership, path/body mismatch, deleted lifecycle, review/accept repeat/rollback, client restriction и concurrency; тесты не запускались.
- Пять Mermaid-схем проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 647 Markdown-файлах библиотеки проверено 5 814 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.15

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- Прослежены восемь RouteController mappings, RouteService builders, child DAO/default filters, четыре route view filters/predicates, MetaFieldQueryService, JPA view entities, rerunnable SQL views и physical qty/task/item migrations.
- По Git проверено влияние commits `d29256da`, `2f91bc07`, `e23a644f`, `4b61d802`, `fc6003c0`, `6ec772f5`, `3a283b5a`, `1e46c564`, `49ce562d` и `6557b9e8`.
- Source-wide test search не нашёл прямых tests восьми endpoints или четырёх views; `EntityInfoConsistencyTest` лишь исключает view entities из общей metadata-проверки. Тесты не запускались.
- Три Mermaid-схемы и один text fence проверены как закрытые Markdown blocks; визуальный renderer не запускался.
- В 648 Markdown-файлах библиотеки проверено 5 847 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.16

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config, templates и миграции не изменялись.
- Прослежены пять ReportController mappings, ReportService/strategy registry/base collector, четыре route collectors, Jasper/JXLS generators, report types, DTO/mappers, route/order DAO paths, permissions и exception advice.
- По Git проверено влияние commits `2cb29574`, `14d6f159`, `c89a8281`, `6611ec27`, `b2392502`, `49b109ed` и `84a9e5eb`.
- ReportServiceIntegrationTest просмотрен: два отрицательных route-order-count tests включены; успешный TH test отключён и относится к OrderReportType, а route available/positive-PDF/Excel/controller-streaming tests не найдены. Тесты не запускались.
- Три Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 649 Markdown-файлах библиотеки проверено 5 879 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.17

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config, Jasper templates и миграции не изменялись.
- Прослежены семь ReportController mappings, ReportService type detection/availability, strategy registry/base collector, пять PDF collectors, Jasper generator, report enum, PackingList DTO/mappers, DAO filters, permissions и exception advice.
- Проверены фактические JRXML expressions MX-1/MX-3/Packing List/M-7, включая direct null dereference событий/transport/company и multi-part M-7 merge.
- По Git проверено влияние commits `b67b2971`, `0e530be7`, `693c3cbf`, `602865e9`, `694950c2`, `141464c7`, `d03b174f`, `d06bd00b`, `e6de1276`, `24e0ddaa`, `443ae69a`, `6611ec27`, `b2392502`, `49b109ed`, `84a9e5eb` и `0b120809`.
- ReportServiceIntegrationTest просмотрен: positive MX-1/MX-3/two Packing List/M-7 и MX-1 not-found включены; ContainerTN success отключён; availability, permissions, negative eligibility, MIME/header/streaming tests не найдены. Тесты не запускались.
- Три Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 650 Markdown-файлах библиотеки проверено 5 923 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.18

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config, XLSX templates и миграции не изменялись.
- Прослежены четыре controller mappings, V1/V2 report services, strategy/base collector, два root collectors, BaseService/DAO/Paging/predicates, client restriction enrichment, DTO/mapper, JXLS generator, templates, permissions и exception advice.
- XLSX templates проверены как ZIP/XML: `receivingOrders`/`shippingOrders`, JXLS areas `A1:I2`, `sheetStreaming=true`, headers и expressions сопоставлены с DTO fields.
- По Git проверено влияние commits `7e50a680`, `576e8787`, `bd4ec3d3`, `905ef6e4`, `969e2059`, `14d6f159`, `d2c385b6`, `3256b8f0`, `84204c4b`, а также coupling filter commit `9791c676`.
- Source-wide test search не нашёл прямых tests четырёх mappings, root collectors или двух PageReportType; общий client restriction integration test не покрывает V2 null-body. Тесты не запускались.
- Три Mermaid-схемы проверены как закрытые fenced blocks; визуальный renderer не запускался.
- В 651 Markdown-файле библиотеки проверено 5 954 локальных ссылочных назначения: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.19

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config, XLSX templates и миграции не изменялись.
- Прослежены восемь controller mappings, V1/V2 report services, strategy/base collector, четыре collectors, BaseService/DAO/Paging, четыре filters/predicates, nested order predicate, client enrichment, DTO/mappers, JXLS generator, templates, permissions и exception advice.
- Четыре XLSX проверены как ZIP/XML: parameter names, JXLS areas, `sheetStreaming`, headers и cell expressions сопоставлены с текущими DTO getters.
- JXLS 3.0.0 bytecode подтверждает параметры evaluator `silent=false`, `strict=true`; source generator дополнительно использует `withExceptionThrower`.
- По Git проверено влияние commits `bd4ec3d3`, `576e8787`, `2e41bd43`, `c2d41a09`, `4d870bdd`, `1b0c4917`, `905ef6e4`, `969e2059`, `3ea221c0`, `443ae69a`, `29283833`, `3256b8f0`, `bf358e4e` и `978f0601`.
- Source-wide test search не нашёл прямых tests восьми mappings, четырёх collectors, PageReportType или templates. Соседние DAO/service/parser tests не запускают export pipeline; тесты не запускались.
- Три Mermaid-схемы и один text fence проверены как закрытые Markdown blocks; визуальный renderer не запускался.
- В 652 Markdown-файлах библиотеки проверено 5 990 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.20

- `HEAD` перед работой остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config, XLSX templates и миграции не изменялись.
- Прослежены восемь controller mappings, V1/V2 report services, strategy/base collector, четыре collectors, BaseService/direct Waybill DAO paths, четыре filters/predicates, client enrichment, DTO/mappers, JXLS generator, report enum, permissions и exception advice.
- Три существующих XLSX и legacy ЭТРАН XLSX проверены как ZIP/XML: parameter names, JXLS areas, headers и expressions сопоставлены с текущими DTO getters; отсутствие `reports/receiving_order_waybill.xlsx` проверено отдельно.
- JXLS behavior сопоставлен с уже подтверждёнными настройками evaluator `silent=false`, `strict=true` и `withExceptionThrower`.
- По Git проверено влияние commits `7e50a680`, `bd4ec3d3`, `576e8787`, `c2d41a09`, `4d870bdd`, `1b0c4917`, `905ef6e4`, `969e2059`, `1e0b0443`, `d2c385b6`, `443ae69a`, `3256b8f0`, `42eee4ee` и `978f0601`.
- Source-wide test search не нашёл прямых tests восьми mappings, четырёх collectors, четырёх report types или XLSX output. Соседние DAO/service/Waybill tests не запускают export pipeline; тесты не запускались.
- Три Mermaid-схемы проверены как закрытые Markdown blocks; визуальный renderer не запускался.
- В 653 Markdown-файлах библиотеки проверено 6 016 локальных ссылочных назначений: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.21

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, XLSX templates, runtime config и миграции не изменялись.
- Прослежены восемь controller mappings, четыре collectors и filters/predicates, четыре response DTO/mappers, report types, BaseService/client enrichment, BaseReport transaction и JXLS behavior.
- Четыре XLSX проверены как ZIP/XML: JXLS parameter names/areas и expressions сопоставлены с фактическими DTO getters; JXLS/HTTP runtime и визуальный renderer не запускались.
- По Git проверено влияние commits `7e50a680`, `576e8787`, `4d870bdd`, `1b0c4917`, `905ef6e4`, `969e2059`, `14d6f159`, `d2c385b6`, `de31b4fb`, `29283833` и `3256b8f0`.
- Source-wide test search не нашёл прямых export mappings/collector/XLSX output tests; тесты не запускались.
- Три Mermaid-схемы проверены как закрытые fenced blocks; renderer не запускался. В 654 Markdown-файлах библиотеки проверено 6 059 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.22

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, XLSX templates, runtime config и миграции не изменялись.
- Проверены восемь controller mappings, V1/V2 services, четыре collectors, filters/predicates, DTO/mappers, старая shipping ЭТРАН entity/DTO chain, report types, BaseService/client enrichment и exception path.
- Четыре XLSX разобраны как ZIP/XML с JXLS comments, shared strings и точными cell references; templates сопоставлены с DTO getters. Фактическое JXLS/HTTP исполнение не проводилось.
- По Git сопоставлены commits `7e50a680`, `576e8787`, `c2d41a09`, `905ef6e4`, `969e2059`, `14d6f159`, `1e0b0443`, `d2c385b6`, `fd8aa53e`, `443ae69a` и `3256b8f0`.
- Source-wide test search не нашёл direct tests восьми endpoints, четырёх collectors или XLSX content. Тесты не запускались.
- Три Mermaid-схемы проверены как закрытые fenced blocks; renderer не запускался. В 655 Markdown-файлах библиотеки проверено 6 107 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.23

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, auth/runtime config и миграции не изменялись.
- Прослежены `ReportController`/`ReportControllerV2`, permission enum/path/level, `Secure`/`Secures`, `PermissionAspectConfiguration`, `PermissionCheckStrategy`, `RolePermissionServiceImpl`/DAO/tree, JWT security, `ExceptionAdvice`, PDF eligibility collectors и Excel filter-enrichment paths.
- Проверены SQL migrations report permission paths и source-wide наличие/отсутствие статических role grants именно для выбранных report paths; live DB, Keycloak и applied migrations не проверялись.
- `PermissionCheckStrategyTest` и `RolePermissionServiceImplTest` просмотрены; прямых tests report permission matrix/OR availability/V1-V2 grants/client ownership/global child export не найдено. Тесты не запускались.
- По Git сопоставлены commits `b67b2971`, `c037494a`, `cbf478f8`, `905ef6e4`, `443ae69a`, `6611ec27` и `0b120809`.
- Три Mermaid-схемы проверены как закрытые fenced blocks; renderer не запускался. В 656 Markdown-файлах библиотеки проверено 6 148 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений.

### Проверки подэтапа 3.24

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, auth/runtime config и миграции не изменялись.
- По исходникам сопоставлены 17 WMS mappings, DTO validation, Keycloak facade/role/user-role services, permission controller/service/DAO/SQL migration, aspect/check strategy, JWT converter, event/cache flow и `ExceptionAdvice`.
- Прочитаны mocked `RolePermissionServiceImplTest` и `PermissionCheckStrategyTest`; прямых tests WMS controllers, string-path mismatch, cross-role record ID, role deletion orphan, cache visibility или JWT refresh не найдено. Тесты не запускались; runtime, Keycloak и applied schema не проверены.
- По Git сопоставлены `c037494a`, `cbf478f8`, `1e2012cc`, `972ce6c7`, `3859af95`, `76698b4a` и `7661266b`.
- Две Mermaid-схемы представлены закрытыми fenced blocks; renderer не запускался. В 657 Markdown-файлах библиотеки проверено 6 196 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений. Проверка не даёт гарантии валидности якорей или исполняемой схемы.

### Проверки подэтапа 3.25

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, security/runtime config и миграции не изменялись.
- По исходникам проверены 17 ALIS group mappings, DTO validation/defaults, `UserGroupService`/Keycloak facade, `ClientUserGroupService`/DAO/predicate, `FilterEnrichServiceImpl`/`RestrictionFilter`/`BaseIdentifierPredicate`, JWT/SecurityUtils, UserInfo и SQL migration создания/rename связей.
- Просмотрены `UserGroupServiceTest`, `UserGroupControllerTest`, `ClientUserGroupServiceIntegrationTest`; они не проверяют empty intersection, path/body owner, Keycloak partial failure или production auth. Тесты не запускались; приложение, Keycloak, applied schema и runtime grants не проверены.
- По Git сверены commits `c037494a`, `4f4cdc881`, `2d3d0f454`, `8397b6bf`, `6a17c5a2`; найденное поведение описано относительно текущего checkout.
- Две Mermaid-схемы представлены закрытыми fenced blocks; renderer не запускался. В 658 Markdown-файлах библиотеки проверено 6 244 локальные ссылки: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений. Это не тест runtime SQL/result.

### Проверки подэтапа 3.26

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime config и миграции не изменялись.
- По исходникам проверены три UserSetting mappings, Map/DTO, `SecurityUtils.getUserId`, service delete/insert/fallback, predicate/null owner, `SearchString` case behavior, repository/advice, JPA model и relevant migration chain/default UUID.
- `UserSettingServiceIntegrationTest` просмотрен: тестируется замена одного ключа при сохранении другого; HTTP/JWT owner/default/migration/race/case tests не найдены. Тесты не запускались, applied schema и live data не проверялись.
- По Git сопоставлены commits `9b4bcd91`, `3ca963c4`, `b17d27b8`, `3c8ce192`, `15f90451`; source-level SQL effect latest migration подтверждён текстом.
- Две Mermaid-схемы проверены как закрытые fenced blocks; renderer не запускался. В 659 Markdown-файлах библиотеки проверено 6 273 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений. Это не подтверждение runtime/security поведения.

### Проверки подэтапа 3.27

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; бизнес-код, runtime/security config и миграции не изменялись.
- По исходникам сопоставлены четыре UserInfo mappings, DTO/filters, JWT authority converter/SecurityUtils, Keycloak profile attributes, role-name map/permission forest/strategy, client-user-group restriction, Client DAO predicate и monitoring flag.
- `UserInfoServiceIntegrationTest` и mocked `PermissionCheckStrategyTest` просмотрены; direct UserInfo controller, empty-client/NO_ACCESS/role drift/page-meta negative tests не найдены. Тесты не запускались; runtime Keycloak/БД/JWT/proxy не проверены.
- По Git сопоставлены commits `2d3d0f45`, `cdae4eec`, `d3aceae5`, `0ab5f3ae` и ранее подтверждённые JWT/permission changes.
- Две Mermaid-схемы проверены как закрытые fenced blocks; renderer не запускался. В 660 Markdown-файлах библиотеки проверено 6 318 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок не найдено; tracked business tree остаётся без локальных изменений. Это не подтверждение runtime client leakage.

### Проверки подэтапа 4.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и миграции не изменялись.
- Сопоставлены `ReceivingOrderController`, три request DTO, MapStruct declarations, `ReceivingOrderService`/`BaseService`, JPA наследование и ключевые SQL changesets ALG/KIS, включая cumulative order v1.33 → v1.34. По Git проверены influencing commits `a90b9076`, `92867cc3`, `78cd428f`, `3e30ddea`, `443ae69a`.
- Просмотрен `ReceivingOrderServiceIntegrationTest`; тесты не запускались, generated MapStruct и applied DB не инспектировались. Mermaid block закрыт; renderer не запускался.
- В 661 Markdown-файле библиотеки проверено 6 378 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок и `git diff --check` не найдено; tracked дерево остаётся без локальных изменений. Проверка ссылок не проверяет anchors или фактические SQL-результаты.

### Проверки подэтапа 4.2

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и миграции не менялись.
- Сверены `ReceivingOrderTransportController`, три DTO/`IdDto`, mapper declarations, transport service/`BaseService`, `ReceivingOrder.transport`/child JPA entity и SQL chain ALG-199/430/568, KIS-282/1106. По Git проверены `11de1385`, `13918fb6`, `c9294b26`.
- Просмотрены `ReceivingOrderTransportDaoServiceTest` и его factory: проверяют DAO positive cases, но не прямой HTTP path/body mismatch, FK failure, reference ownership или изменяющийся справочник. Тесты не запускались; generated MapStruct, приложение и applied DB не проверялись.
- В 662 Markdown-файлах библиотеки проверено 6 407 локальных ссылок: отсутствующих целей нет. Mermaid block закрыт, но renderer/anchors не проверялись; whitespace-ошибок нет, tracked business tree без изменений.

### Проверки подэтапа 4.3

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сверены `ReceivingOrderGoodController`, Creation/Update DTO и `IdDto`, mapper declarations, `ReceivingOrderGoodService`/`BaseService`, JPA model, SQL chain ALG-272/568/842, KIS-1508/1624 и writer `WmsReceivingResultAction`. По Git проверены commits `11de1385`, `0e530be7`, `783899ed`.
- `ReceivingOrderGoodServiceIntegrationTest` просмотрен: source содержит положительные add/update/remove totals и auto-cargo tests; прямых HTTP/price formula/null batch/list rollback/WMS negative tests не найдено. Тесты не запускались; generated MapStruct, приложение и applied DB не проверялись.
- Одна Mermaid-схема представлена закрытым fenced block; renderer не запускался. В 663 Markdown-файлах библиотеки проверены 6 435 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.4

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены `ReceivingOrderCargoController`, Creation/Update DTO/`IdDto`, mapper/ObjectMapper, cargo/good/root/requested-service service paths, JPA fields и SQL chain ALG-274/311/559, KIS-1134/1135/1567/1746. По Git проверены commits `11de1385`, `be2fd261`, `80b4dbb0`, `53e847f2`.
- `ReceivingOrderCargoValidationTest`, `ReceivingOrderCargoServiceIntegrationTest` и DAO test source просмотрены; они покрывают DTO positive/negative числовые ограничения и service positive derivation/totals/soft delete, но не HTTP mismatch, cross-parent linkage, null optional field vs SQL и applied schema. Тесты не запускались, generated MapStruct/приложение/БД не проверялись.
- Одна Mermaid-схема закрыта как fenced block, renderer/anchors не проверялись. В 664 Markdown-файлах библиотеки проверены 6 469 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет, tracked business tree без изменений.

### Проверки подэтапа 4.5

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сверены ReceivingOrderContainer controller/DTO/class validator/mapper/service/DAO/predicate, parent JPA, нужные item-service weight methods и `TosReceivingResultAction`; SQL chain ALG-573/578/635/670/727/843/851, KIS-167/282/1970/2003/2013/3297/3631. По Git проверены `11de1385`, `4c076ef7`, `3ea221c0`, `5dd0dc5a`, `443ae69a`.
- `ReceivingOrderContainerServiceIntegrationTest` и `ReceivingOrderContainerServiceTest` просмотрены: positive totals/empty/items/preview/requested-service tests есть, direct conditional validator/TOS duplicate/weight-writer-conflict tests не найдены. Тесты не запускались; generated MapStruct, приложение, applied DB и внешние TOS payloads не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 665 Markdown-файлах библиотеки проверены 6 507 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.6

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены ReceivingOrderContainerItem controller/Creation/Update DTO/mapper/service/JPA, parent/root/good service writers, SQL ALG-576, KIS-282/2003/2906/3297/3631 и `ReceivingOrderContainerItemFilter.byOrderContainer`. По Git проверены `11de1385`, `13918fb6`, `3ea221c0`, `4b733baf`.
- `ReceivingOrderContainerItemServiceIntegrationTest` и `ReceivingOrderContainerItemListServiceTest` просмотрены: первый проверяет positive root **price**, второй list grouping; root/parent weight, cross-parent pair, old parent transfer, null Container, negative values и HTTP path/body ID напрямую не проверяются. Тесты не запускались; generated MapStruct, приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 666 Markdown-файлах библиотеки проверены 6 541 локальная ссылка: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.7

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены ReceivingOrderRequestedService controller/Creation/Update DTO/mapper/service/JPA, required-row builder в ReceivingOrderService, cargo/container callbacks и WMS/TOS actual writers; SQL AGL/ALG-311, ALG-471/580/764 и KIS-413. По Git проверены `11de1385`, `693c3cbf`, `6c02802e`.
- `ReceivingOrderRequestedServiceServiceIntegrationTest`, parent cargo/container integration sources и DAO test просмотрены: direct REQUEST/CARGO_PLACE calculations, VAT и direct root totals покрыты; required initial totals, duplicate/contract ownership/systemManaged mutation, automatic row→root drift, rounding и actual writers напрямую не проверяются. Тесты не запускались; generated MapStruct, приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 667 Markdown-файлах библиотеки проверены 6 576 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.8

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены ReceivingOrderBlackbox controller/Creation/Update/response DTO/mapper/service/filter/JPA, Cargo find-or-create, BaseService/DAO update-delete semantics, root copy/counter, Excel parser, accept validator, ItemReceivingTask export и remain view; SQL KIS-742/KIS-1134. По Git проверены `1e4f8f22`, `be2fd261`, `b390898a`, `f19442d9`, `52668052`, `978f0601`.
- `ReceivingOrderBlackboxServiceIntegrationTest`, `ReceivingOrderAutoWarehouseContainerParserTest`, accept-validator integration source и outbound unit test просмотрены: direct positive counter/type/update/delete и parser/accept/outbound cases покрыты; duplicate direct create, repeated delete, multi-add, Excel counter/type mismatch, concurrency, null deleted и view multiplicity — нет. Тесты не запускались; приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 668 Markdown-файлах библиотеки проверены 6 610 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.9

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены WaybillIntegrationDto/DatareonController/WaybillDatareonService, Waybill controller/service/mapper/DAO/filter/predicate/JPA, ReceivingOrderEtranInvoice compatibility controller, repository bulk link и reject cleanup; SQL KIS-2273, KIS-3481/3482 и KIS-3631 chain. По Git проверены `feb37a42`, `ce939d57`, `443ae69a`, `84598b3a`, `4ff9dac6`, `4e55d447`.
- `WaybillDatareonServiceIntegrationTest` и `WaybillDaoServiceTest` просмотрены: create root/children, danger/reference paths, status-only repeat, DAO CRUD/filter и bulk links покрыты; nested validation/null dates, duplicate number, concurrent identifier, link status/access/reassignment and migration conflicts — нет. Тесты не запускались; приложение, async refresh и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 669 Markdown-файлах библиотеки проверена 6 641 локальная ссылка: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.10

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены WRC controller/compatibility controller, DTO/mapper/service/filter/predicate/repository/JPA, Waybill Datareon/Excel writers, outbound manifests и `CarriageArrivedAction`; SQL KIS-2273, KIS-3234 и KIS-3631 chain. По Git проверены `feb37a42`, `ce939d57`, `443ae69a`, `1378d120`, `cd8ab542`, `42eee4ee`.
- Integration/unit test sources подтверждают `FINISHED` и `UPLOADED`/multi-Waybill collapse; duplicate pair, null all-finished semantics, Excel new-Waybill identifier и DELETE cascade/postRemove напрямую не покрыты. Тесты не запускались; приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 670 Markdown-файлах библиотеки проверены 6 668 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.11

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены WC controller/DTO/mapper/service/filter/predicate/repository/JPA, Container/ContainerOwner, Waybill Datareon/Excel writers, ZPU, grouped/legacy read, route export, CarriageArrived и TosReceivingResult; SQL KIS-2273, KIS-3482, KIS-3631 и KIS-3785. По Git проверены `feb37a42`, `ce939d57`, `443ae69a`, `c4c21382`, `9460879a`, `00629653`, `0ee0d12d`, `cd8ab542`.
- Import/inbound/owner test sources просмотрены: create count, FINISHED, service/movement, not-all-finished и owner change покрыты; constraints/duplicates/cascade/read net-weight/status regression/Excel snapshot — нет. Тесты не запускались; приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 671 Markdown-файле библиотеки проверена 6 691 локальная ссылка: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.12

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены product controller/DTO/mapper/service/filter/predicate/repository/JPA, Waybill Datareon validation/mapping, ETSNG/DangerProduct/DangerClass, grouped/read totals и railway route-package exporter; SQL KIS-2273, KIS-2906, KIS-3631 и KIS-4352. По Git проверены `feb37a42`, `ce939d57`, `443ae69a`, `935edac2`, `4ff9eb7c`, `4ff9dac6`, `cd8ab542`.
- Waybill integration tests подтверждают product create и danger classifier/lookup/error/eager-fetch paths; все field mappings, outbound cardinality, nullable ЕТСНГ migration, duplicates, weight override и HTTP read endpoints напрямую не покрыты. Тесты не запускались; приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 672 Markdown-файлах библиотеки проверены 6 715 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.13

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены два inbound nested DTO/list aliases, Waybill Datareon mapping/replay, mark controllers/DTO/mappers/services/filters/predicates/repositories/JPA и SQL KIS-2273. По Git проверен `feb37a42`; последующих предметных изменений mark-классов/таблиц не найдено.
- Waybill integration fixture проводит по одному special/tariff mark через happy path, но не утверждает их counts/content. Null/empty/duplicate lists, numeric conversion, repeat/cascade, page DTO и nested filter не покрыты; тесты не запускались, приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 673 Markdown-файлах библиотеки проверены 6 737 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.14

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены rerunnable SQL/include order, GroupedWaybillView/model/filter/predicate/repository/DAO, Waybill controller/service/mapper, event publisher/listener, dropdown queries, Excel writer и base paging. По Git проверены `feb37a42`, `ba7f5d64`/`443ae69a`, `19cb1665`, `229c7d86`, `f52bef29`, `5fff5e70`, `169505ec`, `4d6db879`, `826dbd80`.
- `GroupedWaybillDaoServiceTest` подтверждает route+payer grouping, суммарные WRC/WC counts, product/Waybill IDs и zero/empty children. Status/incoming filters, nullable payer, duplicates, sort/page, DTO hybrid read, async refresh/failure и security не покрыты; тесты не запускались, приложение и applied DB не проверялись.
- Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 674 Markdown-файлах библиотеки проверены 6 759 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.15

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Повторно сведены 14 физических паспортов частей 1–13 и materialized часть 14: направления parent/global FK, shared PK транспорта, nullable ReceivingOrder↔Waybill, cascade tree, soft-delete, business uniqueness, cross-parent gaps, write paths и stored/read aggregates.
- Проверены крупные влияющие commits из детальных паспортов: `11de1385`, `be2fd261`, `feb37a42`, `ce939d57`/`443ae69a`, `19cb1665`/`229c7d86`, `4ff9dac6`, `4e55d447`, `42eee4ee`. Новые тесты не запускались; сводка переиспользует ранее просмотренные source tests.
- Две Mermaid-схемы закрыты как fenced blocks; renderer/anchors не проверялись. В 675 Markdown-файлах библиотеки проверены 6 782 локальные ссылки: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки подэтапа 4.16

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены ShippingOrder creation/update/read DTO, mapper, root service/DAO/controller/JPA, common BaseService, combination/accept validators, status enum, root-altering Liquibase и все найденные root aggregate writers.
- По Git проверены ключевые влияния `11de1385`, `f2734e15`, `c4e6bf2c`, `80b4dbb0`, `a90b9076`, `bc3b0253`, `e58cd9ab`, `52d3c091`, `78cd428f`/`ec84d091`, `d29256da`, `3a283b5a`, `fa27bf56`.
- Source tests связаны с create без optional fields, consignee, review/reject/accept validation, copy и stored totals; тесты не запускались. Одна Mermaid-схема закрыта как fenced block; renderer/anchors не проверялись. В 676 Markdown-файлах библиотеки проверены 6 840 локальных ссылок: отсутствующих целей нет. Whitespace-ошибок нет; tracked business tree без изменений.

### Проверки корректирующего аудита после 3.29/4.24/5.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Повторно сопоставлены обработка `DataIntegrityViolationException`, ограничения `INBOUND_EVENT`, транзакционная граница `ActionsProcessor`, writers `shipping_order.total_weight` и отсутствие production-вызова `ShippingOrderService.accept(UUID)`.
- В 688 Markdown-файлах проверены 7 346 локальных ссылок: отсутствующих целей нет; незакрытых fenced blocks нет.
- Проверка ограничена исправленными утверждениями; остальные выводы подэтапов 4.17–4.24 и 5.1 полностью заново не аудировались. Приложение, БД и тесты не запускались.

### Проверки подэтапа 4.25

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены оба controller, creation/update/grouped/unnumbered DTO, mapper, service, JPA entity/DAO/filter, accept-validator, контейнерная связь, inbound actions, root transport-manifest и route-chain-package exporters.
- Просмотрены CREATE и последующие ALTER/index migrations; ключевые изменения связаны с commits `b67b2971`, `0e530be7`, `693c3cbf`, `0fc7134b`, `3ea221c0`, `b3733c1f`, `5318381a`, `3d4d34d7`, `dfc12682`, `cd8ab542`.
- В 689 Markdown-файлах проверены 7 386 локальных ссылок: отсутствующих целей нет; незакрытых fenced blocks и trailing whitespace нет.
- Service/DAO integration tests прочитаны, но не запускались. Применённая схема, runtime security, HTTP response и внешняя интеграция не проверялись.

### Проверки подэтапа 4.26

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены legacy/V2 controllers, creation/update/merge/detailed/short DTO, mapper, service, JPA/DAO/filter, accept-validator, wagon cascade, transport-manifest path и SQL ALG-631/ALG-682/KIS-1621.
- По Git проверены влияния `b67b2971`, `845acb69`, `57c7ca6c`, `18d7e6d5`, `9d0c3087`, `443ae69a`, `cd8ab542`.
- DAO и accept-validator integration tests прочитаны, но не запускались. Применённая схема, runtime permissions/client scope, HTTP response и production outbound не проверялись.

### Проверки подэтапа 4.27

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены controller, три DTO, mapper, service/BaseService, JPA/DAO/filter/predicate, accept-validator, RouteService, route meta-view, route chain package exporter и SQL KIS-3352/KIS-3663/KIS-3356/KIS-4321.
- По Git проверены влияния `d29256da`, `0a8c1bb5`, `b33f9401`, `9ca9eb80`, `fc6003c0`, `1e46c564`, `49ce562d`, `6557b9e8`, `4ff9eb7c`, `0b2c6b91`, `8691a93e`, `cd8ab542`.
- Два service integration tests uniqueness прочитаны, но не запускались. Применённая схема, runtime permissions/client scope, HTTP response и production outbound не проверялись.

### Проверки подэтапа 4.28

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены controller, три parent DTO, nested ETSNG DTO/service, mapper, container qty service/BaseService, JPA/DAO/filter/predicate/repository, accept-validator, stored total writers, RouteService/RouteExportService, route meta-view и route chain package exporter.
- Просмотрены SQL KIS-3352/KIS-3663 и Git-влияния `d29256da`, `eeac19c4`, `b33f9401`, `19315731`, `9ca9eb80`, `4b61d802`, `2f962915`, `3a283b5a`, `cd8ab542`, `49ce562d`, `6557b9e8`, `4ff9eb7c`, `0b2c6b91`.
- Шесть container qty integration tests и RouteExportService unit tests прочитаны, но не запускались. Применённая схема, runtime permissions/client scope, HTTP response и production route package не проверялись.

### Проверки подэтапа 4.29

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены три child DTO, mapper, child/parent services, JPA/DAO/filter/predicate/repository, BaseService scoped merge, accept-validator, parent nested filter/sort/meta, route view/read и route chain package exporter.
- Просмотрены SQL KIS-3352/KIS-3663 и Git-влияния `d29256da`, `55be7d74`, `2f91bc07`, `b33f9401`, `9ca9eb80`, `4b61d802`, `2f962915`, `4c7d689b`, `23723581`, `cd8ab542`, `49ce562d`, `6557b9e8`, `4ff9eb7c`, `0b2c6b91`.
- Один direct child и относящиеся parent integration tests прочитаны, но не запускались. Применённая схема, runtime permissions/client scope, HTTP response, единицы веса и production route package не проверялись.

### Проверки подэтапа 4.30

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сводная карта повторно сопоставлена с 13 детальными моделями, их services/validators, cumulative SQL, route read/meta, route chain package и outbound-границами.
- Проверены 693 Markdown-файла и 7 507 локальных ссылок: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались. Applied Liquibase/`pg_catalog`, реальные stale/duplicate rows, runtime permissions/client scope, транзакции и production outbound не проверялись.

### Проверки подэтапа 4.31

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Проверены переходы `shipping-orders → integrity map`, `orders → integrity map` и обратные ссылки карты на 13 детальных физических моделей.
- Проверены 693 Markdown-файла и 7 510 локальных ссылок: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались: подэтап меняет только Markdown-навигацию и не добавляет новых утверждений о runtime.

### Проверки подэтапа 6.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены `ShippingOrderController`, creation/update DTO, MapStruct contract, `BaseService.update`, `ShippingOrderService`, `OrderCombinationValidator`, child filling-type guards, accept-validator, SQL constraints, route data/meta и route chain exporter.
- Проверено, что update controller не принимает path ID параметром, а `ShippingOrderService.prepareModelToUpdate` не содержит присваивания `fillingType`; это source-level вывод, не результат runtime HTTP-теста.
- Проверены 694 Markdown-файла и 7 532 локальные ссылки: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались; generated mapper bytecode, runtime error mapping, applied schema, live permissions/client scope и production consumer не проверялись.

### Проверки подэтапа 6.2

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Сопоставлены `DatareonController.handleEvent`, root/nested DTO, Jackson annotations, Bean Validation, `ExceptionAdvice`/`ExceptionAdviceUtils`, converter, `TerminalAreaService`, event service/config registry и controller/converter tests.
- Source flow однозначно объясняет фактический `400`: validation выполняется до controller, поэтому мониторинг, converter, event log и actions не вызываются.
- Проверены 695 Markdown-файлов и 7 544 локальные ссылки: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались; production adapter/gateway, deployed ObjectMapper, live terminal/config rows, timezone источника и monitoring/TOS semantics не проверялись.

### Проверки подэтапа 6.3

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Полный prompt сопоставлен с [`tz-checklist`](../traceability/tz-checklist.md), двумя эталонными результатами, coverage limitations и open-items ownership; обязательные слои API/DTO/service/DB/integration/permissions/tests сохранены.
- Проверены переходы из карты заявок и чек-листа в шаблон, а из шаблона — в coverage, change log, open items и оба заполненных кейса.
- Проверены 696 Markdown-файлов и 7 558 локальных ссылок: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались: подэтап создаёт только Markdown-шаблон анализа и не меняет runtime.

### Проверки подэтапа 6.4

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Проверены все шесть документов раздела traceability, корневой README, coverage и обратные навигационные переходы.
- Индекс не добавляет новых утверждений о бизнес-поведении: он маршрутизирует к уже проверенным документам и сохраняет их ограничения достоверности.
- Проверены 697 Markdown-файлов и 7 587 локальных ссылок: отсутствующих целей нет; незакрытых fenced-блоков и trailing whitespace нет.
- Тесты не запускались: подэтап меняет только Markdown-навигацию.

### Проверки подэтапа 7.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Четыре unit-теста `test_check_docs.py` прошли: корректные ссылки/fences, диагностика missing target/unclosed fence/trailing whitespace, пути с пробелами/URL encoding и ненулевой exit code CLI.
- Новый checker успешно проверил всю библиотеку: 697 Markdown-файлов и 7 591 локальную ссылку; отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Checker не сверяет валидность Markdown-якорей, фактический render Mermaid и свежесть generated-каталогов относительно Java-исходников; подключение к CI не выполнялось.

### Проверки подэтапа 8.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Checker успешно проверил 705 Markdown-файлов и 7 648 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Создан только каркас и единые правила описания: бизнес-владельцы, определения терминов и паспорта конкретных объектов/процессов ещё не подтверждены предметными экспертами.

### Проверки подэтапа 8.2

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Checker успешно проверил 706 Markdown-файлов и 7 672 локальные ссылки: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- В словаре определены 22 `TERM-*`, 7 `SYS-*` и 4 `GAP-GLOSSARY-*`; повторяющихся ID среди строк-определений нет.
- Определения сопоставлены с текущими документами заявок, Waybill, Route, остатков, Batch и интеграционным индексом. Предметная экспертиза и production-проверка не выполнялись.

### Проверки подэтапа 8.3

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Checker успешно проверил 707 Markdown-файлов и 7 689 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Шесть строк-определений `GAP-SYSTEM-*` уникальны; карта не присваивает WMS/TOS/CRM неподтверждённую принадлежность к 1С и не объявляет Datareon master-системой по факту маршрутизации.
- Runtime-маршруты, deployed Datareon, фактические отправители `eventCode` и бизнес-владельцы систем не проверялись.

### Проверки подэтапа 8.4

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Checker успешно проверил 708 Markdown-файлов и 7 706 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Все 12 строк-определений `GAP-SOT-*` уникальны; матрица не выдаёт inferred-кандидатов operational master за `BUSINESS_CONFIRMED`.
- Бизнес-master, владельцы данных, production delivery и правила разрешения конфликтов требуют ответов аналитика/предметных владельцев; runtime-проверка не выполнялась.

### Проверки подэтапа 8.5

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, runtime config и migrations не менялись.
- Checker успешно проверил 709 Markdown-файлов и 7 723 локальные ссылки: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Все 16 строк-определений `ROLE-*` и 10 строк `GAP-ROLE-*` уникальны; RACI и названия организационных ролей явно имеют состояние `PROPOSAL`/`INFERENCE`, а не `BUSINESS_CONFIRMED`.
- Фактическая оргструктура, владельцы процессов и маппинг business role → Keycloak/permission/client scope не проверялись и требуют предметного согласования.

### Проверки подэтапа 9.1

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, frontend, runtime config и migrations не менялись.
- DOCX успешно отрендерен без ошибок в две страницы; обе страницы и четыре исходных изображения просмотрены визуально, текстовые абзацы и метаданные извлечены отдельно.
- Checker успешно проверил 712 Markdown-файлов и 7 749 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Все 25 определений `UIR-*` и 17 определений `GAP-UI-*` уникальны; будущее перемещение Waybill не помечено реализованным, а screen→API не помечен `SOURCE_CONFIRMED` без frontend evidence.
- Стенд, версия приложения, роль пользователя, frontend source, network trace, формы/контекстные действия и runtime Superset не проверялись.

### Проверки подэтапа 9.2

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked бизнес-код, frontend, runtime config и migrations не менялись.
- DOCX успешно отрендерен в четыре страницы; все страницы и семь исходных изображений просмотрены в исходном разрешении.
- Проверены поля DTO и controller mappings поставки, вывоза, рейса и клиента; status translations взяты из enum, а screen→request не объявлен подтверждённым.
- Checker успешно проверил 719 Markdown-файлов и 7 789 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- В библиотеке 49 уникальных определений `UIR-*` и 40 уникальных определений `GAP-UI-*`, включая по одному placeholder в шаблоне; дубликатов нет.
- Стенд, версия, роль, frontend routes/components, network trace, скрытые формы/действия и Superset dataset/RLS/freshness не проверялись.

### Проверки подэтапа 9.3

- Список всех страниц считан непосредственно из Figma UI; каждая предметная page была открыта, а ключевые холсты просмотрены визуально.
- Figma не использована как доказательство реализованного frontend request или server behavior; наблюдение design state отделено от Word snapshot и backend source.
- Checker успешно проверил 722 Markdown-файла и 7 804 локальные ссылки: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Четыре unit-теста `test_check_docs.py` прошли без ошибок.
- Все 62 определения `UIR-*` и 55 определений `GAP-UI-*` уникальны, включая placeholder-шаблона; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; tracked business code не изменялся.
- Не подтверждены Figma version/history, component properties/keys, variables/styles, reactions, WCAG/keyboard behavior и соответствие frontend-компонентам.

### Проверки подэтапа 9.4

- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source, migrations и runtime configuration не менялись.
- В workspace не найден frontend project (`package.json`, Angular/Vite/Nx configuration или frontend source tree), поэтому фактические routes, components и HTTP requests не объявлены подтверждёнными.
- Перепроверены `ReceivingOrderController`, дочерние container/item V2 controllers, cargo/good/transport controllers, route assign/unassign и уже документированная review/accept validation.
- Checker успешно проверил 723 Markdown-файла и 7 830 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 72 определения `UIR-*` и 65 определений `GAP-UI-*` уникальны; дубликатов нет.
- Runtime UI, HAR, role matrix, server error rendering и Figma→frontend implementation не проверялись.

### Проверки дополнения 9.4a

- Все шесть страниц продуктового Figma-файла открыты; верхнеуровневые группы складской, авто-КТК, ЖД-КТК и ЭТРАН страниц просмотрены через дерево слоёв и холсты.
- Read-only режим не предоставил inspect metadata, prototype reactions и осмысленные имена большинства отдельных frames; numbered frames не интерпретировались по догадке.
- Candidate mapping четырёх складских вариантов проверен по `ReceivingOrderDeliveryType`, сервисам good/blackbox/cargo и total-cargo-quantity; Figma не объявлена доказательством фактического request.
- Checker успешно проверил 724 Markdown-файла и 7 842 локальные ссылки: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 80 определений `UIR-*` и 73 определения `GAP-UI-*` уникальны; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source и конфигурация не менялись.

### Проверки подэтапа 9.5

- Перепроверены `RouteController`, Route create/update/read DTO, nested driver/vehicle DTO, `RouteStatus`, lifecycle/assign/unassign, shipping plan/fact и route report contracts.
- Figma использована только как подтверждение наличия проектного действия «Создание нового рейса»; атомарный create+assign flow и фактический frontend request не объявлены подтверждёнными.
- Checker успешно проверил 725 Markdown-файлов и 7 861 локальную ссылку: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 92 определения `UIR-*` и 83 определения `GAP-UI-*` уникальны; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source, migrations и runtime configuration не менялись.
- Не проверены frontend/HAR, реальная role/client matrix, runtime plan/fact/report UI, повтор accept после timeout и поведение create Route без успешного assign.

### Проверки подэтапа 9.6

- Перепроверены root create/update DTO и сервис, `OrderCombinationValidator`, DTO и controllers транспорта, товаров, blackbox, cargo, КТК/items и bulk-связи Waybill, включая class-level validator КТК.
- Figma использована только как проектное доказательство шести сценариев, inline-create и композиции зон; фактические frontend requests, autosave и save orchestration не объявлены подтверждёнными.
- Checker успешно проверил 726 Markdown-файлов и 7 888 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 104 определения `UIR-*` и 93 определения `GAP-UI-*` уникальны; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source, migrations и runtime configuration не менялись.
- Не проверены frontend/HAR, runtime role/client scope, deployed feature flags, applied DB, structured error response, autosave и фактическая обработка partial/duplicate requests.

### Проверки подэтапа 9.7

- Перепроверены `ShippingOrderCreationDto`/`UpdateDto`, root service/JPA semantics, `OrderCombinationValidator`, accept-validator и DTO/controllers товаров, cargo, blackbox, transport, containers/items, ETRAN, wagon/container qty и ETSNG.
- Plan/fact mapping сверена с физической integrity-картой и отдельными моделями qty; отсутствие UI-макета не подменялось backend inference.
- Checker успешно проверил 727 Markdown-файлов и 7 914 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 116 определений `UIR-*` и 103 определения `GAP-UI-*` уникальны; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source, migrations и runtime configuration не менялись.
- Не проверены frontend/HAR, отдельный Figma flow вывоза, runtime permissions/client scope, applied DB, реальная атомарность merge, autosave, structured errors и production route/outbound со stale rows.

### Проверки подэтапа 9.8

- Перепроверены `ServiceOrderController`, `ServiceOrderContainerController`, create/update/response/save DTO, root/container services, status/type enums и уже документированный owner/outbound lifecycle.
- UI-композиция не объявлена AS-IS: отдельный screenshot/Figma/frontend source отсутствует, поэтому server contracts отделены от `PROPOSAL` секций формы.
- Checker успешно проверил 728 Markdown-файлов и 7 927 локальных ссылок: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет.
- Все 20 unit-тестов `docs/docsforanalytics/scripts/test_*.py` прошли без ошибок.
- Все 128 определений `UIR-*` и 113 определений `GAP-UI-*` уникальны; дубликатов нет.
- `HEAD` остался `22fac945e8116d04972ccc87b06b2303acf7a561`; application source, migrations и runtime configuration не менялись.
- Не проверены runtime roles/client scope, applied schema, конкурентный выбор КТК, реальная Datareon-доставка/retry, frontend/HAR и будущие ServiceOrderType.

### Проверки подэтапа 5.2

- `Этран 27-2.docx` отрендерен в 147 страниц; страницы просмотрены обзорными contact sheets, а страницы со схемой, фильтром статусов, outbound-настройкой и handler `etran_27` проверены в полном размере.
- Из Word извлечены 4 783 paragraphs и 10 inline images; C#-алгоритм сопоставлен с текущими `WaybillIntegrationDto` и `WaybillDatareonService` на commit `22fac945…`.
- Excel содержит один лист `Etran27`, 125 строк с заголовком и 124 строки модели; подтверждены 6 массивов, 116 nullable-строк, 8 non-null-строк и 0 включённых проверок заполнения.
- Проверены 700 Markdown-файлов и 7 623 локальные ссылки: отсутствующих целей, незакрытых fenced-блоков и trailing whitespace нет; все 118 уникальных имён узлов/полей Excel присутствуют в паспорте контракта.
- Deployed 1С/Datareon, реальный outbound JSON, gateway, единицы источника, retry и runtime Jackson не проверялись; найденные риски преобразования единиц не объявлены production-дефектами без контрольного payload/DB результата.

Наличие 187 файлов в `src/test`/`src/integrationTest` установлено поиском. Тесты не запускались, а их связь с правилами ещё не описана.

## Открытые вопросы и неподтверждённое

- Не проверено, какие Spring mappings реально зарегистрированы на развернутой среде. Каталог доказывает наличие controller mapping в source package, охваченном текущим `@ComponentScan`, но не итоговый Spring context, security chain, context path, reverse proxy или фактическую доступность маршрута.
- Не проверена применённая схема БД. Для корня `receiving_order` составлена source-level модель; остальные таблицы ещё не сведены в физический каталог.
- Не подтверждены фактические маршруты и mappings Datareon, объекты 1С, состояние ЭТРАН и макеты Figma.
- Дополнительные исследования содержат как AS-IS, так и предложения; перед включением в библиотеку их нужно классифицировать и сверить с commit `22fac945…`.
- `docs/docsforanalytics` пока не отслеживается Git в текущем checkout, поэтому журнал не является частью истории репозитория.
- У 13 типов родитель остаётся нераскрытым, потому что он находится вне текущих DTO source roots (`BaseFilter`, `BaseIdFilter`, `FilterWithPaging`, `HashMap`, `PageImpl`, `BaseIdentifier`). Это явно отмечается в generated-паспортах и не исправлялось догадками.
- Парсер покрывает member nested `class`/`record`/`interface`/`enum` в DTO source roots, но остаётся статическим regex/scanner-анализом, а не Java compiler AST. Локальные и анонимные классы намеренно не каталогизируются.
- В DTO source roots нет `@JsonProperty(required = ...)` и `@JsonCreator`; фактическое поведение отсутствующего JSON-ключа зависит от конфигурации ObjectMapper и способа создания DTO и не выводится генератором.
- Условная бизнес-обязательность остаётся предметом ручных процессных документов и серверных validators; DTO-паспорт не пытается вывести её из имени или Java-типа.
- JPA-паспорта теперь не выдают inferred physical names за подтверждённые, но применённая схема БД и полная цепочка Liquibase не проверялись; SQL-типы, NULL/DEFAULT, PK/FK, UNIQUE/CHECK и индексы остаются вне generated JPA-слоя.
- Генератор JPA остаётся статическим parser-анализом. В текущих моделях отсутствуют `@ManyToMany`, `@JoinTable`, `@ElementCollection`, `@CollectionTable`, `@EmbeddedId` и `@AssociationOverride`; поддержка части конструкций проверена только synthetic-тестами.
- Endpoint-каталог остаётся статическим scanner-анализом: он не исполняет Spring, не разворачивает composed annotations кроме локального `@ApiRestController`, не анализирует exception advice и ветвления handler. Два Java-параметра без transport-аннотаций сохранены как `other/unclassified`, а не угаданы как query или инфраструктурные значения.
- Из 1 291 OpenAPI response declarations у 827 отсутствует явный content/schema. Фактический формат ошибок нельзя вывести только из `description`; отдельный анализ exception advice остаётся ручной работой соответствующего процесса.
- Два верхнеуровневых исследования не фиксируют commit, а Waybill-исследование относится к старому `3d8c8bb7…`; реестр снижает риск неверного использования, но не заменяет их полную предметную актуализацию.
- Текстовые source references в исследованиях ЖД-завершения и Waybill пока не преобразованы в кликабельные ссылки и не проверены автоматически построчно.
- Интеграционные материалы не фиксируют полноценную source version; справочные документы ЭТРАН объединяют backend-факты с неподтверждёнными в этом репозитории скриптами Datareon.
- Draft ТЗ 1С:ДО не реализовано: отсутствуют новый endpoint, согласованный внешний контракт, сетевой маршрут, authentication и подтверждение правил отбора договоров.
- Документ дефекта `/waybill` остаётся историческим после `4e55d447…`; текущий AS-IS вынесен в `business-rules/waybill-etran-as-is.md`, но исходный файл дефекта не переписывался.
- Для `CARRIAGE_ARRIVED` не подтверждены production config mapping, внешний Datareon transform/envelope, ограничения gateway и применённая DB-схема; исходники ALIS не гарантируют дедупликацию по `_id`.
- Для остальных shipping actions не подтверждены production mappings кроме `VH_DEPARTURE`, внешний payload transform и порядок config-строк одинакового priority; WMS nullable batch и три config/status anomaly остаются дефектами/рисками AS-IS, а не предложениями исправления.
- Для receiving actions не подтверждены production mappings, внешний envelope/transform и порядок одинакового priority; `CARRIAGE_ARRIVED` не учитывает WaybillContainer в вагонном условии `DONE`, WMS test закомментирован, а nullable batch падает до журнала.
- Для ServiceOrder не проверены runtime-роли, применённая схема, Datareon `/serviceOrder` и идемпотентность потребителя; конкурентный выбор одного КТК в разные `DRAFT`, повторная проверка owner при accept и row-level доступ по конкретному ID остаются рисками AS-IS.
- Для Waybill не проверены внешний Datareon transform/auth gateway, deployed ЭТРАН, live schema и runtime-роли. Nested validation, status-only replay, справочные перезаписи, конкурентный create, async stale view и bulk link без status/row-level проверки остаются рисками AS-IS.
- Для справочных импортов ЭТРАН не проверены deployed Datareon scripts, исходный контракт 1С, единицы, live schema и gateway. `MessageID` не даёт идемпотентности, update очищает поля, конкурентный upsert не защищён, а direct import tests отсутствуют.
- Для остатков КТК/вагонов не проверены внешние full-sync источники, production payloads/единицы, live schema и runtime security `/remain/**`. `MessageID` не дедуплицирует, Datareon допускает partial success, full sync удаляет снимок до fetch, а direct inbound/full-sync tests отсутствуют.
- Для остатков товаров не проверены внешний full-sync WMS, production payload/единицы, live schema и runtime roles. `MessageID`/timestamp не управляют идемпотентностью/порядком, `packageId` игнорируется, full sync удаляет до fetch, а direct tests отсутствуют.
- Для Datareon Batch не проверены production payloads, live schema и gateway. `MessageID` не дедуплицирует, active игнорируется, syncId не является lookup key, element errors скрыты за `200`, а единственный service test не покрывает HTTP и edge cases.
- Для занятости ячеек не проверены production payload/callback, единицы weight/height, live schema, gateway и runtime permissions. Trigger очищает снимок до отдельного callback, inbound только добавляет строки без ключа/идемпотентности/общей транзакции, а state основан на пустоте таблицы и минимальном id; direct tests отсутствуют.
- Для Datareon Contractor не проверены production payload, отбор 1С:ДО, live schema, gateway и внешний `/contractor`. Current update существующего edoId откатывается на code NOT NULL, blank id снимает lookup predicate, DB unique edoId отсутствует, а успешный create ставит обратное outbound-сообщение с другим ID; direct tests отсутствуют.
- Для Datareon Contract не проверены production payload, порядок после Contractor, live schema, gateway и внешние retry. `_id` не обеспечивает идемпотентность, blank Client/Company может выбрать произвольную запись, lookup Currency не даёт предметной ошибки, `name` остаётся null, а direct HTTP/repeat/concurrency tests отсутствуют.
- Для Company/Currency не установлен runtime-источник наполнения: текущий backend публикует только чтение, миграции не содержат справочных INSERT, live data/applied constraints не проверены. Нет подтверждённых правил unique/normalization/active для `Company.edoId` и `Currency.code`, от которых зависит импорт договора.
- Для Route не проверены runtime mappings/roles, live schema, Datareon delivery и client row-level access прямых UUID endpoints. Update игнорирует path ID, assign/unassign не защищают принадлежность заявки, automatic sync обходит transition map, deleted route остаётся доступен прямым lifecycle-методам, а повторный accept способен создать повторный outbound.
- Для route shipping views не проверены live SQL definitions/data и UI expectations. Data/meta имеют разные filling/deleted/join semantics; unknown/receiving route даёт пустой `200`, meta может видеть soft-deleted route, row-level client scope не обогащается, а nested data читается без общего snapshot.
- Для route reports не проверены runtime security/streaming, фактические templates/output и client scope прямых UUID-вызовов. Availability скрывает причину отказа, unavailable direct TN ожидаемо даёт `500` вместо заявленного `400`, общий Excel игнорирует UI-фильтр и грузит весь набор, а положительный route-TN и три Excel-пути прямыми тестами не покрыты.
- Для order PDF reports не проверены runtime MIME/security/streaming, фактические production PDF и client scope direct UUID. Availability скрывает причины, не валидирует все template dependencies и не имеет общего snapshot; M-7 с отсутствующим событием может быть показан доступным и затем упасть, а unavailable download ожидаемо даёт `500` вместо заявленного `400`.
- Для root order Excel exports не проверены runtime roles/proxy, production XLSX, объём данных и streaming response. V2 без body пропускает client restriction в отличие от `{}`, обе версии грузят весь набор через `Integer.MAX_VALUE`, server max rows и прямые HTTP/filter/content tests отсутствуют.
- Для первой части receiving child Excel exports не проверены runtime roles/gateway и фактическая генерация. V1 не проверяет client ownership path UUID, V2 без body глобально включает soft-deleted, child filters не получают client RLS, Container template ожидаемо несовместим с DTO, Item ЕТСНГ expression сомнительна, а прямые export tests отсутствуют.
- Для второй части receiving child Excel exports не проверены runtime roles/gateway и фактическая генерация. V1 не проверяет client ownership path UUID, V2 допускает глобальный scope, child filters не получают client RLS, Requested Service template несовместим с DTO getters, новый Waybill template отсутствует, а прямые export tests не найдены.
- Для первой части shipping child Excel exports не проверены runtime roles/gateway и фактическая генерация. V1 не проверяет client ownership path UUID, V2 допускает глобальный scope и deleted строки без body, child filters не получают client RLS; Container XLSX обращается к отсутствующим DTO getters, Item ЕТСНГ expression требует runtime-проверки, а direct export tests отсутствуют.
- Для второй части shipping child Excel exports не проверены runtime roles/gateway, live ЭТРАН и фактическая генерация. Shipping сохраняет старую ЭТРАН-модель при receiving Waybill migration; V1 не проверяет owner path UUID, V2 допускает global/deleted scope, child filters не получают client RLS, ЭТРАН/вагонные шаблоны имеют старые заголовки вне area, а direct export tests не найдены.
- Для отчётных permissions не проверены deployed JWT security profile/issuer, gateway, Keycloak roles, RolePermission rows и live data. `@Secure`/paths подтверждают method gate, но не фактические grants или client ownership. Parent/child права наследуются через role forest, а availability/direct/V1/V2 используют разные наборы требований; прямых матричных tests нет.
- Для WMS roles/permissions не проверены runtime controller registration, Keycloak grants/assignments, применённая WMS migration, actual cache/event timing и текущие JWT. String `Role.PermissionPath` не соответствует enum; cross-role update/delete использует record ID без owner/path-ID сверки; role delete не чистит persisted permissions. Эти source-level выводы требуют прямых HTTP/DB tests перед утверждением production поведения.
- Для групп/клиентского доступа не проверены runtime JWT claims, Keycloak membership, применённые `client_user_group` constraints и конкретные SQL/HTTP read paths. Group-role API меняет direct user realm roles; URL group ID не сверяется с body/filter; empty `anyOfId` после intersection игнорируется предикатом. Нужны negative security tests и live данные для подтверждения фактического scope.
- Для UserSetting не проверены deployed JWT claims/issuer, применённая `1.35.0` миграция, фактические overrides и UI-потребитель. Нет прямых tests fallback/null owner/case variant/concurrent writes; миграция содержит `DELETE FROM user_setting` без ограничения по default user ID. Для оценки потери персональных значений нужны применённая история Liquibase и снимок/backup БД, а не только JPA.
- Для UserInfo не проверены live Keycloak profile, JWT refresh, permission cache/grants, доступные Client rows и monitoring delivery. `GET /userInfo` пустой client set не превращает в deny, summary содержит `NO_ACCESS` пути и не доказывает доступ к данным; нужны negative SQL/HTTP tests.
- Для корня `receiving_order` не проверены применённые Liquibase changesets, `pg_catalog` constraints/indexes/defaults, реальная `UNIQUE(number)`, отсутствие FK на `shipper_id` и присутствие отдельного `carrier_id`. Source chain показывает двойной источник номера и nullable/aggregate differences, но их runtime эффект не подтверждён.
- Для `receiving_order_transport` не проверены применённость ALG-430 `DELETE`, FK names/ON DELETE/индексы, реальное состояние удалённых snapshot-колонок, path/body mismatch и справочный snapshot effect на работающем приложении. Нужны `DATABASECHANGELOG`/`pg_catalog`, негативные HTTP/DB tests и контрольный сценарий изменения ClientDriver/ClientVehicle.
- Для `receiving_order_good` не проверены применённость ALG-272 `DELETE`, фактические FK/index/precision constraints, UI price calculation, owner consistency и обработка WMS actualQuantity. Нет прямых tests price multiplication, null batch clearing, path/body mismatch и поздней ошибки списка; внутренний `super.add/update` call path делает атомарность списка неподтверждённой.
- Для `receiving_order_cargo` не проверены применённость ALG-311 `DELETE`, фактический UNIQUE/индексы/FK names, cross-parent good/order consistency, optional null dimensions при SQL NOT NULL, null goodPackage update и package/total formula в разных API путях. JPA `@OneToOne` root противоречит SQL source/test multiple rows; нужна инспекция applied schema и прямые negative HTTP/DB tests.
- Для `receiving_order_container` не проверены applied SQL UNIQUE после ALG-670, FK/index/array constraints, HTTP conditional validator edge cases, soft-deleted duplicate/count race, unknown КТК со ссылками owner/seal/danger и TOS taskId/qty на deployed среде. Parent/item services пишут root `total_weight` по разным формулам; нужен прямой последовательный DB/API test и решение об authoritative source для ТЗ.
- Для `receiving_order_container_item` не проверены applied parent/root FK and CHECK/index/precision, cross-parent ID cases, old parent weight after transfer, неизвестный КТК с null catalog Container, negative gross/net/place values, rollback и end-to-end Waybill compatibility. Root total_goods_price и total_weight перезаписываются конкурирующими сервисами; нужны прямые последовательные DB/API tests прежде чем закреплять одну формулу в ТЗ.
- Для `receiving_order_requested_service` не проверены applied FK/index/NUMERIC conversion, VAT property deployed среды, duplicate root+term, принадлежность условия договору при direct create, изменение/удаление systemManaged строки, WMS/TOS actual и атомарность. Required DAO insert и автоматический CARGO_PLACE reprice не вызывают явный root-total recalculation; возможное отставание stored quantity/price требует последовательного DB/API test.
- Для `receiving_order_blackbox` не проверены applied FK/index/null data, direct duplicate root+Cargo, повторный DELETE, multi-add transaction, concurrent Cargo creation и доступ к незащищённому в source `/all`. Excel DAO insert обходит delivery-type check/root increment, outbound использует одновременно active rows и root counter, remain view связывает blackbox только по Cargo без deleted/parent; нужны последовательные HTTP/DB/view tests.
- Для `waybill` не проверены applied UNIQUE/FK/indexes, duplicate number data, number-based legacy migration conflicts, nested DTO null cases, concurrent same-identifier import, async grouped refresh и external gateway. Repeat обновляет только status; link/bulk не проверяют status/client ownership и могут перепривязать чужую Waybill, а legacy `/all` source не имеет `@Secure`; нужны HTTP/DB/migration/concurrency tests.
- Для `waybill_railway_carriage` не проверены applied FK/indexes, duplicate pair data, отрицательные snapshot values, null-status business semantics, Excel manual Waybill с SQL-required identifier и runtime-защита compatibility `/all`. Физический DELETE каскадирует WaybillContainer/ZPU; успешность последующего поиска и soft-delete соответствующих ReceivingOrderContainer зависит от ORM flush order и требует прямого integration test.
- Для `waybill_container`/`waybill_zpu` не проверены applied FK/index/CHECK, duplicate pairs, null/duplicate seals, справочный overwrite и unit conversion, конкурентный import, status regression и cascade вне WRC compatibility delete. TOS actual quantity теряется; persisted WC netWeight не используется grouped/legacy DTO, а single-result repository queries небезопасны при допустимых схемой дублях.
- Для `waybill_product` не проверены applied FK/index/precision, duplicate rows, units/positivity/formulas, null ЕТСНГ в legacy migration, BigDecimal→Double loss, grouped/read totals и route-package cardinality на legacy/manual data. При одном product без containers outbound product исчезает; 2+ products без container приводят к `get(0)` — прямых tests нет.
- Для `waybill_special_mark`/`waybill_tariff_mark` не проверены applied FK/index/VARCHAR, production payload и UI-потребитель. Null lists ломают first import, duplicate/all-null rows допустимы, text tariff code нормализуется через Integer, повтор не синхронизирует marks, parent отсутствует в page DTO, а nested Waybill predicate выглядит некоррелированным; нужны прямые HTTP/SQL integration tests.
- Для `grouped_waybill` не проверены applied definition/index, query plan/volume, фактическая refresh latency/concurrency, runtime grants и nullable payer. Projection может устареть после Excel/child writers; async failure скрыт от клиента, DTO смешивает materialized и live state, random ID/default pagination нестабильны, tab sorting теряется и client restriction не найден.
- Для сводного ReceivingOrder↔Waybill-контура не проверены applied FK/cascade/UNIQUE/indexes и реальные дубли. Нет end-to-end tests cross-parent Cargo/Item, physical root delete, полного cascade tree, двух container-контуров, всех конкурирующих total writers и refresh после non-Datareon changes.
- Для корня `shipping_order` не проверены applied Liquibase, `pg_catalog`, реальные дубли номера/defaults/FK/indexes и runtime HTTP. Path ID update не используется, nullable currency update способен упасть до SQL, source FK consignee не найден, часть update DTO игнорируется, accept endpoint отсутствует, а четыре totals имеют конкурирующих writers; нужны прямые HTTP/DB/sequential tests.
- Для `shipping_order_railway_carriage` не проверены applied FK/indexes, реальные дубли, runtime permissions и production outbound. Нет DB business UNIQUE/composite wagon↔container guard; update duplicate-check имеет конфликтный порог, global ETRAN не проверяется на membership, nullable owners нельзя безопасно очистить, optional-body preview и неизвестная ETRAN-group имеют NPE-риск, а nullable ETRAN конфликтует с manifest exporter.
- Для `shipping_order_etran_invoice` не проверены applied FK/indexes, реальные дубли, runtime permissions/client scope и production outbound. Нет DB business UNIQUE; update duplicate-check имеет конфликтный порог; ShortDto подменяет ID связи ID накладной; merge и legacy `/all` не имеют явного `@Secure`; update переносит связь без каскада и проверки статуса новой заявки.
- Для `shipping_order_railway_carriage_qty` не проверены applied constraints/indexes, реальные данные KIS-4321, runtime permissions/client scope и production route package. DTO допускает zero против DB CHECK, merge source-level неатомарен, nullable type теряется в meta-view, а stale qty после смены filling type может попасть в outbound.
- Для `shipping_order_container_qty` не проверены applied constraints/indexes, реальные дубли signatures, runtime permissions/client scope и production route package. DTO допускает zero quantity/weight против DB CHECK, items не каскадируют validation, loaded uniqueness не защищена от concurrency, route view повторяет ID, stored total имеет competing writers, а stale qty/items экспортируются без filling-type filter.
- Для `shipping_order_etsng_code` не проверены applied constraints/indexes, реальные weight precision/units, runtime permissions/client scope и production route package. Nested validation не каскадирует, DTO допускает zero против DB CHECK, старый duplicate query не используется, route view повторяет parent ID, а stale child экспортируется без filling-type filter.
- Для сводного 13-табличного shipping-контура не проверены applied FK/UNIQUE/delete semantics и реальные plan/fact дубли. DB не обеспечивает взаимоисключение моделей по `fillingType`, composite parent consistency и ETRAN membership вагонов; competing totals и stale route package требуют последовательных и конкурентных end-to-end tests.
- Для изменения `ShippingOrder.fillingType` не подтверждены runtime HTTP response и generated mapper, но source flow показывает, что root update новое значение не сохраняет. Целевая матрица переходов, политика старых plan/fact rows, единая транзакция, totals и route/outbound semantics требуют решения аналитика.
- Для `POST /datareon/event` не подтверждены production transformation и внешний timezone. Source contract не принимает envelope `MessageID + EventData[]`; после fan-out отдельно остаются риски no-offset `Instant`, неизвестного site/config, HTTP `200` при `SKIPPED/INVALID/FAILED` и потери cargo weight/height.
- Для вкладок карточки поставки не подтверждены frontend route, фактические requests, lazy/eager loading, сохранение состояния и обработка partial failure. Backend-трассировка выявляет необходимые дочерние контракты, но не доказывает, что текущий UI их вызывает. Для ЖД-сценария на снимке не видна точка исправления Waybill/вагона, обязательных для review.
- Для Figma-файла поставки не установлены release/version, актуальность групп `old`, смысл numbered frames, фактические prototype transitions и реализация. Макет показывает `DRAFT → ACCEPTED`, но найденный backend не публикует accept endpoint; зоны ЭТРАН «Архив» и «Дислокация» нельзя сводить к текущим Waybill-полям без отдельного source/runtime trace.
- Для карточки рейса не подтверждены фактический orders request, atomicity create+assign, размещение plan/fact/cargo-chain/reports и direct UUID client scope. Assign может молча пропустить UUID или перенести заявку, unassign — снять чужую связь и удалить transport без восстановления `needTransport`, а повтор accept — сформировать повторный outbound.
- Для формы поставки не подтверждены фактический порядок запросов, autosave, retry/idempotency, целевой legacy/V2 child API и поведение после partial failure. Root и дочерние записи имеют отдельные транзакции; композиции вкладок рабочего снимка и Figma различаются, а create-only payer/станции не имеют найденного общего update API.
- Для формы вывоза не предоставлены screenshot/Figma/frontend/HAR. Не подтверждены допустимые `fillingType` для склада и авто-КТК, обязательность container qty в двух ЖД-ветках, целевой V1/V2 API и политика смены plan/fact. Обычный update не сохраняет `deliveryType/fillingType`, старые rows не очищаются, а aggregate save/idempotency отсутствуют.
- Для формы ServiceOrder не предоставлены screenshot/Figma/frontend/HAR. Не подтверждены runtime grants, direct-ID client scope, видимость outbound status и защита от конкурентного выбора одного КТК в два DRAFT. Повторный accept/path-body mismatch возвращают общий `500`, а компенсация уже выполненной смены владельца не определена.

### Дополнение: каталог физических объектов БД

- Добавлены [реестр физических объектов](../database/catalog/README.md) с навигацией по уже созданным паспортам заявок и Waybill и [шаблон паспорта таблицы](../database/templates/table.md).
- Эталоном выбран существующий подробный паспорт [`shipping_order`](../database/shipping-order-root-as-is.md); дублирующий документ не создавался.
- Уточнена матрица покрытия: физические карты уже существуют, но каталог пока частичный; ownership/remain/movement, прочие таблицы и views, applied schema и сквозная связь правила с тестом остаются открытыми.
- Проверка документации: 730 Markdown-файлов, 7 964 локальные ссылки, битых ссылок, незакрытых блоков кода и trailing whitespace не обнаружено.

## Следующий подэтап

**9.9. Экраны накладных ЭТРАН:** связать зоны Figma «Входящие», «Исходящие», «Архив», «Дислокация» с актуальным Waybill и legacy shipping ETRAN API, фильтрами, DTO, client scope, связью с заявками и состояниями loading/empty/stale/error; не объединять зоны без доказанного источника.

Перед началом сравнить текущий `HEAD` с `22fac945e8116d04972ccc87b06b2303acf7a561`. Candidate screen→API mappings оставлять `INFERENCE` без frontend source или network trace; отсутствующий на снимке экран не считать отсутствующим в продукте.
