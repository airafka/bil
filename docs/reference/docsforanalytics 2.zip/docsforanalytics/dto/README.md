# Каталог DTO

DTO разделены по бизнес-сценарию; один Java DTO описывается одним Markdown-файлом. Каждый файл содержит назначение, endpoints, полный список собственных и наследуемых полей, Bean Validation, маппинг и пример JSON.

Каталог имеет два уровня:

- [полный технический каталог](catalog/README.md) — 461 автоматически сгенерированный паспорт: 417 top-level и 44 nested-типа с FQCN, полями, наследованием, раздельными признаками Java nullability / JSON required / Jackson null-policy / Bean Validation и использованием в endpoints;
- ручные паспорта ниже — проверенный бизнес-смысл, mapping, примеры и выявленные расхождения для ключевых контрактов.

При расхождении приоритет у Java-кода для фактической структуры и у ручного паспорта для явно отмеченной бизнес-интерпретации. Ни Java primitive, ни Bean Validation сами по себе не доказывают, что ключ обязан присутствовать во входном JSON: generated-паспорт показывает эти сигналы отдельно.

Перед проектированием контракта следует выбрать вариант из [классификации заявок](../business-rules/order-types.md), затем применить [общую статусную модель](../business-rules/order-statuses.md) и специализированные правила [поставки](../business-rules/receiving-orders.md), [вывоза](../business-rules/shipping-orders.md) либо [услуги](../business-rules/service-orders.md).

Сводная таблица обязательных полей корневых request DTO, порядок Bean Validation и последующей бизнес-валидации, а также конкретные DTO дочерних ресурсов находятся в [карте валидации заявок](../business-rules/order-validation.md).

Обратная трассировка `endpoint → request DTO → response DTO → handler` находится в [полном API-каталоге](../api/endpoints-generated.md); предметная логика endpoint-групп заявок — в [API заявок](../api/order-api.md).

Обозначения в таблицах:

- **JSON required** — только явно заданный `@JsonProperty(required = true/false)`; «не задано» не означает ни обязательность, ни необязательность;
- **Java null** — допускает ли Java-представление `null`; primitive не допускает `null`, но это не делает JSON-ключ обязательным;
- **Jackson null-policy** — явная обработка переданного `null` через `@JsonSetter`; отсутствие ключа рассматривается отдельно;
- **Bean Validation** — `@NotNull`, `@NotBlank`, `@NotEmpty` и другие constraints, применяемые при фактическом запуске нужной validation-группы;
- **обязательно** в ручных паспортах — запрос не проходит подтверждённую для endpoint Bean Validation или явно описанную серверную проверку;
- **условно** — обязательность проверяет бизнес-валидатор в определённом сценарии;
- **нет** — аннотации обязательности нет; это не обещает, что `null` допустим на всех стадиях процесса;
- `Instant` передаётся ISO-8601 строкой, например `2026-09-08T10:30:00Z`;
- enum передаётся строковым именем константы с учётом регистра;
- ссылочные DTO раскрываются как JSON-объекты, а не как UUID-строка.

## Заявки на поставку

- [ReceivingOrderBaseDto](receiving-order/ReceivingOrderBaseDto.md) — общие входные поля.
- [ReceivingOrderCreationDto](receiving-order/ReceivingOrderCreationDto.md) — создание.
- [ReceivingOrderUpdateDto](receiving-order/ReceivingOrderUpdateDto.md) — изменение.
- [ReceivingOrderDto](receiving-order/ReceivingOrderDto.md) — стандартный ответ.
- [ReceivingOrderDetailedDto](receiving-order/ReceivingOrderDetailedDto.md) — карточка/preview.
- [ReceivingOrderReportDto](receiving-order/ReceivingOrderReportDto.md) — строка отчёта.
- [ReceivingOrderTotalCargoQuantityDto](receiving-order/ReceivingOrderTotalCargoQuantityDto.md) — количество грузовых мест.

## Заявки на вывоз

- [ShippingOrderCreationDto](shipping-order/ShippingOrderCreationDto.md)
- [ShippingOrderUpdateDto](shipping-order/ShippingOrderUpdateDto.md)
- [ShippingOrderDto](shipping-order/ShippingOrderDto.md)
- [ShippingOrderDetailedDto](shipping-order/ShippingOrderDetailedDto.md)
- [ShippingOrderReportDto](shipping-order/ShippingOrderReportDto.md)

## Заявки на услуги

- [ServiceOrderCreationDto](service-order/ServiceOrderCreationDto.md)
- [ServiceOrderUpdateDto](service-order/ServiceOrderUpdateDto.md)
- [ServiceOrderDto](service-order/ServiceOrderDto.md)

## Формы ссылочных объектов

| Java-тип | JSON-поля |
|---|---|
| `IdDto` | `id: UUID` (обязателен при валидации вложенного объекта) |
| `IdCodeDto` | `id: UUID`, `code: string` |
| `IdCodeNamedDto` | `id: UUID`, `code: string`, `name: string` |
| `ContactDto` | `name`, `phone`, `email` — строки без встроенных ограничений |
| `TerminalAreaCatalogDto` | `id`, `code`, `name`; бизнес-логика ориентируется на `code` |

## Остальной DTO-контур

В [техническом каталоге](catalog/README.md) представлены DTO накладных, маршрутов, контейнеров, вагонов, товаров, договоров, справочников, отчётов и интеграций. Структурный контракт для них зафиксирован, но бизнес-семантика пока не аттестована вручную. Ручной файл создаётся по [шаблону](../templates/dto.md); до его появления нельзя считать назначение поля подтверждённым только по имени.

`BaseDto` добавляет в response поле `id: UUID`.

Обновление generated-слоя:

```bash
python3 docs/docsforanalytics/scripts/generate_dto_docs.py
```
