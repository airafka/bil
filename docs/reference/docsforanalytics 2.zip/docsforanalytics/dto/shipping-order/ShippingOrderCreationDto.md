# `ShippingOrderCreationDto`

Связано: [создание вывоза](../../business-rules/shipping-orders.md#создание-и-редактирование), [типы вывоза и заполнения](../../business-rules/order-types.md#5-вид-вывоза-shippingorderdeliverytype), [статусы](../../business-rules/order-statuses.md).

Создаёт заявку на вывоз.

- **Endpoint:** `POST /shippingorder/`
- **Permission:** `SHIPPING_ORDER`, level `CREATE`
- **Response:** [ShippingOrderDto](ShippingOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderCreationDto.java`

## Полный состав полей

| JSON-поле | JSON-тип | Обязательность | Поле модели / правило |
|---|---|---:|---|
| `orderStatus` | string enum | обязательно по DTO | `orderStatus`; при create заменяется на `DRAFT` |
| `client` | object `{id}` | обязательно | `client`; вложенный UUID обязателен |
| `contract` | object `{id}` | обязательно | `contract`; вложенный UUID обязателен |
| `terminalArea` | object `{id,code,name}` | обязательно | `terminalArea`; проверки используют `code` |
| `transportType` | string enum | обязательно | `VEHICLE` или `RAILWAY` |
| `plannedShippingDateTime` | ISO-8601 string | нет | Плановая дата; нужна перед review/accept |
| `currency` | object `{id}` | нет | Валюта; нужна перед review/accept |
| `contact` | object `{name,phone,email}` | нет | Уполномоченный представитель |
| `comment` | string | нет | Особые отметки |
| `deliveryType` | string enum | условно | `BY_GOOD`, `BY_CARGO`, `BY_GOOD_WITH_CARGO_WITH_DETAILS`; обязателен для склада + авто |
| `route` | object `{id,code}` | нет | Рейс; `code` mapper преобразует в `Long` |
| `needTransport` | boolean | нет | Признак необходимости транспорта |
| `consignee` | object `{id}` | условно | Грузополучатель; нужен перед review/accept для `CONTAINER` |
| `consigneeAddress` | string | нет | Адрес, модель ограничивает 1000 символами |
| `fillingType` | string enum | нет | `ALL`, `RAILWAY_CARRIAGE`, `CONTAINER`, `NONE`, `NONE_CONTAINER`; default `ALL` |

## Межполевые правила и результат

- `RAILWAY` допустим только для `terminalArea.code = CONTAINER`.
- `NONE_CONTAINER` допустим только для `CONTAINER + VEHICLE`.
- Вне `WAREHOUSE + VEHICLE` значение `deliveryType` при создании сбрасывается в `null`.
- Сервер генерирует `id` и `number`, устанавливает `DRAFT`, разыменовывает грузополучателя в рамках клиента и добавляет обязательные услуги договора.

## Пример

```json
{
  "orderStatus": "DRAFT",
  "client": {"id": "11111111-1111-1111-1111-111111111111"},
  "contract": {"id": "22222222-2222-2222-2222-222222222222"},
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333", "code": "WAREHOUSE", "name": "Склад"},
  "transportType": "VEHICLE",
  "plannedShippingDateTime": "2026-09-11T10:30:00Z",
  "currency": {"id": "44444444-4444-4444-4444-444444444444"},
  "contact": {"name": "Иван Иванов", "phone": "+79990000000", "email": "user@example.com"},
  "deliveryType": "BY_GOOD",
  "needTransport": true,
  "consignee": {"id": "55555555-5555-5555-5555-555555555555"},
  "consigneeAddress": "Москва, ул. Примерная, 1",
  "fillingType": "ALL",
  "comment": "Вывоз утром"
}
```
