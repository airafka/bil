# `ShippingOrderDto`

Связано: [бизнес-правила](../../business-rules/shipping-orders.md), [типы заявок](../../business-rules/order-types.md), [сущность](../../entities/catalog/entities/shippingorder/ShippingOrder.md), [БД](../../database/orders.md).

Основное представление заявки на вывоз.

- **Направление:** response
- **Endpoints:** get/create/update/review/reject для `/shippingorder`
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderDto.java`
- **Наследует:** `BaseDto.id`

## Полный состав полей

| JSON-поле | JSON-тип | Источник | Смысл / возможное значение |
|---|---|---|---|
| `id` | UUID string | `BaseDto` / `ShippingOrder.id` | Идентификатор |
| `number` | integer(int64) | `number` | Автоматический номер |
| `orderStatus` | string enum | `orderStatus` | Текущий статус |
| `client` | object `{id,code,name}` | `client` | Клиент |
| `plannedShippingDateTime` | ISO-8601 string или `null` | одноимённое поле | Плановое время вывоза |
| `actualShippingDateTime` | ISO-8601 string или `null` | одноимённое поле | Фактическое время из WMS |
| `terminalArea` | object `{id,code,name}` | `terminalArea` | Площадка |
| `transportType` | string enum | `transportType` | `VEHICLE` или `RAILWAY` |
| `createdAt` | ISO-8601 string | audit-поле | Время создания |
| `contract` | object | `contract` | `{id, code, contractType, contractDate}` |
| `currency` | object `{id,code}` или `null` | `currency` | Валюта |
| `contact` | object или `null` | embedded `contact` | `{name, phone, email}` |
| `comment` | string или `null` | `comment` | Комментарий |
| `deliveryType` | string enum или `null` | `deliveryType` | Вид вывоза |
| `route` | object `{id,code}` или `null` | `route` | `code` — номер рейса как строка |
| `needTransport` | boolean | `needTransport` | Требуется транспорт |
| `consignee` | object или `null` | `consignee` | `{id, code, active, name, inn, kpp, addressFact}` |
| `consigneeAddress` | string или `null` | `consigneeAddress` | Адрес грузополучателя |
| `documentConfirmed` | boolean или `null` | DTO / mapper | Признак подтверждения документа; поля в показанной сущности `ShippingOrder` нет, происхождение требует проверки |
| `ktkNumberUnknown` | boolean или `null` | `ktkNumberUnknown` | Неизвестен номер КТК |
| `fillingType` | string enum | `fillingType` | Тип заполнения вагонов/КТК |

Swagger перечисляет не все значения `fillingType`: enum содержит также `NONE_CONTAINER`.

## Пример ответа

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "number": 20871,
  "orderStatus": "DRAFT",
  "client": {"id": "11111111-1111-1111-1111-111111111111", "code": "CLI-01", "name": "Клиент"},
  "plannedShippingDateTime": "2026-09-11T10:30:00Z",
  "actualShippingDateTime": null,
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333", "code": "WAREHOUSE", "name": "Склад"},
  "transportType": "VEHICLE",
  "createdAt": "2026-09-08T08:00:00Z",
  "contract": {"id": "22222222-2222-2222-2222-222222222222", "code": "DOG-42", "contractType": "TOE", "contractDate": "2026-01-15T00:00:00Z"},
  "currency": {"id": "44444444-4444-4444-4444-444444444444", "code": "RUB"},
  "contact": {"name": "Иван Иванов", "phone": "+79990000000", "email": "user@example.com"},
  "comment": "Вывоз утром",
  "deliveryType": "BY_GOOD",
  "route": null,
  "needTransport": true,
  "consignee": {"id": "55555555-5555-5555-5555-555555555555", "code": "CON-1", "active": true, "name": "Получатель", "inn": "7800000000", "kpp": "780001001", "addressFact": "Санкт-Петербург"},
  "consigneeAddress": "Санкт-Петербург",
  "documentConfirmed": null,
  "ktkNumberUnknown": false,
  "fillingType": "ALL"
}
```
