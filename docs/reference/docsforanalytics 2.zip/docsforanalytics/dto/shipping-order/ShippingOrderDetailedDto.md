# `ShippingOrderDetailedDto`

Связано: [агрегат вывоза](../../entities/orders.md#shippingorder--заявка-на-вывоз), [матрица валидации](../../business-rules/shipping-orders.md#матрица-содержательной-валидации), [интеграции](../../business-rules/order-integrations.md#вывоз).

Расширенное представление карточки вывоза.

- **Endpoint:** `GET /shippingorder/{id}/preview`; также response full/partial copy
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderDetailedDto.java`
- **Наследует:** все 21 поле [ShippingOrderDto](ShippingOrderDto.md)

## Полный состав

Наследуемые поля: `id`, `number`, `orderStatus`, `client`, `plannedShippingDateTime`, `actualShippingDateTime`, `terminalArea`, `transportType`, `createdAt`, `contract`, `currency`, `contact`, `comment`, `deliveryType`, `route`, `needTransport`, `consignee`, `consigneeAddress`, `documentConfirmed`, `ktkNumberUnknown`, `fillingType`.

| Дополнительное JSON-поле | JSON-тип | Источник / смысл |
|---|---|---|
| `totalSKUQuantity` | integer(int64) | Число уникальных артикулов |
| `totalWeight` | number | Общий вес товаров |
| `totalCargoQuantity` | integer(int64) | Число грузовых мест |
| `totalPalletQuantity` | integer(int64) | Число мест обработки `PALLET` |
| `totalNotPalletQuantity` | integer(int64) | Число остальных мест |
| `totalGoodsPrice` | number | Общая стоимость товара |
| `totalRequestedServiceQuantity` | integer(int64) | Число дополнительных операций |
| `totalRequestedServicePrice` | number | Стоимость операций без НДС |
| `totalContainerQuantity` | integer(int64) | Число КТК |
| `clientDriver` | object или `null` | Водитель: наследуемые `id`, `code`, `active` плюс `client`, телефон, паспорт, права, доверенность |
| `clientVehicle` | object или `null` | `{id, code, vehicleBrand:{id,code}, trailerNumber}` |
| `legalEntityInn` | string или `null` | `client.inn` |

`clientDriver` в JSON имеет поля `id`, `code`, `active`, `client`, `phoneNumber`, `passportNumber`, `passportIssuedBy`, `passportIssuedDate`, `drivingLicenseNumber`, `drivingLicenseIssuedDate`, `POANumber`, `POAValidTo`. Регистр двух последних имён задан `@JsonProperty`.

## Фрагмент ответа

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "number": 20871,
  "orderStatus": "IN_PROGRESS",
  "totalSKUQuantity": 8,
  "totalWeight": 10800.5,
  "totalCargoQuantity": 14,
  "totalPalletQuantity": 10,
  "totalNotPalletQuantity": 4,
  "totalGoodsPrice": 780000.00,
  "totalRequestedServiceQuantity": 2,
  "totalRequestedServicePrice": 12500.00,
  "totalContainerQuantity": 1,
  "clientDriver": {
    "id": "66666666-6666-6666-6666-666666666666",
    "code": "DRV-15",
    "active": true,
    "client": {"id": "11111111-1111-1111-1111-111111111111", "code": "CLI-01"},
    "phoneNumber": "+79990000000",
    "passportNumber": "0000 000000",
    "passportIssuedBy": "ОВД",
    "passportIssuedDate": "2020-01-10T00:00:00Z",
    "drivingLicenseNumber": "00 00 000000",
    "drivingLicenseIssuedDate": "2022-05-12T00:00:00Z",
    "POANumber": "D-42",
    "POAValidTo": "2027-01-01T00:00:00Z"
  },
  "clientVehicle": {
    "id": "77777777-7777-7777-7777-777777777777",
    "code": "А001АА77",
    "vehicleBrand": {"id": "88888888-8888-8888-8888-888888888888", "code": "KAMAZ"},
    "trailerNumber": "В001ВВ77"
  },
  "legalEntityInn": "7700000000"
}
```

Фрагмент сокращён: response также содержит все поля `ShippingOrderDto`.
