# `ShippingOrderReportDto`

Связано: [вывоз](../../business-rules/shipping-orders.md), [основной response](ShippingOrderDto.md).

Проекция одной строки экспортного отчёта по вывозам. Это внутренний output DTO, не CRUD request.

- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderReportDto.java`

| Поле | Java / JSON-тип | Смысл |
|---|---|---|
| `number` | `Long` / integer | Номер заявки |
| `client` | string | Представление клиента |
| `orderStatus` | string | Форматированный статус |
| `plannedShippingDate` | string | Плановая дата отдельно |
| `plannedShippingTime` | string | Плановое время отдельно |
| `terminalArea` | string | Площадка для печати |
| `transportType` | string | Транспорт для печати |
| `createdAt` | string | Дата создания для печати |

```json
{
  "number": 20871,
  "client": "CLI-01 — Клиент",
  "orderStatus": "Черновик",
  "plannedShippingDate": "11.09.2026",
  "plannedShippingTime": "13:30",
  "terminalArea": "Склад",
  "transportType": "АВТО",
  "createdAt": "08.09.2026"
}
```

Точный формат строк определяется сборщиком отчёта, а не аннотациями DTO.
