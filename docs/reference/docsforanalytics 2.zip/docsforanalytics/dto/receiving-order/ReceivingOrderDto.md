# `ReceivingOrderDto`

Связано: [бизнес-правила](../../business-rules/receiving-orders.md), [типы поставок](../../business-rules/order-types.md#4-вид-поставки-receivingorderdeliverytype), [сущность](../../entities/catalog/entities/receivingorder/ReceivingOrder.md), [БД](../../database/orders.md).

Основное представление заявки на поставку.

- **Направление:** response
- **Endpoints:** `GET /receivingorder/{id}`, `POST /receivingorder/`, `PUT /receivingorder/{id}`, `PUT .../review`, `PUT .../reject`
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderDto.java`
- **Наследует:** `BaseDto.id`

## Полный состав полей

| JSON-поле | JSON-тип | Источник | Смысл / возможное значение |
|---|---|---|---|
| `id` | UUID string | `BaseDto` / `ReceivingOrder.id` | Технический идентификатор |
| `number` | integer(int64) | `number` | Автоматический номер заявки |
| `client` | object `{id,code,name}` | `client` | Клиент |
| `orderStatus` | string enum | `orderStatus` | Текущий статус заявки |
| `planReceivingDateTime` | ISO-8601 string или `null` | одноимённое поле | Плановая дата/время поставки |
| `actualReceivingDateTime` | ISO-8601 string или `null` | одноимённое поле | Фактическое время из WMS |
| `storagePeriod` | number или `null` | `storagePeriod` | Срок хранения |
| `terminalArea` | object `{id,code,name}` | `terminalArea` | Площадка |
| `transportType` | string enum | `transportType` | `VEHICLE` или `RAILWAY` |
| `createdAt` | ISO-8601 string | audit-поле | Время создания |
| `contract` | object | `contract` | `{id, code, contractType, contractDate}` |
| `currency` | object `{id,code}` или `null` | `currency` | Валюта стоимости |
| `contact` | object или `null` | embedded `contact` | `{name, phone, email}` |
| `comment` | string или `null` | `comment` | Комментарий |
| `deliveryType` | string enum или `null` | `deliveryType` | Вид поставки |
| `route` | object `{id,code}` или `null` | `route` | `code` формируется из номера рейса |
| `needTransport` | boolean | `needTransport` | Требуется транспорт |
| `shipper` | object или `null` | `shipper` | `{id, code, active, name, inn, kpp, addressFact}` |
| `waybill` | string или `null` | `waybill` | Номер транспортной накладной |
| `documentConfirmed` | boolean или `null` | `documentConfirmed` | `null` — не обработано, `true` — подтверждено, `false` — отклонено |
| `ktkNumberUnknown` | boolean или `null` | `ktkNumberUnknown` | Неизвестен номер КТК |
| `payer` | object или `null` | `payer` | `{id, code: integer, name}` |
| `departureStation` | object или `null` | `departureStation` | `{id, code, active, name, esrCode}` |
| `destinationStation` | object или `null` | `destinationStation` | `{id, code, active, name, esrCode}` |

## Пример ответа

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "number": 10452,
  "client": {"id": "11111111-1111-1111-1111-111111111111", "code": "CLI-01", "name": "Клиент"},
  "orderStatus": "ACCEPTED",
  "planReceivingDateTime": "2026-09-10T08:00:00Z",
  "actualReceivingDateTime": null,
  "storagePeriod": 3,
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333", "code": "CONTAINER", "name": "Контейнерная площадка"},
  "transportType": "RAILWAY",
  "createdAt": "2026-09-08T07:15:00Z",
  "contract": {"id": "22222222-2222-2222-2222-222222222222", "code": "DOG-42", "contractType": "TOE", "contractDate": "2026-01-15T00:00:00Z"},
  "currency": {"id": "44444444-4444-4444-4444-444444444444", "code": "RUB"},
  "contact": {"name": "Иван Иванов", "phone": "+79990000000", "email": "user@example.com"},
  "comment": "Приём по накладной",
  "deliveryType": null,
  "route": {"id": "99999999-9999-9999-9999-999999999999", "code": "781"},
  "needTransport": false,
  "shipper": {"id": "55555555-5555-5555-5555-555555555555", "code": "SHIP-1", "active": true, "name": "Отправитель", "inn": "7700000000", "kpp": "770001001", "addressFact": "Москва"},
  "waybill": "ТН-2026-10",
  "documentConfirmed": null,
  "ktkNumberUnknown": false,
  "payer": {"id": "66666666-6666-6666-6666-666666666666", "code": 1001, "name": "Плательщик"},
  "departureStation": {"id": "77777777-7777-7777-7777-777777777777", "code": "ST-A", "active": true, "name": "Станция А", "esrCode": "123456"},
  "destinationStation": {"id": "88888888-8888-8888-8888-888888888888", "code": "ST-B", "active": true, "name": "Станция Б", "esrCode": "654321"}
}
```
