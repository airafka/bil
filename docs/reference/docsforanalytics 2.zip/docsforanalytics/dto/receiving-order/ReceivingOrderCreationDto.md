# `ReceivingOrderCreationDto`

Связано: [создание поставки](../../business-rules/receiving-orders.md#создание-и-редактирование), [типы](../../business-rules/order-types.md), [статусы](../../business-rules/order-statuses.md).

Создаёт заявку на поставку.

- **Endpoint:** `POST /receivingorder/`
- **Permission:** `RECEIVING_ORDER`, level `CREATE`
- **Response:** [ReceivingOrderDto](ReceivingOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderCreationDto.java`

## Полный состав полей

| JSON-поле | JSON-тип | Обязательность | Назначение / ограничение |
|---|---|---:|---|
| `client` | object `{id}` | обязательно | Клиент |
| `contract` | object `{id}` | обязательно | Договор |
| `terminalArea` | object `{id,code,name}` | обязательно | Площадка; значим `code` |
| `transportType` | string enum | обязательно | Вид транспорта |
| `planReceivingDateTime` | ISO-8601 string | нет | Плановая дата; обязательна только перед review/accept |
| `storagePeriod` | number | нет | Не меньше 0 |
| `orderStatus` | string enum | обязательно по DTO | Значение будет проигнорировано и заменено на `DRAFT` |
| `currency` | object `{id}` | нет | Валюта; обязательна перед review/accept |
| `contact` | object `{name,phone,email}` | нет | Представитель |
| `comment` | string | нет | Комментарий |
| `deliveryType` | string enum | условно | Обязателен для `WAREHOUSE + VEHICLE` |
| `needTransport` | boolean | нет | Нужен ли транспорт |
| `route` | object `{id,code}` | нет | Рейс; `code` должен представлять число |
| `shipper` | object `{id}` | условно | Нужен перед review/accept для `CONTAINER` |
| `carrier` | object `{id}` | нет | Deprecated, игнорируется |
| `waybill` | string | нет | Номер транспортной накладной |
| `payerId` | object `{id}` | условно | Плательщик для `CONTAINER + RAILWAY` |
| `departureStationId` | object `{id}` | условно | Станция отправления для `CONTAINER + RAILWAY` |
| `destinationStationId` | object `{id}` | условно | Станция назначения для `CONTAINER + RAILWAY` |

Все три ЖД-поля должны быть переданы вместе, когда `RAILWAY_FIELDS_REQUIRED=true`. Фактически отсутствие env-переменной отключает проверку, хотя комментарий исходника заявляет default `true`.

## Маппинг и результат

- Сервер генерирует новый `id` и `number`.
- `payerId → payer`, `departureStationId → departureStation`, `destinationStationId → destinationStation`.
- Статус устанавливается в `DRAFT`.
- После сохранения создаются обязательные услуги из условий договора.

## Пример

```json
{
  "client": {"id": "11111111-1111-1111-1111-111111111111"},
  "contract": {"id": "22222222-2222-2222-2222-222222222222"},
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333", "code": "CONTAINER", "name": "Контейнерная площадка"},
  "transportType": "RAILWAY",
  "planReceivingDateTime": "2026-09-10T08:00:00Z",
  "storagePeriod": 3,
  "orderStatus": "DRAFT",
  "currency": {"id": "44444444-4444-4444-4444-444444444444"},
  "shipper": {"id": "55555555-5555-5555-5555-555555555555"},
  "payerId": {"id": "66666666-6666-6666-6666-666666666666"},
  "departureStationId": {"id": "77777777-7777-7777-7777-777777777777"},
  "destinationStationId": {"id": "88888888-8888-8888-8888-888888888888"},
  "needTransport": false,
  "comment": "Приём по накладной"
}
```
