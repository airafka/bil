# `ReceivingOrderDetailedDto`

Связано: [агрегат поставки](../../entities/orders.md#receivingorder--заявка-на-поставку), [валидация](../../business-rules/receiving-orders.md#матрица-содержательной-валидации), [накладные](../../business-rules/receiving-orders.md#накладные).

Расширенное представление карточки поставки.

- **Endpoint:** `GET /receivingorder/{id}/preview`; также response full/partial copy
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderDetailedDto.java`
- **Наследует:** все 24 поля [ReceivingOrderDto](ReceivingOrderDto.md)

## Полный состав

Наследуемые поля: `id`, `number`, `client`, `orderStatus`, `planReceivingDateTime`, `actualReceivingDateTime`, `storagePeriod`, `terminalArea`, `transportType`, `createdAt`, `contract`, `currency`, `contact`, `comment`, `deliveryType`, `route`, `needTransport`, `shipper`, `waybill`, `documentConfirmed`, `ktkNumberUnknown`, `payer`, `departureStation`, `destinationStation`. Их типы и формы раскрыты в базовом response.

| Дополнительное JSON-поле | JSON-тип | Источник / смысл |
|---|---|---|
| `totalSKUQuantity` | integer(int64) | Число уникальных артикулов |
| `totalWeight` | number | Общий вес; mapper карточки пересчитывает сумму `WaybillProduct.weight` |
| `totalCargoQuantity` | integer(int64) | Число грузовых мест |
| `totalPalletQuantity` | integer(int64) | Грузовые места обработки `PALLET` |
| `totalNotPalletQuantity` | integer(int64) | Остальные грузовые места |
| `totalRailwayCarriageQuantity` | integer(int64) | Число вагонов по накладным заявки |
| `totalContainerQuantity` | integer(int64) | Число контейнеров по накладным заявки |
| `totalGoodsPrice` | number | Общая стоимость товаров |
| `totalRequestedServiceQuantity` | integer(int64) | Число дополнительных операций |
| `totalRequestedServicePrice` | number | Стоимость операций без НДС |
| `clientDriver` | object или `null` | Водитель из `transport.clientDriver`; полный `ClientDriverDto` |
| `clientVehicle` | object или `null` | `{id, code, vehicleBrand:{id,code}, trailerNumber}` |
| `legalEntityInn` | string или `null` | `client.inn` |

## Особенность вычисления

Три значения (`totalWeight`, `totalRailwayCarriageQuantity`, `totalContainerQuantity`) перезаписываются при построении карточки данными накладных. Для аналитики это означает, что response preview не всегда буквально отражает агрегатные колонки `receiving_order`.

## Фрагмент ответа

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "number": 10452,
  "orderStatus": "ACCEPTED",
  "totalSKUQuantity": 12,
  "totalWeight": 24500.75,
  "totalCargoQuantity": 20,
  "totalPalletQuantity": 16,
  "totalNotPalletQuantity": 4,
  "totalRailwayCarriageQuantity": 2,
  "totalContainerQuantity": 6,
  "totalGoodsPrice": 1500000.00,
  "totalRequestedServiceQuantity": 3,
  "totalRequestedServicePrice": 42000.00,
  "clientDriver": null,
  "clientVehicle": null,
  "legalEntityInn": "7700000000"
}
```

Фрагмент сокращён: в реальном response также присутствуют все поля `ReceivingOrderDto`.
