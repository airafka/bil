# `ReceivingOrderTotalCargoQuantityDto`

Связано: [тип `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`](../../business-rules/order-types.md#4-вид-поставки-receivingorderdeliverytype), [валидация склада](../../business-rules/receiving-orders.md#склад--автомобиль).

Точечный request/response количества грузовых мест.

- **Endpoints:** `GET /receivingorder/{id}/total-cargo-quantity`, `POST` того же path с фильтром, `PUT` того же path для записи
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderTotalCargoQuantityDto.java`

| JSON-поле | Java / JSON-тип | Обязательно | Ограничение | Маппинг |
|---|---|---:|---|---|
| `totalCargoQuantity` | `Long` / integer(int64) | задумано как да | `@PositiveOrZero`, то есть ≥ 0 | `ReceivingOrder.totalCargoQuantity` |

Запись разрешена только для `deliveryType = BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` и в статусе, допускающем изменение.

```json
{"totalCargoQuantity": 24}
```

## Дефект контракта

На числовом `Long` установлена строковая аннотация `@NotBlank`. Она не предназначена для чисел и может приводить к ошибке определения валидатора вместо штатного сообщения об обязательности. Для корректного контракта ожидается `@NotNull` + `@PositiveOrZero`; это описание фиксирует ожидаемый смысл, но не маскирует текущее состояние кода.
