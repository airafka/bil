# `ReceivingOrderReportDto`

Связано: [поставка](../../business-rules/receiving-orders.md), [основной response](ReceivingOrderDto.md).

Проекция одной строки экспортного отчёта по поставкам. Это внутренний output формат генератора отчёта, не CRUD request.

- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderReportDto.java`

| Поле | JSON/Java-тип | Смысл |
|---|---|---|
| `number` | string | Отформатированный номер заявки |
| `clientId` | string | Представление клиента для отчёта |
| `orderStatus` | string | Локализованный/форматированный статус |
| `planReceivingDate` | string | Плановая дата отдельно от времени |
| `planReceivingTime` | string | Плановое время отдельно от даты |
| `terminalArea` | string | Площадка для печати |
| `transportType` | string | Вид транспорта для печати |
| `createdAt` | string | Дата создания для печати |
| `documentConfirmed` | string | Представление решения по документам |

Формат строк не закреплён аннотациями DTO и определяется сборщиком отчёта. Пример логической формы:

```json
{
  "number": "10452",
  "clientId": "CLI-01",
  "orderStatus": "Подтверждена",
  "planReceivingDate": "10.09.2026",
  "planReceivingTime": "11:00",
  "terminalArea": "Контейнерная площадка",
  "transportType": "ЖД",
  "createdAt": "08.09.2026",
  "documentConfirmed": "Не обработано"
}
```
