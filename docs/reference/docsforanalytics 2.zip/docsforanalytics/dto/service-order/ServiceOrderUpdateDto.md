# `ServiceOrderUpdateDto`

Связано: [редактирование сервисной заявки](../../business-rules/service-orders.md#правила), [статусы](../../business-rules/order-statuses.md#сервисная-заявка).

Изменяет услугу и комментарий существующей сервисной заявки.

- **Endpoint:** `PUT /service-order/{id}`
- **Permission:** `SERVICE_ORDER`, level `WRITE`
- **Response:** [ServiceOrderDto](ServiceOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/serviceorder/ServiceOrderUpdateDto.java`

| JSON-поле | Java / JSON-тип | Обязательно | Маппинг | Ограничение / смысл |
|---|---|---:|---|---|
| `id` | `UUID` / string | да | Не маппится в изменяемые поля модели; базовый сервис сравнивает с path ID | Должен точно совпадать с `{id}`, иначе `IllegalArgumentException` и HTTP `500` |
| `service` | `ServiceOrderType` / string enum | да | `ServiceOrder.service` | `CHANGE_OWNER` |
| `comment` | `String` / string | нет | `ServiceOrder.comment` | Новое значение или `null` |

Обновление возможно только в `DRAFT`. Клиент, статус, дата выполнения и список контейнеров этим DTO не меняются. `BaseService.update(UUID,U)` явно сравнивает path ID с `body.id`; при несовпадении выбрасывается `IllegalArgumentException`, которую текущий `ExceptionAdvice` обрабатывает общим HTTP `500`.

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "service": "CHANGE_OWNER",
  "comment": "Исправленный комментарий"
}
```
