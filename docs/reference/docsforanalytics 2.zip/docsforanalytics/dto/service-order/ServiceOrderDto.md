# `ServiceOrderDto`

Связано: [бизнес-правила](../../business-rules/service-orders.md), [сущность](../../entities/catalog/entities/serviceorder/ServiceOrder.md), [контейнеры заявки](../../entities/catalog/entities/serviceordercontainer/ServiceOrderContainer.md), [интеграция](../../business-rules/order-integrations.md#заявка-на-услугу).

Полный response сервисной заявки.

- **Endpoints:** page/get/create/update/delete/accept для `/service-order`
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/serviceorder/ServiceOrderDto.java`
- **Наследует:** `BaseDto.id`

| JSON-поле | Java / JSON-тип | Источник | Смысл / возможное значение |
|---|---|---|---|
| `id` | `UUID` / string | `BaseDto` / `ServiceOrder.id` | Идентификатор |
| `number` | `Long` / integer | `ServiceOrder.number` | Автоматический номер |
| `client` | `IdCodeNamedDto` / object | `ServiceOrder.client` | `{id, code, name}` |
| `createdAt` | `Instant` / string | audit-поле | Время создания |
| `containerQuantity` | `Long` / integer | отдельный count query | Число связанных контейнеров; явно обогащается для page |
| `service` | enum / string | `ServiceOrder.service` | `CHANGE_OWNER` |
| `comment` | `String` / string или `null` | `ServiceOrder.comment` | Комментарий |
| `status` | enum / string | `ServiceOrder.status` | `DRAFT` или `DONE` |
| `completionAt` | `Instant` / string или `null` | `ServiceOrder.completionAt` | Устанавливается в текущее время при accept |

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "number": 10501,
  "client": {"id": "11111111-1111-1111-1111-111111111111", "code": "CLI-01", "name": "Клиент"},
  "createdAt": "2026-09-08T08:00:00Z",
  "containerQuantity": 2,
  "service": "CHANGE_OWNER",
  "comment": "Передать контейнеры",
  "status": "DONE",
  "completionAt": "2026-09-08T09:15:30Z"
}
```

При `POST /{id}/accept` требуется хотя бы один связанный контейнер. После успеха владельцем контейнеров становится клиент заявки, статус — `DONE`.
