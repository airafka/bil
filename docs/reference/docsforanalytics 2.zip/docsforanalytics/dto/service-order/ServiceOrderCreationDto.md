# `ServiceOrderCreationDto`

Связано: [правила заявки на услугу](../../business-rules/service-orders.md), [тип `CHANGE_OWNER`](../../business-rules/order-types.md#7-тип-сервисной-заявки-serviceordertype), [сущность](../../entities/catalog/entities/serviceorder/ServiceOrder.md).

Создаёт заявку на отдельную услугу над контейнерами.

- **Endpoint:** `POST /service-order/`
- **Permission:** `SERVICE_ORDER`, level `CREATE`
- **Response:** [ServiceOrderDto](ServiceOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/serviceorder/ServiceOrderCreationDto.java`

| JSON-поле | Java / JSON-тип | Обязательно | Маппинг | Ограничение / смысл |
|---|---|---:|---|---|
| `client` | `IdDto` / object `{id}` | да | `ServiceOrder.client` | `@Valid @NotNull`; вложенный UUID обязателен |
| `service` | `ServiceOrderType` / string enum | да | `ServiceOrder.service` | Сейчас enum содержит только `CHANGE_OWNER` |
| `comment` | `String` / string | нет | `ServiceOrder.comment` | Ограничения длины в DTO нет |

Сервер генерирует `id` и `number`, статус устанавливает в `DRAFT`. Контейнеры в этом request отсутствуют и связываются через отдельный ресурс `ServiceOrderContainer`.

```json
{
  "client": {"id": "11111111-1111-1111-1111-111111111111"},
  "service": "CHANGE_OWNER",
  "comment": "Передать два контейнера новому владельцу"
}
```
