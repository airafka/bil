# `ShippingOrderCargoUpdateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordercargo`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercargo.ShippingOrderCargoUpdateDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercargo`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [ShippingOrderCargoCreationDto](ShippingOrderCargoCreationDto.md)
- **Интерфейсы:** `BaseUpdateDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderCargoUpdateDto.java:15](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercargo/ShippingOrderCargoUpdateDto.java#L15)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/shippingordercargo/{shippingOrderId}/batch` | `ShippingOrderCargoController` (ALIS) |
| request | `PUT` `/shippingordercargo/multipleupdate` | `ShippingOrderCargoController` (ALIS) |
| request | `PUT` `/shippingordercargo/{id}` | `ShippingOrderCargoController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `shippingOrder` | `shippingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderCargoCreationDto` | — |
| `shippingOrderGood` | `shippingOrderGood` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderCargoCreationDto` | — |
| `barcode` | `barcode` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCargoCreationDto` | — |
| `batch` | `batch` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCargoCreationDto` | — |
| `goodPackage` | `goodPackage` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCargoCreationDto` | — |
| `cargo` | `cargo` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderCargoCreationDto` | — |
| `packageQuantity` | `packageQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `totalQuantity` | `totalQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `width` | `width` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `volume` | `volume` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ShippingOrderCargoCreationDto` | — |
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoUpdateDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
