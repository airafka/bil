# `ShippingOrderCargoDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordercargo`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercargo.ShippingOrderCargoDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercargo`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderCargoDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercargo/ShippingOrderCargoDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `DELETE` `/shippingordercargo/{id}` | `ShippingOrderCargoController` (ALIS) |
| response | `GET` `/shippingordercargo/{id}` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shippingordercargo` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shippingordercargo/multipleaddition` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shippingordercargo/page` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shippingordercargo/{shippingOrderId}/batch` | `ShippingOrderCargoController` (ALIS) |
| response | `PUT` `/shippingordercargo/multipleupdate` | `ShippingOrderCargoController` (ALIS) |
| response | `PUT` `/shippingordercargo/{id}` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-cargo/list` | `ShippingOrderCargoControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-cargo/page` | `ShippingOrderCargoControllerV2` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `shippingOrder` | `shippingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `shippingOrderGood` | `shippingOrderGood` | [ShippingOrderGoodInCargoDto](ShippingOrderGoodInCargoDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `clientGood` | `clientGood` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `cargo` | `cargo` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `barcode` | `barcode` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `goodPackage` | `goodPackage` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `packageQuantity` | `packageQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `conversionQuantity` | `conversionQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `totalQuantity` | `totalQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `width` | `width` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `volume` | `volume` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCargoDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
