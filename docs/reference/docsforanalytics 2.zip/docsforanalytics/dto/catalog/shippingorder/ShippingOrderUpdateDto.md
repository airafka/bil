# `ShippingOrderUpdateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingorder`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingorder.ShippingOrderUpdateDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingorder`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [ShippingOrderCreationDto](ShippingOrderCreationDto.md)
- **Интерфейсы:** `BaseUpdateDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderUpdateDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderUpdateDto.java#L18)
- **Ручной бизнес-паспорт:** [ShippingOrderUpdateDto.md](../../shipping-order/ShippingOrderUpdateDto.md)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `PUT` `/shippingorder/{id}` | `ShippingOrderController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `orderStatus` | `orderStatus` | OrderStatus | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderCreationDto` | Статус |
| `client` | `client` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderCreationDto` | Клиент |
| `contract` | `contract` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderCreationDto` | Договор |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderCreationDto` | Площадка |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderCreationDto` | Вид транспорта |
| `plannedShippingDateTime` | `plannedShippingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Плановое время отгрузки товара с площадки |
| `currency` | `currency` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCreationDto` | Валюта стоимости груза |
| `contact` | `contact` | [ContactDto](../contact/ContactDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCreationDto` | Уполномоченный представитель |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Особые отметки и комментарии |
| `deliveryType` | `deliveryType` | ShippingOrderDeliveryType | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Вид вывоза номенклатуры. Предназначен только для заявок с площадкой WAREHOUSE или WAREHOUSE_428 |
| `needTransport` | `needTransport` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Признак необходимости транспорта |
| `consignee` | `consignee` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderCreationDto` | Грузополучатель |
| `consigneeAddress` | `consigneeAddress` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Адрес грузополучателя |
| `fillingType` | `fillingType` | ShippingOrderFillingType | технически возможен (reference) | не задано | не задано | — | `ShippingOrderCreationDto` | Тип заполнения заявки |
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderUpdateDto` | Идентификатор |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
