# `ShippingOrderDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingorder`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingorder.ShippingOrderDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingorder`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [ShippingOrderDto](ShippingOrderDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderDetailedDto.java:20](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderDetailedDto.java#L20)
- **Ручной бизнес-паспорт:** [ShippingOrderDetailedDto.md](../../shipping-order/ShippingOrderDetailedDto.md)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/shippingorder/{id}/preview` | `ShippingOrderController` (ALIS) |
| response | `POST` `/shippingorder/{id}/full-copy` | `ShippingOrderController` (ALIS) |
| response | `POST` `/shippingorder/{id}/partial-copy` | `ShippingOrderController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Номер |
| `orderStatus` | `orderStatus` | OrderStatus | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Статус |
| `client` | `client` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Клиент |
| `plannedShippingDateTime` | `plannedShippingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Плановое время отгрузки товара с площадки |
| `actualShippingDateTime` | `actualShippingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Фактическое время отгрузки товара с площадки |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Площадка |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Вид транспорта |
| `createdAt` | `createdAt` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Дата создания |
| `contract` | `contract` | [ContractShortDto](../contract/ContractShortDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Договор |
| `currency` | `currency` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Валюта стоимости груза |
| `contact` | `contact` | [ContactDto](../contact/ContactDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Уполномоченный представитель |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Особые отметки и комментарии |
| `deliveryType` | `deliveryType` | ShippingOrderDeliveryType | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Вид вывоза номенклатуры. Предназначен только для заявок с площадкой WAREHOUSE или WAREHOUSE_428 |
| `route` | `route` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Рейс, к которому принадлежит заявка |
| `needTransport` | `needTransport` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Признак необходимости транспорта |
| `consignee` | `consignee` | [ClientRelatedEntityShortDto](../clientrelatedentity/ClientRelatedEntityShortDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Грузополучатель |
| `consigneeAddress` | `consigneeAddress` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Адрес грузополучателя |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDto` | Флаг номер КТК неизвестен |
| `totalSKUQuantity` | `totalSKUQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество уникальных артикулов |
| `totalWeight` | `totalWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общий вес товаров |
| `totalCargoQuantity` | `totalCargoQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество грузовых мест |
| `totalPalletQuantity` | `totalPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество грузомест с типом обработки PALLET |
| `totalNotPalletQuantity` | `totalNotPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество грузомест с типом обработки, отличным от PALLET |
| `totalGoodsPrice` | `totalGoodsPrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общая стоимость товаров |
| `totalRequestedServiceQuantity` | `totalRequestedServiceQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество доп. операций |
| `totalRequestedServicePrice` | `totalRequestedServicePrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общая стоимость доп. операций без НДС |
| `totalContainerQuantity` | `totalContainerQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | Общее количество КТК |
| `clientDriver` | `clientDriver` | [ClientDriverDto](../clientdriver/ClientDriverDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | — |
| `clientVehicle` | `clientVehicle` | [ClientVehiclePreviewDto](../clientvehicle/ClientVehiclePreviewDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | — |
| `legalEntityInn` | `legalEntityInn` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderDetailedDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
