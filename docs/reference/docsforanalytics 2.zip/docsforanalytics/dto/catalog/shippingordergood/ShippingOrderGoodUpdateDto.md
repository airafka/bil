# `ShippingOrderGoodUpdateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordergood`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordergood.ShippingOrderGoodUpdateDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordergood`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [ShippingOrderGoodCreationDto](ShippingOrderGoodCreationDto.md)
- **Интерфейсы:** `BaseUpdateDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderGoodUpdateDto.java:16](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordergood/ShippingOrderGoodUpdateDto.java#L16)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/shippingordergood/{shippingOrderId}/batch` | `ShippingOrderGoodController` (ALIS) |
| request | `PUT` `/shippingordergood/multipleupdate` | `ShippingOrderGoodController` (ALIS) |
| request | `PUT` `/shippingordergood/{id}` | `ShippingOrderGoodController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `shippingOrder` | `shippingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderGoodCreationDto` | — |
| `clientGood` | `clientGood` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderGoodCreationDto` | — |
| `batch` | `batch` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderGoodCreationDto` | — |
| `batchUnknown` | `batchUnknown` | boolean | невозможен (`primitive`) | не задано | не задано | — | `ShippingOrderGoodCreationDto` | — |
| `plannedQuantity` | `plannedQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@NotNull`, `@Positive` | `ShippingOrderGoodCreationDto` | — |
| `price` | `price` | BigDecimal | технически возможен (reference) | не задано | не задано | `@NotNull`, `@Min(0)` | `ShippingOrderGoodCreationDto` | — |
| `totalPrice` | `totalPrice` | BigDecimal | технически возможен (reference) | не задано | не задано | `@NotNull`, `@Min(0)` | `ShippingOrderGoodCreationDto` | — |
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderGoodUpdateDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
