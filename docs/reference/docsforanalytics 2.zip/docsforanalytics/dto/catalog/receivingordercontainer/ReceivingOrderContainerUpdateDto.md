# `ReceivingOrderContainerUpdateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.receivingordercontainer`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingordercontainer.ReceivingOrderContainerUpdateDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingordercontainer`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [ReceivingOrderContainerCreationDto](ReceivingOrderContainerCreationDto.md)
- **Интерфейсы:** `BaseUpdateDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderContainerUpdateDto.java:15](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingordercontainer/ReceivingOrderContainerUpdateDto.java#L15)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `PUT` `/receivingordercontainer/{id}` | `ReceivingOrderContainerController` (ALIS) |
| request | `POST` `/receiving-order/{receivingOrderId}/receiving-order-container/batch` | `ReceivingOrderContainerControllerV2` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `receivingOrder` | `receivingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ReceivingOrderContainerCreationDto` | — |
| `container` | `container` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerCreationDto` | — |
| `sealNumbers` | `sealNumbers` | List<String> | технически возможен (reference) | не задано | не задано | `elements: @NotBlank`, `elements: @Size(max = 50)` | `ReceivingOrderContainerCreationDto` | — |
| `sealType` | `sealType` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerCreationDto` | — |
| `empty` | `empty` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ReceivingOrderContainerCreationDto` | — |
| `customsClearance` | `customsClearance` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerCreationDto` | — |
| `dangerClass` | `dangerClass` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderContainerCreationDto` | — |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerCreationDto` | Собственник КТК. Если значение не передано, используется defaultContainerOwner заявки. |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerCreationDto` | — |
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerUpdateDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
