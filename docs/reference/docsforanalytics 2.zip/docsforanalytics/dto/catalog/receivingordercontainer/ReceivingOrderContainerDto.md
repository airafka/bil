# `ReceivingOrderContainerDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.receivingordercontainer`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingordercontainer.ReceivingOrderContainerDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingordercontainer`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderContainerDto.java:22](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingordercontainer/ReceivingOrderContainerDto.java#L22)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `DELETE` `/receivingordercontainer/{id}` | `ReceivingOrderContainerController` (ALIS) |
| response | `GET` `/receivingordercontainer/{id}` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receivingordercontainer` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receivingordercontainer/multipleaddition` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receivingordercontainer/page` | `ReceivingOrderContainerController` (ALIS) |
| response | `PUT` `/receivingordercontainer/{id}` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receiving-order/{receivingOrderId}/receiving-order-container/batch` | `ReceivingOrderContainerControllerV2` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `receivingOrder` | `receivingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `waybillRailwayCarriage` | `waybillRailwayCarriage` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | KIS-3631: замена receivingOrderRailwayCarriage (таблица удалена). Теперь связь контейнера с вагоном идёт через WaybillContainer → WaybillRailwayCarriage. |
| `container` | `container` | [ContainerDto](../container/ContainerDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `sealNumbers` | `sealNumbers` | List<String> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `sealType` | `sealType` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `empty` | `empty` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `customsClearance` | `customsClearance` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `actualQuantity` | `actualQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `dangerClass` | `dangerClass` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | Номер КТК неизвестен |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderContainerDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
