# `TermOfServiceCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.termofservice`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.termofservice.TermOfServiceCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.termofservice`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [BaseNamedCreationDto](../wms/BaseNamedCreationDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [TermOfServiceCreationDto.java:19](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/termofservice/TermOfServiceCreationDto.java#L19)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/termofservice` | `TermOfServiceController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `active` | `active` | Boolean | разрешён (`@Nullable`) | не задано | не задано | — | `BaseActivatedCreationDto` | — |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | `@NotBlank`, `@Size(max = ValidationConstants.MAX_LENGTH_100)` | `BaseCodedCreationDto` | — |
| `name` | `name` | String | технически возможен (reference) | не задано | не задано | — | `BaseNamedCreationDto` | — |
| `contract` | `contract` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `TermOfServiceCreationDto` | — |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | `@NotNull` | `TermOfServiceCreationDto` | — |
| `validFrom` | `validFrom` | Instant | технически возможен (reference) | не задано | не задано | `@NotNull` | `TermOfServiceCreationDto` | — |
| `validTo` | `validTo` | Instant | технически возможен (reference) | не задано | не задано | — | `TermOfServiceCreationDto` | — |
| `indefinitely` | `indefinitely` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `TermOfServiceCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
