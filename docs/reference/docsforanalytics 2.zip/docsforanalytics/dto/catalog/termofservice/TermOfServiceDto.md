# `TermOfServiceDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.termofservice`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.termofservice.TermOfServiceDto`
- **Java package:** `ru.korusconsulting.alis.dto.termofservice`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [IdActiveCodeDto](../wms/IdActiveCodeDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [TermOfServiceDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/termofservice/TermOfServiceDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/termofservice/{id}` | `TermOfServiceController` (ALIS) |
| response | `POST` `/termofservice` | `TermOfServiceController` (ALIS) |
| response | `POST` `/termofservice/page` | `TermOfServiceController` (ALIS) |
| response | `PUT` `/termofservice/{id}` | `TermOfServiceController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | — | `IdCodeDto` | — |
| `active` | `active` | Boolean | технически возможен (reference) | не задано | не задано | — | `IdActiveCodeDto` | — |
| `syncId` | `syncId` | UUID | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `client` | `client` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `contract` | `contract` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `currency` | `currency` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `validFrom` | `validFrom` | Instant | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `validTo` | `validTo` | Instant | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |
| `indefinitely` | `indefinitely` | Boolean | технически возможен (reference) | не задано | не задано | — | `TermOfServiceDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
