# `WaybillProductDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.waybillproduct`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybillproduct.WaybillProductDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.waybillproduct`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [WaybillProductDto](WaybillProductDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [WaybillProductDetailedDto.java:13](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybillproduct/WaybillProductDetailedDto.java#L13)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/waybill-product/{id}` | `WaybillProductController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `etsngCode` | `etsngCode` | [EtsngCodeDto](../etsng/EtsngCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | ЕТСНГ код |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Масса (кг) |
| `volume` | `volume` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Объем |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Максимальная длина груза |
| `width` | `width` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Максимальная ширина груза |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Максимальная высота груза |
| `additional` | `additional` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDto` | Дополнительная информация |
| `dangerClass` | `dangerClass` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Код класса опасности |
| `gngCode` | `gngCode` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Груз по ГНГ |
| `cargoFullName` | `cargoFullName` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Точное наименование груза |
| `marksStampsShipper` | `marksStampsShipper` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Знаки и марки грузоотправителя |
| `signDanger` | `signDanger` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Признак опасности |
| `isDangerous` | `isDangerous` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Аварийный груз |
| `emergencyCardNumber` | `emergencyCardNumber` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Номер аварийной карты |
| `customsDeclarationNumber` | `customsDeclarationNumber` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Номер декларации на товар |
| `customsDeclarationProductNumber` | `customsDeclarationProductNumber` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Номер позиции груза в декларации |
| `packagingType` | `packagingType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Вид упаковки |
| `packagesCount` | `packagesCount` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Количество пакетов |
| `placesCount` | `placesCount` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Количество мест |
| `weightLoaded` | `weightLoaded` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Масса погруженного груза |
| `grossWeight` | `grossWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Масса места брутто |
| `netWeight` | `netWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillProductDetailedDto` | Масса места нетто |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
