# `OutboundDataDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.outbounddata`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.outbounddata.OutboundDataDto`
- **Java package:** `ru.korusconsulting.alis.dto.outbounddata`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [OutboundDataDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/outbounddata/OutboundDataDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/outbounddata/{id}` | `OutboundDataController` (ALIS) |
| response | `POST` `/outbounddata/page` | `OutboundDataController` (ALIS) |
| response | `PUT` `/outbounddata/resend/{id}` | `OutboundDataController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `messageType` | `messageType` | MessageType | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `entityType` | `entityType` | EntityType | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `rootObjectId` | `rootObjectId` | UUID | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `success` | `success` | Boolean | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `messageId` | `messageId` | UUID | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `responseCode` | `responseCode` | Integer | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `errorMessage` | `errorMessage` | String | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `attempts` | `attempts` | Integer | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `lastAttemptAt` | `lastAttemptAt` | Instant | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `createdAt` | `createdAt` | Instant | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |
| `updatedAt` | `updatedAt` | Instant | технически возможен (reference) | не задано | не задано | — | `OutboundDataDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
