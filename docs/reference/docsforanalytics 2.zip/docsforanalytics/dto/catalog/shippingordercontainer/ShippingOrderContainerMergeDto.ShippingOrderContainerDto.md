# `ShippingOrderContainerMergeDto.ShippingOrderContainerDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

Вложенный DTO `ShippingOrderContainerMergeDto.ShippingOrderContainerDto`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercontainer.ShippingOrderContainerMergeDto.ShippingOrderContainerDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercontainer`
- **Тип:** `class` (nested)
- **Использование в controller signatures:** не найдено
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderContainerMergeDto.java:41](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercontainer/ShippingOrderContainerMergeDto.java#L41)
- **Вложен в:** [ShippingOrderContainerMergeDto](ShippingOrderContainerMergeDto.md)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `container` | `container` | ru.korusconsulting.alis.dto.container.ContainerDto | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | КТК |
| `sealNumbers` | `sealNumbers` | List<String> | технически возможен (reference) | не задано | не задано | `elements: @NotBlank` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Номера ЗПУ |
| `sealType` | `sealType` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Тип ЗПУ |
| `empty` | `empty` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Порожний |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Min(0)` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Масса с грузом (брутто) |
| `customsClearance` | `customsClearance` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Таможенная очистка |
| `actualQuantity` | `actualQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Min(0)` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Фактическое количество |
| `dangerClass` | `dangerClass` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Класс опасности груза |
| `random` | `random` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Является ли контейнер произвольным |
| `dataTimeKrugloyePole` | `dataTimeKrugloyePole` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Дата и время прибытия на ст. "Круглое поле" |
| `customerService` | `customerService` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Заказчик услуг |
| `ownerRailwayCarriage` | `ownerRailwayCarriage` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Собственник вагона |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Собственник КТК |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerMergeDto.ShippingOrderContainerDto` | Номер КТК неизвестен |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
