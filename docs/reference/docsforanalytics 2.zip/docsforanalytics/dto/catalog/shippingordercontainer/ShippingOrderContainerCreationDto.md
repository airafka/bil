# `ShippingOrderContainerCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordercontainer`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercontainer.ShippingOrderContainerCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercontainer`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** `BaseCreationDto`
- **Class-level validation:** `@ValidShippingOrderContainer`
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderContainerCreationDto.java:27](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercontainer/ShippingOrderContainerCreationDto.java#L27)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/shippingordercontainer` | `ShippingOrderContainerController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `shippingOrder` | `shippingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ShippingOrderContainerCreationDto` | — |
| `shippingOrderRailwayCarriage` | `shippingOrderRailwayCarriage` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderContainerCreationDto` | — |
| `container` | `container` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderContainerCreationDto` | — |
| `sealNumbers` | `sealNumbers` | List<String> | технически возможен (reference) | не задано | не задано | `elements: @NotBlank`, `elements: @Size(max = 50)` | `ShippingOrderContainerCreationDto` | — |
| `sealType` | `sealType` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `empty` | `empty` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerCreationDto` | — |
| `customsClearance` | `customsClearance` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `dangerClass` | `dangerClass` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ShippingOrderContainerCreationDto` | — |
| `random` | `random` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | default: `Boolean.TRUE` |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `dataTimeKrugloyePole` | `dataTimeKrugloyePole` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `customerService` | `customerService` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `ownerRailwayCarriage` | `ownerRailwayCarriage` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
