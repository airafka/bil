# `ShippingOrderContainerItemPreviewDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordercontainer`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercontainer.ShippingOrderContainerItemPreviewDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercontainer`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderContainerItemPreviewDto.java:17](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercontainer/ShippingOrderContainerItemPreviewDto.java#L17)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/shippingordercontaineritem/preview` | `ShippingOrderContainerItemController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `container` | `container` | [ContainerDto](../container/ContainerDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerItemPreviewDto` | — |
| `etsngCode` | `etsngCode` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerItemPreviewDto` | — |
| `grossWeight` | `grossWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerItemPreviewDto` | — |
| `netWeight` | `netWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderContainerItemPreviewDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
