# `ReceivingOrderRailwayCarriagePreviewDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

KIS-3631 (legacy compatibility): старый формат ответа эндпоинта {@code POST /receivingorderrailwaycarriage/preview}. Соответствие со старой схемой ↔ новая модель: {@code id} — раньше {@code ReceivingOrderRailwayCarriage.id}; теперь {@code WaybillRailwayCarriage.id}. {@code etranInvoice} — раньше ссылка на {@code EtranInvoice}; теперь маппится из {@code Waybill}: {@code id = waybill.id}, {@code code = waybill.number}. {@code railwayCarriage} — без изменений ({@code RailwayCarriage}). {@code containers} — раньше {@code ReceivingOrderContainer[]}; теперь {@code WaybillContainer[]} принадлежащие конкретному вагону накладной. Это обёртка для обратной совместимости с фронтом, который ещё ходит на старый URL. Новый код должен использовать {@code POST /receivingorderrailwaycarriage/preview/{receivingOrderId}} → {@code ReceivingOrderWaybillCarriageGroupDto}.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingorderrailwaycarriage.ReceivingOrderRailwayCarriagePreviewDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingorderrailwaycarriage`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderRailwayCarriagePreviewDto.java:37](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorderrailwaycarriage/ReceivingOrderRailwayCarriagePreviewDto.java#L37)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/receivingorderrailwaycarriage/preview` | `ReceivingOrderRailwayCarriageController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `etranInvoice` | `etranInvoice` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderRailwayCarriagePreviewDto` | — |
| `railwayCarriage` | `railwayCarriage` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderRailwayCarriagePreviewDto` | — |
| `containers` | `containers` | List<[ContainerPreviewDto](../container/ContainerPreviewDto.md)> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderRailwayCarriagePreviewDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
