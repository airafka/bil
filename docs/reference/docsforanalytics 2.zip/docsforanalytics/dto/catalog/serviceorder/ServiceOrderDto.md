# `ServiceOrderDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.serviceorder`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.serviceorder.ServiceOrderDto`
- **Java package:** `ru.korusconsulting.alis.dto.serviceorder`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ServiceOrderDto.java:22](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/serviceorder/ServiceOrderDto.java#L22)
- **Ручной бизнес-паспорт:** [ServiceOrderDto.md](../../service-order/ServiceOrderDto.md)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `DELETE` `/service-order/{id}` | `ServiceOrderController` (ALIS) |
| response | `GET` `/service-order/{id}` | `ServiceOrderController` (ALIS) |
| response | `POST` `/service-order` | `ServiceOrderController` (ALIS) |
| response | `POST` `/service-order/page` | `ServiceOrderController` (ALIS) |
| response | `POST` `/service-order/{id}/accept` | `ServiceOrderController` (ALIS) |
| response | `PUT` `/service-order/{id}` | `ServiceOrderController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Номер |
| `client` | `client` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Клиент |
| `createdAt` | `createdAt` | Instant | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Дата создания |
| `containerQuantity` | `containerQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Количество КТК |
| `service` | `service` | ServiceOrderType | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Услуга |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Комментарий |
| `status` | `status` | ServiceOrderStatus | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Статус |
| `completionAt` | `completionAt` | Instant | технически возможен (reference) | не задано | не задано | — | `ServiceOrderDto` | Дата выполнения |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
