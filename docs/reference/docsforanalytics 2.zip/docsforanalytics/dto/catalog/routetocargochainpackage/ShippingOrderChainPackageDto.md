# `ShippingOrderChainPackageDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.routetocargochainpackage`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.routetocargochainpackage.ShippingOrderChainPackageDto`
- **Java package:** `ru.korusconsulting.alis.dto.routetocargochainpackage`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderChainPackageDto.java:20](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/routetocargochainpackage/ShippingOrderChainPackageDto.java#L20)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `orderStatus` | `orderStatus` | OrderStatus | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `clientId` | `clientId` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `contractId` | `contractId` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `terminalArea` | `terminalArea` | TerminalArea | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `plannedShippingDateTime` | `plannedShippingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `actualShippingDateTime` | `actualShippingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `currencyId` | `currencyId` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `contactName` | `contactName` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `contactPhone` | `contactPhone` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `contactEmail` | `contactEmail` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalSKUQuantity` | `totalSKUQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalWeight` | `totalWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalCargoQuantity` | `totalCargoQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalPalletQuantity` | `totalPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalNotPalletQuantity` | `totalNotPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalGoodsPrice` | `totalGoodsPrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalRequestedServiceQuantity` | `totalRequestedServiceQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalRequestedServicePrice` | `totalRequestedServicePrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `totalContainerQuantity` | `totalContainerQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `deliveryType` | `deliveryType` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `routeId` | `routeId` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `needTransport` | `needTransport` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `consigneeAddress` | `consigneeAddress` | String | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `shipperId` | `shipperId` | UUID | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ShippingOrderChainPackageDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
