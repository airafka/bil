# `ReceivingOrderCargoDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.receivingordercargo`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingordercargo.ReceivingOrderCargoDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingordercargo`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [ReceivingOrderCargoDto](ReceivingOrderCargoDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderCargoDetailedDto.java:15](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingordercargo/ReceivingOrderCargoDetailedDto.java#L15)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/receivingordercargo/multipleaddition` | `ReceivingOrderCargoController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `receivingOrder` | `receivingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `receivingOrderGood` | `receivingOrderGood` | [ReceivingOrderGoodInCargoDto](ReceivingOrderGoodInCargoDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `clientGood` | `clientGood` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `cargo` | `cargo` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `barcode` | `barcode` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `goodPackage` | `goodPackage` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `packageQuantity` | `packageQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `conversionQuantity` | `conversionQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `totalQuantity` | `totalQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `width` | `width` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `volume` | `volume` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDto` | — |
| `receivingOrderGoodList` | `receivingOrderGoodList` | List<[ReceivingOrderGoodDto](../receivingordergood/ReceivingOrderGoodDto.md)> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderCargoDetailedDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
