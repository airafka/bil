# `RailwayCarriageUpdateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.railway`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.railway.RailwayCarriageUpdateDto`
- **Java package:** `ru.korusconsulting.alis.dto.railway`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [RailwayCarriageCreationDto](RailwayCarriageCreationDto.md)
- **Интерфейсы:** `BaseUpdateDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [RailwayCarriageUpdateDto.java:15](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/railway/RailwayCarriageUpdateDto.java#L15)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `PUT` `/railwaycarriage/{id}` | `RailwayCarriageController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `active` | `active` | Boolean | разрешён (`@Nullable`) | не задано | не задано | — | `BaseActivatedCreationDto` | — |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `RailwayCarriageCreationDto` | — |
| `type` | `type` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@NotNull` | `RailwayCarriageCreationDto` | — |
| `liftingCapacity` | `liftingCapacity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@NotNull` | `RailwayCarriageCreationDto` | — |
| `model` | `model` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `dateDepotRepair` | `dateDepotRepair` | Instant | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `sort` | `sort` | String | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `volume` | `volume` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `axlesCount` | `axlesCount` | Integer | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `owner` | `owner` | String | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `proxyOperator` | `proxyOperator` | String | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `mileageRate` | `mileageRate` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `mileage` | `mileage` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `remainingMileage` | `remainingMileage` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `noworkingParking` | `noworkingParking` | Boolean | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageCreationDto` | — |
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `RailwayCarriageUpdateDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
