# `ReceivingOrderDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.receivingorder`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingorder.ReceivingOrderDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingorder`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [ReceivingOrderDto](ReceivingOrderDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderDetailedDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderDetailedDto.java#L18)
- **Ручной бизнес-паспорт:** [ReceivingOrderDetailedDto.md](../../receiving-order/ReceivingOrderDetailedDto.md)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/receivingorder/{id}/preview` | `ReceivingOrderController` (ALIS) |
| response | `POST` `/receivingorder/{id}/full-copy` | `ReceivingOrderController` (ALIS) |
| response | `POST` `/receivingorder/{id}/partial-copy` | `ReceivingOrderController` (ALIS) |
| response | `PUT` `/receivingorder/{id}/confirm-document` | `ReceivingOrderController` (ALIS) |
| response | `PUT` `/receivingorder/{id}/unconfirm-document` | `ReceivingOrderController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `client` | `client` | [IdCodeNamedDto](../wms/IdCodeNamedDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `defaultContainerOwner` | `defaultContainerOwner` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `orderStatus` | `orderStatus` | OrderStatus | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `planReceivingDateTime` | `planReceivingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `actualReceivingDateTime` | `actualReceivingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `storagePeriod` | `storagePeriod` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `createdAt` | `createdAt` | Instant | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `contract` | `contract` | [ContractShortDto](../contract/ContractShortDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `currency` | `currency` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `contact` | `contact` | [ContactDto](../contact/ContactDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `deliveryType` | `deliveryType` | ReceivingOrderDeliveryType | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `route` | `route` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `needTransport` | `needTransport` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `shipper` | `shipper` | [ClientRelatedEntityShortDto](../clientrelatedentity/ClientRelatedEntityShortDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `waybill` | `waybill` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `documentConfirmed` | `documentConfirmed` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `ktkNumberUnknown` | `ktkNumberUnknown` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `payer` | `payer` | [PayerDto](../payer/PayerDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `departureStation` | `departureStation` | [RailwayStationDto](../railway/RailwayStationDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `destinationStation` | `destinationStation` | [RailwayStationDto](../railway/RailwayStationDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDto` | — |
| `totalSKUQuantity` | `totalSKUQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalWeight` | `totalWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalCargoQuantity` | `totalCargoQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalPalletQuantity` | `totalPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalNotPalletQuantity` | `totalNotPalletQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalRailwayCarriageQuantity` | `totalRailwayCarriageQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalContainerQuantity` | `totalContainerQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalGoodsPrice` | `totalGoodsPrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalRequestedServiceQuantity` | `totalRequestedServiceQuantity` | Long | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `totalRequestedServicePrice` | `totalRequestedServicePrice` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `clientDriver` | `clientDriver` | [ClientDriverDto](../clientdriver/ClientDriverDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `clientVehicle` | `clientVehicle` | [ClientVehiclePreviewDto](../clientvehicle/ClientVehiclePreviewDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |
| `legalEntityInn` | `legalEntityInn` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderDetailedDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
