# `ReceivingOrderWaybillCarriageFilter`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

Фильтр для вкладки «Вагоны» внутри заявки на поставку.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybill.ReceivingOrderWaybillCarriageFilter`
- **Java package:** `ru.korusconsulting.alis.dto.waybill`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** BaseFilter
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderWaybillCarriageFilter.java:30](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybill/ReceivingOrderWaybillCarriageFilter.java#L30)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `carriageNumber` (aliases: `number`) | `carriageNumber` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `railwayCarriageType` (aliases: `sort`) | `railwayCarriageType` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | Род вагона: значение поля railwayCarriage.sort. |
| `railwayCarriageModel` (aliases: `model`) | `railwayCarriageModel` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `liftingCapacity` | `liftingCapacity` | SearchNumber<BigDecimal> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `ownership` | `ownership` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `dateDepotRepair` | `dateDepotRepair` | SearchDate<Instant> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `status` | `status` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `search` | `search` | SearchString | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `anyOfId` | `anyOfId` | Set<UUID> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |
| `pageInfo` | `pageInfo` | PageInfo | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillCarriageFilter` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
- Поля внешнего родителя `BaseFilter` не раскрыты: его исходник не найден среди DTO source roots.
