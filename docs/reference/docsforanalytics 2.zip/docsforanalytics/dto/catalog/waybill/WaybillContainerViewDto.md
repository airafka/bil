# `WaybillContainerViewDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

КТК из накладной (вкладка «КТК»)

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybill.WaybillContainerViewDto`
- **Java package:** `ru.korusconsulting.alis.dto.waybill`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [WaybillContainerViewDto.java:19](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybill/WaybillContainerViewDto.java#L19)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `containerId` | `containerId` | UUID | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | id контейнера из справочника Container (waybill_container.container_id) |
| `number` | `number` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `containerType` | `containerType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `tareWeight` | `tareWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `grossWeight` | `grossWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `netWeight` | `netWeight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `liftingCapacity` | `liftingCapacity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `owner` | `owner` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `zpuNumbers` | `zpuNumbers` | List<String> | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `zpuType` | `zpuType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | — |
| `status` | `status` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | Статус обработки КТК в рамках заявки (TaskStatus) |
| `containerStatus` | `containerStatus` | ContainerStatus | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | Текущее состояние КТК в регистре остатков. |
| `etsngCode` | `etsngCode` | String | технически возможен (reference) | не задано | не задано | — | `WaybillContainerViewDto` | Код ЕТСНГ из грузов накладной (через запятую, если несколько) |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
