# `ReceivingOrderWaybillContainerFilter`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

Фильтр для вкладки «КТК» внутри заявки на поставку.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybill.ReceivingOrderWaybillContainerFilter`
- **Java package:** `ru.korusconsulting.alis.dto.waybill`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** BaseFilter
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderWaybillContainerFilter.java:27](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybill/ReceivingOrderWaybillContainerFilter.java#L27)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `containerNumber` (aliases: `number`) | `containerNumber` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `carriageNumber` | `carriageNumber` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `containerType` (aliases: `type`) | `containerType` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `tareWeight` | `tareWeight` | SearchNumber<BigDecimal> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `grossWeight` (aliases: `weight`) | `grossWeight` | SearchNumber<BigDecimal> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `liftingCapacity` | `liftingCapacity` | SearchNumber<BigDecimal> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `owner` | `owner` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `ownerContainer` | `ownerContainer` | ClientFilter | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `zpu` | `zpu` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `zpuType` | `zpuType` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `status` | `status` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `search` | `search` | SearchString | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `anyOfId` | `anyOfId` | Set<UUID> | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |
| `pageInfo` | `pageInfo` | PageInfo | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderWaybillContainerFilter` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
- Поля внешнего родителя `BaseFilter` не раскрыты: его исходник не найден среди DTO source roots.
