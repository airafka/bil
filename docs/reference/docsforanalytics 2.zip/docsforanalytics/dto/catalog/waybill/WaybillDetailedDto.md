# `WaybillDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.waybill`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybill.WaybillDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.waybill`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [WaybillDetailedDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybill/WaybillDetailedDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/waybill/{id}` | `WaybillController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `status` | `status` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Статус |
| `creationSource` | `creationSource` | WaybillCreationSource | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Источник накладной |
| `number` | `number` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Номер накладной |
| `waybillIdentifier` | `waybillIdentifier` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | ИД накладной в АС ЭТРАН |
| `type` | `type` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Тип накладной |
| `shipmentType` | `shipmentType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Вид отправки |
| `shipmentSpeed` | `shipmentSpeed` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Скорость отправки |
| `formType` | `formType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Тип бланка |
| `deliveryDeadline` | `deliveryDeadline` | LocalDate | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата истечения срока доставки |
| `departure` | `departure` | [StationDto](WaybillDetailedDto.StationDto.md) | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Станция отправления |
| `shipperName` | `shipperName` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Наименование грузоотправителя |
| `shipperAddress` | `shipperAddress` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Адрес грузоотправителя |
| `shipperTgnl` | `shipperTgnl` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | ТГНЛ грузоотправителя |
| `shipperOkpo` | `shipperOkpo` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | ОКПО грузоотправителя |
| `payer` | `payer` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Плательщик |
| `paymentForm` | `paymentForm` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Форма оплаты |
| `railwayCarriageOwnershipType` | `railwayCarriageOwnershipType` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Планируемый тип собственности вагонов |
| `responsiblePerson` | `responsiblePerson` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Ответственное лицо |
| `waybillCreatedAt` | `waybillCreatedAt` | Instant | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата создания накладной в АС ЭТРАН |
| `submittedAt` | `submittedAt` | Instant | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата предъявления |
| `acceptedAt` | `acceptedAt` | Instant | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата принятия приемосдатчиком |
| `cargoAcceptedAt` | `cargoAcceptedAt` | Instant | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата принятия груза |
| `departureAt` | `departureAt` | Instant | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Дата отправления |
| `destination` | `destination` | [StationDto](WaybillDetailedDto.StationDto.md) | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Станция назначения |
| `consigneeName` | `consigneeName` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Наименование грузополучателя |
| `consigneeAddress` | `consigneeAddress` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Адрес грузополучателя |
| `consigneeTgnl` | `consigneeTgnl` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | ТГНЛ грузополучателя |
| `consigneeOkpo` | `consigneeOkpo` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | ОКПО грузополучателя |
| `payerCode` | `payerCode` | Long | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Код плательщика |
| `paymentPlace` | `paymentPlace` | String | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Место оплаты |
| `plannedRailwayCarriages` | `plannedRailwayCarriages` | Integer | технически возможен (reference) | не задано | не задано | — | `WaybillDetailedDto` | Планируемое число вагонов |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
