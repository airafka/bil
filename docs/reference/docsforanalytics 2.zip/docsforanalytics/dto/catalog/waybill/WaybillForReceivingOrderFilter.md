# `WaybillForReceivingOrderFilter`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

Фильтр для вкладки «Накладные ЭТРАН» внутри заявки

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.waybill.WaybillForReceivingOrderFilter`
- **Java package:** `ru.korusconsulting.alis.dto.waybill`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** [WaybillBaseFilter](WaybillBaseFilter.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** `@AssertTrue → isRequiredFieldsPresent()`
- **Java-источник:** [WaybillForReceivingOrderFilter.java:19](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybill/WaybillForReceivingOrderFilter.java#L19)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `payerId` | `payerId` | UUID | технически возможен (reference) | не задано | не задано | — | `WaybillBaseFilter` | — |
| `departureStationId` | `departureStationId` | UUID | технически возможен (reference) | не задано | не задано | — | `WaybillBaseFilter` | — |
| `destinationStationId` | `destinationStationId` | UUID | технически возможен (reference) | не задано | не задано | — | `WaybillBaseFilter` | — |
| `pageInfo` | `pageInfo` | PageInfo | технически возможен (reference) | не задано | не задано | — | `WaybillBaseFilter` | — |
| `receivingOrderId` | `receivingOrderId` | UUID | технически возможен (reference) | не задано | не задано | — | `WaybillForReceivingOrderFilter` | — |
| `search` | `search` | SearchString | технически возможен (reference) | не задано | не задано | — | `WaybillForReceivingOrderFilter` | Полнотекстовый поиск по колонкам таблицы выбора накладных: {@code number}, {@code waybillCreatedAt}, {@code shipmentType}, {@code status}. Семантика: OR (накладная попадает в выдачу, если хотя бы одна из колонок содержит подстроку). Если поле пустое или не передано — поиск не применяется. Контракт обёртки совпадает с {@code POST /etraninvoice/page} (см. {@code EtranInvoiceFilter.search}): JSON {@code {"type": "CONTAINS", "content": "abc", "byOr": true}}. |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
