# `ParamTemplateDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.template`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.template.ParamTemplateDto`
- **Java package:** `ru.korusconsulting.alis.dto.template`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ParamTemplateDto.java:11](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/template/ParamTemplateDto.java#L11)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `etranInvoices` | `etranInvoices` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `shippers` | `shippers` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `consignees` | `consignees` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `railwayStations` | `railwayStations` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `containerCodes` | `containerCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `dangerClasses` | `dangerClasses` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `railwayCarriageCodes` | `railwayCarriageCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `railwayCarriageTypes` | `railwayCarriageTypes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `railwayCarriageModels` | `railwayCarriageModels` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `etsngCodes` | `etsngCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `transportationTypes` | `transportationTypes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `containerTypes` | `containerTypes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `clientGoodItems` | `clientGoodItems` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `batchCodes` | `batchCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `goodPackageCodes` | `goodPackageCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `sealTypeCodes` | `sealTypeCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `standardSizeCodes` | `standardSizeCodes` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |
| `partners` | `partners` | List<String> | технически возможен (reference) | не задано | не задано | — | `ParamTemplateDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
