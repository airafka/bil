# `IdsCodeDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.wms.dto`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.wms.dto.IdsCodeDto`
- **Java package:** `ru.korusconsulting.wms.dto`
- **Тип:** `record` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [IdsCodeDto.java:7](../../../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/IdsCodeDto.java#L7)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/cargo/meta/{fieldName}` | `CargoController` (ALIS) |
| response | `POST` `/client/meta/{fieldName}` | `ClientController` (ALIS) |
| response | `POST` `/clientdriver/meta/{fieldName}` | `ClientDriverController` (ALIS) |
| response | `POST` `/clientgood/meta/{fieldName}` | `ClientGoodController` (ALIS) |
| response | `POST` `/clientgooddigitalsign/meta/{fieldName}` | `ClientGoodDigitalSignController` (ALIS) |
| response | `POST` `/clientgoodtype/meta/{fieldName}` | `ClientGoodTypeController` (ALIS) |
| response | `POST` `/clientrelatedentity/meta/{fieldName}` | `ClientRelatedEntityController` (ALIS) |
| response | `POST` `/clientvehicle/meta/{fieldName}` | `ClientVehicleController` (ALIS) |
| response | `POST` `/company/meta/{fieldName}` | `CompanyController` (ALIS) |
| response | `POST` `/container/meta/{fieldName}` | `ContainerController` (ALIS) |
| response | `POST` `/containermovement/meta/{fieldName}` | `ContainerMovementController` (ALIS) |
| response | `POST` `/container/{id}/owner-history/meta/{fieldName}` | `ContainerOwnerHistoryController` (ALIS) |
| response | `POST` `/contract/meta/{fieldName}` | `ContractController` (ALIS) |
| response | `POST` `/currency/meta/{fieldName}` | `CurrencyController` (ALIS) |
| response | `POST` `/dangerclass/meta/{fieldName}` | `DangerClassController` (ALIS) |
| response | `POST` `/etsngcode/meta/{fieldName}` | `EtsngCodeController` (ALIS) |
| response | `POST` `/frequencyofservices/meta/{fieldName}` | `FrequencyOfServicesController` (ALIS) |
| response | `POST` `/goodgroup/meta/{fieldName}` | `GoodGroupController` (ALIS) |
| response | `POST` `/goodpackagebarcode/meta/{fieldName}` | `GoodPackageBarcodeController` (ALIS) |
| response | `POST` `/goodpackage/meta/{fieldName}` | `GoodPackageController` (ALIS) |
| response | `POST` `/goodtype/meta/{fieldName}` | `GoodTypeController` (ALIS) |
| response | `POST` `/loadingtype/meta/{fieldName}` | `LoadingTypeController` (ALIS) |
| response | `POST` `/producttype/meta/{fieldName}` | `ProductTypeController` (ALIS) |
| response | `POST` `/railwaycarriage/meta/{fieldName}` | `RailwayCarriageController` (ALIS) |
| response | `POST` `/railwaycarriagemodel/meta/{fieldName}` | `RailwayCarriageModelController` (ALIS) |
| response | `POST` `/railwaycarriagetype/meta/{fieldName}` | `RailwayCarriageTypeController` (ALIS) |
| response | `POST` `/railwaystation/meta/{fieldName}` | `RailwayStationController` (ALIS) |
| response | `POST` `/receivingorderblackbox/meta/{fieldName}` | `ReceivingOrderBlackboxController` (ALIS) |
| response | `POST` `/receivingorderblackbox/receiving-order/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderBlackboxController` (ALIS) |
| response | `POST` `/receivingordercargo/meta/{fieldName}` | `ReceivingOrderCargoController` (ALIS) |
| response | `POST` `/receivingordercargo/receiving-order/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderCargoController` (ALIS) |
| response | `POST` `/receivingordercontainer/meta/{fieldName}` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receivingordercontainer/receiving-order/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderContainerController` (ALIS) |
| response | `POST` `/receivingordercontaineritem/meta/{fieldName}` | `ReceivingOrderContainerItemController` (ALIS) |
| response | `POST` `/receivingordercontaineritem/receiving-order/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderContainerItemController` (ALIS) |
| response | `POST` `/receivingorder/meta/{fieldName}` | `ReceivingOrderController` (ALIS) |
| response | `POST` `/receivingorder/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderController` (ALIS) |
| response | `POST` `/receivingordergood/meta/{fieldName}` | `ReceivingOrderGoodController` (ALIS) |
| response | `POST` `/receivingordergood/receiving-order/{receivingOrderId}/meta/{fieldName}` | `ReceivingOrderGoodController` (ALIS) |
| response | `POST` `/receivingorderrequestedservice/meta/{fieldName}` | `ReceivingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/role/meta/{fieldName}` | `RoleController` (WMS) |
| response | `POST` `/role/{roleId}/permission/meta/{fieldName}` | `RolePermissionController` (WMS) |
| response | `POST` `/routes/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/routes/{routeId}/orders/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/routes/{routeId}/shipping-order/auto/fact/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/routes/{routeId}/shipping-order/container/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/routes/{routeId}/shipping-order/fact/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/routes/{routeId}/shipping-order/railway-carriage/meta/{fieldName}` | `RouteController` (ALIS) |
| response | `POST` `/service/meta/{fieldName}` | `ServiceController` (ALIS) |
| response | `POST` `/service-order/{serviceOrderId}/container/edit/meta/{fieldName}` | `ServiceOrderContainerController` (ALIS) |
| response | `POST` `/service-order/{serviceOrderId}/container/meta/{fieldName}` | `ServiceOrderContainerController` (ALIS) |
| response | `POST` `/service-order/meta/{fieldName}` | `ServiceOrderController` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-blackbox/meta/{fieldName}` | `ShippingOrderBlackboxControllerV2` (ALIS) |
| response | `POST` `/shippingordercargo/meta/{fieldName}` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-cargo/meta/{fieldName}` | `ShippingOrderCargoControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-container/meta/{fieldName}`<br>`/shipping-order/{shippingOrderId}/shipping-order-container/unnumbered/meta/{fieldName}` | `ShippingOrderContainerControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-container-item/meta/{fieldName}` | `ShippingOrderContainerItemControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-container-qty/meta/{fieldName}` | `ShippingOrderContainerQtyController` (ALIS) |
| response | `POST` `/shippingorder/meta/{fieldName}` | `ShippingOrderController` (ALIS) |
| response | `POST` `/shippingorderetraninvoice/meta/{fieldName}` | `ShippingOrderEtranInvoiceController` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-etran-invoice/meta/{fieldName}` | `ShippingOrderEtranInvoiceControllerV2Read` (ALIS) |
| response | `POST` `/shippingordergood/meta/{fieldName}` | `ShippingOrderGoodController` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-good/meta/{fieldName}` | `ShippingOrderGoodControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-railway-carriage/meta/{fieldName}`<br>`/shipping-order/{shippingOrderId}/shipping-order-railway-carriage/unnumbered/meta/{fieldName}` | `ShippingOrderRailwayCarriageControllerV2` (ALIS) |
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-railway-carriage-qty/meta/{fieldName}` | `ShippingOrderRailwayCarriageQtyController` (ALIS) |
| response | `POST` `/shippingorderrequestedservice/meta/{fieldName}` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/standardsize/meta/{fieldName}` | `StandardSizeController` (ALIS) |
| response | `POST` `/termofperiodicservice/meta/{fieldName}` | `TermOfPeriodicServiceController` (ALIS) |
| response | `POST` `/termofrequestedservice/meta/{fieldName}` | `TermOfRequestedServiceController` (ALIS) |
| response | `POST` `/termofservice/meta/{fieldName}` | `TermOfServiceController` (ALIS) |
| response | `POST` `/terminalarea/meta/{fieldName}` | `TerminalAreaController` (ALIS) |
| response | `POST` `/transportpackage/meta/{fieldName}` | `TransportPackageController` (ALIS) |
| response | `POST` `/unitofmeasure/meta/{fieldName}` | `UnitOfMeasureController` (ALIS) |
| response | `POST` `/user/meta/{fieldName}` | `UserController` (ALIS) |
| response | `POST` `/usergroup/meta/{fieldName}` | `UserGroupController` (ALIS) |
| response | `POST` `/usergroup/{groupId}/role/meta/{fieldName}` | `UserGroupRoleController` (ALIS) |
| response | `POST` `/userInfo/client/meta/{fieldName}` | `UserInfoController` (ALIS) |
| response | `POST` `/vehiclebrand/meta/{fieldName}` | `VehicleBrandController` (ALIS) |
| response | `POST` `/vehicletype/meta/{fieldName}` | `VehicleTypeController` (ALIS) |
| response | `POST` `/waybill-container/meta/{fieldName}` | `WaybillContainerController` (ALIS) |
| response | `POST` `/waybill-container/receiving-order/{receivingOrderId}/meta/{fieldName}` | `WaybillContainerController` (ALIS) |
| response | `POST` `/waybill/archive/meta/{fieldName}` | `WaybillController` (ALIS) |
| response | `POST` `/waybill/incoming/meta/{fieldName}` | `WaybillController` (ALIS) |
| response | `POST` `/waybill/outgoing/meta/{fieldName}` | `WaybillController` (ALIS) |
| response | `POST` `/waybill/receiving-order/{receivingOrderId}/meta/{fieldName}` | `WaybillController` (ALIS) |
| response | `POST` `/waybill-product/meta/{fieldName}` | `WaybillProductController` (ALIS) |
| response | `POST` `/waybill-product/receiving-order/{receivingOrderId}/meta/{fieldName}` | `WaybillProductController` (ALIS) |
| response | `POST` `/waybill-railway-carriage/meta/{fieldName}` | `WaybillRailwayCarriageController` (ALIS) |
| response | `POST` `/waybill-railway-carriage/receiving-order/{receivingOrderId}/meta/{fieldName}` | `WaybillRailwayCarriageController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `ids` | `ids` | UUID[] | технически возможен (reference) | не задано | не задано | — | `IdsCodeDto` | Массив идентификаторов сущностей, сгруппированных по значению поля |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | — | `IdsCodeDto` | Значение поля сущности, по которому произведена группировка |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
