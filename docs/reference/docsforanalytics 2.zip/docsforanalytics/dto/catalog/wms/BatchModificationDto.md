# `BatchModificationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.wms.dto`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.wms.dto.BatchModificationDto`
- **Java package:** `ru.korusconsulting.wms.dto`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [BatchModificationDto.java:18](../../../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/BatchModificationDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/receiving-order/{receivingOrderId}/receiving-order-container/batch` | `ReceivingOrderContainerControllerV2` (ALIS) |
| request | `POST` `/receiving-order/{receivingOrderId}/receiving-order-container-item/batch` | `ReceivingOrderContainerItemControllerV2` (ALIS) |
| request | `POST` `/shippingordercargo/{shippingOrderId}/batch` | `ShippingOrderCargoController` (ALIS) |
| request | `POST` `/shippingordergood/{shippingOrderId}/batch` | `ShippingOrderGoodController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `add` | `add` | List<C> | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull`, `elements: @NotNull` | `BatchModificationDto` | default: `Collections.emptyList()` |
| `update` | `update` | List<U> | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull`, `elements: @NotNull` | `BatchModificationDto` | default: `Collections.emptyList()` |
| `delete` | `delete` | Set<UUID> | технически возможен (reference) | не задано | не задано | `@NotNull`, `elements: @NotNull` | `BatchModificationDto` | default: `Collections.emptySet()` |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
