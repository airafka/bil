# `ContractCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.contract`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.contract.ContractCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.contract`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** `BaseCreationDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ContractCreationDto.java:24](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/contract/ContractCreationDto.java#L24)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/contract` | `ContractController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | `@NotBlank`, `@Size(max = ValidationConstants.MAX_LENGTH_100)` | `ContractCreationDto` | — |
| `name` | `name` | String | технически возможен (reference) | не задано | не задано | `@NotBlank` | `ContractCreationDto` | — |
| `active` | `active` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractCreationDto` | — |
| `syncId` | `syncId` | UUID | разрешён (`@Nullable`) | не задано | не задано | — | `ContractCreationDto` | — |
| `edoId` | `edoId` | String | разрешён (`@Nullable`) | не задано | не задано | — | `ContractCreationDto` | — |
| `client` | `client` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ContractCreationDto` | — |
| `company` | `company` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ContractCreationDto` | — |
| `currency` | `currency` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ContractCreationDto` | — |
| `contractDate` | `contractDate` | Instant | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractCreationDto` | — |
| `contractType` | `contractType` | ContractType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractCreationDto` | — |
| `validFrom` | `validFrom` | Instant | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractCreationDto` | — |
| `validTo` | `validTo` | Instant | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
