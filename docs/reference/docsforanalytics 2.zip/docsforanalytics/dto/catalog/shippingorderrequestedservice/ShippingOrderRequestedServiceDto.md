# `ShippingOrderRequestedServiceDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingorderrequestedservice`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingorderrequestedservice.ShippingOrderRequestedServiceDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingorderrequestedservice`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderRequestedServiceDto.java:18](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorderrequestedservice/ShippingOrderRequestedServiceDto.java#L18)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `DELETE` `/shippingorderrequestedservice/{id}` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `GET` `/shippingorderrequestedservice/{id}` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/shippingorderrequestedservice` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/shippingorderrequestedservice/all` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/shippingorderrequestedservice/multipleaddition` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `POST` `/shippingorderrequestedservice/page` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `PUT` `/shippingorderrequestedservice/multipleupdate` | `ShippingOrderRequestedServiceController` (ALIS) |
| response | `PUT` `/shippingorderrequestedservice/{id}` | `ShippingOrderRequestedServiceController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `shippingOrder` | `shippingOrder` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `termOfRequestedService` | `termOfRequestedService` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `serviceOfMeasure` | `serviceOfMeasure` | ServiceOfMeasure | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `plannedQuantity` | `plannedQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `rate` | `rate` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `priceWithoutVAT` | `priceWithoutVAT` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `priceWithVAT` | `priceWithVAT` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `actualQuantity` | `actualQuantity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `systemManaged` | `systemManaged` | boolean | невозможен (`primitive`) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |
| `deleted` | `deleted` | boolean | невозможен (`primitive`) | не задано | не задано | — | `ShippingOrderRequestedServiceDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
