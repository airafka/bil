# `ContractEdoDatareonDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.datareon`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.datareon.ContractEdoDatareonDto`
- **Java package:** `ru.korusconsulting.alis.dto.datareon`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ContractEdoDatareonDto.java:16](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/ContractEdoDatareonDto.java#L16)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/datareon/contract` | `DatareonController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `_id` | `id` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `_client` | `client` | String | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ContractEdoDatareonDto` | — |
| `_company` | `company` | String | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ContractEdoDatareonDto` | — |
| `number` | `number` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `date` | `date` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `dateFrom` | `dateFrom` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `dateTo` | `dateTo` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `currency` | `currency` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |
| `contractType` | `contractType` | ContractType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractEdoDatareonDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
