# `ContractorEdoDatareonDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.datareon`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.datareon.ContractorEdoDatareonDto`
- **Java package:** `ru.korusconsulting.alis.dto.datareon`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ContractorEdoDatareonDto.java:14](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/ContractorEdoDatareonDto.java#L14)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/datareon/contractor` | `DatareonController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `_id` | `id` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractorEdoDatareonDto` | — |
| `name` | `name` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractorEdoDatareonDto` | — |
| `fullName` | `fullName` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `INN` | `inn` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractorEdoDatareonDto` | — |
| `KPP` | `kpp` | String | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContractorEdoDatareonDto` | — |
| `OKPO` | `okpo` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `OGRN` | `ogrn` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `addressLegal` | `addressLegal` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `addressFact` | `addressFact` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `signatoryName` | `signatoryName` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `signatoryPosition` | `signatoryPosition` | String | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |
| `isClient` | `isClient` | Boolean | технически возможен (reference) | не задано | не задано | — | `ContractorEdoDatareonDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
