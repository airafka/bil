# `RouteCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.route`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.route.RouteCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.route`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** нет
- **Интерфейсы:** `BaseCreationDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [RouteCreationDto.java:23](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/route/RouteCreationDto.java#L23)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/routes` | `RouteController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `routeType` | `routeType` | RouteType | технически возможен (reference) | не задано | не задано | `@NotNull` | `RouteCreationDto` | — |
| `dataTime` | `dataTime` | Instant | технически возможен (reference) | не задано | не задано | `@NotNull` | `RouteCreationDto` | — |
| `terminalArea` | `terminalArea` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@NotNull` | `RouteCreationDto` | — |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | `@NotNull` | `RouteCreationDto` | — |
| `clientRelatedEntity` | `clientRelatedEntity` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteCreationDto` | — |
| `clientDriver` | `clientDriver` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteCreationDto` | — |
| `clientVehicle` | `clientVehicle` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteCreationDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | `@Size(max = ValidationConstants.MAX_LENGTH_200)` | `RouteCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
