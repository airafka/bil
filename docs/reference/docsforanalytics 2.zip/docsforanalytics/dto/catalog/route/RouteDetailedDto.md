# `RouteDetailedDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.route`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.route.RouteDetailedDto`
- **Java package:** `ru.korusconsulting.alis.dto.route`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [RouteDetailedDto.java:22](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/route/RouteDetailedDto.java#L22)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `GET` `/routes/{id}` | `RouteController` (ALIS) |
| response | `POST` `/routes` | `RouteController` (ALIS) |
| response | `POST` `/routes/{id}/change-status/accept` | `RouteController` (ALIS) |
| response | `POST` `/routes/{id}/partial-copy` | `RouteController` (ALIS) |
| response | `PUT` `/routes/{id}` | `RouteController` (ALIS) |
| response | `PUT` `/routes/{id}/reject` | `RouteController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `routeType` | `routeType` | RouteType | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `dataTime` | `dataTime` | Instant | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `terminalArea` | `terminalArea` | [TerminalAreaCatalogDto](../terminalarea/TerminalAreaCatalogDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `clientRelatedEntity` | `clientRelatedEntity` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `clientDriver` | `clientDriver` | [ClientDriverShortDto](../clientdriver/ClientDriverShortDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `clientVehicle` | `clientVehicle` | [ClientVehicleShortDto](../clientvehicle/ClientVehicleShortDto.md) | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |
| `status` | `status` | RouteStatus | технически возможен (reference) | не задано | не задано | — | `RouteDetailedDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
