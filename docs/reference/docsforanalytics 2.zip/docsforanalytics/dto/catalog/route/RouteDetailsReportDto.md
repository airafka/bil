# `RouteDetailsReportDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.route`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.route.RouteDetailsReportDto`
- **Java package:** `ru.korusconsulting.alis.dto.route`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** не найдено
- **Наследует:** нет
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [RouteDetailsReportDto.java:10](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/route/RouteDetailsReportDto.java#L10)

## Использование в endpoints

Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `number` | `number` | Long | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `routeType` | `routeType` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `dataTime` | `dataTime` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `terminalArea` | `terminalArea` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `transportType` | `transportType` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `driverName` | `driverName` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `driverPhone` | `driverPhone` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `driverPoaNumber` | `driverPoaNumber` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `clientRelatedCode` | `clientRelatedCode` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `vehicleCode` | `vehicleCode` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `vehicleInsuranceNumber` | `vehicleInsuranceNumber` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `vehicleWithTrailer` | `vehicleWithTrailer` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `vehicleTrailerNumber` | `vehicleTrailerNumber` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |
| `status` | `status` | String | технически возможен (reference) | не задано | не задано | — | `RouteDetailsReportDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
