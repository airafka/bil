# `ContainerDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.container`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.container.ContainerDto`
- **Java package:** `ru.korusconsulting.alis.dto.container`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [IdActiveCodeDto](../wms/IdActiveCodeDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ContainerDto.java:20](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/container/ContainerDto.java#L20)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `DELETE` `/container/{id}` | `ContainerController` (ALIS) |
| response | `GET` `/container/{id}` | `ContainerController` (ALIS) |
| response | `POST` `/container` | `ContainerController` (ALIS) |
| response | `POST` `/container/all` | `ContainerController` (ALIS) |
| response | `POST` `/container/directory/actual` | `ContainerController` (ALIS) |
| response | `POST` `/container/page` | `ContainerController` (ALIS) |
| response | `POST` `/container/remains/actual` | `ContainerController` (ALIS) |
| response | `PUT` `/container/{id}` | `ContainerController` (ALIS) |
| response | `POST` `/containerremains/all` | `ContainerRemainsController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | — | `IdCodeDto` | — |
| `active` | `active` | Boolean | технически возможен (reference) | не задано | не задано | — | `IdActiveCodeDto` | — |
| `containerType` | `containerType` | ContainerType | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Тип КТК |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Масса тары (т) |
| `liftingCapacity` | `liftingCapacity` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Грузоподъемность (т) |
| `refrigerator` | `refrigerator` | Boolean | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Признак рефрижератора |
| `standardSize` | `standardSize` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Размер КТК |
| `owner` | `owner` | String | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Собственник из ЭТРАН |
| `ownerName` | `ownerName` | String | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Наименование собственника из ЭТРАН |
| `ownerContainer` | `ownerContainer` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Текущий собственник КТК |
| `renter` | `renter` | String | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | — |
| `renterName` | `renterName` | String | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | — |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | — |
| `containerTypeISO` | `containerTypeISO` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | — |
| `containerStatus` | `containerStatus` | ContainerStatus | технически возможен (reference) | не задано | не задано | — | `ContainerDto` | Статус КТК |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
