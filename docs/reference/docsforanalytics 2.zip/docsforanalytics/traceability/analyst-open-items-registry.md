# Реестр открытых вопросов: что нужно аналитику и что — от Datareon/1С/ЭТРАН/TOS/WMS

Сверено с checkout `22fac945e8116d04972ccc87b06b2303acf7a561` 18.09.2026. Это **сводный реестр**, собранный сканированием разделов «Вопросы для ТЗ», «Неподтверждённое», «Что остаётся вопросом» и аналогичных во всех ~65 AS-IS документах `business-rules/`, `database/`, `scenarios/` и `research/README.md`. Он ничего не расследует заново — только группирует уже найденные пункты по тому, **кто должен их закрыть**, и даёт ссылку на источник для каждого.

## Как читать реестр

Каждый пункт помечен одной из трёх меток:

- **[АНАЛИТИК]** — решение бизнес-логики или архитектуры, которое не следует из кода: выбор между несколькими найденными вариантами поведения, признание чего-то дефектом или намеренным решением, определение authoritative-правила там, где сейчас несколько конкурирующих источников. Это и есть «колонки», которые должен заполнить аналитик/владелец процесса — простого чтения исходников для этого недостаточно.
- **[DATAREON/1С/ЭТРАН/TOS/WMS]** — поведение или алгоритм **внешней** системы, которого нет в этом backend-репозитории. Закрывается только получением контракта/скрипта/конфигурации от соответствующей внешней команды, а не разработкой ALIS.
- **[ОКРУЖЕНИЕ]** — требует доступа к развёрнутой среде (применённая схема `pg_catalog`/`DATABASECHANGELOG`, реальные роли/gratns, живые данные, прогон уже написанных тестов) — задача для DevOps/DBA/QA, не для аналитика и не для внешней команды.

Раздел A — то, что нужно аналитику. Раздел B — прямой ответ на вопрос «требуется ли предоставить алгоритмы Datareon»: да, вот конкретный список. Раздел C — для полноты, но это не работа аналитика.

## Топ-10 по влиянию (если читать только один раздел)

1. **[АНАЛИТИК]** Кто authoritative-писатель `total_weight`/`total_goods_price` у заявок на поставку и вывоз — сейчас у каждого по 2–4 конкурирующих сервиса с разными формулами. См. [receiving-order-waybill-integrity-map.md](../database/receiving-order-waybill-integrity-map.md#aggregate-authority-одного-источника-нет), [shipping-order-integrity-map.md](../database/shipping-order-integrity-map.md#aggregate-authority-одного-источника-нет).
2. **[DATAREON]** Прислать реальные production-строки `INBOUND_EVENT_CONFIG` — из репозитория подтверждается только `VH_DEPARTURE`, остальные 7+ кодов событий существуют только в тестах. См. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md#таблица-конфигурации-inbound_event_config).
3. **[АНАЛИТИК]** `PermissionPathController` использует устаревшую строку `permissionName`, не совпадающую с текущим enum — оба endpoint возвращают `403` даже админу. Подтвердить дефект и решить, чинить ли. См. [roles-permissions-as-is.md](../business-rules/roles-permissions-as-is.md).
4. **[АНАЛИТИК]** Файл шаблона `reports/receiving_order_waybill.xlsx` физически отсутствует — соответствующий export должен падать. Решить: создать шаблон или снять endpoint. См. [receiving-order-child-excel-exports-part2-as-is.md](../business-rules/receiving-order-child-excel-exports-part2-as-is.md).
5. **[DATAREON/1С]** Источник и процесс наполнения `Company.edoId`/`Currency.code` не установлен нигде в репозитории — без него нельзя закрыть создание договоров. См. [company-currency-contract-prerequisites-as-is.md](../business-rules/company-currency-contract-prerequisites-as-is.md).
6. **[АНАЛИТИК]** `UserSettingController` не имеет `@Secure` ни на одном из трёх endpoints — подтвердить как осознанное решение (личные настройки без RBAC) или дефект. См. [user-settings-as-is.md](../business-rules/user-settings-as-is.md).
7. **[АНАЛИТИК]** `ShippingOrderService.accept(UUID)`/`ReceivingOrderService.accept(UUID)` — подтверждённый мёртвый код (нет ни одного production-вызова). Решить: строить HTTP-доступ или официально списать. См. [order-statuses.md](../business-rules/order-statuses.md).
8. **[DATAREON]** Подтвердить, повторяет ли Datareon доставку одного и того же `taskId` (at-least-once) — от этого зависит, нужно ли восстанавливать удалённый unique index дедупликации. См. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md#дедупликация-задуманный-механизм-физически-недоступен).
9. **[АНАЛИТИК]** Дублирующийся `consignee`/`consigneeAddress` между `shipping_order` и `shipping_order_transport` — transport-версия не имеет ни одного найденного потребителя. Подтвердить, что это забытое поле, и решить судьбу. См. [shipping-order-transport-as-is.md](../database/shipping-order-transport-as-is.md#дублирующийся-грузополучатель-root-и-transport--разные-правила).
10. **[ОКРУЖЕНИЕ]** Единый экспорт применённых `RolePermission`/`PermissionPath`/Keycloak-назначений закрыл бы сразу пункты из `roles-permissions-as-is.md`, `user-groups-client-restriction-as-is.md`, `user-profile-permissions-as-is.md` и `order-report-access-as-is.md` одним запросом к среде.

## Раздел A — что должен решить аналитик / владелец процесса

### A.1 Заявка на вывоз (ShippingOrder)

- Должно ли поле `fillingType` изменяться через `PUT /shippingorder/{id}`: update DTO его принимает, но `ShippingOrderService.prepareModelToUpdate` не копирует в существующую сущность. Если смена нужна, определить матрицу переходов, cleanup/migration plan/fact rows, атомарность, totals и route/outbound semantics. [заполненный пример проверки ТЗ](tz-example-shipping-filling-type.md).
- Почему `orderStatus` обязателен в create DTO, если сервер всегда ставит `DRAFT`; что означает response-only `documentConfirmed`, у которого нет backing-поля. [shipping-order-root-as-is.md](../database/shipping-order-root-as-is.md), [shipping-orders.md](../business-rules/shipping-orders.md).
- Path ID или body ID должен быть authoritative на `PUT /shippingorder/{id}` (сейчас body побеждает молча, path не сверяется вообще — тот же вопрос повторяется на **каждом** дочернем `PUT`-endpoint заявки: transport, good, cargo, container, container-item, requested-service). [shipping-order-root-as-is.md](../database/shipping-order-root-as-is.md).
- Нужна ли физическая (не soft) delete заявки — требует полной карты child FK/cascade, которой сейчас нет. [shipping-order-root-as-is.md](../database/shipping-order-root-as-is.md).
- Дублирующийся `consignee`/`consigneeAddress` root vs transport — забытое поле или намеренный второй источник. [shipping-order-transport-as-is.md](../database/shipping-order-transport-as-is.md).
- `OrderServiceUtils.checkOrderStatusForUpdate` жёстко проверяет `RECEIVING_ORDER_SEND_TO_ACCEPT` для ~12 дочерних сервисов обеих сторон — параметризовать правом вызывающей стороны или подтвердить как задумано. [shipping-order-transport-as-is.md](../database/shipping-order-transport-as-is.md), [order-statuses.md](../business-rules/order-statuses.md).
- Нужно ли повторно генерировать outbound `TRANSPORT_MANIFEST`, если транспорт заявки меняется **после** `accept()`. [shipping-order-transport-as-is.md](../database/shipping-order-transport-as-is.md).
- `@OneToOne` на `ShippingOrderGood.shippingOrder` — переименовать в `@ManyToOne` (аннотация вводит в заблуждение) или оставить. [shipping-order-good-as-is.md](../database/shipping-order-good-as-is.md).
- Authoritative writer `total_goods_price` между `ShippingOrderGoodService` и `ShippingOrderContainerItemService`. [shipping-order-good-as-is.md](../database/shipping-order-good-as-is.md).
- Судьба мёртвого DTO-поля `batch` у `ShippingOrderCargo` (принимается, но никогда не сохраняется) — удалить контракт или реализовать. [shipping-order-cargo-as-is.md](../database/shipping-order-cargo-as-is.md).
- Действительно ли нужны все четыре bulk/upsert-контракта `ShippingOrderCargo` (`multipleaddition`/`multipleupdate`/`{shippingOrderId}`/`{shippingOrderId}/batch`) с разной атомарностью, или это случайное разрастание API. [shipping-order-cargo-as-is.md](../database/shipping-order-cargo-as-is.md).
- Текст сообщения `ValidShippingOrderContainer` перечисляет поля (`weight`, `dangerousCargo`), которых валидатор не проверяет и колонки для одного из них уже нет — обновить сообщение или реализовать проверку. [shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md).
- Бизнес-смысл флага `ShippingOrderContainer.random` — в коде есть только имя колонки и default `true`. [shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md).
- Должен ли `PUT /merge` заменять КТК всей заявки или только присланного вагона (сейчас — вся заявка, что может неожиданно удалить контейнеры не упомянутых вагонов). [shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md).
- Переносить ли null-guard из read-side мэппера в persistence-side пересчёт веса КТК, либо запретить содержимое у контейнеров с неизвестным номером (`ktkNumberUnknown=true` → NPE при пересчёте). [shipping-order-container-item-as-is.md](../database/shipping-order-container-item-as-is.md).
- Authoritative writer среди трёх конкурирующих `total_weight` (cargo/container/container-item). [shipping-order-container-item-as-is.md](../database/shipping-order-container-item-as-is.md), [shipping-order-integrity-map.md](../database/shipping-order-integrity-map.md).
- Нужна ли composite-проверка принадлежности `item.shippingOrderContainer.shippingOrder.id == item.shippingOrder.id`. [shipping-order-container-item-as-is.md](../database/shipping-order-container-item-as-is.md).
- Объединить ли две независимо реализованные формулы пересчёта `CARGO_PLACE`-услуг (`ShippingOrderCargoService` vs `ShippingOrderRequestedServiceService`). [shipping-order-requested-service-as-is.md](../database/shipping-order-requested-service-as-is.md).
- Должен ли Excel-импорт blackbox создавать отсутствующий `Cargo` (как у поставки) или намеренно требовать существующий код; должен ли он увеличивать `total_cargo_quantity`. [shipping-order-blackbox-as-is.md](../database/shipping-order-blackbox-as-is.md).
- `VhDepartureAction` проверяет площадку по жёстко закодированной `WAREHOUSE`, а не по реальной площадке заявки — дефект или намеренно. [scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md](../scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md).
- Правило сверки между `actualQuantity` (факт от WMS/TOS) и plan-based root totals — сейчас это две независимые метрики без точки согласования. [scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md](../scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md).
- Действительно ли нужны переходы `ACCEPTED → DRAFT` и `DONE → REJECTED`, или enum-модель статусов избыточно широкая. [order-statuses.md](../business-rules/order-statuses.md).
- Судьба пяти пар `@Deprecated`/закомментированного outbound-кода (transport/good/cargo/container/requested-service) — удалить или восстановить конфигурацию. Общий пункт для всех пяти физических моделей.
- *(добавлено 15.10.2026, KIS-4830)* Владелец КТК на строке вывоза — снимок registry на момент добавления/смены КТК. Нужно ли обновлять его при смене владельца до отгрузки и дозаполнить строки, созданные 22.09–08.10.2026 (у них `owner_container_id = NULL`, в route chain package уходит пустой `ownerContainerId`). [container-remains-and-owner-as-is.md](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).
- *(добавлено 15.10.2026, KIS-4830)* `ShippingOrderContainerMergeDto…ownerContainer` остаётся `@NotNull`, хотя сервер значение игнорирует — снять ограничение? [container-remains-and-owner-as-is.md](../business-rules/container-remains-and-owner-as-is.md#открытые-вопросы).

### A.2 Заявка на поставку (ReceivingOrder)

- Добавлять ли публичный HTTP `accept` endpoint (сервисный метод есть, вызывающего пути нет — как и на стороне вывоза); должен ли `PUT` использовать path ID вместо `body.id`. [receiving-orders.md](../business-rules/receiving-orders.md).
- Должен ли update DTO поддерживать поля плательщика/станций ЖД; должен ли `contact=null` очищать существующий контакт. [receiving-orders.md](../business-rules/receiving-orders.md).
- Нужна ли явная проверка «хотя бы один контейнер» для `CONTAINER+RAILWAY` поставки (сейчас не форсируется). [receiving-orders.md](../business-rules/receiving-orders.md).
- `CARRIAGE_ARRIVED` проверяет отсутствие контейнеров только в старой `receiving_order_container`, хотя контейнеры ЖД-поставки — в `waybill_container`; риск преждевременного `DONE`. Подтвердить/исправить. [receiving-orders.md](../business-rules/receiving-orders.md).
- Нужна ли серверная проверка `totalPrice = plannedQuantity × price` для товарной строки поставки. [receiving-order-good-as-is.md](../database/receiving-order-good-as-is.md).
- Authoritative writer `total_weight`/`total_goods_price` поставки между Good/Cargo/Container/ContainerItem-сервисами — тот же класс вопроса, что и на стороне вывоза. [receiving-order-container-as-is.md](../database/receiving-order-container-as-is.md), [receiving-order-container-item-as-is.md](../database/receiving-order-container-item-as-is.md), [receiving-order-waybill-integrity-map.md](../database/receiving-order-waybill-integrity-map.md).
- Можно ли изменять/soft-удалять `systemManaged`-строки обязательных услуг через обычный update (сейчас ничего не запрещает). [receiving-order-requested-service-as-is.md](../database/receiving-order-requested-service-as-is.md).
- Приемлемо ли, что `vehicleInfo`/`driverInfo` в ответе транспорта — это текущая запись справочника, а не снимок на дату заявки. [receiving-order-transport-as-is.md](../database/receiving-order-transport-as-is.md).
- Персистить ли TOS-присланное количество КТК как `actualQuantity` (сейчас читается и отбрасывается); нужны ли правила запрета регресса статуса `WaybillContainer` (например, `FINISHED → UPLOADED`). [waybill-container-as-is.md](../database/waybill-container-as-is.md).
- Какое из трёх независимых представлений «опасности» груза (`isDangerous`, `signDanger`, `DangerProduct.dangerClass`) authoritative; допустимо ли, что неизвестный danger-product ID блокирует даже статусный повтор уже известной накладной. [waybill-product-as-is.md](../database/waybill-product-as-is.md).
- Совпадает ли трактовка `NULL`-статуса `WaybillRailwayCarriage` как «не блокирующего» (через SQL `UNKNOWN`-семантику) с реальным бизнес-правилом. [waybill-railway-carriage-as-is.md](../database/waybill-railway-carriage-as-is.md).
- Нужна ли проверка статуса/владельца при линковке-релинковке-bulk-replace Waybill↔ReceivingOrder (сейчас отсутствует). [waybill-root-as-is.md](../database/waybill-root-as-is.md).
- Является ли жёсткий контракт «оба списка отметок non-null иначе NPE» при импорте накладной задуманным. [waybill-marks-as-is.md](../database/waybill-marks-as-is.md).
- Единый источник «веса/итогов заявки» через все writers и detailed-DTO override — нужно явное правило по сценарию, а не общая формулировка. [receiving-order-root-as-is.md](../database/receiving-order-root-as-is.md).
- *(добавлено 15.10.2026, KIS-4830)* Отмена первой поставки КТК теперь оставляет в registry строку `DEPARTED` с владельцем из отменённой заявки (раньше строка удалялась) — ожидаемо ли это для справочника КТК. [container-remains-and-owner-as-is.md](../business-rules/container-remains-and-owner-as-is.md#открытые-вопросы).
- *(добавлено 15.10.2026, KIS-4861)* В кандидаты для привязки к поставке теперь попадают накладные со статусом «Работа с документом окончена» — подтвердить, что это целевое правило, а не временное. [waybill-etran-as-is.md](../business-rules/waybill-etran-as-is.md).

### A.3 Общие правила заявок

- `NullPointerException` при копировании заявки без контакта (`copy` не проверяет null) — подтвердить как дефект. [order-copying.md](../business-rules/order-copying.md).
- Список полей для будущего ТЗ на копирование нужно вести белым списком, а не формулировкой «скопировать полностью» — маршрут/даты/документы/фактические значения обычно не должны наследоваться. [order-copying.md](../business-rules/order-copying.md).
- Момент генерации outbound (до/после commit), гранулярность root-объекта, ключ идемпотентности и правило повторной доставки; поведение при пустом составе дочерних объектов; влияние route chain package; эффект отмены/повторного accept на уже созданные outbound-строки. [order-integrations.md](../business-rules/order-integrations.md).
- В коде прямо оставлен комментарий «на проработке аналитиками» для пустого warehouse cargo-shipment outbound — этот пробел признан самим кодом, нужно решение. [order-integrations.md](../business-rules/order-integrations.md).
- *(добавлено 15.10.2026, KIS-4841)* Старые товарные строки с партионным учётом, но без партии и с `batchUnknown=false` теперь падают с `OrderGood.MissingBatch` при изменении/копировании и с NPE при выгрузке заданий `ITEM_*_TASK` в WMS. Нужна ли миграция данных (проставить `batchUnknown=true`)? [order-integrations.md](../business-rules/order-integrations.md), [order-validation.md](../business-rules/order-validation.md).
- *(добавлено 15.10.2026, KIS-4841)* Когда строка «партия неизвестна» привязалась к партии X, следующие позиции того же товара из WMS с партией Y создают новые строки с планом 0 (при `BY_CARGO` количество теряется). Это целевой способ разбивки по партиям? Должна ли проверка партии выполняться и при review/accept, а не только при add/update, и проверять принадлежность партии выбранному `ClientGood`? [receiving-inbound-actions.md](../business-rules/receiving-inbound-actions.md), [shipping-inbound-actions.md](../business-rules/shipping-inbound-actions.md).
- *(добавлено 15.10.2026, KIS-4841)* Excel «Номенклатура» новой формы: строка-пример 2 импортируется как данные, если её не удалить; лист «Контейнеры» ссылается на старую колонку; новая форма не создаёт партии, а старая создаёт; отсутствие обязательной колонки не ловится проверкой структуры (вероятен HTTP 500). Что исправлять в шаблоне, что в парсере, и сколько поддерживать старую форму? [order-goods-excel-import-as-is.md](../business-rules/order-goods-excel-import-as-is.md).
- *(добавлено 15.10.2026, KIS-4841)* `resolveUnknownBatch` ищет партию только по `syncId`: известный код с новым `syncId` упрётся в уникальность `(code, client_good_id)` и событие WMS упадёт. Нужен ли поиск по коду и может ли WMS перезаписывать код и даты существующей партии? **[WMS]** — подтвердить, стабилен ли `syncId` партии. [batch-datareon-as-is.md](../business-rules/batch-datareon-as-is.md).

### A.4 Рейсы

- Path ID vs body ID для update; правила assign/unassign для неизвестного ID, переноса между рейсами, восстановления `needTransport`. [route-lifecycle-as-is.md](../business-rules/route-lifecycle-as-is.md).
- Приемлемы ли обратные переходы статуса при автосинхронизации; нужен ли ключ идемпотентности/дедупликации outbound при accept. [route-lifecycle-as-is.md](../business-rules/route-lifecycle-as-is.md).
- Видимость soft-deleted рейса и client-level доступ по прямому UUID; контракт `cargo-chain` для RECEIVING (сейчас пуст). [route-lifecycle-as-is.md](../business-rules/route-lifecycle-as-is.md).
- Определить «план»/«факт» через бизнес-событие/статус, а не через выбор таблицы; единый scope data/meta по каждому filling type. [route-shipping-plan-fact-as-is.md](../business-rules/route-shipping-plan-fact-as-is.md).
- Отображение безномерных контейнеров/вагонов без модели/типа; какой сущности принадлежит `BaseIdFilter.id` на каждом уровне; код ответа для неизвестного/не того типа/удалённого рейса; client row-level правило поверх method permission. [route-shipping-plan-fact-as-is.md](../business-rules/route-shipping-plan-fact-as-is.md).
- Требуемая комбинация прав и правило `available` для отчётов рейса; доступ к удалённым/чужим рейсам по прямому UUID; точные условия eligibility ContainerTN; контракт кодов ошибок и `Content-Disposition`. [route-reports-as-is.md](../business-rules/route-reports-as-is.md).
- *(добавлено 15.10.2026, frontend KIS-4863)* Вкладка «Рейс» заявки показывает текущий рейс, даже если он уже не `DRAFT`, и с него можно снять отметку (отвязать заявку). Допустимо ли это для рейса не в `DRAFT`? Можно ли считать локальные фильтры таблиц выбора (только в браузере, выбранные строки не скрываются) целевым решением, или это временная мера до серверных фильтров? [route-ui-rules-as-is.md](../business-rules/route-ui-rules-as-is.md), [order-ui-rules-as-is.md](../business-rules/order-ui-rules-as-is.md).
- *(добавлено 15.10.2026, frontend KIS-4842)* Таблицы просмотра товаров не показывают флажок `batchUnknown` — строка «партия неизвестна» выглядит как строка без партии. Нужно ли отображать флажок? [order-ui-rules-as-is.md](../business-rules/order-ui-rules-as-is.md).

### A.5 Сервисные заявки

- Расширять ли `ServiceOrderType` на другие операции или каждой операции нужен свой агрегат; где хранить снимок предыдущего владельца (на заявке или только в истории); нужна ли компенсация после исчерпанных outbound-повторов; повторная проверка доступности КТК в момент исполнения accept; допустим ли один КТК в двух параллельных `DRAFT`. [service-orders.md](../business-rules/service-orders.md).

### A.6 Права доступа, роли, группы, настройки

- Правила владения ролью/разрешением, кросс-role проверка ID, неизменяемость admin, поведение при удалении Keycloak-роли (orphaned RolePermission), уникальность, валидный `permissionName`, таймингJWT-обновления. [roles-permissions-as-is.md](../business-rules/roles-permissions-as-is.md).
- `PermissionPathController` — устаревшая строка `permissionName`, дающая `403` даже админу — подтвердить/исправить (см. топ-10 #3). [roles-permissions-as-is.md](../business-rules/roles-permissions-as-is.md).
- Смысл «роли группы», допустимость снятия ролей пользователя из другого контекста, обязательность совпадения path/body group ID, семантика добавления клиентов (replace vs append), safe-deny при пустом пересечении client ID, client-owner проверка для прямого UUID, атомарность/компенсация Keycloak+БД. [user-groups-client-restriction-as-is.md](../business-rules/user-groups-client-restriction-as-is.md).
- Разграничение профильного и JWT username, кэшированной сводки прав и реального method-gate, присутствия `NO_ACCESS`-пути от реального разрешения. [user-profile-permissions-as-is.md](../business-rules/user-profile-permissions-as-is.md).
- Должен ли `GET /all` настроек включать defaults; регистр/нормализация/лимит длины ключа; схема/версионирование значения; поведение при отсутствующем/невалидном JWT `sub`; требования permission на endpoints (сейчас `@Secure` нет вовсе — см. топ-10 #6); гонки при параллельном POST в один ключ. [user-settings-as-is.md](../business-rules/user-settings-as-is.md).
- Матрица роль → право → допустимые client/order ID; правило для прямого UUID; обязательный scope V2; поведение при soft-delete и отсутствующем user ID. [order-report-access-as-is.md](../business-rules/order-report-access-as-is.md).
- *(добавлено 15.10.2026, frontend KIS-4247)* **[ОКРУЖЕНИЕ]** Поддерживает ли Keycloak-расширение (`KeycloakExtendedApi.getUserMetaFields`) поля `fullName` и `type` для `/user/meta/{field}` — фильтры списка пользователей на них опираются, но в backend-репозитории список поддерживаемых полей не виден. [admin-ui-rules-as-is.md](../business-rules/admin-ui-rules-as-is.md).

### A.7 Отчёты (PDF/Excel) — повторяющиеся пункты по всем 4+4+2 endpoint-группам

- Полный набор обязательных данных на шаблон сверх `checkCanExport` (несколько «доступных» отчётов падают в Jasper на отсутствующих зависимостях). [order-pdf-reports-as-is.md](../business-rules/order-pdf-reports-as-is.md).
- Правило выбора при нескольких событиях `REC_START`/`REC_FINISH` (сейчас — по ID записи, не по времени события). [order-pdf-reports-as-is.md](../business-rules/order-pdf-reports-as-is.md).
- Стабильные HTTP/бизнес-коды ошибок; должна ли причина недоступности доходить до клиента; row-level (client-owner) проверка для прямых UUID-загрузок — повторяется во **всех** PDF/Excel документах. [order-pdf-reports-as-is.md](../business-rules/order-pdf-reports-as-is.md) и Excel-документы ниже.
- V1/V2 семантика отсутствующего тела запроса vs `{}` — риск утечки client-scope при V2 без тела; лимит строк/пагинация/timeout/необходимость async; итоговая сортировка/timezone/locale/`Content-Disposition`. [order-excel-exports-as-is.md](../business-rules/order-excel-exports-as-is.md), [receiving-order-child-excel-exports-as-is.md](../business-rules/receiving-order-child-excel-exports-as-is.md), [receiving-order-child-excel-exports-part2-as-is.md](../business-rules/receiving-order-child-excel-exports-part2-as-is.md), [shipping-order-child-excel-exports-as-is.md](../business-rules/shipping-order-child-excel-exports-as-is.md), [shipping-order-child-excel-exports-part2-as-is.md](../business-rules/shipping-order-child-excel-exports-part2-as-is.md).
- Судьба legacy URI-термина `etran-invoice`; **физически отсутствующий файл шаблона** `reports/receiving_order_waybill.xlsx` (см. топ-10 #4); несовпадающие getter'ы шаблона Requested Service — нужно исправление. [receiving-order-child-excel-exports-part2-as-is.md](../business-rules/receiving-order-child-excel-exports-part2-as-is.md).
- Container XLSX-шаблон ссылается на несуществующие `getDangerousCargo`/`getRefrigerator` — нужно исправление DTO или шаблона. [shipping-order-child-excel-exports-as-is.md](../business-rules/shipping-order-child-excel-exports-as-is.md).
- Сосуществование старой shipping-ЭТРАН модели и новой receiving-Waybill модели (разошлись после KIS-3631) — какую считать актуальной для новых ТЗ. [shipping-order-child-excel-exports-part2-as-is.md](../business-rules/shipping-order-child-excel-exports-part2-as-is.md).

### A.8 Входящие события и общие интеграции

- Судьба неиспользуемого `InboundEventDaoService.getUnprocessedEvents()` — строить ретрай `NEW`/`FAILED` событий или официально признать, что реобработки не будет. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md).
- Расширять ли `event_code` в `INBOUND_EVENT` вслед за `INBOUND_EVENT_CONFIG` (риск усечения). [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md).
- Приемлем ли fail-fast между несколькими actions одного события (более поздние по приоритету просто не выполняются при ошибке раннего) или нужна изоляция сбоев. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md).
- Явное правило tie-break для config-строк одного приоритета (сейчас порядок зависит от возврата БД). [shipping-inbound-actions.md](../business-rules/shipping-inbound-actions.md), [receiving-inbound-actions.md](../business-rules/receiving-inbound-actions.md).
- Целевой дизайн завершения последнего вагона (перевод `ShippingOrder → DONE`), исправление сверки `_id`/`_order`, новый ключ идемпотентности для порожнего ЖД-вывоза. [shipping-railway-empty-completion.md](../business-rules/shipping-railway-empty-completion.md).
- Является ли `container_remain` authoritative-состоянием или отчётным снимком; нужны ли side-эффекты при переходе заявки в `DONE`. [research/README.md](../research/README.md).
- Выбор варианта overlay (A/B/C) и согласование владения `stockClient` для ЖД-модели вокруг Waybill. [research/README.md](../research/README.md).

## Раздел B — алгоритмы и контракты, которые нужно запросить у внешних систем

Это прямой ответ на вопрос «требуется ли предоставить алгоритмы Datareon» — да, вот по каким конкретным точкам.

### B.1 Datareon (общая шина событий)

- **Полный снимок production-строк `INBOUND_EVENT_CONFIG`** — из репозитория миграциями подтверждается только `VH_DEPARTURE → VH_DEPARTURE`; `VH_ARRIVED`, `REC_START`, `REC_FINISH`, `SHIP_FINISH`, `LOAD_FINISH`, `UNLOAD_FINISH` существуют только в тестовой конфигурации. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md).
- Подтвердить, **повторяет ли Datareon доставку** одного и того же `taskId` (at-least-once) — определяет, нужен ли восстановленный unique-индекс дедупликации на стороне ALIS. [inbound-event-registry-as-is.md](../business-rules/inbound-event-registry-as-is.md).
- Алгоритм преобразования Datareon-конверта `MessageID + EventData[]` в один или несколько плоских `InboundEventDto`, которые принимает `POST /datareon/event`; определить fan-out/batch, partial success, retry, correlation и timezone. [заполненный разбор ошибки](tz-example-datareon-event-envelope.md), [shipping-railway-empty-completion.md](../business-rules/shipping-railway-empty-completion.md), [receiving-inbound-actions.md](../business-rules/receiving-inbound-actions.md), [waybill-etran-as-is.md](../business-rules/waybill-etran-as-is.md).
- Какое именно событие шлёт TOS при уходе порожнего вагона; как соотносятся ID сообщения и ID вагонной задачи (для проверки, достаточна ли дедупликация по одному `_id`). [research/README.md](../research/README.md), [shipping-railway-empty-completion.md](../business-rules/shipping-railway-empty-completion.md).
- Реальная production-последовательность `eventCode → action_code` для сценария вывоза со склада (какие именно события шлёт WMS/Datareon для конкретного склада). [scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md](../scenarios/shipping-warehouse-vehicle-lifecycle-as-is.md).
- Обработка gateway/reverse-proxy: путь `/api/datareon/waybill` встречается в старом исследовании дефекта, а controller mapping — `/datareon/waybill`; нужно подтверждение реального внешнего маршрута. [research/README.md](../research/README.md).
- Реальный payload и тайминг callback `/reportbi` для занятости ячеек (`eventCode=getReportsCellOccupancy`); единицы измерения weight/height полей. [cell-occupancy-datareon-as-is.md](../business-rules/cell-occupancy-datareon-as-is.md).

### B.2 1С:ДО (договоры и контрагенты)

- **Источник и процесс наполнения `Company.edoId` и `Currency.code`** — не установлен нигде в backend-репозитории; без него нельзя закрыть ни один сценарий с договором. [company-currency-contract-prerequisites-as-is.md](../business-rules/company-currency-contract-prerequisites-as-is.md).
- Актуальный производственный набор валют и правила активности записи. [company-currency-contract-prerequisites-as-is.md](../business-rules/company-currency-contract-prerequisites-as-is.md).
- Правила отбора договоров/контрагентов, которые 1С:ДО решает отправлять в ALIS; сетевой маршрут, аутентификация, `External-ID`, retry/очередь Datareon. [research/README.md](../research/README.md), [contractor-edo-datareon-as-is.md](../business-rules/contractor-edo-datareon-as-is.md), [contract-edo-datareon-as-is.md](../business-rules/contract-edo-datareon-as-is.md).
- Фактическое поведение echo `/contractor` (что 1С:ДО ожидает получить обратно после исходящего сообщения). [contractor-edo-datareon-as-is.md](../business-rules/contractor-edo-datareon-as-is.md).

### B.3 ЭТРАН (справочники вагонов/КТК, накладные)

- Реальные внешние скрипты 1С/Datareon: mapping `sort → type`, расчёт `remaining_mileage`, подстановка кода контейнера, вычисление ISO — нужен сам алгоритм, а не предположение по старому исследованию. [etran-reference-imports-as-is.md](../business-rules/etran-reference-imports-as-is.md), [research/README.md](../research/README.md).
- Фактические единицы/масштаб входных значений (вес, грузоподъёмность, `×1000`-преобразования ISO). [etran-reference-imports-as-is.md](../business-rules/etran-reference-imports-as-is.md).
- Развёрнутая версия скриптов, стендовые справочные коды, регистрозависимость, контракт идемпотентности `MessageID`. [etran-reference-imports-as-is.md](../business-rules/etran-reference-imports-as-is.md), [research/README.md](../research/README.md).
- Внешний контракт для отметок накладной: гарантия порядка, уникальность, формат налогового кода с ведущими нулями. [waybill-marks-as-is.md](../database/waybill-marks-as-is.md).
- Гарантирует ли фактическая интеграция ЭТРАН/Datareon то соответствие количества груза/контейнеров, на которое рассчитывает outbound route-package export. [waybill-product-as-is.md](../database/waybill-product-as-is.md).

### B.4 TOS

- Должен ли TOS участвовать в затарке/растарке КТК и какое поле именно ожидает WMS. [research/README.md](../research/README.md).
- Реальное внешнее состояние остатков контейнеров/вагонов (для сверки с `receiving-inbound-actions.md`/`remain-inbound-as-is.md`).

### B.5 WMS

- Повторная доставка `WMS_SHIPMENT_RESULT` для того же события — задваивает ли кумулятивный `executor`/`actualQuantity` cargo/good. [shipping-order-cargo-as-is.md](../database/shipping-order-cargo-as-is.md).

## Раздел C — требует доступа к окружению (не аналитик и не внешняя команда)

Эти пункты повторяются буквально в каждом документе библиотеки и не перечислены здесь по одному — их закрывает единственное действие: **выгрузка применённой схемы (`pg_catalog`/`DATABASECHANGELOG`) и запуск уже написанных, но никогда не выполнявшихся тестов**. Отдельно стоит выделить специфичные пункты, которые нельзя закрыть одним общим действием:

- Экспорт реальных `RolePermission`/`PermissionPath`/Keycloak ролей и назначений — закрывает сразу несколько документов из раздела A.6.
- Конкурентность: soft-delete + повторное создание того же `(shippingOrder, container)` в `shipping_order_container` (живой `UNIQUE` без учёта `deleted`). [shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md).
- Конкурентность: параллельная запись `Batch`/`GoodRemain` с ошибкой в межпоточном логировании. [good-remain-inbound-as-is.md](../business-rules/good-remain-inbound-as-is.md).
- Порядок ORM flush при физическом удалении `WaybillRailwayCarriage` и параллельном `postRemove`-cleanup `ReceivingOrderContainer`. [waybill-railway-carriage-as-is.md](../database/waybill-railway-carriage-as-is.md).
- Гонка при одновременном создании двух накладных с одинаковым новым `waybill_identifier`. [waybill-root-as-is.md](../database/waybill-root-as-is.md).
- Подтвердить, применена ли в проде миграция от 26.08.2026, стирающая все строки `user_setting`. [user-settings-as-is.md](../business-rules/user-settings-as-is.md).
- Подтвердить фактическое значение `config.vat.rate` в проде (source fallback `0.2` не доказан как боевая ставка). [receiving-order-requested-service-as-is.md](../database/receiving-order-requested-service-as-is.md).

## Как использовать этот реестр

1. Раздел A — раздать по одному пункту на встречу с аналитиком/владельцем процесса соответствующей области; каждый пункт уже содержит достаточно контекста в исходном документе по ссылке, чтобы не требовать повторного объяснения от разработчика.
2. Раздел B — сформировать конкретные технические запросы к командам Datareon/1С/ЭТРАН/TOS/WMS; большинство пунктов — не «опишите систему», а один точный вопрос (например «пришлите текущие строки `INBOUND_EVENT_CONFIG`»).
3. Раздел C — передать в DevOps/DBA/QA как чек-лист для одной сессии на реальном/staging-окружении; многие пункты закрываются одним и тем же экспортом.

Этот реестр не заменяет исходные документы: при работе с конкретным пунктом всегда открывать документ по ссылке — там разобран полный контекст находки, а не только вывод.
