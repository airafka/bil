# Пример проверки ошибки: envelope вместо `InboundEventDto`

Срез исходников: `22fac945e8116d04972ccc87b06b2303acf7a561`. Разбираемый симптом:

```text
POST /datareon/event → 400 Bad Request
errorCode = NotBlank.inboundEventDto.eventCode
```

Фактически был отправлен пакет верхнего уровня `MessageID + EventData[]`, внутри которого `eventCode` присутствовал. Этот документ объясняет, почему сервер всё равно считает поле пустым, и формирует проверяемый контракт для исправления интеграции.

Это source-level разбор. Production gateway/Datareon transformation, применённая конфигурация событий и фактическая обработка `LOAD_FINISH` на стенде не проверялись.

## Короткий ответ

[`POST /datareon/event`](../api/endpoints-generated.md#datareoncontroller) принимает **ровно один плоский** [`InboundEventDto`](../dto/catalog/datareon/inbound/InboundEventDto.md). DTO для envelope с полями `MessageID` и `EventData` у этого endpoint нет.

Поскольку `InboundEventDto` помечен `@JsonIgnoreProperties(ignoreUnknown = true)`, Jackson не отклоняет незнакомые корневые поля. Он игнорирует и `MessageID`, и весь массив `EventData`, создавая объект, у которого `_id`, `_order`, `eventCode` и остальные ожидаемые поля равны `null`. Затем `@Valid` срабатывает **до входа в controller method** и возвращает `400`.

Следовательно, ошибка не означает, что `eventCode` отсутствовал внутри `EventData[0]`. Она означает, что он находился **не на том уровне JSON**, который десериализует endpoint.

## Как получен именно такой ответ

```mermaid
flowchart TD
    A[POST /datareon/event] --> B[Корень JSON:<br/>MessageID + EventData]
    B --> C[Jackson строит InboundEventDto]
    C --> D[Неизвестные MessageID/EventData<br/>игнорируются]
    D --> E[Все ожидаемые поля DTO = null]
    E --> F[Bean Validation до controller]
    F --> G[MethodArgumentNotValidException]
    G --> H[ExceptionAdvice берёт одну последнюю ошибку]
    H --> I[400 + NotBlank.inboundEventDto.eventCode]
```

[`ExceptionAdviceUtils`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java) берёт только последний `ObjectError` из `BindingResult`, поэтому клиент видит одну проблему, хотя в созданном DTO одновременно отсутствуют несколько обязательных полей. Формат ответа также объясняется кодом:

- `errorMessage: "must not be blank"` — сообщение `@NotBlank`;
- `errorCode: "NotBlank.inboundEventDto.eventCode"` — первый validation code поля;
- `contextObject.type: "inboundEventDto"` — object name из binding result;
- `contextObject.code/id: null` — у validation error нет предметной сущности.

Controller, converter, мониторинг, таблица `INBOUND_EVENT` и actions при таком `400` не вызываются.

## Фактический HTTP-контракт AS-IS

| JSON-поле | Java-поле | Bean Validation | Дополнительное фактическое требование |
|---|---|---|---|
| `_id` | `taskId` | `@NotBlank` | Converter вызывает `UUID.fromString`; невалидный UUID проходит Bean Validation, но падает позже |
| `_order` | `order` | `@NotBlank` | Converter вызывает `UUID.fromString` |
| `orderNumber` | `orderNumber` | `@NotNull` | Пустая строка формально допустима |
| `source` | `source` | `@NotNull` | Принимается DTO, но converter не переносит в `InboundEventData` |
| `site` | `site` | `@NotBlank` | Ищется как полное имя `TerminalArea` без учёта регистра; неизвестное значение бросает `IllegalArgumentException` |
| `eventName` | `eventName` | `@NotNull` | Пустая строка формально допустима |
| `eventCode` | `eventCode` | `@NotBlank` | Свободная case-sensitive строка для точного поиска `INBOUND_EVENT_CONFIG` |
| `eventDateTime` | `eventDateTime` | `@NotNull` | Тип `Instant`: JSON должен содержать UTC `Z` или offset |
| `dock` | `dock` | — | Принимается, но converter не переносит дальше |
| `cargoResult` | список Cargo DTO | `@Valid` | Optional; правила зависят от выбранного action |
| `itemsResult` | список Item DTO | `@Valid` | Optional; поля `_item`/`_package` должны быть UUID на WMS path |
| `addServicesResult` | список услуг | `@Valid` | Optional; вложенный `operationType` обязателен для строки |

Header `External-ID` optional. Controller пишет его только в application log; для best-effort monitoring используется `_id`/`taskId`, а не envelope `MessageID`.

## Минимально корректная форма одного запроса

Ниже структура, которую endpoint способен десериализовать. Значение времени приведено с offset; конкретная временная зона должна соответствовать внешнему контракту.

```json
{
  "_id": "d71f0509-aedd-43e7-9b79-6352db955029",
  "_order": "de2be35a-8460-42cd-ba04-1f820416316e",
  "source": "TOS",
  "site": "Терминал",
  "eventName": "Погрузка завершена",
  "eventCode": "LOAD_FINISH",
  "eventDateTime": "2026-09-08T01:04:02+03:00",
  "orderNumber": "20530",
  "cargoResult": [
    {
      "cargoNumber": "COIU4109496",
      "cargoType": "Стандартный 40",
      "weight": "3700",
      "height": "0",
      "qty": 1,
      "transportType": "АВТО",
      "transportNumber": "Х401НТ116",
      "active": true,
      "cargoSpec": [],
      "seals": [
        { "code": "РЖДО3405313" }
      ]
    }
  ]
}
```

Если `2026-09-08T01:04:02` уже обозначает UTC, нужно использовать `2026-09-08T01:04:02Z`; если это локальное время другой зоны — её offset. В исходном значении offset отсутствовал, поэтому после удаления envelope десериализация `Instant` может дать другой `400` (`HttpMessageNotReadableException`).

Поле `site` должно полностью совпасть с `TerminalArea.name` в работающей БД; регистр не учитывается. Наличие значения «Терминал» в production не подтверждено; тесты используют «Контейнерная площадка». Неизвестный site сейчас способен дойти до общего `500`, а не до validation `400`.

## Поля исходного cargo, которые не доходят до action

`CargoProcessingResultDto` принимает `weight` и `height`, но [`InboundEventConverter.toCargoProcessingResultDataList`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/converter/InboundEventConverter.java) их не копирует. Он переносит `cargoNumber`, `cargoType`, `qty`, `transportType`, `transportNumber`, `active`, `cargoSpec` и `seals`.

Поэтому присутствие `weight=3700` и `height=0` в корректном JSON не означает, что эти значения участвуют в `TOS_SHIPMENT_RESULT`. Если они нужны бизнес-логике, это отдельное изменение DTO→model conversion и action tests.

## Два допустимых варианта исправления интеграции

### Вариант A — преобразование до ALIS

Adapter/Datareon должен развернуть `EventData[]` и для каждого элемента выполнить отдельный `POST /datareon/event`, отправляя сам элемент как корневой JSON. `MessageID` можно передать в `External-ID`, но AS-IS это даст только запись в application log и не обеспечит идемпотентность.

Для этого варианта необходимо определить:

- один `MessageID` на пакет или отдельный ID на событие;
- что делать при частичном успехе массива;
- сохраняется ли порядок `EventData[]`;
- повторяется весь пакет или только неуспешный элемент;
- какой timeout/retry и какой ответ считается успешным.

### Вариант B — новый envelope-контракт ALIS

Добавить отдельный request DTO `MessageID + @Valid EventData[]` и endpoint/режим batch-processing. Тогда ТЗ должно явно определить атомарность, maximum batch size, validation response по индексам, дедупликацию, status per item и совместимость со старым плоским endpoint.

Просто добавить aliases `MessageID`/`EventData` к существующему `InboundEventDto` недостаточно: корень и элемент имеют разную cardinality, а controller/service сейчас обрабатывают только одно событие.

## Что произойдёт после исправления формы

Успешная Bean Validation ещё не доказывает выполнение погрузки:

1. Converter парсит `_id`/`_order` как UUID и ищет площадку по `site`.
2. Service ищет `INBOUND_EVENT_CONFIG` точным `eventCode=LOAD_FINISH`.
3. Если конфигураций нет, событие записывается как `SKIPPED`, а HTTP всё равно будет `200`.
4. Если настроен `TOS_SHIPMENT_RESULT`, action применяет собственную проверку состава `cargoResult`/услуг и предметные изменения.
5. Ошибка action записывается как `INVALID` или `FAILED`, но controller в большинстве таких случаев также возвращает `200`.

В репозитории `LOAD_FINISH` встречается в тестах, но INSERT соответствующей production-конфигурации Liquibase не найден. Фактическую строку нужно получить из применённой `INBOUND_EVENT_CONFIG`.

## Минимальная трассировка исправления

| Требование | Контракт | Реализация AS-IS | Пробел | Acceptance test |
|---|---|---|---|---|
| `REQ-EVENT-001` Принять согласованную форму | Один flat event либо envelope | Только flat `InboundEventDto` | Внешняя форма не совпадает | Реальный JSON внешней системы даёт ожидаемый status |
| `REQ-EVENT-002` Валидировать обязательные поля | `_id`, `_order`, site, eventCode и др. | Bean Validation, advice возвращает одну ошибку | Нет полного списка/index в batch | Missing/blank по каждому полю и нескольким полям сразу |
| `REQ-EVENT-003` Нормализовать время | ISO-8601 Instant | Offset обязателен десериализатору | Внешняя timezone не определена | `Z`, согласованный offset и no-offset negative test |
| `REQ-EVENT-004` Связать IDs | MessageID/task/order | `_id` — taskId; MessageID отсутствует в DTO | Correlation/idempotency не определены | Repeat packet/event и проверка monitor/event log |
| `REQ-EVENT-005` Обработать массив | `EventData[]` | Controller принимает один объект | Нет partial/atomic policy | 2 valid; valid+invalid; retry failed item |
| `REQ-EVENT-006` Обработать site/code | Directory/config lookup | Full site name без учёта регистра и exact eventCode | Runtime values вне репозитория | Unknown site/code и known `LOAD_FINISH` |
| `REQ-EVENT-007` Не терять cargo data | weight/height и остальные поля | weight/height отбрасываются converter'ом | Business ownership не определён | Converter/action assertions для каждого нужного поля |
| `REQ-EVENT-008` Согласовать HTTP/result status | Transport result vs processing result | `200` возможен для SKIPPED/INVALID/FAILED | Caller не видит предметный исход | Контракт response/status для каждого processing status |

## Набор проверок для исправления

1. Исходный envelope воспроизводит `400` и не создаёт `INBOUND_EVENT`.
2. Один плоский event с валидным offset проходит controller validation.
3. No-offset timestamp даёт предсказуемый `400` с документированным error code.
4. Невалидные UUID `_id`/`_order` и неизвестный `site` дают согласованный `4xx`, а не случайный `500`.
5. Несколько отсутствующих полей возвращают либо полный список, либо документированное правило выбора одной ошибки.
6. Для варианта A два элемента создают два независимых вызова; частичный сбой и retry проверены.
7. Для варианта B `@Valid` каскадирует в каждый `EventData[i]`, а ошибка указывает индекс.
8. `MessageID` имеет определённую correlation/idempotency semantics, а не только переносится без использования.
9. Known/unknown `LOAD_FINISH` config различаются в event log (`DONE/INVALID/FAILED` против `SKIPPED`).
10. Нужные `weight`/`height` либо доходят до action, либо официально удалены из внешнего контракта.

## Итог

Для немедленного вызова существующего endpoint нужно отправлять **`EventData[0]` как корень**, убрать envelope и добавить offset к `eventDateTime`. Это исправляет текущую ошибку формы, но не гарантирует предметный успех: отдельно проверяются точное имя `site`, UUID, production-конфигурация `LOAD_FINISH` и результат action в `INBOUND_EVENT`.

Для постоянного решения ТЗ должно закрепить один из двух контрактов: upstream fan-out либо новый batch endpoint. Без этого одинаковый пакет продолжит расходиться с backend DTO, а `MessageID` останется неиспользуемым данным.

## Проверено и не подтверждено

Сопоставлены `DatareonController.handleEvent`, `InboundEventDto` и nested DTO, Jackson annotations, Bean Validation, `ExceptionAdvice`/`ExceptionAdviceUtils`, converter, terminal lookup, `InboundEventDatareonService`, config registry и controller/converter tests. Тесты не запускались.

Не проверены production adapter/transformation, gateway, deployed ObjectMapper settings, live `TerminalArea`, applied `INBOUND_EVENT_CONFIG`, фактический timezone источника, monitoring service и TOS consumer semantics.
