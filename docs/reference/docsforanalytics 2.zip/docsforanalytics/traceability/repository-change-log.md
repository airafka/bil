# Журнал сверки документации с репозиторием

Здесь фиксируются изменения, обнаруженные после обновления локального репозитория: диапазон Git, изменившееся поведение, затронутая документация и коммит-источник. Журнал нужен, чтобы при загрузке документации в GPT было видно не только текущее правило, но и происхождение изменения.

## Актуализация backend от 15 октября 2026 года

Диапазон `49576a842..729c9a17` (`dev`, 6 содержательных коммитов, 08–14.10.2026). Каталоги API/DTO/entities перегенерированы скриптами; изменились только паспорта, затронутые коммитами (плюс ссылки `endpoints-generated.md` на DTO-каталог вместо Java-исходников для `WaybillStationPairGroupDto`/`WaybillContainerOwnerUpdateDto`). Frontend сверен в той же актуализации — см. таблицу ниже.

| Коммит | Что изменилось | Где отражено |
|---|---|---|
| `401bbea3` KIS-4830 | `shipping_order_container.owner_container_id` → FK на `client` (data-миграция, несопоставленные — `NULL`); сервер заполняет владельца на строке вывоза снимком из registry при create/смене КТК/TOS-отгрузке; **закрыт дефект `ownerContainerId = null` в route chain package вывоза**; отмена поставки больше не удаляет `ContainerOwner`, а отмена поставки/вывоза восстанавливает ссылку на предыдущую заявку; история владельцев — только выполненные заявки; из трёх Excel-шаблонов загрузки вывоза удалена колонка «Собственник КТК*»; в ЖД-шаблоне вывоза «Собственник вагона» теперь реально пишется в `ownerRailwayCarriage` | [регистр владельца КТК](../business-rules/container-remains-and-owner-as-is.md), [часть 20 БД](../database/shipping-order-container-as-is.md), [route chain package](../business-rules/route-chain-package-export-as-is.md), [справка для 1С](../integrations/container-owner-outbound-contract.md), [обработка в Datareon](../integrations/route-chain-package-datareon-processing.md), [интеграции заявок](../business-rules/order-integrations.md), [правила вывоза](../business-rules/shipping-orders.md), [выгрузки вывоза](../business-rules/shipping-order-child-excel-exports-as-is.md), [модель БД](../database/README.md) |
| `143d3a43` KIS-4830 | API истории владельцев дополнительно фильтрует `newStatus IN (ON_TERMINAL, DEPARTED)` | [регистр владельца КТК](../business-rules/container-remains-and-owner-as-is.md#api-истории-владельцев-containeridowner-history), [`UI-DICT-040`](../business-rules/dictionary-ui-rules-as-is.md) |
| `a1238ba1` KIS-4830 | `ContainerOwnerHistoryDto.orderClient` → `newClient` (несовместимое изменение контракта; frontend уже использует `newClient`); фильтр `orderClient` удалён | то же + [DTO](../dto/catalog/containerownerhistory/ContainerOwnerHistoryDto.md) |
| `8ee1ab68` KIS-4841 | Признак «партия неизвестна» `batch_unknown` у товаров поставки/вывоза; серверная проверка партии (`OrderGood.MissingBatch`/`BatchUnknownWithBatch`/`BatchUnknownNotAllowed`); новый payload `batch` в заданиях WMS; привязка фактической партии из результата WMS и ошибка неоднозначного сопоставления; новая форма листа «Номенклатура» в Excel-шаблонах Авто СК | [импорт товаров из Excel](../business-rules/order-goods-excel-import-as-is.md), БД [`receiving_order_good`](../database/receiving-order-good-as-is.md)/[`shipping_order_good`](../database/shipping-order-good-as-is.md), [inbound поставки](../business-rules/receiving-inbound-actions.md)/[вывоза](../business-rules/shipping-inbound-actions.md), [партии Datareon](../business-rules/batch-datareon-as-is.md), [UI-правила заявок](../business-rules/order-ui-rules-as-is.md), [интеграции заявок](../business-rules/order-integrations.md), [глоссарий](../business/glossary.md), DTO/entities-каталоги |
| `a4e3b5f8` KIS-4665 | Changeset unknown-модели вагона `Не определено` стал идемпотентным (новый id, вставка только при отсутствии) | [модель БД](../database/README.md) |
| `059d5f5a` KIS-4861 | Кандидаты накладных для поставки (`POST /waybill/for-receiving-order/page`) больше не исключают статус «Работа с документом окончена» | [накладные ЭТРАН](../business-rules/waybill-etran-as-is.md) |

### Frontend: `971288126..ab02fa985` (9 коммитов, 08–14.10.2026)

| Коммит | Что изменилось | Где отражено |
|---|---|---|
| `316a0dc6d` | Таблицы и карточки КТК вывоза показывают владельца из строки заявки (снимок KIS-4830), а не из реестра; при пустом снимке — прочерк. Загрузка КТК авто из Excel сразу обновляет таблицу | [order-ui](../business-rules/order-ui-rules-as-is.md) (`UI-ORDER-015`) |
| `74362d4bb` | Вкладка ЭТРАН вывоза читает все связанные накладные (раньше первые 25 — при сохранении остальные, вероятно, терялись); блокировки на время загрузки Excel | `UI-ORDER-015`, [shipping-order-create-edit](../ui/screens/shipping-order-create-edit.md) |
| `610f9935d` KIS-4845 | Подписи «Вид заполнения» для авто-вывоза | `UI-ORDER-016` |
| `e183a6f0b` KIS-4247 | Фильтры списка пользователей (ФИО, тип) и групп (описание) | [admin-ui](../business-rules/admin-ui-rules-as-is.md) (`UI-ADM-006`, `UI-ADM-017`), [user-groups](../ui/screens/user-groups.md) |
| `ba1bbd441` KIS-4830 | История владельцев КТК — `newClient` | [`UI-DICT-040`](../business-rules/dictionary-ui-rules-as-is.md) |
| `941fe0a9a` | UIKIT 19.4.1 | правил не меняет |
| `8fb9e37e8` KIS-4842 | Флажок «Партия неизвестна» в товарах поставки и вывоза; партия обязательна только при учёте по дате и снятом флажке — совпадает с сервером (KIS-4841); **`UI-DIFF-14` закрыт** | [order-ui](../business-rules/order-ui-rules-as-is.md), `UI-DICT-031` |
| `999b26824` KIS-4863 | Таблицы выбора (ЭТРАН, грузы blackbox, накладные поставки, заявки рейса): выбранные строки читаются целиком и идут первыми; локальные текстовые фильтры по кандидатам | `UI-ORDER-013`, [route-ui](../business-rules/route-ui-rules-as-is.md) `UI-ROUTE-015`, [waybill-ui](../business-rules/waybill-ui-rules-as-is.md) `UI-WB-011`, экраны вкладок поставки и рейса |
| `370ad3c96` KIS-4863/4842 | Вкладка «Рейс» заявки: текущий рейс закреплён первым, даже если не проходит фильтр; поставка — выбор одного рейса; товары поставки: «Артикул»/«Номенклатура» как у вывоза; кнопка «Готово» в мастере | `UI-ORDER-014`, `UI-ORDER-017`, `UI-ORDER-018`, [receiving-order-card](../ui/screens/receiving-order-card.md) |

Якорь UI-документов перенесён на `ab02fa985` только в тех файлах, которые сверялись; clients, order-lists, route-card, service-order-create-edit и receiving-order-create-edit остаются на `971288126`.

Новые открытые вопросы внесены в [реестр](analyst-open-items-registry.md) (разделы A.1–A.4, A.6). Тесты не запускались; поведение восстановлено по исходному коду.

## Актуализация frontend от 7 октября 2026 года

Диапазон `62e1edfb..971288126` (9 коммитов). Изменения, влияющие на правила, внесены в UI-документы; якорный коммит всех UI-документов и паспортов обновлён.

| Коммит | Что изменилось | Где отражено |
|---|---|---|
| `823dc3173` KIS-4827 | В мастере создания «Далее» на вкладке КТК — только при наличии непорожнего КТК; в вывозе (КТК + авто) при «номер КТК неизвестен» владелец больше не обязателен; КТК без номера подписывается «неизвестен» | [`UI-ORDER-012`](../business-rules/order-ui-rules-as-is.md#общие-правила), [дочерние таблицы](../business-rules/order-ui-rules-as-is.md#дочерние-таблицы-проверки-строк) |
| `d2c14d5a6` fix alert | Ошибки отмены и отправки разбираются по кодам `ContainerStatus.Cancel*`/`*Already*`/`ShippingNotReceived`/`ShippingMissingInRemains` с отдельными сообщениями | [`UI-ORDER-002`](../business-rules/order-ui-rules-as-is.md#общие-правила), [`UI-ROUTE-008`](../business-rules/route-ui-rules-as-is.md#правила) |
| `1128b0b09` KIS-4661 | История владельцев КТК: дата и время, сортировка от старых к новым | [`UI-DICT-040`](../business-rules/dictionary-ui-rules-as-is.md#ктк-и-вагоны) |
| `d9e59f520` | Обновление UIKIT 19.3.5 | правил не меняет |

При перепроверке найдено и исправлено собственное упущение первичной сверки: во всех таблицах КТК вывоза поле «Владелец» не редактируется и подставляется из реестра (так с 25.09.2026); добавлен риск [`UI-DIFF-18`](../business-rules/order-ui-rules-as-is.md#реестр-расхождений-ui--backend).

## Сверка с frontend от 1 октября 2026 года — контур заявок

Источник: `alis-frontend`, ветка `dev`, commit `62e1edfb32fb88cd831bcb979b7b14bb9d6d7342`. Библиотека впервые сверена с клиентским кодом, а не только с backend.

- Новый документ [`business-rules/order-ui-rules-as-is.md`](../business-rules/order-ui-rules-as-is.md): правила `UI-ORDER-*`/`UI-SRV-*`, матрица вкладок, поля форм поставки и вывоза, проверки дочерних таблиц, 17 расхождений `UI-DIFF-*` и 12 frontend-запросов без серверного endpoint (все не вызываются из UI).
- Обновлены [`order-validation.md`](../business-rules/order-validation.md) (уровень 0 — UI), [`order-statuses.md`](../business-rules/order-statuses.md) (пользовательский путь через accept рейса после KIS-4735), [`business-rules/README.md`](../business-rules/README.md), [`ui/README.md`](../ui/README.md), [`ui/screen-inventory.md`](../ui/screen-inventory.md).
- Главная находка-кандидат в дефект: `UI-DIFF-07` — форма редактирования ЖД-поставки позволяет менять станцию назначения и плательщика, которых нет в `ReceivingOrderUpdateDto`.
- Вторым шагом добавлен [`business-rules/route-ui-rules-as-is.md`](../business-rules/route-ui-rules-as-is.md): правила `UI-ROUTE-*` и 9 расхождений `UI-RDIFF-*` (главные — несогласованные права на отмену/документы/копирование и отсутствие защиты от переназначения заявки из чужого рейса); ссылка добавлена в [`route-lifecycle-as-is.md`](../business-rules/route-lifecycle-as-is.md).
- Третьим шагом обновлены восемь паспортов в `ui/screens/` (реестры, карточка/вкладки/форма поставки, форма вывоза, форма услуги, карточка/вкладки рейса): `INFERENCE`/`OPEN_QUESTION` по screen→request заменены на `SOURCE_CONFIRMED` (frontend), добавлены разделы «Подтверждение по frontend source» с ответами на 40+ `GAP-UI-*` вопросов. Исправлено устаревшее: кнопка «Отправить» на снимке `UI-SNAPSHOT-002` относится к сборке до KIS-4735.
- Четвёртым шагом добавлен [`business-rules/dictionary-ui-rules-as-is.md`](../business-rules/dictionary-ui-rules-as-is.md): правила `UI-DICT-*` и 12 расхождений `UI-DDIFF-*` (главные — права на договоры и группы номенклатуры проверяются не теми path, UI строже DTO по обязательным полям, удаление справочников отсутствует); обновлён паспорт [`ui/screens/clients.md`](../ui/screens/clients.md). Повторная сверка endpoints контура заявок более надёжным скриптом подтвердила прежний список.
- Пятым шагом добавлен [`business-rules/admin-ui-rules-as-is.md`](../business-rules/admin-ui-rules-as-is.md): правила `UI-ADM-*` и 10 расхождений `UI-ADIFF-*` (главные — UI вызывает отсутствующий `DELETE /usergroup/{id}`, раздел групп закрыт path `User` вместо `UserGroup`, пользователь без ролей выпадает из группы); обновлён паспорт [`ui/screens/user-groups.md`](../ui/screens/user-groups.md).
- Шестым шагом добавлен [`business-rules/waybill-ui-rules-as-is.md`](../business-rules/waybill-ui-rules-as-is.md): правила `UI-WB-*` и 5 расхождений `UI-WDIFF-*` (главные — привязка накладных защищена статусом только в UI, просрочка считается в часовом поясе браузера, старый экран за флагом `SHOW_OLD_WAYBILL` вызывает удалённый endpoint).
- Не сверены: услуги, комплексные услуги и условия обслуживания (тарифы), отчёты; паспорта экранов в `ui/screens/` по-прежнему помечают `screen→request` как `INFERENCE`.

## Актуализация от 29 сентября 2026 года — выполнена полностью

Эта запись изначально фиксировала расхождение документации с кодом и план работ (см. ниже). Весь чек-лист, включая пять пунктов из раздела «Что осталось» первой волны правок, закрыт в тот же день (в несколько заходов). Статус — в самом конце раздела, после исходного плана.

### Что сделано

1. **README.md** — якорный коммит заменён на `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026, текущий `HEAD` `dev`).
2. **Перегенерированы каталоги**: `generate_endpoint_catalog.py` (648 mapping-методов, было 671 по заявлению устаревшего README), `generate_dto_docs.py` (457 страниц: 409 top-level + 48 nested), `generate_entity_docs.py` (124 страницы: 113 entities + 11 mapped superclasses).
3. **Удалены осиротевшие generated-страницы** entity-каталога для сущностей, удалённых из кода, но не подчищенных генератором (`generate_entity_docs.py` не делает `rmtree`, в отличие от DTO-генератора): `entities/catalog/entities/groupedwaybill/`, `.../receivingordertransport/`, `.../shippingordertransport/`. **Находка для мейнтейнера скрипта:** стоит добавить очистку output-каталога в `generate_entity_docs.py` по аналогии с `generate_dto_docs.py`, иначе каждое удаление сущности будет требовать такой же ручной чистки.
4. **`check_docs.py`**: битые ссылки сокращены с 56 (после регенерации — временно выросло до 59 из-за удаления осиротевших страниц) до 21. Все 21 оставшиеся — **не связаны** с диапазоном этой сверки: они существовали и раньше (ссылки на никогда не созданные `integrations/*.md`, `*.puml` и несколько `alis-*-as-is.md` из `research/README.md`, `_meta/PROGRESS.md`, `contract-edo-datareon-as-is.md`, `contractor-edo-datareon-as-is.md`, `etran-reference-imports-as-is.md`, `waybill-etran-as-is.md:5,242`). Это отдельный долг документации, не входящий в объём данной актуализации.
5. **Помечены DEPRECATED** (удалённый код, ссылки на удалённые страницы де-линкованы, добавлен forward-pointer на замену): [`database/grouped-waybill-as-is.md`](../database/grouped-waybill-as-is.md) (заменено `waybill_view`, KIS-4690), [`database/receiving-order-transport-as-is.md`](../database/receiving-order-transport-as-is.md) и [`database/shipping-order-transport-as-is.md`](../database/shipping-order-transport-as-is.md) (поля перенесены в root-заявку и `route`, KIS-4093).
6. **Обновлены ссылающиеся документы** под новую модель: [`business-rules/waybill-etran-as-is.md`](../business-rules/waybill-etran-as-is.md) (таблица `/waybill` endpoints переписана под `WaybillFilter`/`WaybillStationPairGroupDto`/`WaybillType`), [`business-rules/order-validation.md`](../business-rules/order-validation.md) (строка «Транспорт» — теперь через `Route`), [`business-rules/order-pdf-reports-as-is.md`](../business-rules/order-pdf-reports-as-is.md) (MX-1 читает `receivingOrder.getWaybill()` напрямую), [`business-rules/user-profile-permissions-as-is.md`](../business-rules/user-profile-permissions-as-is.md) (datareon-мониторинг удалён без замены), [`ui/screens/receiving-order-create-edit.md`](../ui/screens/receiving-order-create-edit.md), [`ui/screens/receiving-order-tabs-and-actions.md`](../ui/screens/receiving-order-tabs-and-actions.md), [`ui/screens/shipping-order-create-edit.md`](../ui/screens/shipping-order-create-edit.md).
7. **Закрыт пункт 6 исходного чек-листа** (сверка `42eee4ee` vs `fade0b93`) — **результат: это разные изменения, расхождение реально, а не только документационное.** `42eee4ee` (KIS-4368, legacy/dev, 27 августа 2026) — 10 файлов, включая новый `ShippingOrderContainerItemControllerV2` с endpoint `POST .../preview/meta/{fieldName}`, фиксы `WaybillContainerFilter`/`WaybillRailwayCarriageFilter`/`WaybillRailwayCarriagePredicate`, `WaybillContainerService`. `fade0b93` (KIS-4369, dev, 3 сентября 2026) — только 2 файла (`ShippingOrderContainerItemPredicate`, `ShippingOrderController`), другой набор изменений. На текущем `dev` класс `ShippingOrderContainerItemControllerV2` существует, но с другим набором endpoint'ов (`/page`, `/list`, `/meta/{fieldName}`, `/merge`) — **endpoint `preview/meta/{fieldName}` в текущем коде отсутствует**. Нужно решить у разработчиков: это осознанный отказ от endpoint'а или потерянная при переносе с legacy-ветки функциональность.

### Вторая волна (тот же день) — все пять оставшихся пунктов закрыты

1. **Владелец контейнера** (KIS-4661/4716) — новый документ [`business-rules/container-remains-and-owner-as-is.md`](../business-rules/container-remains-and-owner-as-is.md): полная state-машина `ContainerStatusService` (`EXPECTED/ON_TERMINAL/RESERVED_OUT/DEPARTED`), риск «отмена принятой поставки всегда даёт `DEPARTED`, а не восстановленный статус», асимметрия типов `ownerContainer` между `ReceivingOrderContainer`/`WaybillContainer` (мигрировано на `Client`) и `ShippingOrderContainer` (нет), удаление `MissingOwnerContainer`-проверки для вывоза 25.09.2026. Обновлены [`receiving-inbound-actions.md`](../business-rules/receiving-inbound-actions.md), [`shipping-inbound-actions.md`](../business-rules/shipping-inbound-actions.md) (найдена конкретная ошибка: `TOS_SHIPMENT_RESULT` больше **не удаляет** владельцев КТК, документ утверждал обратное), [`remain-inbound-as-is.md`](../business-rules/remain-inbound-as-is.md) (disambiguation), [`order-errors.md`](../business-rules/order-errors.md).
2. **Модель ошибок** (KIS-4682/4683/4724) — новый документ [`business-rules/error-model-as-is.md`](../business-rules/error-model-as-is.md): параллельные деревья `WmsEntityException`/`AlisException`, оба сводятся к одному `ApiErrorDto`; таблица категория→HTTP-статус (`BUSINESS_RULE_VIOLATION→422` — новый статус, но **ни разу не используется** в production-коде на 29.09.2026, как и `InvalidRequestException`/`ConflictException`/`TechnicalException`/`ValidationErrorCode`); асимметрия заполнения `errorCode` для multi-error `AlisException`.
3. **`database/README.md`** — три записи помечены DEPRECATED (части 2, 14, 17), счётчик сущностей исправлен на 113, добавлена таблица всех 13 changeset'ов v.1.34.0–v.1.35.0 + двух новых view с явной пометкой «покрыто/не покрыто» (KIS-4432 container iso/length reconciliation и `view_container_movement_meta.sql` остаются открытыми пунктами).
4. **`integrations/README.md`** — добавлен раздел про снятие datareon-мониторинга (затронуло ~20 `*DatareonRestService` и весь `DatareonController`) и про stub `POST /datareon/contract_with_contractor` (принимает и только логирует, не путать с TO-BE `/contract-with-client`); те же правки — в [`contract-edo-datareon-as-is.md`](../business-rules/contract-edo-datareon-as-is.md) и [`contractor-edo-datareon-as-is.md`](../business-rules/contractor-edo-datareon-as-is.md).
5. **Route/ContainerTN/overdueDays** — в [`route-lifecycle-as-is.md`](../business-rules/route-lifecycle-as-is.md): KIS-4667 добавил проверку транспортных полей route и на update (закрывает ранее задокументированный `NullPointerException`-риск для случая полностью пропущенной ссылки, но не для `IdDto{id:null}`), KIS-4357 добавил `@Size(max=200)` на `RouteCreationDto.comment` (но не на `UpdateDto` — новая асимметрия). В [`route-reports-as-is.md`](../business-rules/route-reports-as-is.md): источник данных ContainerTN — `Route`, а не удалённый `ShippingOrderTransport`; добавлены поля `CurrentPrintDate`/`FacticalArriveDate`/`sealNumbers` (KIS-4583). В [`waybill-etran-as-is.md`](../business-rules/waybill-etran-as-is.md): `overdueDays` считается по `X-Timezone` заголовку и только для накладных без привязки к поставке (KIS-4690).

Итог по `check_docs.py`: 21 битая ссылка на конец обеих волн правок — все не связаны с диапазоном этой сверки (существовали до 26 августа 2026).

### Третья волна (в диалоге с разработчиками) — outbound route chain package

При устном подтверждении от разработчиков, что `ShippingOrderContainer.ownerContainer` «поправили», перепроверка кода показала: поправили **чтение** (все read/list/detail-мапперы теперь берут владельца из registry `container.containerOwner.client`), но не сам механизм экспорта. Найдено и задокументировано: `ShippingOrderContainerMapper.toChainPackageDto` и потребляющий его [`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) (строка 361) по-прежнему читают немигрированное и с 22 сентября 2026 всегда `null` поле `ShippingOrderContainer.ownerContainer`, а не registry — то есть **route chain package для вывоза отправляет в Datareon `ownerContainerId = null`**, пока feature flag route chain package включён. Добавлено: раздел «Побочный эффект» в [`container-remains-and-owner-as-is.md`](../business-rules/container-remains-and-owner-as-is.md) и раздел «Outbound» в [`database/shipping-order-container-as-is.md`](../database/shipping-order-container-as-is.md), включая разграничение с отдельным, мёртвым row-level `outbound_config`-механизмом для той же таблицы. Открытый вопрос разработчикам: регрессия или осознанное временное состояние — нужен отдельный тикет на фикс, если нет.

### Четвёртая волна — новый документ: `route-chain-package-export-as-is.md`

По запросу аналитика («где информация про route chain package») выяснилось, что содержимое всех четырёх пакетов (Shipping/ReceivingAuto/ReceivingRailway/ServiceOrder route chain package) нигде не описано: `route-lifecycle-as-is.md` покрывает только логику выбора типа сообщения, а сами DTO (`ru.korusconsulting.alis.datareon.dto.routechainpackage.*`) физически исключены из автогенерируемого каталога — `generate_dto_docs.py` сканирует только `ru.korusconsulting.alis.dto`, не `datareon.dto` (отдельная находка для мейнтейнера генератора). Написан новый документ [`business-rules/route-chain-package-export-as-is.md`](../business-rules/route-chain-package-export-as-is.md): общий retry/backoff-движок `BaseExportService` (включая находку — очередь обрабатывается `createdAt DESC`, «новые вперёд», а не FIFO), планировщики (fixed delay 5000мс, drain-цикл), root-объект/endpoint/состав для всех 4 типов, подтверждение что дефект `ownerContainerId=null` — только у shipping-варианта (receiving auto/railway читают корректно мигрированные поля), и новая находка — асимметричная логика привязки `WaybillProduct` к «первому» `WaybillContainer` накладной при 2+ товарах в `ReceivingRailwayRouteChainPackageExportService.toWaybillProductDtos`. Зарегистрирован в индексе `business-rules/README.md` и перекрёстно связан с `order-integrations.md`, `route-lifecycle-as-is.md`, `database/shipping-order-container-as-is.md`. Следом по запросу «документ не описывает какие поля выгружает конкретный пакет» в тот же документ добавлены полные field-by-field таблицы по всем 4 DTO (типы, `@JsonProperty`-алиасы) — прочитаны Java-файлы `*.dto.routechainpackage.*` напрямую; найдены новые расхождения между тремя похожими пакетами (`currencyID` vs `currencyId`, `clientRelatedEntity` строкой vs ID, отсутствие `waybill` у ReceivingRailway, `isDangerous: String`).

### Пятая волна — внешний материал: обработка route chain package на стороне Datareon

Аналитик предоставил C#-скрипты трансформации Datareon (движок "SystemModels") для 3 из 4 пакетов (`receiving_auto`, `recievingCont`/ReceivingRailway, `ship_cont_pack`/Shipping — последний получен не полностью, обрывается в середине «Блок алгоритм 2»; `SERVICE_ORDER_CHAIN_PACKAGE` не предоставлен). Это не source-level материал (репозиторий `backend` не содержит Datareon-сторону) — задокументирован отдельно, с explicit-пометкой основания, в новом [`integrations/route-chain-package-datareon-processing.md`](../integrations/route-chain-package-datareon-processing.md). Ключевые находки: временный workaround (`WaybillContainer.id` кладётся в старое поле `Route.receivingOrderIds`, т.к. выделенного поля ещё нет в модели Datareon — явно помечено комментарием как временное); fallback на «первую заявку рейса» при непарсящемся `receivingOrderId` контейнера; расхождение комментария/кода (`weightNet` в комментарии vs фактический перенос `weightGross`) в группировке `ReceivingOrderContainerItem`; дважды повторяющийся паттерн смешения семантики «вагон vs автомобиль» в одном поле (`railwayCarriageId` получает ID `ClientVehicle` в auto-случае для ReceivingRailway; `railwayClientVehicleId` получает `railwayCarriageId` как fallback для Shipping) — оба явно помечены как временные в комментариях; хардкод-фильтрация двух ETSNG-кодов «порожнего контейнера» с исключением продукта из пакета целиком; защищённая (с проверкой количества) дедупликация `WaybillRailwayCarriage`; подстановка дефолтного ЕТСНГ-кода-заглушки при полном отсутствии товарных данных в `receiving_auto`. Подтверждено (косвенно, из-за неполноты shipping-скрипта): ни один скрипт не компенсирует известный дефект `ownerContainerId=null` — Datareon просто передаёт то, что получил от ALIS.

### Шестая волна — деловая справка для аналитика 1С: `ownerContainerId`

По запросу «опишем для аналитика 1С, в каких пакетах и блоках передаём Собственника КТК» написан отдельный, короткий, ориентированный на внешнего читателя документ [`integrations/container-owner-outbound-contract.md`](../integrations/container-owner-outbound-contract.md): сводная таблица «пакет → блок → поле → статус» по всем трём релевантным пакетам (поставка авто/ЖД — передаётся корректно; вывоз — известный дефект, поле всегда пустое, явно помечено как не согласованное ограничение, а баг на нашей стороне) плюс пояснение, как найти карточку владельца через справочный блок `Client[]` того же пакета. Документ написан в более деловом, чем в остальной библиотеке, тоне — для передачи внешнему стейкхолдеру. Перекрёстно связан с `route-chain-package-export-as-is.md` и `container-remains-and-owner-as-is.md`.

### Исходный план (как был зафиксирован до начала работ)

### Обнаруженная проблема с якорным коммитом

- README указывает якорный коммит `22fac945e8116d04972ccc87b06b2303acf7a561` («сверено 22 сентября 2026»), а этот же журнал — pull от 9 сентября 2026 с тем же HEAD. Обе даты не совпадают друг с другом и обе фактически неверны.
- Коммит `22fac945e8116d04972ccc87b06b2303acf7a561` **не входит в историю текущей ветки `dev`** (`git merge-base --is-ancestor` → false). Он существует только в `origin/legacy/dev` и в неслитой ветке `origin/fix/KIS-4369`, то есть `dev` разошлась с той линией, на которую опирается документация.
- Фактическая точка, где история `dev` и задокументированное состояние совпадают: `c1848ad5953b1d29c346115a693470da7d579164` — merge `fix/KIS-4450` от 26 августа 2026. Все прочие коммиты из предыдущего pull (`15f90451`, `cc90d2df`, `6a17c5a2`, `6557b9e8`, `22355528`) в `dev` присутствуют; отсутствует только `42eee4ee` (KIS-4368, fix meta filtering and nested frame issues).
- Вероятный заменитель `42eee4ee` в `dev` — `fade0b93` (KIS-4369, «fix include all shipping orders in meta filtering», 3 сентября 2026). Это предположение по смыслу сообщения коммита, не по диффу — нужно свериться отдельно (см. чек-лист, пункт 6).
- **Рекомендация:** использовать `c1848ad5953b1d29c346115a693470da7d579164` как новую опорную точку в README вместо `22fac945…`, либо явно закрыть вопрос, почему `dev` не содержит `42eee4ee`.

### Диапазон для актуализации

- предыдущий фактический HEAD документации: `c1848ad5953b1d29c346115a693470da7d579164` (26 августа 2026);
- текущий HEAD: `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026);
- в диапазоне: 58 содержательных коммитов (без merge-коммитов), охватывают тикеты KIS-4093, KIS-4357, KIS-4369, KIS-4430, KIS-4432, KIS-4583, KIS-4604, KIS-4626, KIS-4661, KIS-4664, KIS-4665, KIS-4667, KIS-4682, KIS-4683, KIS-4690, KIS-4692, KIS-4716, KIS-4720, KIS-4724, плюс несколько коммитов без тикета (datareon monitoring, CORS, error handling для WMS);
- затронуто (без CI/build-инфраструктуры): 379 файлов, `+7532 / -7039` строк.

### Изменения по областям

| Область | Что изменилось | Источник (тикеты) | Целевой документ |
|---|---|---|---|
| Entities/JPA — удаления | Удалены `GroupedWaybill` (+DaoService/Filter/Predicate/Repository/View), `ReceivingOrderTransport`, `ShippingOrderTransport` | KIS-4093, KIS-4690, KIS-4626 | `entities/catalog/`, `entities/orders.md` |
| Entities/JPA — добавления | Новые `WaybillView` (+DaoService/Predicate/Repository), `WaybillCreationSource`, `WaybillType`, `ContainerStatus`, `ContainerMovementMetaView` | KIS-4690, KIS-4626, KIS-4661, KIS-4664 | `entities/catalog/` |
| Entities/JPA — изменения полей | `Container`, `ContainerOwner`, `ContainerOwnerHistory`, `RailwayCarriage`, `Route`, `ReceivingOrder(Container)`, `ShippingOrder`, `Waybill`, `WaybillContainer` | KIS-4661, KIS-4716, KIS-4665, KIS-4583, KIS-4357 | `entities/catalog/`, `business/` |
| API/контроллеры | Изменения в 17 контроллерах: Datareon, OrderStatus, ReceivingOrder*, Route, ShippingOrder*, UserInfo, Waybill; заявленное число mapping-методов (671) не соответствует текущему коду | все тикеты выше + KIS-4716 | `api/README.md`, `api/endpoints-generated.md` (перегенерировать) |
| База данных — миграции | 13 новых changeset'ов v.1.34.0–v.1.35.0: удаление order transport (с backfill), реконсиляция ISO-словаря и длины контейнера (KIS-4432), unknown container type (KIS-4664) / unknown railway carriage model (KIS-4665), waybill creation source + delivery deadline→date + drop grouped_waybill (KIS-4626), container owner status (KIS-4661), owner client columns + миграция данных (KIS-4716); новые view `view_container_movement_meta.sql`, `view_waybill.sql` | см. выше | `database/README.md` и связанные страницы модели |
| Бизнес-правила — ошибки | Унифицирована обработка ошибок: новая иерархия `AlisException`, общая модель ошибки, WMS-обработчик замаплен на старый `ApiErrorDto` | KIS-4682, KIS-4683, KIS-4724 | `business-rules/`, `api/README.md` (контракт ошибок) |
| Бизнес-правила — владелец контейнера | Поле owner контейнера: добавлено, затем откачено (`Revert`), затем снова добавлено с исправлением логики в `/list`; миграция owner client columns/data | KIS-4716 | `business-rules/`, `entities/catalog/` |
| Бизнес-правила — накладная | Новое представление `WaybillView` вместо `GroupedWaybill`; `SearchDate` обобщён для temporal-типов; overdueDays считается с учётом таймзоны пользователя | KIS-4690 | `business-rules/`, `dto/` |
| Бизнес-правила — прочее | Валидация типа транспорта route при обновлении (KIS-4667), комментарий route (KIS-4357), новые даты в `ContainerTN` (KIS-4583), фильтрация/сортировка движений контейнера (KIS-4430) | см. тикеты | `business-rules/` |
| Интеграции — Datareon | Удалён datareon-мониторинг (`MonitorClient` и классы инцидентов); добавлено JSON-логирование и заготовка endpoint для `contract_with_contractor` | без тикета, без тикета | `integrations/` |
| Инфраструктура (не требует правок доков) | spotless в CI, миграция CI-платформы, CORS-конфигурация, MapStruct-конфигурация, Gradle | — | — |

### Чек-лист актуализации (по порядку)

1. Обновить в README.md якорный коммит — заменить `22fac945…` на подтверждённый ancestor `dev` (см. раздел про проблему с якорным коммитом) и исправить дату.
2. Перегенерировать каталоги: `python3 docs/docsforanalytics/api/generate_endpoint_catalog.py`, `generate_dto_docs.py`, `generate_entity_docs.py` — учтут удаление GroupedWaybill/*Transport, добавление WaybillView и изменения контроллеров.
3. Обновить ручные бизнес-правила: владелец контейнера (KIS-4661/4716), модель ошибок (KIS-4682/4683/4724), представление накладной (KIS-4690), валидация транспорта route (KIS-4667), комментарий route (KIS-4357), даты ContainerTN (KIS-4583), overdueDays/таймзона.
4. Обновить `database/README.md` и модель БД под миграции v.1.34.0–v.1.35.0 (список выше) и два новых view.
5. Обновить `integrations/README.md` — убрать описание datareon-мониторинга, добавить `contract_with_contractor`.
6. Проверить, действительно ли `fade0b93` (KIS-4369) закрывает то же поведение, что задокументированный, но отсутствующий в `dev` коммит `42eee4ee` (KIS-4368) — при расхождении завести отдельный пункт в «Вопросы и расхождения».
7. Прогнать `python3 docs/docsforanalytics/scripts/check_docs.py` после ручных правок.
8. Добавить итоговую запись по правилу ведения журнала (ниже) с финальными diff-цифрами после выполнения пп. 1–7.

## Pull от 9 сентября 2026 года

### Диапазон

- предыдущий HEAD: `3d8c8bb71a04fef2e9319d350ae7c0d1bfbaa318`;
- новый HEAD: `22fac945e8116d04972ccc87b06b2303acf7a561`;
- тип обновления: fast-forward;
- в диапазоне: 12 коммитов — 6 содержательных и 6 merge-коммитов;
- затронуто: 19 файлов, `+295 / -56` строк.

```mermaid
flowchart LR
    P[git pull<br/>3d8c8bb7 → 22fac945] --> A[API<br/>+1 endpoint]
    P --> F[Фильтры и meta]
    P --> DB[Миграции и SQL view]
    P --> UI[100 default user settings]
    A --> DOC1[endpoints-generated.md<br/>653 → 654]
    F --> DOC2[DTO и ручная API-документация]
    DB --> DOC3[Модель БД и журнал изменений]
    UI --> DOC3
```

### Коммиты диапазона

| Реализация | Merge в `dev` | Изменение |
|---|---|---|
| `22355528e744ffcf1f270453d9a71a5ba297af40` — Remove central warehouse terminal area | `62b10499cfb292a9e908f85b6974f76706ebf461` | Перенос ссылок с «Центрального склада Алабуга» на «Складской комплекс» и удаление старой площадки. |
| `15f90451aba50ee8b552ebed1da2f1b11408bd55` — KIS-4624 update default values in user_setting table | `c7cf7fb9d29c34b9e7a06bf49704dd2f4cd4936a` | Полная замена содержимого `user_setting` на 100 default-записей фиксированного пользователя. |
| `cc90d2df053103697e28f8551dbaa52ffd2207cf` — KIS-4247 fix the search in the meta endpoint in the usergroup | `7aeaf39846a68b21b4e8548aafe24a256b2c5dc1` | `KeycloakGroupFilter` получил Lombok getters/setters, необходимые для использования полей фильтра. |
| `6a17c5a21a300669b05b2b2b1a9c132cbfeb30cb` — KIS-4167 fix keycloak filters | `83611109d5625c9d7ea15dd1ce4a2059423324b6` | `KeycloakGroupFilter` стал конкретным request type, удалён `KeycloakGroupFilterImpl`; role-meta отбирает только роли, соответствующие поиску. |
| `6557b9e88da7c933ea9a5c892884a8ef9e09f559` — KIS-4450 fix meta endpoints for route tables | `c1848ad5953b1d29c346115a693470da7d579164` | Исправлено разрешение planned date meta-полей маршрута; количественные КТК без ЕТСНГ сохраняются в route view. |
| `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18` — KIS-4368 fix meta filtering and nested frame issues | `22fac945e8116d04972ccc87b06b2303acf7a561` | Новый preview-meta endpoint, исправления gross/net meta, ЕТСНГ контейнеров накладной и семантики рода вагона. |

### Изменения поведения

| Область | До pull | После pull | Коммит |
|---|---|---|---|
| Каталог endpoints | 653 mapping-метода | 654 mapping-метода | `42eee4e` |
| Items КТК вывоза | Не было отдельного meta endpoint фрейма preview | Добавлен `POST /shipping-order/{shippingOrderId}/shipping-order-container-item/preview/meta/{fieldName}` | `42eee4e` |
| Scope preview-meta | — | Controller принудительно задаёт ID заявки и `shippingOrderContainer.hasShippingOrderRailwayCarriage=true` | `42eee4e` |
| Meta веса item вывоза | `grossweight → shippingOrderContainer.weight`, `netweight → netWeight` | `grossweight → wightGross`, `netweight → wightNet` | `42eee4e` |
| Род вагона | `railwayCarriageType`/alias `sort` искал `railwayCarriage.sort` | alias `type`; поиск, meta и сортировка используют `railwayCarriage.type.code`; отдельный `sort` продолжает означать поле `sort` | `42eee4e` |
| ЕТСНГ контейнера накладной | Специального `etsngcode` meta не было | Значения берутся из `WaybillProduct` накладных выбранных контейнеров; в `IdsCodeDto.ids` попадают ID контейнеров соответствующей накладной | `42eee4e` |
| Route order planned date meta | Использовались строковые константы фильтров, не совпадающие с JPA-полями | Для вывоза разрешается `plannedShippingDateTime`, для поставки — `planReceivingDateTime` через metadata QueryDSL | `6557b9e` |
| `view_shipping_route_containers` | `INNER JOIN` к `shipping_order_etsng_code` и `etsng_code` | `LEFT JOIN`: количественная строка КТК остаётся в view даже без ЕТСНГ | `6557b9e` |
| User group request filter | `KeycloakGroupFilterImpl` | `KeycloakGroupFilter` | `6a17c5a` |
| Role meta группы | После фильтра пользователя в результат могли попадать все его роли | В meta `role` добавляются только роли, совпавшие с role search | `6a17c5a` |
| Терминальная площадка | Существовал «Центральный склад Алабуга» (`fb6bdf47-…`) | Все ссылки перенесены на «Складской комплекс» (`8c2e7a54-…`), старая запись удалена | `2235552` |
| Пользовательские настройки | Существующие строки сохранялись | Миграция выполняет `DELETE FROM user_setting`, затем вставляет 100 defaults для пользователя `49d19fdf-…` | `15f9045` |

### Таблицы, затронутые удалением центрального склада

Коммит `22355528e744ffcf1f270453d9a71a5ba297af40` заменяет `terminal_area_catalog_id` в:

- `good_movement`;
- `good_remain`;
- `receiving_order`;
- `route`;
- `service`;
- `shipping_order`;
- `term_of_service`.

После переноса запись `terminal_area_catalog.id = fb6bdf47-44e1-4b4b-9fa6-deae0b7774c9` удаляется. Это изменение данных, а не структуры JPA entity.

### Результат перегенерации

После pull выполнены все три генератора.

| Каталог | Результат | Реальный diff |
|---|---|---|
| API | 119 controllers, 654 mappings | Добавлен один preview-meta endpoint; `UserGroupController` переведён на `KeycloakGroupFilter`; обновлены line links. |
| DTO | 415 страниц, один конфликт имени пропущен | Изменены `ReceivingOrderWaybillCarriageFilter.md` и usage-list `IdsCodeDto.md`. |
| Entities | 114 entities и 11 mapped superclasses | Содержательных изменений нет, поскольку pull не менял JPA entity-классы. |

### Риски, которые важно учитывать в ТЗ

1. Миграция KIS-4624 удаляет **все** существующие пользовательские настройки, а не только defaults. При применении на среде персональные настройки таблиц будут сброшены.
2. ЕТСНГ для container meta определяется на уровне накладной: один код товара накладной связывается с ID всех выбранных контейнеров этой накладной. Это не прямая связь «конкретный контейнер → конкретный товар».
3. Клиенты старого API, отправляющие `sort` как alias поля `railwayCarriageType`, больше не используют прежнюю семантику. Для рода вагона следует отправлять `type` или `railwayCarriageType`; `sort` теперь является отдельным полем сортности.
4. Новый preview-meta endpoint принимает optional body и сам безопасно создаёт пустые wrapper/filter, в отличие от ряда старых `/all` endpoints.

## Правило ведения журнала

После каждого pull:

1. зафиксировать `ORIG_HEAD`, новый `HEAD` и тип обновления;
2. просмотреть `git diff ORIG_HEAD..HEAD` и содержательные коммиты;
3. перегенерировать API, DTO и entity catalogs;
4. обновить ручные бизнес-правила для изменившейся серверной логики;
5. добавить строку в этот журнал с полным commit hash и ссылкой на затронутый документ.
