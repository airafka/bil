# Пример проверки ТЗ: изменение `ShippingOrder.fillingType`

Срез исходников: `22fac945e8116d04972ccc87b06b2303acf7a561`. Документ показывает, как проверять новое требование по [общему чек-листу](tz-checklist.md) и связывать бизнес-правило с HTTP, DTO, сервисом, физическими таблицами, route/outbound и тестами.

Это **заполненный пример ревью**, а не утверждённое TO-BE. Формулировки в блоке «Что должно определить ТЗ» являются вопросами к автору требования. Факты AS-IS подтверждены кодом и существующими паспортами; runtime и применённая БД не проверялись.

## Проверяемая формулировка

> Пользователь может изменить `fillingType` существующей заявки на вывоз. После изменения система использует соответствующую номерную или количественную модель вагонов и КТК.

## Результат проверки

**Вердикт: ТЗ неполно, а заявленное изменение не поддержано текущим update path.**

Главный source-level факт: [`ShippingOrderUpdateDto`](../dto/shipping-order/ShippingOrderUpdateDto.md) наследует поле `fillingType`, и MapStruct создаёт update-модель с новым значением. Однако [`ShippingOrderService.prepareModelToUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) копирует в существующую сущность contract, currency, contact, planned date, comment, consignee и route, но **не копирует `fillingType`**. Вызов `OrderCombinationValidator.validate(existingModel)` поэтому проверяет старое сохранённое значение.

Практическое следствие для текущего `PUT /shippingorder/{id}`:

- новое значение из body принимается DTO, но в `shipping_order.filling_type` не записывается;
- недопустимый для текущей площадки/транспорта новый тип также может не дать ожидаемую ошибку, потому что валидируется старое значение;
- дочерние merge-сервисы продолжают разрешать или запрещать записи по старому `fillingType`;
- path `{id}` не передаётся в Java-метод update: объект ищется по обязательному `body.id`.

Это вывод из source flow. Фактический HTTP-ответ и generated MapStruct-класс в работающем приложении тестом не подтверждались.

## Сквозной AS-IS flow

```mermaid
flowchart TD
    A[PUT /shippingorder/{id}] --> B[ShippingOrderUpdateDto<br/>body.id + fillingType]
    B --> C[mapper.modelUpdate]
    C --> D[preUpdate<br/>проверка статуса старой заявки]
    D --> E[prepareModelToUpdate]
    E --> F[Копируются отдельные поля<br/>fillingType не копируется]
    F --> G[validate existingModel<br/>проверяется старый fillingType]
    G --> H[UPDATE shipping_order<br/>filling_type остаётся прежним]
    H --> I[Child merge и route read<br/>видят прежнюю модель]
```

## Минимальная трассировка требования

| Требование проверки | Бизнес-правило / AS-IS | API и DTO | Service / entity | DB / read model | Integration | Нужный тест |
|---|---|---|---|---|---|---|
| `REQ-SO-FT-001` Сохранить новый тип | [`BR-SO-004`](../business-rules/shipping-orders.md) описывает default/допустимость, но не смену | `PUT /shippingorder/{id}` + [`ShippingOrderUpdateDto`](../dto/shipping-order/ShippingOrderUpdateDto.md) | `prepareModelToUpdate` сейчас не копирует поле | `shipping_order.filling_type NOT NULL` + CHECK пяти значений | Route/outbound читают persisted type | HTTP test: значение изменилось в response и БД |
| `REQ-SO-FT-002` Определить доступные переходы | [`order-types`](../business-rules/order-types.md) и [`order-validation`](../business-rules/order-validation.md) | Нужна явная ошибка для запрещённой пары | `OrderCombinationValidator` знает только `NONE_CONTAINER` и default `ALL` | DB CHECK проверяет enum, не terminal/transport combination | — | Параметризованный test всех old→new и terminal/transport |
| `REQ-SO-FT-003` Переключить child-модель | [plan/fact-матрица](../database/shipping-order-integrity-map.md#planfact-развилка-по-fillingtype) | Отдельные merge endpoints для fact и qty | Каждый child service проверяет текущий тип отдельно | Plan/fact rows могут сосуществовать | Route data выбирает одну ветку | Transactional transition test для каждой пары моделей |
| `REQ-SO-FT-004` Обработать прежние строки | Бизнес-правило очистки отсутствует | Update DTO не содержит migration policy | Root update не вызывает child services | DB не запрещает stale plan/fact rows | Route chain package собирает обе модели | Проверка cleanup/retain/archive и rollback |
| `REQ-SO-FT-005` Согласовать totals | Единого authoritative writer нет | Ответ возвращает stored totals | Physical Container и ContainerQty конкурируют за total | `total_container_quantity` хранится в root | Route live count/SUM может отличаться от package total | Последовательный test old→new→old с totals |
| `REQ-SO-FT-006` Согласовать route/meta | [`BR-ROUTE-VIEW-001/005`](../business-rules/route-shipping-plan-fact-as-is.md) | Два plan data и два meta endpoints | `RouteService` делает switch | Meta views объединяют обе модели | UI-фильтры могут видеть stale значения | Data/meta parity после перехода |
| `REQ-SO-FT-007` Согласовать outbound | [карта интеграций](../business-rules/order-integrations.md) | Отдельного transition-сообщения нет | Root/route exporters читают разные наборы | Stale children физически остаются | Route chain package экспортирует plan и fact вместе | Payload test после каждого перехода |
| `REQ-SO-FT-008` Обеспечить конкурентность | Текущее правило не задано | Нет version/ETag контракта | Root update transactional; wagon qty merge имеет transaction gap | Нет DB exclusivity plan/fact | Параллельный exporter может увидеть промежуточное состояние | Concurrent update/merge/export test |

## Что именно переключает `fillingType`

| Значение | Вагоны | КТК | Дополнительное условие |
|---|---|---|---|
| `ALL` | `shipping_order_railway_carriage` | `shipping_order_container` + item | Нужен ETRAN membership; у каждого вагона нужна глобальная ЭТРАН |
| `RAILWAY_CARRIAGE` | `shipping_order_railway_carriage` | `shipping_order_container_qty` + ETSNG child | ETRAN у вагона nullable |
| `CONTAINER` | `shipping_order_railway_carriage_qty` | `shipping_order_container` + item | — |
| `NONE` | `shipping_order_railway_carriage_qty` | `shipping_order_container_qty` + ETSNG child | — |
| `NONE_CONTAINER` | Не применяется | Ровно одна qty-строка `quantity=1`, `empty=true`, без ETSNG | Только `CONTAINER + VEHICLE` |

Полные FK, uniqueness, delete semantics и каскады приведены в [13-табличной ER/integrity-карте](../database/shipping-order-integrity-map.md). DB constraints не обеспечивают соответствие набора строк текущему `fillingType`.

## Почему одного изменения root-поля недостаточно

Пример перехода `ALL → NONE`:

1. До перехода допустимы ETRAN membership, физические wagon rows и физические container/item rows.
2. После перехода валидатор ожидает `railway_carriage_qty` и `container_qty`; optional ETSNG children принадлежат container qty.
3. Текущий root update не меняет поле, поэтому qty merge продолжит отклонять данные как несовместимые со старым `ALL`.
4. Даже если поле изменить напрямую, DB не удалит и не запретит прежние physical/ETRAN rows.
5. Route data переключится на qty-модель, meta views продолжат объединять старые и новые строки, а route chain package способен отправить оба набора.
6. `total_container_quantity` может остаться от physical writer либо быть перезаписан qty writer; атомарной операции перехода нет.

Аналогичный анализ требуется для каждой разрешённой пары old→new. Нельзя считать переход только редактированием enum.

## Что должно определить ТЗ

### Контракт операции

- Разрешено ли менять тип только в `DRAFT` или также в `ON_REVIEW`; нужен ли отдельный permission. AS-IS общий helper разрешает оба статуса, но для `ON_REVIEW` проверяет receiving-permission `RECEIVING_ORDER_SEND_TO_ACCEPT`.
- Используется существующий полный `PUT`, отдельный transition endpoint или атомарная команда с новым child payload.
- Как сверяются path `{id}` и `body.id`; текущий controller path ID игнорирует.
- Является ли `null` командой default/сброса или ошибкой. При create `CONTAINER + RAILWAY` null нормализуется в `ALL`, при update такой контракт не реализован.
- Какие стабильные error codes и HTTP statuses возвращаются для запрещённого перехода, неполного target payload, stale version и конфликта.

### Миграция дочерних данных

Для каждого источника и назначения нужно выбрать ровно одну политику:

- удалить старые строки (с указанием soft/physical delete и cascade);
- сохранить как архив, но исключить из **всех** read/meta/outbound;
- преобразовать physical rows в qty либо qty в physical rows по явно заданному алгоритму;
- запретить переход, пока несовместимые строки не удалены отдельными endpoints.

Автоматическое qty→physical преобразование нельзя подразумевать: qty не содержит номеров вагонов/КТК. Physical→qty также требует правил группировки по type, empty и ETSNG+weight signature.

### Атомарность и агрегаты

- Root field, удаление старой модели, создание новой и пересчёт totals должны иметь определённую transaction boundary.
- Нужна защита от двух параллельных переходов и от одновременного child merge; optimistic version в текущем контракте не описан.
- Следует назначить authoritative formula для `total_container_quantity`, `total_weight` и других затронутых totals.
- Нужно определить, может ли route/export читать заявку во время перехода и какой snapshot считается согласованным.

## Минимальные acceptance criteria для готового ТЗ

1. Позитивный переход для каждой разрешённой пары old→new с проверкой response, root column и целевой child-модели.
2. Запрещённые terminal/transport/type combinations возвращают согласованный business error без изменения БД.
3. `path.id ≠ body.id`, неизвестный/deleted/cross-client ID и недостаточный permission покрыты отдельно.
4. `DRAFT`, `ON_REVIEW` и все остальные статусы имеют явный ожидаемый результат.
5. Ошибка в середине child conversion откатывает root type, children и totals целиком.
6. Старые plan/fact rows после успеха либо удалены, либо гарантированно не видны в data, meta и outbound согласно выбранной политике.
7. Проверены route wagon/container data, обе meta views и route chain package после перехода.
8. Проверены ETRAN membership/cascade для переходов из `ALL` и nullable ETRAN для `RAILWAY_CARRIAGE`.
9. Два конкурентных перехода и параллельный child merge дают детерминированный результат без смешанной модели.
10. Повтор той же команды определён как idempotent success либо стабильная ошибка.

## Итоговая рекомендация ревью

Требование в исходной однострочной форме нельзя передавать в разработку. Минимально нужно выбрать transition contract, матрицу разрешённых переходов, политику старых children, одну транзакцию, authoritative totals, read/meta/outbound semantics, permission/client scope и ошибки. После этого строки `REQ-SO-FT-001…008` становятся основой acceptance criteria и тестовой матрицы.

## Проверено и не подтверждено

Сопоставлены controller/DTO/MapStruct contract, `BaseService.update`, `ShippingOrderService`, `OrderCombinationValidator`, child filling-type guards, accept-validator, JPA/SQL constraints, route data/meta и route chain exporter. Использованы [бизнес-правила вывоза](../business-rules/shipping-orders.md), [карта валидации](../business-rules/order-validation.md), [route plan/fact](../business-rules/route-shipping-plan-fact-as-is.md) и [физическая карта](../database/shipping-order-integrity-map.md).

Тесты не запускались. Не проверены generated mapper bytecode, runtime HTTP/error mapping, applied Liquibase, реальные stale rows, live permissions/client scope, UI orchestration и production outbound consumer.
