# Матрица источников истины

Документ разделяет происхождение данных, систему преобразования, фактических writers и бизнес-master. Он нужен, чтобы наличие таблицы в ALIS или направление HTTP-вызова не превращалось автоматически в ошибочное утверждение «ALIS владеет этими данными».

## Паспорт

| Атрибут | Значение |
|---|---|
| Состояние | `AS_IS` |
| Основное основание | `SOURCE_CONFIRMED` |
| Дополнительное основание для ЖД-накладной | `EXTERNAL_SNAPSHOT` |
| Бизнес-подтверждение master-систем | `OPEN_QUESTION` |
| Версия ALIS | `dev`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` |
| Последняя актуализация | 22.09.2026 |

Метки определены в [модели доказательности](evidence-model.md), системы и роли потоков — в [карте систем](systems.md).

## Пять разных понятий

| Понятие | Значение | Пример |
|---|---|---|
| Источник происхождения | Где впервые возникло полученное значение | `акс_Накладная` в предоставленном контуре 1С ЭТРАН |
| Преобразующий слой | Где значение нормализовано, вычислено или отфильтровано | Datareon вычисляет часть полей `Etran27` |
| Authoritative writer AS-IS | Какой подтверждённый код способен записать текущее поле | `WaybillDatareonService` сохраняет Waybill в ALIS |
| Операционная копия | Где значение используется текущим процессом ALIS | Таблицы `waybill`, WRC, WC и Product |
| Бизнес-master | Где должно приниматься окончательное решение при конфликте копий | Для Waybill пока `OPEN_QUESTION` |

Authoritative writer здесь означает только фактический writer реализации. Это не синоним бизнес-master.

## Сводная матрица

| Объект / данные | Происхождение | Преобразование / доставка | Writers в ALIS AS-IS | Роль хранения ALIS | Бизнес-master | Основание |
|---|---|---|---|---|---|---|
| Заявка на поставку | Пользователь/оператор или копирование существующей заявки | API и серверные mapper/validators | ReceivingOrder services и inbound actions | Основная операционная модель планирования и исполнения | ALIS — обоснованный кандидат, требуется бизнес-подтверждение | `SOURCE_CONFIRMED` + `INFERENCE` |
| Заявка на вывоз | Пользователь/оператор или копирование существующей заявки | API и серверные mapper/validators | ShippingOrder services и inbound actions | Основная операционная модель планирования и исполнения | ALIS — обоснованный кандидат, требуется бизнес-подтверждение | `SOURCE_CONFIRMED` + `INFERENCE` |
| Заявка на услугу | Пользователь ALIS | API; выполнение операции внутри ALIS | ServiceOrder lifecycle, включая смену владельца КТК | Основная операционная модель услуги | ALIS — обоснованный кандидат | `SOURCE_CONFIRMED` + `INFERENCE` |
| Рейс | Пользователь/оператор ALIS, частично автоматическое изменение по заявкам | Route API и status synchronization | RouteService и status listeners | Основная модель группировки заявок | ALIS — обоснованный кандидат | `SOURCE_CONFIRMED` + `INFERENCE` |
| ЖД-накладная `Waybill` | В предоставленном потоке — `акс_Накладная` в 1С ЭТРАН | Datareon `Etran27`: нормализация, вычисления, фильтр статусов | `WaybillDatareonService`; повтор меняет только status; есть пользовательские операции link/read | Операционная копия перевозочного документа для процессов ALIS | Официальный ЭТРАН, 1С ЭТРАН или иной владелец — `OPEN_QUESTION` | `EXTERNAL_SNAPSHOT` + `SOURCE_CONFIRMED` |
| Справочный вагон `RailwayCarriage` | Внешний ЭТРАН-контур по именованию потоков | Datareon / внешняя подготовка | Отдельный `/datareon/etran_railway`; импорт Waybill также создаёт/перезаписывает вагон; существуют другие ALIS endpoints | Локальный глобальный справочник | `OPEN_QUESTION`; writers конкурируют | `SOURCE_CONFIRMED` |
| Справочный КТК `Container` | Внешний ЭТРАН/TOS-контур по именованию материалов | Datareon / внешняя подготовка | Отдельный `/datareon/etran_container`; Waybill также создаёт/перезаписывает КТК; ALIS использует справочник в других процессах | Локальный глобальный справочник | `OPEN_QUESTION`; writers конкурируют | `SOURCE_CONFIRMED` |
| Вагон/КТК внутри Waybill | Пакет конкретной ЖД-накладной | Datareon → `WaybillIntegrationDto` | Только создание нового агрегата; повтор существующего identifier не обновляет состав | Snapshot участия объекта в конкретной накладной | Master накладной — `OPEN_QUESTION`; ALIS хранит неизменяемую после первого импорта копию состава | `SOURCE_CONFIRMED` |
| КТК заявки поставки/вывоза | Пользователь, копирование и входящие результаты | Order API и inbound actions | Receiving/Shipping container services, container item services, TOS/WMS actions | Операционная строка конкретной заявки | ALIS — кандидат для плана; master факта операции зависит от поля | `SOURCE_CONFIRMED` + `OPEN_QUESTION` |
| Владение КТК `ContainerOwner` | Существующее состояние ALIS и результаты операций | ServiceOrder и order inbound actions | Несколько ALIS services/actions изменяют owner и history | Текущая операционная связь КТК с клиентом | ALIS — кандидат, но бизнес-правило и внешний master не подтверждены | `SOURCE_CONFIRMED` + `INFERENCE` |
| Номенклатура клиента `ClientGood` | Внешний/справочный контур, точная граница вне текущего подэтапа | Используется по `syncId` в inbound | Существуют API/sync-механизмы вне этой матрицы | Локальный справочник для заявок и остатков | `OPEN_QUESTION` | `SOURCE_CONFIRMED` ограниченно |
| Партия `Batch` | Datareon-пакет либо отдельная WMS-синхронизация; доступен ручной create | Разные контракты используют `syncId`, ClientGood и code | `/datareon/batch`, `/batch/synchronize`, `POST /batch` | Локальный справочник партий для остатков | `OPEN_QUESTION`; три write paths не имеют общего правила master | `SOURCE_CONFIRMED` |
| Остаток товара `GoodRemain` | Внешний складской снимок | Инкрементальный Datareon push или ALIS-инициированный full sync | GoodRemain transaction/full-sync services | Текущая локальная копия снимка | Внешний WMS/учётная система — кандидат; точная система `OPEN_QUESTION` | `SOURCE_CONFIRMED` + `INFERENCE` |
| Остаток содержимого КТК `ContainerRemain` | Внешний терминальный/складской снимок | Datareon push или full sync | ContainerRemain services | Текущая локальная копия по client+container+ETSNG | `OPEN_QUESTION` | `SOURCE_CONFIRMED` |
| Остаток вагона `RailwayCarriageRemain` | Внешний терминальный/складской снимок | Datareon push или full sync | RailwayCarriageRemain services | Текущая локальная копия по вагону и клиенту | `OPEN_QUESTION` | `SOURCE_CONFIRMED` |
| Движение КТК `container_movement` | События, обработанные ALIS | Inbound actions | ALIS action/services | Журнал движения, отличный от remain snapshot | Владелец физического факта события `OPEN_QUESTION`; ALIS хранит производную запись | `SOURCE_CONFIRMED` |
| Занятость складской ячейки | Внешний снимок после инициированного ALIS обновления | ALIS trigger → Datareon → callback `/datareon/cell-occupancy` | Cell occupancy service заменяет/добавляет строки неатомарным процессом | Локальный снимок занятости | Внешний расчётный контур — кандидат; точная система `OPEN_QUESTION` | `SOURCE_CONFIRMED` + `INFERENCE` |
| Клиент/контрагент ЭДО | Внешний ЭДО-контур для integration path; существуют другие ALIS writers | Datareon | `/datareon/contractor` создаёт/пытается обновить Client; другие client APIs также существуют | Общий справочник клиентов ALIS | `OPEN_QUESTION`; integration identifier не определяет единственный master | `SOURCE_CONFIRMED` |
| Договор | Внешний ЭДО-контур для integration path; возможны пользовательские операции ALIS | Datareon | `/datareon/contract` всегда создаёт; client-contract API имеет отдельные операции | Договорная модель ALIS | `OPEN_QUESTION`; нет общей политики external ID/update | `SOURCE_CONFIRMED` |
| Company | Источник наполнения не найден | Не установлен | В текущем публичном backend-контуре обнаружено чтение, но не write/import endpoint | Prerequisite для договора | `OPEN_QUESTION` | `SOURCE_CONFIRMED` о пробеле |
| Currency | Источник наполнения не найден | Не установлен | В текущем публичном backend-контуре обнаружено чтение, но не write/import endpoint | Prerequisite для договора | `OPEN_QUESTION` | `SOURCE_CONFIRMED` о пробеле |

## Классификация хранения ALIS

```mermaid
flowchart TD
    O[Объект в ALIS] --> Q{Где возникает бизнес-факт?}
    Q -->|в ALIS| M[Кандидат на operational master]
    Q -->|во внешней системе| C[Внешняя копия / snapshot]
    Q -->|не установлено| U[OPEN_QUESTION]
    C --> W{Есть несколько writers?}
    W -->|нет| S[Зафиксировать refresh/replay policy]
    W -->|да| X[Зафиксировать conflict authority]
    M --> B[Требуется BUSINESS_CONFIRMED]
    S --> B
    X --> B
    U --> B
```

| Категория | Объекты первой волны |
|---|---|
| Кандидат на operational master ALIS | Заявки, рейсы, заявки на услугу |
| Внешний snapshot / операционная копия | Waybill, WRC/WC, остатки, занятость ячеек |
| Локальный справочник с внешними writers | Container, RailwayCarriage, Batch |
| Производные данные ALIS | ContainerMovement, часть totals, grouped Waybill view |
| Источник не установлен | Company, Currency; частично ClientGood |

Категория «кандидат» не является бизнес-решением. Она показывает наиболее вероятную роль по текущему write path и должна быть подтверждена владельцем процесса.

## Конфликты writers, которые нельзя скрывать

### КТК и вагоны

Один глобальный `Container` или `RailwayCarriage` способен обновляться отдельным справочным импортом и одновременно импортом новой Waybill. В этих потоках различаются validation, преобразования единиц и набор перезаписываемых полей. Правило «кто победил последним, тот истина» является техническим эффектом AS-IS, а не согласованной политикой.

### Партии

`Batch` записывается Datareon endpoint, отдельной WMS-синхронизацией и ручным create. Эти пути имеют разные ключи поиска и правила обновления. Наличие `syncId UNIQUE` решает только часть физических конфликтов и не определяет master.

### Остатки

Инкрементальный push и полная синхронизация пишут один снимок. Full sync удаляет текущие данные до получения/сохранения нового набора в нескольких контурах. Требуются политика порядка, версия snapshot и поведение при параллельном push.

### Waybill

Первый импорт фиксирует состав, а повтор меняет только status. Если внешний master исправил вагон, КТК, товар или отметку, ALIS не применит исправление. Это должна быть либо осознанная immutable-snapshot политика, либо GAP текущей реализации.

### Агрегаты заявок

Плановые данные вводятся пользователем ALIS, фактические — приходят через inbound actions, а totals пересчитываются несколькими дочерними сервисами. Source of truth нужно назначать на уровне группы полей, а не всей таблицы заявки одним решением.

## Правило назначения source of truth в ТЗ

Для каждого изменяемого набора данных ТЗ должно содержать:

1. канонический объект и конкретную группу полей;
2. систему, создающую исходный факт;
3. бизнес-master при конфликте;
4. допустимых writers и условия их записи;
5. направление синхронизации;
6. политику полного snapshot, patch и delete;
7. версию/время события и порядок обработки;
8. ключ идемпотентности;
9. правило разрешения конфликтов;
10. журналирование и процедуру ручного исправления.

Недостаточно написать «справочник приходит из Datareon»: Datareon может быть только транспортом, а один объект может обновляться другим endpoint.

## Пакет вопросов аналитику

Ответы на эти вопросы переводят строки из `OPEN_QUESTION` в `BUSINESS_CONFIRMED`.

| ID | Решение | Кого привлечь | Что изменится в документации |
|---|---|---|---|
| `GAP-SOT-001` | ALIS является master заявок и рейсов или копирует их из другой системы? | Владелец продукта ALIS | Статус четырёх операционных объектов |
| `GAP-SOT-002` | Где юридически значимый оригинал Waybill и кто исправляет его состав? | Владелец ЖД-процесса | Master и replay policy накладной |
| `GAP-SOT-003` | Кто master справочных КТК и вагонов? | Владелец ЭТРАН/TOS | Приоритет `/etran_*` против Waybill writer |
| `GAP-SOT-004` | Может ли Waybill перезаписывать глобальные справочники или должна только ссылаться на них? | Архитектор + владелец справочника | Граница агрегата и conflict policy |
| `GAP-SOT-005` | Какой из трёх путей является основным для `Batch`? | Владелец WMS/складского учёта | Ключи create/update и приоритет writers |
| `GAP-SOT-006` | Какая конкретная система master для GoodRemain, ContainerRemain и RailwayCarriageRemain? | Владельцы WMS/TOS | Source systems и full-sync правила |
| `GAP-SOT-007` | Кто имеет приоритет при пересечении incremental push и full sync? | Архитектор интеграции | Ordering/version/conflict policy |
| `GAP-SOT-008` | Является ли `ContainerOwner` юридическим владельцем, клиентом стока или операционным признаком ALIS? | Владелец контейнерного учёта | Канонический смысл ownership |
| `GAP-SOT-009` | Какая система наполняет Company и Currency? | Владелец НСИ | Устранение неизвестного источника prerequisites |
| `GAP-SOT-010` | Где master Client, Contract и ClientGood и какие поля допускают локальное изменение? | Владельцы CRM/ЭДО/НСИ | Field-level ownership справочников |
| `GAP-SOT-011` | Какие plan/fact/totals поля заявки принадлежат пользователю, WMS, TOS или вычислению ALIS? | Владельцы операций поставки/вывоза | Field-level authority заявок |
| `GAP-SOT-012` | Какая процедура исправляет расхождение внешнего master и ALIS-копии? | Поддержка + владельцы процессов | Reconciliation и audit process |

На предметной встрече не нужно разбирать Java-классы. Достаточно пройти строки этой таблицы; технические доказательства подключаются только при споре о текущем AS-IS.

## Технические доказательства

- заявки и outbound: [интеграционные эффекты заявок](../business-rules/order-integrations.md);
- Waybill: [текущий AS-IS](../business-rules/waybill-etran-as-is.md) и [сквозной внешний поток](../integrations/1c-etran-waybill-gu27-as-is.md);
- КТК и вагоны: [справочные импорты](../business-rules/etran-reference-imports-as-is.md);
- партии: [Batch/Datareon](../business-rules/batch-datareon-as-is.md);
- остатки: [товары](../business-rules/good-remain-inbound-as-is.md) и [КТК/вагоны](../business-rules/remain-inbound-as-is.md);
- занятость ячеек: [AS-IS](../business-rules/cell-occupancy-datareon-as-is.md);
- договорные prerequisites: [Company/Currency](../business-rules/company-currency-contract-prerequisites-as-is.md).
