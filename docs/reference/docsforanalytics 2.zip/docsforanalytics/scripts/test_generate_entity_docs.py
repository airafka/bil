#!/usr/bin/env python3
"""Focused regression checks for generated JPA storage semantics."""

from __future__ import annotations

import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import generate_entity_docs as generator  # noqa: E402


class EntityStorageTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.counter = 0

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def parse(self, source: str) -> generator.ClassInfo:
        self.counter += 1
        path = self.root / f"Model{self.counter}.java"
        path.write_text(textwrap.dedent(source).lstrip(), encoding="utf-8")
        result = generator.parse_class(path)
        self.assertIsNotNone(result)
        return result

    def test_inverse_one_to_many_has_no_local_column(self) -> None:
        info = self.parse(
            """
            package example;
            @Entity
            public class Parent {
                @OneToMany(mappedBy = "parent")
                private List<Child> children;
            }
            """
        )
        field = info.fields[0]

        self.assertEqual("inverse association", generator.storage_category(field))
        self.assertEqual("нет локальной колонки; owning side: `parent`", generator.storage(field, info))

    def test_owning_join_column_is_reported_as_fk(self) -> None:
        info = self.parse(
            """
            package example;
            @Entity
            public class Child {
                @ManyToOne(optional = false)
                @JoinColumn(name = "parent_id", nullable = false)
                private Parent parent;
            }
            """
        )
        field = info.fields[0]

        self.assertEqual("owning association (FK)", generator.storage_category(field))
        self.assertEqual("`parent_id` (FK)", generator.storage(field, info))
        self.assertEqual(
            "`nullable = false` (`@JoinColumn`); `optional = false` (`@ManyToOne`)",
            generator.jpa_nullability(field, info),
        )

    def test_unspecified_basic_and_join_names_are_not_invented(self) -> None:
        info = self.parse(
            """
            package example;
            @Entity
            public class Item {
                private String eventCode;
                @Column(name = "external_code", nullable = false)
                private String externalCode;
                @ManyToOne private Parent parent;
            }
            """
        )

        self.assertEqual("колонка; имя не задано", generator.storage(info.fields[0], info))
        self.assertEqual("`external_code`", generator.storage(info.fields[1], info))
        self.assertEqual("`nullable = false` (`@Column`)", generator.jpa_nullability(info.fields[1], info))
        self.assertEqual("join column (FK); имя не задано", generator.storage(info.fields[2], info))
        self.assertEqual("имя не задано в `@Table`", generator.table_display(info))

    def test_transient_formula_and_embedded_are_distinct(self) -> None:
        info = self.parse(
            '''
            package example;
            @Entity
            public class ReportRow {
                @Transient private String runtimeValue;
                @Formula("select 1") private Integer calculated;
                @Embedded private Address address;
            }
            '''
        )

        self.assertEqual(["transient", "computed (`@Formula`)", "embedded"], [generator.storage_category(f) for f in info.fields])

    def test_collection_storage_distinguishes_join_and_collection_tables(self) -> None:
        info = self.parse(
            """
            package example;
            @Entity
            public class Group {
                @ManyToMany
                @JoinTable(name = "group_member")
                private List<Member> members;
                @ElementCollection
                @CollectionTable(name = "group_tag")
                private List<String> tags;
            }
            """
        )

        self.assertEqual("owning association (collection)", generator.storage_category(info.fields[0]))
        self.assertEqual("join table `group_member`", generator.storage(info.fields[0], info))
        self.assertEqual("element collection", generator.storage_category(info.fields[1]))
        self.assertEqual("collection table `group_tag`", generator.storage(info.fields[1], info))

    def test_inherited_field_honors_attribute_override(self) -> None:
        parent = self.parse(
            """
            package example;
            @MappedSuperclass
            public class BaseCode {
                @Column(name = "CODE") protected String code;
            }
            """
        )
        child = self.parse(
            """
            package example;
            @Entity
            @AttributeOverride(name = "code", column = @Column(name = "code", nullable = false))
            public class Concrete extends BaseCode {
                private String name;
            }
            """
        )
        fields = generator.all_fields(child, {parent.name: parent, child.name: child})

        self.assertEqual(["code", "name"], [field.name for field in fields])
        self.assertEqual("`code` (`@AttributeOverride`)", generator.storage(fields[0], child))
        self.assertEqual("`nullable = false` (`@AttributeOverride`)", generator.jpa_nullability(fields[0], child))


if __name__ == "__main__":
    unittest.main()
