#!/usr/bin/env python3
"""Regression tests for the read-only documentation checker."""

from __future__ import annotations

import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from check_docs import check_library, main


class CheckDocsTest(unittest.TestCase):
    def test_valid_library(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "target.md").write_text("# Target\n", encoding="utf-8")
            (root / "index.md").write_text(
                "# Index\n\n"
                "[Local](target.md#section)\n\n"
                "[External](https://example.com)\n\n"
                "```text\nvalue\n```\n\n"
                "~~~~\nvalue\n~~~~\n",
                encoding="utf-8",
            )

            result = check_library(root)

            self.assertEqual(result.markdown_files, 2)
            self.assertEqual(result.local_links, 1)
            self.assertEqual(result.error_count, 0)

    def test_frontend_src_links(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            root = base / "backend" / "docs" / "lib"
            root.mkdir(parents=True)
            frontend = base / "frontend"
            (frontend / "src").mkdir(parents=True)
            (frontend / "src" / "a.ts").write_text("", encoding="utf-8")
            (root / "index.md").write_text(
                "[Ok](../../../src/a.ts)\n[Gone](../../../src/b.ts)\n[Other](../../x.md)\n",
                encoding="utf-8",
            )

            skipped = check_library(root)
            self.assertEqual(skipped.frontend_links, 2)
            self.assertEqual(len(skipped.broken_links), 1)  # ../../x.md only

            verified = check_library(root, frontend)
            self.assertEqual(len(verified.broken_links), 2)
            self.assertTrue(any("src/b.ts" in item for item in verified.broken_links))

    def test_reports_each_supported_violation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "invalid.md").write_text(
                "[Missing](missing.md)  \n\n```text\nvalue\n",
                encoding="utf-8",
            )

            result = check_library(root)

            self.assertEqual(result.markdown_files, 1)
            self.assertEqual(result.local_links, 1)
            self.assertEqual(len(result.broken_links), 1)
            self.assertEqual(len(result.unclosed_fences), 1)
            self.assertEqual(len(result.trailing_whitespace), 1)
            self.assertEqual(result.error_count, 3)

    def test_angle_brackets_and_url_encoding(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "file with spaces.md").write_text("# Target\n", encoding="utf-8")
            (root / "index.md").write_text(
                "[Angle](<file with spaces.md>)\n"
                "[Encoded](file%20with%20spaces.md)\n",
                encoding="utf-8",
            )

            result = check_library(root)

            self.assertEqual(result.local_links, 2)
            self.assertEqual(result.error_count, 0)

    def test_cli_returns_nonzero_for_violation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "invalid.md").write_text("[Missing](missing.md)\n", encoding="utf-8")

            with (
                patch("sys.argv", ["check_docs.py", "--root", str(root)]),
                redirect_stdout(StringIO()),
            ):
                self.assertEqual(main(), 1)


if __name__ == "__main__":
    unittest.main()
