#!/usr/bin/env python3
"""Generate technical DTO passports and connect them to Spring endpoints.

Generated pages contain only facts visible in Java declarations and controller
signatures. Hand-written DTO pages remain the source for business semantics.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from dataclasses import dataclass, field, replace
from pathlib import Path


REPO = Path(__file__).resolve().parents[3]
OUTPUT = REPO / "docs/docsforanalytics/dto/catalog"
DTO_ROOTS = (
    REPO / "web-layer/src/main/java/ru/korusconsulting/alis/dto",
    REPO / "wms-layer/src/main/java/ru/korusconsulting/wms/dto",
)
sys.path.insert(0, str(REPO / "docs/docsforanalytics/api"))
import generate_endpoint_catalog as endpoint_catalog  # noqa: E402


@dataclass
class FieldInfo:
    name: str
    java_type: str
    annotations: str = ""
    type_annotations: str = ""
    description: str = ""
    default: str = ""
    declared_in: str = ""


@dataclass
class DtoInfo:
    name: str
    enclosing: tuple[str, ...]
    package: str
    path: Path
    source: str
    kind: str
    type_parameters: tuple[str, ...]
    superclass: str | None
    interfaces: list[str]
    imports: tuple[str, ...]
    class_annotations: str
    description: str
    declaration_line: int
    fields: list[FieldInfo] = field(default_factory=list)


@dataclass(frozen=True)
class Usage:
    method: str
    paths: tuple[str, ...]
    role: str
    controller: str
    origin: str


@dataclass(frozen=True)
class ClassDeclaration:
    name: str
    kind: str
    tail: str
    start: int
    body_start: int
    body_end: int
    enclosing: tuple[str, ...]


def snake(value: str) -> str:
    value = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", value)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value).lower()


def clean_javadoc(raw: str | None) -> str:
    if not raw:
        return ""
    text = re.sub(r"^\s*/\*\*|\*/\s*$", "", raw.strip(), flags=re.S)
    lines: list[str] = []
    for line in text.splitlines():
        line = re.sub(r"^\s*\*\s?", "", line).strip()
        if line.startswith("@") or line in {"<p>", "</p>", "<ul>", "</ul>"}:
            continue
        line = re.sub(r"\{@link\s+([^ }]+)(?:\s+([^}]+))?}", lambda match: match.group(2) or match.group(1), line)
        line = re.sub(r"</?[^>]+>", "", line)
        if line:
            lines.append(line)
    return " ".join(lines)


def mask_non_code(source: str) -> str:
    """Hide comments and literals while preserving offsets and line breaks."""
    result = list(source)
    state = "code"
    escaped = False
    index = 0
    while index < len(source):
        char = source[index]
        following = source[index + 1] if index + 1 < len(source) else ""
        if state in {"string", "char"}:
            if char != "\n":
                result[index] = " "
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif (state == "string" and char == '"') or (state == "char" and char == "'"):
                state = "code"
        elif state == "line_comment":
            if char == "\n":
                state = "code"
            else:
                result[index] = " "
        elif state == "block_comment":
            if char != "\n":
                result[index] = " "
            if char == "*" and following == "/":
                result[index + 1] = " "
                index += 1
                state = "code"
        elif char == "/" and following == "/":
            result[index] = result[index + 1] = " "
            index += 1
            state = "line_comment"
        elif char == "/" and following == "*":
            result[index] = result[index + 1] = " "
            index += 1
            state = "block_comment"
        elif char == '"':
            result[index] = " "
            state = "string"
        elif char == "'":
            result[index] = " "
            state = "char"
        index += 1
    return "".join(result)


def matching_brace(masked_source: str, body_start: int) -> int:
    depth = 0
    for index in range(body_start, len(masked_source)):
        if masked_source[index] == "{":
            depth += 1
        elif masked_source[index] == "}":
            depth -= 1
            if depth == 0:
                return index
    return len(masked_source) - 1


def class_declarations(source: str) -> list[ClassDeclaration]:
    """Find a public top-level DTO and its member nested types."""
    masked = mask_non_code(source)
    depths: list[int] = [0] * (len(masked) + 1)
    depth = 0
    for index, char in enumerate(masked):
        depths[index] = depth
        if char == "{":
            depth += 1
        elif char == "}":
            depth = max(0, depth - 1)
    pattern = re.compile(
        r"\b(?P<modifiers>(?:(?:public|protected|private|static|abstract|final|sealed|non-sealed|strictfp)\s+)*)"
        r"(?P<kind>class|record|interface|enum)\s+(?P<name>\w+)(?P<tail>.*?)\{",
        re.S,
    )
    result: list[ClassDeclaration] = []
    stack: list[ClassDeclaration] = []
    for match in pattern.finditer(masked):
        start = match.start()
        body_start = match.end() - 1
        while stack and start > stack[-1].body_end:
            stack.pop()
        declaration_depth = depths[start]
        if declaration_depth == 0:
            if "public" not in match.group("modifiers").split():
                continue
            enclosing: tuple[str, ...] = ()
        else:
            if not stack or declaration_depth != depths[stack[-1].body_start] + 1:
                continue
            enclosing = (*stack[-1].enclosing, stack[-1].name)
        declaration = ClassDeclaration(
            name=match.group("name"),
            kind=match.group("kind"),
            tail=source[match.start("tail"):match.end("tail")],
            start=start,
            body_start=body_start,
            body_end=matching_brace(masked, body_start),
            enclosing=enclosing,
        )
        result.append(declaration)
        stack.append(declaration)
    return result


def annotation_value(annotations: str, name: str) -> str | None:
    match = re.search(rf"@{re.escape(name)}\s*\(\s*(?:value\s*=\s*)?\"([^\"]+)\"", annotations, re.S)
    return match.group(1) if match else None


def schema_description(annotations: str) -> str:
    match = re.search(r"@Schema\s*\(.*?description\s*=\s*\"((?:\\.|[^\"])*)\"", annotations, re.S)
    return match.group(1).replace('\\"', '"') if match else ""


def top_level_statements(source: str, body_start: int) -> list[str]:
    """Return semicolon-terminated declarations at depth one of a class body."""
    statements: list[str] = []
    depth = 1
    start = body_start + 1
    index = start
    state = "code"
    escaped = False
    while index < len(source) and depth:
        char = source[index]
        following = source[index + 1] if index + 1 < len(source) else ""
        if state in {"string", "char"}:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif (state == "string" and char == '"') or (state == "char" and char == "'"):
                state = "code"
        elif state == "line_comment":
            if char == "\n":
                state = "code"
        elif state == "block_comment":
            if char == "*" and following == "/":
                state = "code"
                index += 1
        elif char == "/" and following == "/":
            state = "line_comment"
            index += 1
        elif char == "/" and following == "*":
            state = "block_comment"
            index += 1
        elif char == '"':
            state = "string"
        elif char == "'":
            state = "char"
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 1:
                start = index + 1
        elif char == ";" and depth == 1:
            statements.append(source[start:index + 1])
            start = index + 1
        index += 1
    return statements


def split_leading_annotations(value: str) -> tuple[str, str]:
    annotations: list[str] = []
    rest = value.lstrip()
    while rest.startswith("@"):
        name = re.match(r"@[\w.]+", rest)
        if not name:
            break
        end = name.end()
        whitespace_end = end
        while whitespace_end < len(rest) and rest[whitespace_end].isspace():
            whitespace_end += 1
        if whitespace_end < len(rest) and rest[whitespace_end] == "(":
            end = endpoint_catalog.balanced_end(rest, whitespace_end)
        annotations.append(rest[:end].strip())
        rest = rest[end:].lstrip()
    return "\n".join(annotations), rest


def parse_fields(source: str, body_start: int, owner: str) -> list[FieldInfo]:
    result: list[FieldInfo] = []
    for statement in top_level_statements(source, body_start):
        docs = list(re.finditer(r"/\*\*.*?\*/", statement, re.S))
        description = clean_javadoc(docs[-1].group(0)) if docs else ""
        cleaned = re.sub(r"/\*.*?\*/", " ", statement, flags=re.S)
        cleaned = re.sub(r"//[^\n]*", " ", cleaned).strip()
        annotations, declaration = split_leading_annotations(cleaned)
        declaration = declaration.removesuffix(";").strip()
        modifiers: list[str] = []
        while True:
            modifier = re.match(r"(public|protected|private|final|transient|volatile|static)\b\s*", declaration)
            if not modifier:
                break
            modifiers.append(modifier.group(1))
            declaration = declaration[modifier.end():]
        if "static" in modifiers or not declaration:
            continue
        before_default, default = split_default(declaration)
        match = re.match(r"(.+?)\s+(\w+)$", before_default.strip(), re.S)
        if not match:
            continue
        raw_type = " ".join(match.group(1).split())
        type_annotations = " ".join(re.findall(r"@[\w.]+(?:\([^)]*\))?", raw_type))
        java_type = re.sub(r"@[\w.]+(?:\([^)]*\))?\s*", "", raw_type)
        java_type = " ".join(java_type.split())
        if not re.match(r"^[\w.$<>, ?\[\]]+$", java_type):
            continue
        description = description or schema_description(annotations)
        result.append(FieldInfo(
            name=match.group(2),
            java_type=java_type,
            annotations=annotations,
            type_annotations=type_annotations,
            description=description,
            default=default,
            declared_in=owner,
        ))
    return result


def split_top_level(value: str) -> list[str]:
    result: list[str] = []
    start = 0
    angle = paren = 0
    for index, char in enumerate(value):
        if char == "<":
            angle += 1
        elif char == ">":
            angle = max(0, angle - 1)
        elif char == "(":
            paren += 1
        elif char == ")":
            paren = max(0, paren - 1)
        elif char == "," and angle == 0 and paren == 0:
            result.append(value[start:index].strip())
            start = index + 1
    result.append(value[start:].strip())
    return [item for item in result if item]


def split_default(value: str) -> tuple[str, str]:
    angle = paren = 0
    in_string = False
    escaped = False
    for index, char in enumerate(value):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "<":
            angle += 1
        elif char == ">":
            angle = max(0, angle - 1)
        elif char == "(":
            paren += 1
        elif char == ")":
            paren = max(0, paren - 1)
        elif char == "=" and angle == 0 and paren == 0:
            return value[:index].strip(), value[index + 1:].strip()
    return value.strip(), ""


def parse_record_fields(header: str, owner: str) -> list[FieldInfo]:
    open_paren = header.find("(")
    if open_paren < 0:
        return []
    close_paren = endpoint_catalog.balanced_end(header, open_paren) - 1
    result: list[FieldInfo] = []
    for component in split_top_level(header[open_paren + 1:close_paren]):
        annotations = " ".join(re.findall(r"@[\w.]+(?:\([^)]*\))?", component))
        cleaned = re.sub(r"@[\w.]+(?:\([^)]*\))?\s*", "", component).strip()
        match = re.match(r"(.+)\s+(\w+)$", cleaned)
        if match:
            result.append(FieldInfo(
                name=match.group(2),
                java_type=" ".join(match.group(1).split()),
                annotations=annotations,
                description=schema_description(annotations),
                declared_in=owner,
            ))
    return result


def strip_leading_type_parameters(tail: str) -> str:
    """Remove `<T ...>` declared immediately after the class name."""
    value = tail.lstrip()
    if not value.startswith("<"):
        return value
    depth = 0
    for index, char in enumerate(value):
        if char == "<":
            depth += 1
        elif char == ">":
            depth -= 1
            if depth == 0:
                return value[index + 1:].lstrip()
    return value


def declared_type_parameters(tail: str) -> tuple[str, ...]:
    value = tail.lstrip()
    if not value.startswith("<"):
        return ()
    depth = 0
    closing = -1
    for index, char in enumerate(value):
        if char == "<":
            depth += 1
        elif char == ">":
            depth -= 1
            if depth == 0:
                closing = index
                break
    if closing < 0:
        return ()
    result: list[str] = []
    for declaration in split_top_level(value[1:closing]):
        match = re.match(r"(?:@[\w.]+\s+)*(\w+)", declaration)
        if match:
            result.append(match.group(1))
    return tuple(result)


def raw_type(value: str) -> str:
    return value.split("<", 1)[0].strip()


def type_arguments(value: str) -> list[str]:
    opening = value.find("<")
    if opening < 0:
        return []
    depth = 0
    for index in range(opening, len(value)):
        if value[index] == "<":
            depth += 1
        elif value[index] == ">":
            depth -= 1
            if depth == 0:
                return split_top_level(value[opening + 1:index])
    return []


def inheritance_clauses(kind: str, tail: str) -> tuple[str | None, list[str]]:
    """Parse inheritance after class type parameters, not bounds inside them."""
    value = strip_leading_type_parameters(tail).strip()
    superclass: str | None = None
    extends_match = re.search(r"\bextends\s+(.+?)(?=\s+(?:implements|permits)\b|$)", value, re.S)
    if extends_match:
        superclass = " ".join(extends_match.group(1).split())
    implements_match = re.search(r"\bimplements\s+(.+?)(?=\s+permits\b|$)", value, re.S)
    interfaces = split_top_level(implements_match.group(1)) if implements_match else []
    if kind in {"record", "enum"}:
        superclass = None
    return superclass, interfaces


def java_name(info: DtoInfo) -> str:
    return ".".join((*info.enclosing, info.name))


def parse_dtos(path: Path) -> list[DtoInfo]:
    source = path.read_text(encoding="utf-8", errors="ignore")
    package_match = re.search(r"^package\s+([\w.]+);", source, re.M)
    if not package_match:
        return []
    imports = tuple(re.findall(r"^import\s+(?!static\s)([\w.*]+);", source, re.M))
    masked = mask_non_code(source)
    result: list[DtoInfo] = []
    declarations = class_declarations(source)
    by_scope = {(*item.enclosing, item.name): item for item in declarations}
    for declaration in declarations:
        parent_scope = declaration.enclosing
        region_start = by_scope[parent_scope].body_start + 1 if parent_scope else 0
        boundary = max(
            masked.rfind(";", region_start, declaration.start),
            masked.rfind("}", region_start, declaration.start),
            region_start - 1,
        )
        prefix = source[boundary + 1:declaration.start]
        docs = list(re.finditer(r"/\*\*.*?\*/", prefix, re.S))
        class_annotations = prefix[docs[-1].end():] if docs else prefix
        superclass, interfaces = inheritance_clauses(declaration.kind, declaration.tail)
        owner = ".".join((*declaration.enclosing, declaration.name))
        info = DtoInfo(
            name=declaration.name,
            enclosing=declaration.enclosing,
            package=package_match.group(1),
            path=path,
            source=source,
            kind=declaration.kind,
            type_parameters=declared_type_parameters(declaration.tail),
            superclass=superclass,
            interfaces=interfaces,
            imports=imports,
            class_annotations=class_annotations,
            description=clean_javadoc(docs[-1].group(0)) if docs else "",
            declaration_line=source.count("\n", 0, declaration.start) + 1,
        )
        header = source[declaration.start:declaration.body_start + 1]
        info.fields = (
            parse_record_fields(header, owner)
            if declaration.kind == "record"
            else parse_fields(source, declaration.body_start, owner)
        )
        result.append(info)
    return result


def parse_dto(path: Path) -> DtoInfo | None:
    """Backward-compatible helper returning the top-level DTO."""
    return next((info for info in parse_dtos(path) if not info.enclosing), None)


def simple_type(value: str | None) -> str | None:
    if not value:
        return None
    return raw_type(value).rsplit(".", 1)[-1]


def qualified_name(info: DtoInfo) -> str:
    return f"{info.package}.{java_name(info)}"


def build_dto_indexes(infos: list[DtoInfo]) -> tuple[dict[str, DtoInfo], dict[str, list[DtoInfo]]]:
    by_qualified_name = {qualified_name(info): info for info in infos}
    by_simple_name: dict[str, list[DtoInfo]] = {}
    for info in infos:
        by_simple_name.setdefault(info.name, []).append(info)
    return by_qualified_name, by_simple_name


def resolve_dto(
    value: str | None,
    owner: DtoInfo,
    by_qualified_name: dict[str, DtoInfo],
    by_simple_name: dict[str, list[DtoInfo]],
) -> DtoInfo | None:
    if not value:
        return None
    raw_name = raw_type(value)
    if not raw_name:
        return None
    if raw_name in by_qualified_name:
        return by_qualified_name[raw_name]
    simple_name = raw_name.rsplit(".", 1)[-1]
    if "." in raw_name:
        package_candidate = by_qualified_name.get(f"{owner.package}.{raw_name}")
        if package_candidate:
            return package_candidate
    owner_scope = (*owner.enclosing, owner.name)
    for length in range(len(owner_scope), 0, -1):
        scoped_name = ".".join((*owner_scope[:length], raw_name))
        candidate = by_qualified_name.get(f"{owner.package}.{scoped_name}")
        if candidate:
            return candidate
    first_segment, _, suffix = raw_name.partition(".")
    for imported in owner.imports:
        if not imported.endswith(".*") and imported.rsplit(".", 1)[-1] == first_segment:
            imported_candidate = imported + (f".{suffix}" if suffix else "")
            if imported_candidate in by_qualified_name:
                return by_qualified_name[imported_candidate]
    package_candidate = by_qualified_name.get(f"{owner.package}.{raw_name}")
    if package_candidate:
        return package_candidate
    for imported in owner.imports:
        if imported.endswith(".*"):
            candidate = by_qualified_name.get(f"{imported[:-2]}.{raw_name}")
            if candidate:
                return candidate
    candidates = by_simple_name.get(simple_name, [])
    return candidates[0] if len(candidates) == 1 else None


def all_fields(
    info: DtoInfo,
    by_qualified_name: dict[str, DtoInfo],
    by_simple_name: dict[str, list[DtoInfo]],
) -> list[FieldInfo]:
    lineage: list[tuple[DtoInfo, dict[str, str]]] = []
    visited: set[str] = set()
    current: DtoInfo | None = info
    substitutions: dict[str, str] = {}
    while current:
        current_name = qualified_name(current)
        if current_name in visited:
            break
        visited.add(current_name)
        lineage.append((current, substitutions))
        parent = resolve_dto(current.superclass, current, by_qualified_name, by_simple_name)
        arguments = type_arguments(current.superclass or "")
        parent_substitutions = {
            parameter: substitute_java_type(argument, substitutions)
            for parameter, argument in zip(parent.type_parameters if parent else (), arguments)
        }
        current = parent
        substitutions = parent_substitutions
    merged: dict[str, FieldInfo] = {}
    for current, current_substitutions in reversed(lineage):
        for current_field in current.fields:
            merged[current_field.name] = replace(
                current_field,
                java_type=substitute_java_type(current_field.java_type, current_substitutions),
            )
    return list(merged.values())


def substitute_java_type(value: str, substitutions: dict[str, str]) -> str:
    result = value
    for parameter in sorted(substitutions, key=len, reverse=True):
        result = re.sub(rf"\b{re.escape(parameter)}\b", substitutions[parameter], result)
    return result


def parsed_annotations(value: str) -> list[tuple[str, str]]:
    parsed: list[tuple[str, str]] = []
    position = 0
    while True:
        match = re.search(r"@([\w.]+)", value[position:])
        if not match:
            break
        at = position + match.start()
        name_end = position + match.end()
        paren_at = name_end
        while paren_at < len(value) and value[paren_at].isspace():
            paren_at += 1
        end = endpoint_catalog.balanced_end(value, paren_at) if paren_at < len(value) and value[paren_at] == "(" else name_end
        annotation = value[at:end]
        parsed.append((match.group(1).rsplit(".", 1)[-1], " ".join(annotation.split())))
        position = max(end, at + 1)
    return parsed


def annotation(field: FieldInfo, simple_name: str) -> str | None:
    return next(
        (value for name, value in parsed_annotations(field.annotations) if name == simple_name),
        None,
    )


def annotation_argument(value: str, name: str) -> str | None:
    match = re.search(rf"\b{re.escape(name)}\s*=\s*([\w.]+|\"[^\"]*\")", value)
    return match.group(1) if match else None


def constraints(field: FieldInfo) -> list[str]:
    names = {
        "NotNull", "NotBlank", "NotEmpty", "Null", "Size", "Min", "Max",
        "DecimalMin", "DecimalMax", "Positive", "PositiveOrZero", "Negative",
        "NegativeOrZero", "Pattern", "Email", "Past", "PastOrPresent", "Future",
        "FutureOrPresent", "AssertTrue", "AssertFalse", "Valid",
    }

    result: list[str] = []
    for name, annotation in parsed_annotations(field.annotations):
        if name in names or (name.startswith("Valid") and name != "Validated"):
            result.append(annotation)
    for name, annotation in parsed_annotations(field.type_annotations):
        if name in names or (name.startswith("Valid") and name != "Validated"):
            result.append(f"elements: {annotation}")
    return list(dict.fromkeys(result))


def java_nullability(field: FieldInfo) -> str:
    if field.java_type in {"boolean", "byte", "short", "int", "long", "float", "double", "char"}:
        return "невозможен (`primitive`)"
    if raw_type(field.java_type) in {"Optional", "java.util.Optional"}:
        return "`Optional`-контейнер"
    annotation_names = {name for name, _ in parsed_annotations(field.annotations)}
    if "Nullable" in annotation_names:
        return "разрешён (`@Nullable`)"
    if "NonNull" in annotation_names:
        return "помечен `@NonNull`"
    return "технически возможен (reference)"


def json_required_declaration(field: FieldInfo) -> str:
    json_property = annotation(field, "JsonProperty")
    if not json_property:
        return "не задано"
    required_value = annotation_argument(json_property, "required")
    return f"`{required_value}` (`@JsonProperty`)" if required_value in {"true", "false"} else "не задано"


def jackson_null_handling(field: FieldInfo) -> str:
    json_setter = annotation(field, "JsonSetter")
    if not json_setter:
        return "не задано"
    values: list[str] = []
    for argument_name in ("nulls", "contentNulls"):
        argument_value = annotation_argument(json_setter, argument_name)
        if argument_value:
            values.append(f"`{argument_name} = {argument_value}`")
    return ", ".join(values) or "`@JsonSetter` без null-policy"


def json_name(field: FieldInfo) -> str:
    return annotation_value(field.annotations, "JsonProperty") or field.name


def json_aliases(field: FieldInfo) -> str:
    match = re.search(r"@JsonAlias\s*\((.*?)\)", field.annotations, re.S)
    if not match:
        return "—"
    values = re.findall(r'"([^\"]+)"', match.group(1))
    return ", ".join(f"`{value}`" for value in values) or "—"


def type_links(
    java_type: str,
    owner: DtoInfo,
    page: Path,
    pages: dict[str, Path],
    by_qualified_name: dict[str, DtoInfo],
    by_simple_name: dict[str, list[DtoInfo]],
) -> str:
    pattern = re.compile(r"\b[A-Z][A-Za-z0-9_]*(?:\.[A-Z][A-Za-z0-9_]*)*\b")
    result: list[str] = []
    position = 0
    for match in pattern.finditer(java_type):
        result.append(java_type[position:match.start()])
        label = match.group(0)
        target_info = resolve_dto(label, owner, by_qualified_name, by_simple_name)
        target = pages.get(qualified_name(target_info)) if target_info else None
        if target:
            rel = Path(os.path.relpath(target, page.parent)).as_posix()
            result.append(f"[{label}]({rel})")
        else:
            result.append(label)
        position = match.end()
    result.append(java_type[position:])
    return "".join(result).replace("|", "\\|")


def endpoint_usages(infos: list[DtoInfo]) -> dict[str, list[Usage]]:
    by_qualified_name, by_simple_name = build_dto_indexes(infos)
    result: dict[str, list[Usage]] = {qualified_name(info): [] for info in infos}
    endpoints: list[endpoint_catalog.Endpoint] = []
    for controller, scope in endpoint_catalog.discover_controller_sources():
        endpoints.extend(endpoint_catalog.parse_controller(controller, scope))
    for endpoint in endpoints:
        controller_source = endpoint.source.read_text(encoding="utf-8", errors="ignore")
        imports = tuple(re.findall(r"^import\s+(?!static\s)([\w.*]+);", controller_source, re.M))
        for role, signature_type in (("request", endpoint.request_body), ("response", endpoint.response)):
            for name in set(re.findall(r"\b[A-Z][A-Za-z0-9_]*Dto\b", signature_type)):
                candidates = by_simple_name.get(name, [])
                target = candidates[0] if len(candidates) == 1 else None
                if len(candidates) > 1:
                    imported_name = next(
                        (item for item in imports if not item.endswith(".*") and item.rsplit(".", 1)[-1] == name),
                        None,
                    )
                    target = by_qualified_name.get(imported_name) if imported_name else None
                if not target:
                    continue
                usage = Usage(endpoint.http_method, endpoint.paths, role, endpoint.controller, endpoint.origin)
                target_name = qualified_name(target)
                if usage not in result[target_name]:
                    result[target_name].append(usage)
    return result


def manual_pages() -> dict[str, Path]:
    result: dict[str, Path] = {}
    root = REPO / "docs/docsforanalytics/dto"
    for page in root.rglob("*.md"):
        if OUTPUT in page.parents or page.name == "README.md":
            continue
        result.setdefault(page.stem, page)
    return result


def page_for(info: DtoInfo) -> Path:
    alis_prefix = "ru.korusconsulting.alis.dto"
    wms_prefix = "ru.korusconsulting.wms.dto"
    if info.package == alis_prefix:
        relative_package = "base"
    elif info.package.startswith(alis_prefix + "."):
        relative_package = info.package.removeprefix(alis_prefix + ".").replace(".", "/")
    elif info.package == wms_prefix:
        relative_package = "wms"
    elif info.package.startswith(wms_prefix + "."):
        relative_package = "wms/" + info.package.removeprefix(wms_prefix + ".").replace(".", "/")
    else:
        relative_package = info.package.replace(".", "/")
    return OUTPUT / relative_package / f"{java_name(info)}.md"


def write_page(
    info: DtoInfo,
    by_qualified_name: dict[str, DtoInfo],
    by_simple_name: dict[str, list[DtoInfo]],
    pages: dict[str, Path],
    usages: dict[str, list[Usage]],
    manuals: dict[str, Path],
) -> None:
    info_name = qualified_name(info)
    page = pages[info_name]
    page.parent.mkdir(parents=True, exist_ok=True)
    source_rel = Path(os.path.relpath(info.path, page.parent)).as_posix()
    parent_name = simple_type(info.superclass)
    parent = type_links(
        info.superclass or "нет", info, page, pages, by_qualified_name, by_simple_name
    )
    interfaces = ", ".join(f"`{value}`" for value in info.interfaces) or "нет"
    direction = sorted({usage.role for usage in usages.get(info_name, [])})
    manual = manuals.get(info.name) if not info.enclosing else None
    class_constraints = re.findall(r"@(Valid[A-Z]\w*|AssertTrue)\b", info.class_annotations)
    method_constraints = [
        f"@{match.group(1)} → {match.group(2)}()"
        for match in re.finditer(
            r"@(AssertTrue|AssertFalse)\b(?:\s*\([^)]*\))?\s*"
            r"(?:public|private|protected)?\s*boolean\s+(\w+)\s*\(",
            info.source,
            re.S,
        )
    ]
    display_name = java_name(info)
    location = "nested" if info.enclosing else "top-level"
    lines = [
        f"# `{display_name}`",
        "",
        "> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.",
        "",
        info.description or (f"Вложенный DTO `{display_name}`." if info.enclosing else f"DTO пакета `{info.package}`."),
        "",
        "## Паспорт",
        "",
        f"- **Java FQCN:** `{info_name}`",
        f"- **Java package:** `{info.package}`",
        f"- **Тип:** `{info.kind}` ({location})",
        f"- **Использование в controller signatures:** {', '.join(direction) if direction else 'не найдено'}",
        f"- **Наследует:** {parent}",
        f"- **Интерфейсы:** {interfaces}",
        f"- **Class-level validation:** {', '.join(f'`@{name}`' for name in class_constraints) if class_constraints else 'нет'}",
        f"- **Method/property validation:** {', '.join(f'`{value}`' for value in method_constraints) if method_constraints else 'нет'}",
        f"- **Java-источник:** [{info.path.name}:{info.declaration_line}]({source_rel}#L{info.declaration_line})",
    ]
    if info.enclosing:
        enclosing_name = ".".join(info.enclosing)
        enclosing_fqcn = f"{info.package}.{enclosing_name}"
        enclosing_page = pages.get(enclosing_fqcn)
        if enclosing_page:
            enclosing_rel = Path(os.path.relpath(enclosing_page, page.parent)).as_posix()
            lines.append(f"- **Вложен в:** [{enclosing_name}]({enclosing_rel})")
    if manual:
        manual_rel = Path(os.path.relpath(manual, page.parent)).as_posix()
        lines.append(f"- **Ручной бизнес-паспорт:** [{manual.name}]({manual_rel})")
    lines.extend(["", "## Использование в endpoints", ""])
    info_usages = usages.get(info_name, [])
    if info_usages:
        lines.extend(["| Роль | Метод и путь | Контроллер (происхождение) |", "|---|---|---|"])
        for usage in sorted(info_usages, key=lambda item: (item.controller, item.method, item.paths)):
            paths = "<br>".join(f"`{path}`" for path in usage.paths)
            lines.append(f"| {usage.role} | `{usage.method}` {paths} | `{usage.controller}` ({usage.origin}) |")
    else:
        lines.append("Прямое использование в сигнатурах Spring-контроллеров не найдено. DTO может быть вложенным, внутренним, интеграционным, report DTO либо частью другого DTO.")
    lines.extend([
        "",
        "## Поля",
        "",
        "| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |",
        "|---|---|---|---|---|---|---|---|---|",
    ])
    fields = all_fields(info, by_qualified_name, by_simple_name)
    if not fields:
        lines.append("| — | — | — | — | — | — | — | — | Поля верхнего уровня не найдены |")
    for item in fields:
        escaped_constraints = [value.replace("|", "\\|") for value in constraints(item)]
        validation = ", ".join(f"`{value}`" for value in escaped_constraints) or "—"
        meaning = item.description or "—"
        if item.default:
            meaning = (meaning + "; " if meaning != "—" else "") + f"default: `{item.default}`"
        meaning = meaning.replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| `{json_name(item)}`{(' (aliases: ' + json_aliases(item) + ')') if json_aliases(item) != '—' else ''} "
            f"| `{item.name}` | {type_links(item.java_type, info, page, pages, by_qualified_name, by_simple_name)} "
            f"| {java_nullability(item)} | {json_required_declaration(item)} | {jackson_null_handling(item)} "
            f"| {validation} | `{item.declared_in}` | {meaning} |"
        )
    lines.extend([
        "",
        "## Ограничения интерпретации",
        "",
        "- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.",
        "- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.",
        "- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.",
        "- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.",
        "- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.",
        "- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.",
        "- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.",
        "- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.",
    ])
    if parent_name and not resolve_dto(info.superclass, info, by_qualified_name, by_simple_name):
        lines.append(f"- Поля внешнего родителя `{parent_name}` не раскрыты: его исходник не найден среди DTO source roots.")
    page.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    if OUTPUT.name != "catalog" or OUTPUT.parent.name != "dto":
        raise RuntimeError(f"Refusing to clean unexpected output path: {OUTPUT}")
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    infos: list[DtoInfo] = []
    for root in DTO_ROOTS:
        if not root.exists():
            continue
        for path in root.rglob("*.java"):
            infos.extend(parse_dtos(path))
    by_qualified_name, by_simple_name = build_dto_indexes(infos)
    pages = {qualified_name(info): page_for(info) for info in infos}
    if len(set(pages.values())) != len(pages):
        raise RuntimeError("Multiple DTO types resolve to the same documentation page")
    usages = endpoint_usages(infos)
    manuals = manual_pages()
    for info in sorted(infos, key=qualified_name):
        write_page(info, by_qualified_name, by_simple_name, pages, usages, manuals)

    index = [
        "# Полный технический каталог DTO",
        "",
        "> Каталог сгенерирован из Java. Запуск: `python3 docs/docsforanalytics/scripts/generate_dto_docs.py`.",
        "",
        f"Top-level DTO-типов: **{sum(not info.enclosing for info in infos)}**. Вложенных DTO-типов: **{sum(bool(info.enclosing) for info in infos)}**. Всего паспортов: **{len(infos)}**.",
        "",
        "Ручные паспорта содержат бизнес-смысл и имеют приоритет. Generated-паспорта обеспечивают полноту полей, раздельные признаки Java nullability / JSON required / Jackson null-policy / Bean Validation и связь с endpoint signatures.",
        "Каждый тип идентифицируется Java FQCN. Родитель и ссылка на поле разрешаются относительно внешнего класса, по полному имени, явному import, текущему package, wildcard import либо единственному совпадению простого имени. При повторном объявлении поля в наследнике в таблицу попадает наиболее конкретное объявление.",
        "",
        "| DTO | Java FQCN | Размещение | Полей с наследованием | Endpoint roles | Ручной паспорт |",
        "|---|---|---|---:|---|---|",
    ]
    for info in sorted(infos, key=qualified_name):
        info_name = qualified_name(info)
        page = pages[info_name]
        link = page.relative_to(OUTPUT).as_posix()
        roles = ", ".join(sorted({usage.role for usage in usages.get(info_name, [])})) or "—"
        manual = manuals.get(info.name) if not info.enclosing else None
        if manual:
            manual_link = Path(os.path.relpath(manual, OUTPUT)).as_posix()
            manual_cell = f"[да]({manual_link})"
        else:
            manual_cell = "нет"
        index.append(
            f"| [`{java_name(info)}`]({link}) | `{info_name}` | {'nested' if info.enclosing else 'top-level'} | {len(all_fields(info, by_qualified_name, by_simple_name))} | {roles} | {manual_cell} |"
        )
    (OUTPUT / "README.md").write_text("\n".join(index) + "\n", encoding="utf-8")
    print(
        f"Generated {len(infos)} DTO pages: "
        f"{sum(not info.enclosing for info in infos)} top-level, "
        f"{sum(bool(info.enclosing) for info in infos)} nested"
    )


if __name__ == "__main__":
    main()
