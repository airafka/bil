#!/usr/bin/env python3
"""Focused regression checks for DTO inheritance parsing."""

from __future__ import annotations

import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import generate_dto_docs as generator  # noqa: E402


class DtoInheritanceTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.counter = 0

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def parse(self, source: str) -> generator.DtoInfo:
        self.counter += 1
        path = self.root / f"Dto{self.counter}.java"
        path.write_text(textwrap.dedent(source).lstrip(), encoding="utf-8")
        result = generator.parse_dto(path)
        self.assertIsNotNone(result)
        return result

    def test_generic_bound_is_not_treated_as_superclass(self) -> None:
        info = self.parse(
            """
            package example.child;
            import example.base.BaseDto;
            public abstract class HierarchyDto<
                TNode extends HierarchyDto<TNode, TElement>, TElement
            > extends BaseDto {
                private String code;
            }
            """
        )

        self.assertEqual("BaseDto", info.superclass)
        self.assertIn("example.base.BaseDto", info.imports)

    def test_import_resolves_parent_and_inherits_id_once(self) -> None:
        base = self.parse(
            """
            package example.base;
            public class BaseDto {
                protected java.util.UUID id;
            }
            """
        )
        other_base = self.parse(
            """
            package example.other;
            public class BaseDto {
                protected String wrongParentField;
            }
            """
        )
        hierarchy = self.parse(
            """
            package example.child;
            import example.base.BaseDto;
            public class HierarchyDto<T extends HierarchyDto<T>> extends BaseDto {
                private String code;
            }
            """
        )
        by_qualified_name, by_simple_name = generator.build_dto_indexes([base, other_base, hierarchy])

        fields = generator.all_fields(hierarchy, by_qualified_name, by_simple_name)

        self.assertEqual(["id", "code"], [field.name for field in fields])
        self.assertEqual(1, sum(field.name == "id" for field in fields))
        self.assertIs(base, generator.resolve_dto(hierarchy.superclass, hierarchy, by_qualified_name, by_simple_name))

    def test_same_package_parent_is_selected_when_simple_name_is_ambiguous(self) -> None:
        local_parent = self.parse(
            """
            package example.child;
            public class ParentDto { protected String localValue; }
            """
        )
        other_parent = self.parse(
            """
            package example.other;
            public class ParentDto { protected String otherValue; }
            """
        )
        child = self.parse(
            """
            package example.child;
            public class ChildDto extends ParentDto { private String value; }
            """
        )
        by_qualified_name, by_simple_name = generator.build_dto_indexes([local_parent, other_parent, child])

        resolved = generator.resolve_dto(child.superclass, child, by_qualified_name, by_simple_name)

        self.assertIs(local_parent, resolved)

    def test_cycle_and_hidden_field_do_not_duplicate_output_fields(self) -> None:
        first = self.parse(
            """
            package example.cycle;
            public class FirstDto extends SecondDto {
                protected String shared;
                private String first;
            }
            """
        )
        second = self.parse(
            """
            package example.cycle;
            public class SecondDto extends FirstDto {
                protected String shared;
                private String second;
            }
            """
        )
        by_qualified_name, by_simple_name = generator.build_dto_indexes([first, second])

        fields = generator.all_fields(first, by_qualified_name, by_simple_name)

        self.assertEqual(1, sum(field.name == "shared" for field in fields))
        self.assertEqual({"shared", "first", "second"}, {field.name for field in fields})

    def test_nested_type_has_fqcn_fields_and_contextual_link(self) -> None:
        path = self.root / "RailwayCarriageRemainSyncDto.java"
        path.write_text(
            textwrap.dedent(
                """
                package example.remain;
                import java.util.List;
                public class RailwayCarriageRemainSyncDto {
                    private List<Leftover> leftovers;
                    public static class Leftover {
                        private String timestamp;
                        private String eventCode;
                    }
                }
                """
            ).lstrip(),
            encoding="utf-8",
        )
        infos = generator.parse_dtos(path)
        by_qualified_name, by_simple_name = generator.build_dto_indexes(infos)
        outer = by_qualified_name["example.remain.RailwayCarriageRemainSyncDto"]
        nested = by_qualified_name["example.remain.RailwayCarriageRemainSyncDto.Leftover"]
        pages = {generator.qualified_name(info): generator.page_for(info) for info in infos}

        rendered_type = generator.type_links(
            "List<Leftover>", outer, pages[generator.qualified_name(outer)], pages,
            by_qualified_name, by_simple_name,
        )

        self.assertEqual(("RailwayCarriageRemainSyncDto",), nested.enclosing)
        self.assertEqual(["timestamp", "eventCode"], [field.name for field in nested.fields])
        self.assertIs(nested, generator.resolve_dto("Leftover", outer, by_qualified_name, by_simple_name))
        self.assertIn("[Leftover]", rendered_type)

    def test_qualified_nested_name_wins_over_same_named_top_level_dto(self) -> None:
        generic_parent = self.parse(
            """
            package example.good;
            import java.util.List;
            public class HierarchyDto<TNode, TElement> {
                private List<TNode> children;
                private List<TElement> elements;
            }
            """
        )
        hierarchy_path = self.root / "ClientGoodHierarchyDto.java"
        hierarchy_path.write_text(
            textwrap.dedent(
                """
                package example.good;
                public class ClientGoodHierarchyDto extends
                        HierarchyDto<ClientGoodHierarchyDto, ClientGoodHierarchyDto.ClientGoodDto> {
                    private ClientGoodHierarchyDto.ClientGoodDto element;
                    public static class ClientGoodDto { private String nestedValue; }
                }
                """
            ).lstrip(),
            encoding="utf-8",
        )
        top_level = self.parse(
            """
            package example.good;
            public class ClientGoodDto { private String topLevelValue; }
            """
        )
        infos = [generic_parent, *generator.parse_dtos(hierarchy_path), top_level]
        by_qualified_name, by_simple_name = generator.build_dto_indexes(infos)
        outer = by_qualified_name["example.good.ClientGoodHierarchyDto"]
        nested = by_qualified_name["example.good.ClientGoodHierarchyDto.ClientGoodDto"]

        resolved = generator.resolve_dto(
            "ClientGoodHierarchyDto.ClientGoodDto", outer, by_qualified_name, by_simple_name
        )

        self.assertIs(nested, resolved)
        inherited_types = {field.name: field.java_type for field in generator.all_fields(outer, by_qualified_name, by_simple_name)}
        self.assertEqual("List<ClientGoodHierarchyDto>", inherited_types["children"])
        self.assertEqual("List<ClientGoodHierarchyDto.ClientGoodDto>", inherited_types["elements"])

    def test_same_simple_top_level_names_get_distinct_fqcn_pages(self) -> None:
        alis = self.parse(
            """
            package ru.example.alis.dto;
            public class BaseActivatedUpdateDto { private String alisValue; }
            """
        )
        wms = self.parse(
            """
            package ru.example.wms.dto;
            public class BaseActivatedUpdateDto { private String wmsValue; }
            """
        )

        pages = {generator.qualified_name(info): generator.page_for(info) for info in (alis, wms)}

        self.assertEqual(2, len(pages))
        self.assertEqual(2, len(set(pages.values())))

    def test_bean_validation_does_not_become_json_required_declaration(self) -> None:
        field = generator.FieldInfo(name="eventCode", java_type="String", annotations="@NotBlank")

        self.assertEqual(["@NotBlank"], generator.constraints(field))
        self.assertEqual("не задано", generator.json_required_declaration(field))
        self.assertEqual("технически возможен (reference)", generator.java_nullability(field))

    def test_json_property_required_is_reported_separately(self) -> None:
        field = generator.FieldInfo(
            name="code",
            java_type="String",
            annotations='@JsonProperty(value = "event_code", required = true) @NotBlank',
        )

        self.assertEqual("event_code", generator.json_name(field))
        self.assertEqual("`true` (`@JsonProperty`)", generator.json_required_declaration(field))
        self.assertEqual(["@NotBlank"], generator.constraints(field))

    def test_primitive_nullable_optional_and_json_setter_are_independent(self) -> None:
        primitive = generator.FieldInfo(name="active", java_type="boolean")
        nullable = generator.FieldInfo(name="comment", java_type="String", annotations="@Nullable")
        optional = generator.FieldInfo(name="code", java_type="Optional<String>")
        skip_null = generator.FieldInfo(
            name="clients",
            java_type="List<UUID>",
            annotations="@JsonSetter(nulls = Nulls.SKIP, contentNulls = Nulls.FAIL)",
        )

        self.assertEqual("невозможен (`primitive`)", generator.java_nullability(primitive))
        self.assertEqual("не задано", generator.json_required_declaration(primitive))
        self.assertEqual("разрешён (`@Nullable`)", generator.java_nullability(nullable))
        self.assertEqual("`Optional`-контейнер", generator.java_nullability(optional))
        self.assertEqual(
            "`nulls = Nulls.SKIP`, `contentNulls = Nulls.FAIL`",
            generator.jackson_null_handling(skip_null),
        )


if __name__ == "__main__":
    unittest.main()
