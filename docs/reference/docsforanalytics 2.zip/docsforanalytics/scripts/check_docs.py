#!/usr/bin/env python3
"""Read-only structural checks for the docsforanalytics Markdown library."""

from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import unquote


DEFAULT_ROOT = Path(__file__).resolve().parents[1]
LINK_PATTERN = re.compile(r"!?\[[^\]\n]*\]\(([^)\n]+)\)")
FENCE_PATTERN = re.compile(r"^\s*(`{3,}|~{3,})")
EXTERNAL_PREFIXES = ("http://", "https://", "mailto:", "tel:", "data:")


@dataclass
class CheckResult:
    markdown_files: int = 0
    local_links: int = 0
    frontend_links: int = 0
    broken_links: list[str] = field(default_factory=list)
    unclosed_fences: list[str] = field(default_factory=list)
    trailing_whitespace: list[str] = field(default_factory=list)

    @property
    def error_count(self) -> int:
        return len(self.broken_links) + len(self.unclosed_fences) + len(self.trailing_whitespace)


def parse_link_target(raw_target: str) -> str:
    """Return the destination part, excluding an optional Markdown title."""
    target = raw_target.strip()
    if target.startswith("<"):
        closing = target.find(">")
        return target[1:closing] if closing >= 0 else target[1:]
    return target.split(maxsplit=1)[0] if target else ""


def resolve_local_target(source: Path, target: str) -> Path | None:
    """Resolve a local Markdown destination; return None for non-file links."""
    if not target or target.startswith("#") or target.lower().startswith(EXTERNAL_PREFIXES):
        return None

    path_part = target.split("#", 1)[0].split("?", 1)[0]
    if not path_part:
        return None

    destination = Path(unquote(path_part))
    if not destination.is_absolute():
        destination = source.parent / destination
    return destination


def frontend_source_path(root: Path, source: Path, target: str) -> str | None:
    """Return the path inside the frontend repo for a link that leaves `root` into `src/`."""
    path_part = unquote(target.split("#", 1)[0].split("?", 1)[0])
    if Path(path_part).is_absolute():
        return None
    destination = Path(*(source.parent / path_part).parts)
    resolved = Path(os.path.normpath(destination))
    if resolved.is_relative_to(root):
        return None
    parts = path_part.replace("\\", "/").lstrip("./").split("/")
    parts = [part for part in parts if part not in ("", ".", "..")]
    return "/".join(parts) if parts and parts[0] == "src" else None


def check_fences(path: Path, lines: list[str], result: CheckResult) -> None:
    active_character: str | None = None
    active_length = 0
    active_line = 0

    for line_number, line in enumerate(lines, start=1):
        match = FENCE_PATTERN.match(line)
        if not match:
            continue

        marker = match.group(1)
        character = marker[0]
        if active_character is None:
            active_character = character
            active_length = len(marker)
            active_line = line_number
        elif character == active_character and len(marker) >= active_length:
            active_character = None
            active_length = 0
            active_line = 0

    if active_character is not None:
        result.unclosed_fences.append(f"{path}:{active_line}: unclosed {active_character * active_length} fence")


def check_document(path: Path, result: CheckResult, root: Path, frontend_root: Path | None) -> None:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)

    check_fences(path, lines, result)

    for line_number, line in enumerate(lines, start=1):
        content = line.removesuffix("\n").removesuffix("\r")
        if content.endswith((" ", "\t")):
            result.trailing_whitespace.append(f"{path}:{line_number}: trailing whitespace")

    for match in LINK_PATTERN.finditer(text):
        target = parse_link_target(match.group(1))
        destination = resolve_local_target(path, target)
        if destination is None:
            continue

        frontend_path = frontend_source_path(root, path, target)
        if frontend_path is not None:
            result.frontend_links += 1
            if frontend_root is not None and not (frontend_root / frontend_path).exists():
                line_number = text.count("\n", 0, match.start()) + 1
                result.broken_links.append(f"{path}:{line_number}: missing frontend target {target}")
            continue

        result.local_links += 1
        if not destination.exists():
            line_number = text.count("\n", 0, match.start()) + 1
            result.broken_links.append(f"{path}:{line_number}: missing target {target}")


def check_library(root: Path, frontend_root: Path | None = None) -> CheckResult:
    result = CheckResult()
    markdown_files = sorted(root.rglob("*.md"))
    result.markdown_files = len(markdown_files)
    for path in markdown_files:
        check_document(path, result, root, frontend_root)
    return result


def print_result(root: Path, result: CheckResult) -> None:
    print(f"Documentation root: {root}")
    print(f"Markdown files: {result.markdown_files}")
    print(f"Local links: {result.local_links}")
    print(f"Frontend source links (not checked without --frontend-root): {result.frontend_links}")
    print(f"Broken links: {len(result.broken_links)}")
    print(f"Unclosed fences: {len(result.unclosed_fences)}")
    print(f"Trailing whitespace: {len(result.trailing_whitespace)}")

    diagnostics = result.broken_links + result.unclosed_fences + result.trailing_whitespace
    if diagnostics:
        print("\nDiagnostics:")
        for diagnostic in diagnostics:
            print(f"- {diagnostic}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=DEFAULT_ROOT,
        help="Markdown root to check (default: docs/docsforanalytics)",
    )
    parser.add_argument(
        "--frontend-root",
        type=Path,
        default=None,
        help="alis-frontend checkout; when set, links into src/ are verified against it",
    )
    args = parser.parse_args()

    root = args.root.expanduser().resolve()
    if not root.is_dir():
        parser.error(f"documentation root does not exist or is not a directory: {root}")

    frontend_root = args.frontend_root.expanduser().resolve() if args.frontend_root else None
    if frontend_root is not None and not frontend_root.is_dir():
        parser.error(f"frontend root does not exist or is not a directory: {frontend_root}")

    result = check_library(root, frontend_root)
    print_result(root, result)
    return 1 if result.error_count else 0


if __name__ == "__main__":
    sys.exit(main())
