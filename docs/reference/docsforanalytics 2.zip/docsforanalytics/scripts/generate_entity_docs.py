#!/usr/bin/env python3
"""Generate analyst-facing JPA entity pages from the Java model.

The generator intentionally extracts only facts visible in source annotations and
declarations. Business meaning that cannot be inferred safely remains in manually
maintained domain pages next to the generated catalog.
"""

from __future__ import annotations

import re
import os
from dataclasses import dataclass, field
from pathlib import Path


REPO = Path(__file__).resolve().parents[3]
OUTPUT = REPO / "docs/docsforanalytics/entities/catalog"
SOURCE_ROOTS = [
    REPO / "db-layer/src/main/java",
    REPO / "wms-layer/src/main/java",
]


@dataclass
class FieldInfo:
    name: str
    java_type: str
    annotations: str
    description: str
    declared_in: str
    default: str = ""


@dataclass
class ClassInfo:
    name: str
    package: str
    path: Path
    source: str
    superclass: str | None
    interfaces: list[str]
    entity: bool
    mapped_superclass: bool
    table: str
    explicit_table: bool
    class_annotations: str
    description: str
    fields: list[FieldInfo] = field(default_factory=list)


def snake(value: str) -> str:
    value = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", value)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value).lower()


def clean_javadoc(raw: str | None) -> str:
    if not raw:
        return ""
    text = re.sub(r"^\s*/\*\*|\*/\s*$", "", raw.strip(), flags=re.S)
    lines = []
    for line in text.splitlines():
        line = re.sub(r"^\s*\*\s?", "", line).strip()
        if line.startswith("@") or line in {"<p>", "</p>", "<ul>", "</ul>"}:
            continue
        line = re.sub(r"\{@link\s+([^ }]+)(?:\s+([^}]+))?}", lambda m: m.group(2) or m.group(1), line)
        line = re.sub(r"</?[^>]+>", "", line)
        if line:
            lines.append(line)
    return " ".join(lines)


def class_depth(source: str, position: int, body_start: int) -> int:
    fragment = source[body_start:position]
    return fragment.count("{") - fragment.count("}")


def parse_fields(source: str, body_start: int, owner: str) -> list[FieldInfo]:
    pattern = re.compile(
        r"(?P<doc>/\*\*.*?\*/\s*)?"
        r"(?P<ann>(?:\s*@[\w.]+(?:\s*\([^;{}]*?(?:\{[^{}]*\}[^;{}]*?)?\))?\s*)*)"
        r"(?:private|protected|public)\s+(?!static\b)(?:final\s+)?"
        r"(?P<type>[\w.$<>, ?\[\]]+)\s+(?P<name>\w+)\s*"
        r"(?P<default>=\s*[^;]+)?;",
        flags=re.S,
    )
    result = []
    for match in pattern.finditer(source, body_start):
        if class_depth(source, match.start(), body_start) != 1:
            continue
        java_type = " ".join(match.group("type").split())
        if "(" in java_type or java_type.startswith("return "):
            continue
        default = (match.group("default") or "").removeprefix("=").strip()
        result.append(
            FieldInfo(
                name=match.group("name"),
                java_type=java_type,
                annotations=match.group("ann") or "",
                description=clean_javadoc(match.group("doc")),
                declared_in=owner,
                default=default,
            )
        )
    return result


def parse_class(path: Path) -> ClassInfo | None:
    source = path.read_text(encoding="utf-8", errors="ignore")
    package_match = re.search(r"^package\s+([\w.]+);", source, re.M)
    class_match = re.search(
        r"public\s+(?:abstract\s+)?class\s+(\w+)"
        r"(?:\s+extends\s+([\w.]+))?"
        r"(?:\s+implements\s+([^\{]+))?\s*\{",
        source,
    )
    if not package_match or not class_match:
        return None
    name = class_match.group(1)
    entity = bool(re.search(r"^\s*@Entity(?:\s*\(|\s*$)", source[: class_match.start()], re.M))
    mapped = bool(re.search(r"^\s*@MappedSuperclass\s*$", source[: class_match.start()], re.M))
    if not entity and not mapped:
        return None
    table_match = re.search(r"@Table\s*\(.*?name\s*=\s*\"([^\"]+)\"", source[: class_match.start()], re.S)
    table = table_match.group(1) if table_match else snake(name)
    prefix = source[: class_match.start()]
    docs = list(re.finditer(r"/\*\*.*?\*/", prefix, re.S))
    description = clean_javadoc(docs[-1].group(0)) if docs else ""
    interfaces = [x.strip().split("<", 1)[0] for x in (class_match.group(3) or "").split(",") if x.strip()]
    info = ClassInfo(
        name=name,
        package=package_match.group(1),
        path=path,
        source=source,
        superclass=class_match.group(2),
        interfaces=interfaces,
        entity=entity,
        mapped_superclass=mapped,
        table=table,
        explicit_table=bool(table_match),
        class_annotations=source[: class_match.start()],
        description=description,
    )
    info.fields = parse_fields(source, class_match.end() - 1, name)
    return info


def annotation_name(annotations: str, kind: str, arg: str) -> str | None:
    match = re.search(rf"@{kind}\s*\([^)]*\b{arg}\s*=\s*\"([^\"]+)\"", annotations, re.S)
    return match.group(1) if match else None


def has_annotation(annotations: str, kind: str) -> bool:
    return bool(re.search(rf"@(?:[\w.]+\.)?{re.escape(kind)}\b", annotations))


def annotation_boolean(annotations: str, kind: str, arg: str) -> str | None:
    match = re.search(rf"@{kind}\s*\([^)]*\b{arg}\s*=\s*(true|false)", annotations, re.S)
    return match.group(1) if match else None


def association_kind(field: FieldInfo) -> str | None:
    return next(
        (kind for kind in ("OneToOne", "OneToMany", "ManyToOne", "ManyToMany") if has_annotation(field.annotations, kind)),
        None,
    )


def mapped_by(field: FieldInfo) -> str | None:
    match = re.search(r'mappedBy\s*=\s*"([^"]+)"', field.annotations)
    return match.group(1) if match else None


def attribute_override(info: ClassInfo, field: FieldInfo) -> tuple[str | None, str | None] | None:
    match = re.search(
        rf'@AttributeOverride\s*\(\s*name\s*=\s*"{re.escape(field.name)}"\s*,\s*column\s*=\s*@Column\s*\((.*?)\)\s*\)',
        info.class_annotations,
        re.S,
    )
    if not match:
        return None
    arguments = match.group(1)
    name_match = re.search(r'\bname\s*=\s*"([^"]+)"', arguments)
    nullable_match = re.search(r"\bnullable\s*=\s*(true|false)", arguments)
    return (
        name_match.group(1) if name_match else None,
        nullable_match.group(1) if nullable_match else None,
    )


def relative_link(from_page: Path, to_page: Path, label: str) -> str:
    return f"[{label}]({Path(os.path.relpath(to_page, from_page.parent)).as_posix()})"


def relation(field: FieldInfo, page: Path, pages_by_name: dict[str, Path]) -> str:
    annotations = field.annotations
    for kind, label in (
        ("OneToOne", "1:1"),
        ("OneToMany", "1:N"),
        ("ManyToOne", "N:1"),
        ("ManyToMany", "N:M"),
        ("Embedded", "embedded"),
        ("EmbeddedId", "embedded id"),
        ("ElementCollection", "коллекция значений"),
    ):
        if has_annotation(annotations, kind):
            mapped = mapped_by(field)
            ownership = "; inverse" if mapped else ("; owning" if kind in {"OneToOne", "OneToMany", "ManyToOne", "ManyToMany"} else "")
            value = f"{label}{ownership}; mappedBy={mapped}" if mapped else f"{label}{ownership}"
            targets = [token for token in re.findall(r"\b[A-Z][A-Za-z0-9_]+\b", field.java_type) if token in pages_by_name]
            if targets:
                value += " → " + relative_link(page, pages_by_name[targets[-1]], f"`{targets[-1]}`")
            return value
    return "—"


def storage_category(field: FieldInfo) -> str:
    kind = association_kind(field)
    if has_annotation(field.annotations, "Transient"):
        return "transient"
    if has_annotation(field.annotations, "Formula"):
        return "computed (`@Formula`)"
    if kind and mapped_by(field):
        return "inverse association"
    if kind in {"ManyToOne", "OneToOne"}:
        return "owning association (FK)"
    if kind in {"OneToMany", "ManyToMany"}:
        return "owning association (collection)"
    if has_annotation(field.annotations, "EmbeddedId"):
        return "embedded id"
    if has_annotation(field.annotations, "Embedded"):
        return "embedded"
    if has_annotation(field.annotations, "ElementCollection"):
        return "element collection"
    return "basic column"


def storage(field: FieldInfo, info: ClassInfo) -> str:
    category = storage_category(field)
    annotations = field.annotations
    if category == "transient":
        return "не хранится через JPA"
    if category.startswith("computed"):
        return "SQL-выражение; отдельной колонки поля нет"
    if category == "inverse association":
        return f"нет локальной колонки; owning side: `{mapped_by(field)}`"
    if category in {"embedded", "embedded id"}:
        return "колонки embedded-типа в таблице владельца"
    if category == "element collection":
        table = annotation_name(annotations, "CollectionTable", "name")
        return f"collection table `{table}`" if table else "collection table; имя не задано"
    kind = association_kind(field)
    join = annotation_name(annotations, "JoinColumn", "name")
    if kind in {"ManyToOne", "OneToOne"}:
        return f"`{join}` (FK)" if join else "join column (FK); имя не задано"
    if kind in {"OneToMany", "ManyToMany"}:
        if join:
            return f"`{join}` (FK в таблице целевого типа)"
        join_table = annotation_name(annotations, "JoinTable", "name")
        return f"join table `{join_table}`" if join_table else "join table; имя не задано"
    override = attribute_override(info, field)
    if override and override[0]:
        return f"`{override[0]}` (`@AttributeOverride`)"
    explicit = annotation_name(annotations, "Column", "name")
    return f"`{explicit}`" if explicit else "колонка; имя не задано"


def java_nullability(field: FieldInfo) -> str:
    if field.java_type in {"boolean", "byte", "short", "int", "long", "float", "double", "char"}:
        return "невозможен (`primitive`)"
    if has_annotation(field.annotations, "Nullable"):
        return "разрешён (`@Nullable`)"
    if has_annotation(field.annotations, "NonNull"):
        return "помечен `@NonNull`"
    return "технически возможен (reference)"


def jpa_nullability(field: FieldInfo, info: ClassInfo) -> str:
    category = storage_category(field)
    if category in {"transient", "inverse association", "embedded", "embedded id", "element collection"} or category.startswith("computed"):
        return "не применимо к локальной колонке"
    override = attribute_override(info, field)
    if override and override[1]:
        return f"`nullable = {override[1]}` (`@AttributeOverride`)"
    values: list[str] = []
    for kind in ("Column", "JoinColumn"):
        value = annotation_boolean(field.annotations, kind, "nullable")
        if value:
            values.append(f"`nullable = {value}` (`@{kind}`)")
    kind = association_kind(field)
    if kind:
        optional = annotation_boolean(field.annotations, kind, "optional")
        if optional:
            values.append(f"`optional = {optional}` (`@{kind}`)")
    return "; ".join(values) or "не задано явно"


def bean_validation(field: FieldInfo) -> str:
    values = re.findall(r"@(?:jakarta\.validation\.constraints\.)?(NotNull|NotBlank|NotEmpty|Size|Min|Max)\b(?:\s*\([^)]*\))?", field.annotations, re.S)
    return ", ".join(f"`@{value}`" for value in dict.fromkeys(values)) or "—"


def enum_storage(field: FieldInfo) -> str:
    if "@Enumerated" not in field.annotations:
        return ""
    return "; enum STRING" if "EnumType.STRING" in field.annotations else "; enum ORDINAL/default"


def all_fields(info: ClassInfo, by_name: dict[str, ClassInfo]) -> list[FieldInfo]:
    inherited: list[FieldInfo] = []
    seen: set[str] = set()
    parent_name = info.superclass.split(".")[-1] if info.superclass else None
    while parent_name and parent_name in by_name and parent_name not in seen:
        seen.add(parent_name)
        parent = by_name[parent_name]
        inherited = parent.fields + inherited
        parent_name = parent.superclass.split(".")[-1] if parent.superclass else None
    return inherited + info.fields


def relative_source(page: Path, source: Path) -> str:
    return Path(os.path.relpath(source, page.parent))


def table_display(info: ClassInfo) -> str:
    return f"`{info.table}`" if info.explicit_table else "имя не задано в `@Table`"


def write_page(info: ClassInfo, by_name: dict[str, ClassInfo], page: Path, pages_by_name: dict[str, Path]) -> Path:
    page.parent.mkdir(parents=True, exist_ok=True)
    kind = "JPA-сущность" if info.entity else "mapped superclass"
    description = info.description or f"{('JPA-сущность' if info.entity else 'Наследуемая модель')} предметной области `{info.package.split('.')[-1]}`."
    hierarchy = f"`{info.name}`"
    if info.superclass:
        parent = info.superclass.split(".")[-1]
        parent_label = relative_link(page, pages_by_name[parent], f"`{parent}`") if parent in pages_by_name else f"`{parent}`"
        hierarchy = f"{parent_label} → `{info.name}`"
    lines = [
        f"# `{info.name}`",
        "",
        "> Файл сгенерирован из Java-модели. Бизнес-контекст дополняется вручную; поля, связи и аннотации обновляются генератором.",
        "",
        description,
        "",
        "## Паспорт",
        "",
        f"- **Тип:** {kind}",
        f"- **Java package:** `{info.package}`",
        f"- **Таблица:** {table_display(info) if info.entity else 'собственной таблицы нет'}",
        f"- **Наследование:** {hierarchy}",
        f"- **Интерфейсы:** {', '.join(f'`{x}`' for x in info.interfaces) if info.interfaces else 'нет'}",
        f"- **Исходник:** [{info.path.name}]({relative_source(page, info.path)})",
        "",
        "## Поля и связи",
        "",
        "| Поле | Java-тип | JPA-категория | Колонка / хранение | Java null | JPA nullable/optional | Bean Validation | Связь | Объявлено в | Смысл / default |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    fields = all_fields(info, by_name)
    if not fields:
        lines.append("| — | — | — | — | — | — | — | — | — | Собственных и наследуемых полей не найдено |")
    for item in fields:
        meaning = item.description or "—"
        if item.default:
            meaning = (meaning + "; " if meaning != "—" else "") + f"default: `{item.default}`"
        meaning = meaning.replace("|", "\\|")
        rel = relation(item, page, pages_by_name) + enum_storage(item)
        lines.append(
            f"| `{item.name}` | `{item.java_type}` | {storage_category(item)} | {storage(item, info)} "
            f"| {java_nullability(item)} | {jpa_nullability(item, info)} | {bean_validation(item)} "
            f"| {rel} | `{item.declared_in}` | {meaning} |"
        )
    lines += [
        "",
        "## Аналитические замечания",
        "",
        "- `inverse association` с `mappedBy` не создаёт локальную колонку или join table на этой стороне; хранение задаёт owning side.",
        "- «Имя не задано» означает, что Java-аннотация не фиксирует физическое имя. Его нельзя считать подтверждённым без naming strategy и Liquibase.",
        "- `JPA nullable/optional` отражает только явные параметры аннотаций. Bean Validation и Java primitive показаны отдельно и не подтверждают constraint работающей БД.",
        "- `@Formula` вычисляется SQL-выражением при чтении и не является отдельной физической колонкой поля.",
        "- Итоговые SQL-типы, NULL/DEFAULT, PK/FK, UNIQUE/CHECK и индексы необходимо сверять с полной цепочкой Liquibase или применённой схемой.",
    ]
    if any(has_annotation(x.annotations, "Transient") for x in info.fields):
        lines.append("- Transient-поля участвуют в runtime-логике, но не являются колонками таблицы.")
    if any("deleted" == x.name for x in fields):
        lines.append("- Сущность содержит признак `deleted`; сценарии чтения должны учитывать мягкое удаление.")
    related = {
        "Order": [("Типы заявок", "business-rules/order-types.md"), ("Статусная модель", "business-rules/order-statuses.md"), ("Агрегаты заявок", "entities/orders.md")],
        "TransportOrder": [("Типы заявок", "business-rules/order-types.md"), ("Статусная модель", "business-rules/order-statuses.md"), ("Агрегаты заявок", "entities/orders.md")],
        "ReceivingOrder": [("Правила поставки", "business-rules/receiving-orders.md"), ("Типы заявок", "business-rules/order-types.md"), ("DTO", "dto/receiving-order/ReceivingOrderDto.md"), ("Модель БД", "database/orders.md")],
        "ShippingOrder": [("Правила вывоза", "business-rules/shipping-orders.md"), ("Типы заявок", "business-rules/order-types.md"), ("DTO", "dto/shipping-order/ShippingOrderDto.md"), ("Модель БД", "database/orders.md")],
        "ServiceOrder": [("Правила заявки на услугу", "business-rules/service-orders.md"), ("Типы заявок", "business-rules/order-types.md"), ("DTO", "dto/service-order/ServiceOrderDto.md"), ("Модель БД", "database/orders.md")],
    }.get(info.name, [])
    if related:
        lines += ["", "## Связанные документы", ""]
        for label, target in related:
            absolute = REPO / "docs/docsforanalytics" / target
            lines.append(f"- {relative_link(page, absolute, label)}")
    page.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return page


def main() -> None:
    infos = []
    for root in SOURCE_ROOTS:
        for path in root.rglob("*.java"):
            parsed = parse_class(path)
            if parsed:
                infos.append(parsed)
    by_name = {item.name: item for item in infos}
    name_counts = {name: sum(1 for item in infos if item.name == name) for name in {item.name for item in infos}}
    page_by_info = {
        (item.package, item.name): OUTPUT
        / ("entities" if item.entity else "mapped-superclasses")
        / snake(item.package.split(".")[-1])
        / f"{item.name}.md"
        for item in infos
    }
    pages_by_name = {
        item.name: page_by_info[(item.package, item.name)]
        for item in infos
        if name_counts[item.name] == 1
    }
    pages: list[tuple[ClassInfo, Path]] = []
    for info in sorted(infos, key=lambda x: (not x.entity, x.package, x.name)):
        page = page_by_info[(info.package, info.name)]
        pages.append((info, write_page(info, by_name, page, pages_by_name)))

    index = [
        "# Полный каталог JPA-модели",
        "",
        "> Каталог сгенерирован из Java-кода. Запуск: `python3 docs/docsforanalytics/scripts/generate_entity_docs.py`.",
        "",
        f"Всего: **{sum(i.entity for i, _ in pages)} сущностей** и **{sum(i.mapped_superclass for i, _ in pages)} mapped superclass**.",
        "",
        "Для проектирования используйте технический паспорт вместе с [картой предметных областей](../README.md) и [бизнес-правилами](../../business-rules/README.md). Связи между сущностями в таблицах полей кликабельны.",
        "Категория хранения строится только по Java-аннотациям: basic column, owning/inverse association, embedded, element collection, transient или computed `@Formula`. Если `@Column`, `@JoinColumn`, `@JoinTable` либо `@CollectionTable` не задаёт имя явно, каталог не подставляет предполагаемое физическое имя.",
        "",
        "## Сущности с физическим хранением",
        "",
        "| Сущность | Таблица | Package | Полей с учётом наследования |",
        "|---|---|---|---:|",
    ]
    for info, page in pages:
        if not info.entity:
            continue
        link = page.relative_to(OUTPUT).as_posix()
        table = table_display(info)
        index.append(f"| [`{info.name}`]({link}) | {table} | `{info.package}` | {len(all_fields(info, by_name))} |")
    index += ["", "## Наследуемые модели без собственной таблицы", "", "| Класс | Package | Полей с учётом наследования |", "|---|---|---:|"]
    for info, page in pages:
        if not info.mapped_superclass:
            continue
        link = page.relative_to(OUTPUT).as_posix()
        index.append(f"| [`{info.name}`]({link}) | `{info.package}` | {len(all_fields(info, by_name))} |")
    (OUTPUT / "README.md").write_text("\n".join(index) + "\n", encoding="utf-8")
    print(f"Generated {len(pages)} pages: {sum(i.entity for i, _ in pages)} entities, {sum(i.mapped_superclass for i, _ in pages)} mapped superclasses")


if __name__ == "__main__":
    main()
