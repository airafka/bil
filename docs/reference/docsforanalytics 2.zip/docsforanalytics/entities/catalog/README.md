# Полный каталог JPA-модели

> Каталог сгенерирован из Java-кода. Запуск: `python3 docs/docsforanalytics/scripts/generate_entity_docs.py`.

Всего: **113 сущностей** и **11 mapped superclass**.

Для проектирования используйте технический паспорт вместе с [картой предметных областей](../README.md) и [бизнес-правилами](../../business-rules/README.md). Связи между сущностями в таблицах полей кликабельны.
Категория хранения строится только по Java-аннотациям: basic column, owning/inverse association, embedded, element collection, transient или computed `@Formula`. Если `@Column`, `@JoinColumn`, `@JoinTable` либо `@CollectionTable` не задаёт имя явно, каталог не подставляет предполагаемое физическое имя.

## Сущности с физическим хранением

| Сущность | Таблица | Package | Полей с учётом наследования |
|---|---|---|---:|
| [`AdditionalAgreement`](entities/additionalagreement/AdditionalAgreement.md) | `additional_agreement` | `ru.korusconsulting.alis.model.additionalagreement` | 13 |
| [`Batch`](entities/batch/Batch.md) | `BATCH` | `ru.korusconsulting.alis.model.batch` | 14 |
| [`Cargo`](entities/cargo/Cargo.md) | `cargo` | `ru.korusconsulting.alis.model.cargo` | 6 |
| [`CellOccupancy`](entities/cell_occupancy/CellOccupancy.md) | `cell_occupancy` | `ru.korusconsulting.alis.model.cell_occupancy` | 10 |
| [`Client`](entities/client/Client.md) | `client` | `ru.korusconsulting.alis.model.client` | 20 |
| [`ClientDriver`](entities/clientdriver/ClientDriver.md) | `CLIENT_DRIVER` | `ru.korusconsulting.alis.model.clientdriver` | 17 |
| [`ClientGood`](entities/clientgood/ClientGood.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.clientgood` | 25 |
| [`ClientGoodDigitalSign`](entities/clientgooddigitalsign/ClientGoodDigitalSign.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.clientgooddigitalsign` | 12 |
| [`ClientGoodType`](entities/clientgoodtype/ClientGoodType.md) | `CLIENT_GOOD_TYPE` | `ru.korusconsulting.alis.model.clientgoodtype` | 13 |
| [`ClientRelatedEntity`](entities/clientrelatedentity/ClientRelatedEntity.md) | `CLIENT_RELATED_ENTITY` | `ru.korusconsulting.alis.model.clientrelatedentity` | 17 |
| [`ClientUserGroup`](entities/clientusergroup/ClientUserGroup.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.clientusergroup` | 7 |
| [`ClientVehicle`](entities/clientvehicle/ClientVehicle.md) | `CLIENT_VEHICLE` | `ru.korusconsulting.alis.model.clientvehicle` | 17 |
| [`Company`](entities/company/Company.md) | `COMPANY` | `ru.korusconsulting.alis.model.company` | 19 |
| [`Container`](entities/container/Container.md) | `container` | `ru.korusconsulting.alis.model.container` | 20 |
| [`ContainerMovement`](entities/containermovement/ContainerMovement.md) | `container_movement` | `ru.korusconsulting.alis.model.containermovement` | 18 |
| [`ContainerMovementMetaView`](entities/containermovement/ContainerMovementMetaView.md) | `container_movement_meta_view` | `ru.korusconsulting.alis.model.containermovement` | 15 |
| [`ContainerOwner`](entities/containerowner/ContainerOwner.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.containerowner` | 10 |
| [`ContainerOwnerHistory`](entities/containerownerhistory/ContainerOwnerHistory.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.containerownerhistory` | 12 |
| [`ContainerRemain`](entities/containerremain/ContainerRemain.md) | `container_remain` | `ru.korusconsulting.alis.model.containerremain` | 15 |
| [`ContainerRemainLog`](entities/containerremainlog/ContainerRemainLog.md) | `container_remain_log` | `ru.korusconsulting.alis.model.containerremainlog` | 5 |
| [`ContainerRemainLogDetails`](entities/containerremainlogdetails/ContainerRemainLogDetails.md) | `container_remain_log_details` | `ru.korusconsulting.alis.model.containerremainlogdetails` | 4 |
| [`ContainerRemains`](entities/containerremains/ContainerRemains.md) | `container_movement` | `ru.korusconsulting.alis.model.containerremains` | 13 |
| [`ContainerRemainStatus`](entities/containerremainstatus/ContainerRemainStatus.md) | `container_remain_status` | `ru.korusconsulting.alis.model.containerremainstatus` | 2 |
| [`ContainerRemainView`](entities/containerremainview/ContainerRemainView.md) | `container_remain_view` | `ru.korusconsulting.alis.model.containerremainview` | 7 |
| [`ContainerTypeISO`](entities/containertypeiso/ContainerTypeISO.md) | `container_type_iso` | `ru.korusconsulting.alis.model.containertypeiso` | 7 |
| [`Contract`](entities/contract/Contract.md) | `CONTRACT` | `ru.korusconsulting.alis.model.contract` | 17 |
| [`Currency`](entities/currency/Currency.md) | `CURRENCY` | `ru.korusconsulting.alis.model.currency` | 9 |
| [`DangerClass`](entities/dangerclass/DangerClass.md) | `DANGER_CLASS` | `ru.korusconsulting.alis.model.dangerclass` | 9 |
| [`DangerProduct`](entities/dangerproduct/DangerProduct.md) | `DANGER_PRODUCT` | `ru.korusconsulting.alis.model.dangerproduct` | 6 |
| [`InboundEvent`](entities/datareoninbound/InboundEvent.md) | `INBOUND_EVENT` | `ru.korusconsulting.alis.model.datareoninbound` | 15 |
| [`InboundEventConfig`](entities/datareoninbound/InboundEventConfig.md) | `INBOUND_EVENT_CONFIG` | `ru.korusconsulting.alis.model.datareoninbound` | 11 |
| [`EntityInfo`](entities/entityinfo/EntityInfo.md) | `entity_info` | `ru.korusconsulting.alis.model.entityinfo` | 4 |
| [`EtranInvoice`](entities/etran/EtranInvoice.md) | `ETRAN_INVOICE` | `ru.korusconsulting.alis.model.etran` | 16 |
| [`EtsngCode`](entities/etsng/EtsngCode.md) | `etsng_code` | `ru.korusconsulting.alis.model.etsng` | 8 |
| [`FrequencyOfServices`](entities/frequencyofservices/FrequencyOfServices.md) | `FREQUENCY_OF_SERVICES` | `ru.korusconsulting.alis.model.frequencyofservices` | 9 |
| [`GoodGroup`](entities/goodgroup/GoodGroup.md) | `good_group` | `ru.korusconsulting.alis.model.goodgroup` | 9 |
| [`GoodMovement`](entities/goodmovement/GoodMovement.md) | `good_movement` | `ru.korusconsulting.alis.model.goodmovement` | 16 |
| [`GoodPackage`](entities/goodpackage/GoodPackage.md) | `GOOD_PACKAGE` | `ru.korusconsulting.alis.model.goodpackage` | 20 |
| [`GoodPackageBarcode`](entities/goodpackagebarcode/GoodPackageBarcode.md) | `GOOD_PACKAGE_BARCODE` | `ru.korusconsulting.alis.model.goodpackagebarcode` | 9 |
| [`GoodRemain`](entities/goodremains/GoodRemain.md) | `good_remain` | `ru.korusconsulting.alis.model.goodremains` | 17 |
| [`GoodRemainLog`](entities/goodremains/GoodRemainLog.md) | `good_remain_log` | `ru.korusconsulting.alis.model.goodremains` | 5 |
| [`GoodRemainLogDetails`](entities/goodremains/GoodRemainLogDetails.md) | `good_remain_log_details` | `ru.korusconsulting.alis.model.goodremains` | 4 |
| [`GoodRemainView`](entities/goodremains/GoodRemainView.md) | `good_remain_view` | `ru.korusconsulting.alis.model.goodremains` | 13 |
| [`ZoneStatusCatalog`](entities/goodremains/ZoneStatusCatalog.md) | `zone_status_catalog` | `ru.korusconsulting.alis.model.goodremains` | 2 |
| [`GoodType`](entities/goodtype/GoodType.md) | `GOOD_TYPE` | `ru.korusconsulting.alis.model.goodtype` | 9 |
| [`LoadingType`](entities/loadingtype/LoadingType.md) | `LOADING_TYPE` | `ru.korusconsulting.alis.model.loadingtype` | 9 |
| [`OutboundData`](entities/outbounddata/OutboundData.md) | `outbound_data` | `ru.korusconsulting.alis.model.outbounddata` | 14 |
| [`Payer`](entities/payer/Payer.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.payer` | 3 |
| [`ProductType`](entities/producttype/ProductType.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.producttype` | 6 |
| [`RailwayCarriage`](entities/railway/RailwayCarriage.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.railway` | 22 |
| [`RailwayCarriageModel`](entities/railway/RailwayCarriageModel.md) | `RAILWAY_CARRIAGE_MODEL` | `ru.korusconsulting.alis.model.railway` | 7 |
| [`RailwayCarriageType`](entities/railway/RailwayCarriageType.md) | `RAILWAY_CARRIAGE_TYPE` | `ru.korusconsulting.alis.model.railway` | 8 |
| [`RailwayStation`](entities/railway/RailwayStation.md) | `RAILWAY_STATION` | `ru.korusconsulting.alis.model.railway` | 9 |
| [`RailwayCarriageRemain`](entities/railwaycarriageremain/RailwayCarriageRemain.md) | `railway_carriage_remain` | `ru.korusconsulting.alis.model.railwaycarriageremain` | 10 |
| [`RailwayCarriageRemainLog`](entities/railwaycarriageremainlog/RailwayCarriageRemainLog.md) | `railway_carriage_remain_log` | `ru.korusconsulting.alis.model.railwaycarriageremainlog` | 5 |
| [`RailwayCarriageRemainLogDetails`](entities/railwaycarriageremainlogdetails/RailwayCarriageRemainLogDetails.md) | `railway_carriage_remain_log_details` | `ru.korusconsulting.alis.model.railwaycarriageremainlogdetails` | 4 |
| [`RailwayCarriageRemainView`](entities/railwaycarriageremainview/RailwayCarriageRemainView.md) | `railway_carriage_remain_view` | `ru.korusconsulting.alis.model.railwaycarriageremainview` | 3 |
| [`ReceivingOrder`](entities/receivingorder/ReceivingOrder.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.receivingorder` | 39 |
| [`ReceivingOrderBlackbox`](entities/receivingorderblackbox/ReceivingOrderBlackbox.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.receivingorderblackbox` | 8 |
| [`ReceivingOrderCargo`](entities/receivingordercargo/ReceivingOrderCargo.md) | `RECEIVING_ORDER_CARGO` | `ru.korusconsulting.alis.model.receivingordercargo` | 19 |
| [`ReceivingOrderContainer`](entities/receivingordercontainer/ReceivingOrderContainer.md) | `RECEIVING_ORDER_CONTAINER` | `ru.korusconsulting.alis.model.receivingordercontainer` | 18 |
| [`ReceivingOrderContainerItem`](entities/receivingordercontainer/ReceivingOrderContainerItem.md) | `RECEIVING_ORDER_CONTAINER_ITEM` | `ru.korusconsulting.alis.model.receivingordercontainer` | 14 |
| [`ReceivingOrderGood`](entities/receivingordergood/ReceivingOrderGood.md) | `RECEIVING_ORDER_GOOD` | `ru.korusconsulting.alis.model.receivingordergood` | 14 |
| [`ReceivingOrderRequestedService`](entities/receivingorderrequestedservice/ReceivingOrderRequestedService.md) | `RECEIVING_ORDER_REQUESTED_SERVICE` | `ru.korusconsulting.alis.model.receivingorderrequestedservice` | 15 |
| [`RelatedService`](entities/relatedservice/RelatedService.md) | `related_service` | `ru.korusconsulting.alis.model.relatedservice` | 7 |
| [`Route`](entities/route/Route.md) | `ROUTE` | `ru.korusconsulting.alis.model.route` | 16 |
| [`ShippingRouteAutoFactContainerView`](entities/route/ShippingRouteAutoFactContainerView.md) | `shipping_route_auto_fact_container_view` | `ru.korusconsulting.alis.model.route` | 7 |
| [`ShippingRouteContainerView`](entities/route/ShippingRouteContainerView.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.route` | 8 |
| [`ShippingRouteFactContainerView`](entities/route/ShippingRouteFactContainerView.md) | `shipping_route_fact_container_view` | `ru.korusconsulting.alis.model.route` | 7 |
| [`ShippingRouteRailwayCarriageView`](entities/route/ShippingRouteRailwayCarriageView.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.route` | 7 |
| [`SealType`](entities/sealtype/SealType.md) | `SEAL_TYPE` | `ru.korusconsulting.alis.model.sealtype` | 8 |
| [`Service`](entities/service/Service.md) | `SERVICE` | `ru.korusconsulting.alis.model.service` | 20 |
| [`ServiceOrder`](entities/serviceorder/ServiceOrder.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.serviceorder` | 11 |
| [`ServiceOrderContainer`](entities/serviceordercontainer/ServiceOrderContainer.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.serviceordercontainer` | 7 |
| [`ShippingOrder`](entities/shippingorder/ShippingOrder.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.shippingorder` | 32 |
| [`ShippingOrderBlackbox`](entities/shippingorderblackbox/ShippingOrderBlackbox.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.shippingorderblackbox` | 8 |
| [`ShippingOrderCargo`](entities/shippingordercargo/ShippingOrderCargo.md) | `SHIPPING_ORDER_CARGO` | `ru.korusconsulting.alis.model.shippingordercargo` | 21 |
| [`ShippingOrderContainer`](entities/shippingordercontainer/ShippingOrderContainer.md) | `SHIPPING_ORDER_CONTAINER` | `ru.korusconsulting.alis.model.shippingordercontainer` | 23 |
| [`ShippingOrderContainerItem`](entities/shippingordercontainer/ShippingOrderContainerItem.md) | `SHIPPING_ORDER_CONTAINER_ITEM` | `ru.korusconsulting.alis.model.shippingordercontainer` | 14 |
| [`ShippingOrderContainerQty`](entities/shippingordercontainerqty/ShippingOrderContainerQty.md) | `shipping_order_container_qty` | `ru.korusconsulting.alis.model.shippingordercontainerqty` | 5 |
| [`ShippingOrderEtranInvoice`](entities/shippingorderetraninvoice/ShippingOrderEtranInvoice.md) | `SHIPPING_ORDER_ETRAN_INVOICE` | `ru.korusconsulting.alis.model.shippingorderetraninvoice` | 8 |
| [`ShippingOrderEtsngCode`](entities/shippingorderetsngcode/ShippingOrderEtsngCode.md) | `shipping_order_etsng_code` | `ru.korusconsulting.alis.model.shippingorderetsngcode` | 4 |
| [`ShippingOrderGood`](entities/shippingordergood/ShippingOrderGood.md) | `SHIPPING_ORDER_GOOD` | `ru.korusconsulting.alis.model.shippingordergood` | 14 |
| [`ShippingOrderRailwayCarriage`](entities/shippingorderrailwaycarriage/ShippingOrderRailwayCarriage.md) | `SHIPPING_ORDER_RAILWAY_CARRIAGE` | `ru.korusconsulting.alis.model.shippingorderrailwaycarriage` | 15 |
| [`ShippingOrderRailwayCarriageQty`](entities/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQty.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.shippingorderrailwaycarriageqty` | 4 |
| [`ShippingOrderRequestedService`](entities/shippingorderrequestedservice/ShippingOrderRequestedService.md) | `SHIPPING_ORDER_REQUESTED_SERVICE` | `ru.korusconsulting.alis.model.shippingorderrequestedservice` | 15 |
| [`StandardSize`](entities/standardsize/StandardSize.md) | `STANDARD_SIZE` | `ru.korusconsulting.alis.model.standardsize` | 7 |
| [`TempRegime`](entities/tempregime/TempRegime.md) | `TEMP_REGIME` | `ru.korusconsulting.alis.model.tempregime` | 9 |
| [`TerminalArea`](entities/terminalarea/TerminalArea.md) | `terminal_area_catalog` | `ru.korusconsulting.alis.model.terminalarea` | 8 |
| [`TermOfPeriodicService`](entities/termofperiodicservice/TermOfPeriodicService.md) | `TERM_OF_PERIODIC_SERVICE` | `ru.korusconsulting.alis.model.termofperiodicservice` | 11 |
| [`TermOfRequestedService`](entities/termofrequestedservice/TermOfRequestedService.md) | `TERM_OF_REQUESTED_SERVICE` | `ru.korusconsulting.alis.model.termofrequestedservice` | 13 |
| [`TermOfService`](entities/termofservice/TermOfService.md) | `TERM_OF_SERVICE` | `ru.korusconsulting.alis.model.termofservice` | 13 |
| [`TransportPackage`](entities/transportpackage/TransportPackage.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.transportpackage` | 7 |
| [`UnitOfMeasure`](entities/unitofmeasure/UnitOfMeasure.md) | `UNIT_OF_MEASURE` | `ru.korusconsulting.alis.model.unitofmeasure` | 10 |
| [`UserSetting`](entities/usersetting/UserSetting.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.usersetting` | 6 |
| [`VehicleBrand`](entities/vehiclebrand/VehicleBrand.md) | `VEHICLE_BRAND` | `ru.korusconsulting.alis.model.vehiclebrand` | 9 |
| [`VehicleType`](entities/vehicletype/VehicleType.md) | `VEHICLE_TYPE` | `ru.korusconsulting.alis.model.vehicletype` | 9 |
| [`Waybill`](entities/waybill/Waybill.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybill` | 41 |
| [`WaybillView`](entities/waybill/WaybillView.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybill` | 19 |
| [`WaybillContainer`](entities/waybillcontainer/WaybillContainer.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybillcontainer` | 14 |
| [`WaybillProduct`](entities/waybillproduct/WaybillProduct.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybillproduct` | 26 |
| [`WaybillRailwayCarriage`](entities/waybillrailwaycarriage/WaybillRailwayCarriage.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybillrailwaycarriage` | 14 |
| [`WaybillSpecialMark`](entities/waybillspecialmark/WaybillSpecialMark.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybillspecialmark` | 6 |
| [`WaybillTariffMark`](entities/waybilltariffmark/WaybillTariffMark.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybilltariffmark` | 7 |
| [`WaybillZpu`](entities/waybillzpu/WaybillZpu.md) | имя не задано в `@Table` | `ru.korusconsulting.alis.model.waybillzpu` | 6 |
| [`Dictionary`](entities/dictionary/Dictionary.md) | `DICTIONARY` | `ru.korusconsulting.wms.model.dictionary` | 9 |
| [`DictionaryLine`](entities/dictionary/DictionaryLine.md) | `DICTIONARY_LINE` | `ru.korusconsulting.wms.model.dictionary` | 10 |
| [`DictionaryLineParameter`](entities/dictionary/DictionaryLineParameter.md) | `DICTIONARY_LINE_PARAMETER` | `ru.korusconsulting.wms.model.dictionary` | 8 |
| [`DictionaryParameter`](entities/dictionary/DictionaryParameter.md) | `DICTIONARY_PARAMETER` | `ru.korusconsulting.wms.model.dictionary` | 10 |
| [`PermissionPath`](entities/permission/PermissionPath.md) | `PERMISSION_PATH` | `ru.korusconsulting.wms.model.permission` | 3 |
| [`RolePermission`](entities/permission/RolePermission.md) | `ROLE_PERMISSION` | `ru.korusconsulting.wms.model.permission` | 8 |
| [`UnitOfMeasure`](entities/uom/UnitOfMeasure.md) | `UNIT_OF_MEASURE` | `ru.korusconsulting.wms.model.uom` | 9 |
| [`UnitOfMeasureConversion`](entities/uom/UnitOfMeasureConversion.md) | `UNIT_OF_MEASURE_CONVERSION` | `ru.korusconsulting.wms.model.uom` | 5 |

## Наследуемые модели без собственной таблицы

| Класс | Package | Полей с учётом наследования |
|---|---|---:|
| [`Order`](mapped-superclasses/order/Order.md) | `ru.korusconsulting.alis.model.order` | 7 |
| [`TransportOrder`](mapped-superclasses/order/TransportOrder.md) | `ru.korusconsulting.alis.model.order` | 10 |
| [`BaseCreatable`](mapped-superclasses/base/BaseCreatable.md) | `ru.korusconsulting.wms.model.base` | 3 |
| [`BaseEditable`](mapped-superclasses/base/BaseEditable.md) | `ru.korusconsulting.wms.model.base` | 5 |
| [`BaseIdActiveCode`](mapped-superclasses/base/BaseIdActiveCode.md) | `ru.korusconsulting.wms.model.base` | 7 |
| [`BaseIdCode`](mapped-superclasses/base/BaseIdCode.md) | `ru.korusconsulting.wms.model.base` | 6 |
| [`BaseIdentifier`](mapped-superclasses/base/BaseIdentifier.md) | `ru.korusconsulting.wms.model.base` | 1 |
| [`BaseNamed`](mapped-superclasses/base/BaseNamed.md) | `ru.korusconsulting.wms.model.base` | 8 |
| [`PrioritizedWithId`](mapped-superclasses/base/PrioritizedWithId.md) | `ru.korusconsulting.wms.model.base` | 7 |
| [`Sequential`](mapped-superclasses/base/Sequential.md) | `ru.korusconsulting.wms.model.base` | 6 |
| [`BaseUnitOfMeasure`](mapped-superclasses/uom/BaseUnitOfMeasure.md) | `ru.korusconsulting.wms.model.uom` | 9 |
