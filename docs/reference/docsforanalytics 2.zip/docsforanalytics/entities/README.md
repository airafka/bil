# Карта сущностей

Технические паспорта всех классов находятся в [полном каталоге JPA-модели](catalog/README.md): 114 сущностей и 11 `@MappedSuperclass`, каждый класс — в отдельном файле со всеми собственными и наследуемыми полями.

В таблицах паспортов отдельно показаны:

- `basic column` — обычное persistent-поле;
- `owning association (FK)` — сторона отношения, содержащая join column;
- `inverse association` — обратная сторона с `mappedBy`, которая не создаёт локальную колонку;
- `embedded` — поля встраиваемого типа в таблице владельца;
- `transient` — поле, не сохраняемое через JPA;
- `computed (@Formula)` — значение SQL-выражения при чтении, а не отдельная колонка.

Физическое имя указывается только при явном `@Table`, `@Column`, `@JoinColumn`, `@JoinTable`, `@CollectionTable` или `@AttributeOverride`. Пометка «имя не задано» требует отдельной сверки с naming strategy и Liquibase.

## Предметные области

| Область | Основные сущности | Назначение |
|---|---|---|
| Заявки | `ReceivingOrder`, `ShippingOrder`, `ServiceOrder` | Поставка, вывоз и отдельные операции с контейнерами |
| Груз и номенклатура | `ClientGood`, `Batch`, `Cargo`, `GoodPackage`, `GoodPackageBarcode`, `GoodGroup` | Описание товара, партий и грузовых мест |
| Контейнеры | `Container`, `ContainerMovement`, `ContainerOwner`, `ContainerRemain*` | Справочник КТК, движения, владение и остатки |
| Железная дорога | `RailwayCarriage`, `RailwayCarriageType`, `RailwayCarriageModel`, `RailwayStation`, `RailwayCarriageRemain*` | Вагоны, станции и остатки |
| Накладные | `Waybill` и `Waybill*` | Накладная, вагоны, контейнеры, товары, ЗПУ и отметки |
| Клиенты и договоры | `Client`, `Contract`, `ClientRelatedEntity`, `ClientDriver`, `ClientVehicle` | Участники, договорные и транспортные данные |
| Маршруты | `Route` и `ShippingRoute*View` | Группировка заявок в рейсы и представления факта |
| Тарификация и услуги | `Service`, `TermOfService`, `TermOfRequestedService`, `RelatedService` | Условия и стоимость операций |
| Интеграции | `InboundEvent`, `InboundEventConfig`, `OutboundData`, `EtranInvoice` | Входящие события и очередь исходящих сообщений |
| Справочники | `Currency`, `TerminalArea`, `UnitOfMeasure`, `DangerClass` и другие | Нормализованные значения предметной области |
| Доступ и настройки | `PermissionPath`, `RolePermission`, `UserSetting` | Права и пользовательская конфигурация |

## Сводный реестр JPA-сущностей ALIS

Реестр построен по классам с `@Entity` в `db-layer`. Имя таблицы в generated-паспорте указывается только при наличии `@Table`; иначе отображается «имя не задано в `@Table`», а физическое имя требуется сверять с настройкой именования Hibernate и миграциями.

| Группа | Сущности |
|---|---|
| Заявки на поставку | `ReceivingOrder`, `ReceivingOrderBlackbox`, `ReceivingOrderCargo`, `ReceivingOrderContainer`, `ReceivingOrderContainerItem`, `ReceivingOrderGood`, `ReceivingOrderRequestedService`, `ReceivingOrderTransport` |
| Заявки на вывоз | `ShippingOrder`, `ShippingOrderBlackbox`, `ShippingOrderCargo`, `ShippingOrderContainer`, `ShippingOrderContainerItem`, `ShippingOrderContainerQty`, `ShippingOrderEtranInvoice`, `ShippingOrderEtsngCode`, `ShippingOrderGood`, `ShippingOrderRailwayCarriage`, `ShippingOrderRailwayCarriageQty`, `ShippingOrderRequestedService`, `ShippingOrderTransport` |
| Заявки на услуги | `ServiceOrder`, `ServiceOrderContainer` |
| Накладные | `Waybill`, `WaybillContainer`, `WaybillProduct`, `WaybillRailwayCarriage`, `WaybillSpecialMark`, `WaybillTariffMark`, `WaybillZpu`, `GroupedWaybillView` |
| Товар | `Batch`, `Cargo`, `ClientGood`, `ClientGoodDigitalSign`, `ClientGoodType`, `GoodGroup`, `GoodMovement`, `GoodPackage`, `GoodPackageBarcode`, `GoodRemain`, `GoodRemainLog`, `GoodRemainLogDetails`, `GoodRemainView`, `ZoneStatusCatalog` |
| Контейнеры | `Container`, `ContainerMovement`, `ContainerOwner`, `ContainerOwnerHistory`, `ContainerRemain`, `ContainerRemainLog`, `ContainerRemainLogDetails`, `ContainerRemainStatus`, `ContainerRemainView`, `ContainerRemains`, `ContainerTypeISO` |
| Железная дорога | `RailwayCarriage`, `RailwayCarriageModel`, `RailwayCarriageType`, `RailwayStation`, `RailwayCarriageRemain`, `RailwayCarriageRemainLog`, `RailwayCarriageRemainLogDetails`, `RailwayCarriageRemainView` |
| Клиенты | `Client`, `ClientDriver`, `ClientRelatedEntity`, `ClientUserGroup`, `ClientVehicle`, `Company` |
| Договоры и услуги | `AdditionalAgreement`, `Contract`, `FrequencyOfServices`, `RelatedService`, `Service`, `TermOfPeriodicService`, `TermOfRequestedService`, `TermOfService` |
| Маршруты | `Route`, `ShippingRouteAutoFactContainerView`, `ShippingRouteContainerView`, `ShippingRouteFactContainerView`, `ShippingRouteRailwayCarriageView` |
| Интеграции | `EtranInvoice`, `InboundEvent`, `InboundEventConfig`, `OutboundData` |
| Справочники и прочее | `CellOccupancy`, `Currency`, `DangerClass`, `DangerProduct`, `EntityInfo`, `EtsngCode`, `GoodType`, `LoadingType`, `Payer`, `ProductType`, `SealType`, `StandardSize`, `TempRegime`, `TerminalArea`, `TransportPackage`, `UnitOfMeasure`, `UserSetting`, `VehicleBrand`, `VehicleType` |

`@MappedSuperclass` (`Order`, `TransportOrder`, базовые audit-классы) не является самостоятельной таблицей; такие классы отдельно перечислены в [техническом каталоге](catalog/README.md#наследуемые-модели-без-собственной-таблицы).

## Правило дальнейшей детализации

Для каждого агрегата создаётся отдельный файл: назначение, владелец данных, жизненный цикл, инварианты, связи, API, интеграции, права и вопросы. Начальная реализация для заявок: [orders.md](orders.md).
