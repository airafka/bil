# Сущности заявок

Связанные разделы: [типы заявок](../business-rules/order-types.md), [статусы](../business-rules/order-statuses.md), [DTO](../dto/README.md), [модель БД](../database/orders.md).

## Общая модель

`Order` — абстрактная основа всех заявок. Она добавляет автоматически генерируемый неизменяемый `number` и неизменяемую после создания ссылку на `client`. `TransportOrder` расширяет её полями `orderStatus`, `terminalArea` и `transportType`.

```text
BaseEditable
└── Order
    ├── ServiceOrder
    └── TransportOrder
        ├── ReceivingOrder
        └── ShippingOrder
```

Все заявки наследуют `id`, `createdAt`, `createdBy`, `updatedAt`, `updatedBy`. Это технические audit-поля, а не самостоятельные бизнес-атрибуты.

## ReceivingOrder — заявка на поставку

Полные правила специализации: [business-rules/receiving-orders.md](../business-rules/receiving-orders.md). Технический паспорт: [ReceivingOrder](catalog/entities/receivingorder/ReceivingOrder.md).

Назначение: планирование поступления груза на терминал. Основные данные: договор, валюта, площадка и транспорт, плановая/фактическая дата, вид поставки, маршрут, грузоотправитель, накладная и агрегированные показатели.

Состав агрегата:

- товары — `ReceivingOrderGood`;
- грузовые места — `ReceivingOrderCargo` и `ReceivingOrderBlackbox`;
- контейнеры и их состав — `ReceivingOrderContainer`, `ReceivingOrderContainerItem`;
- автомобиль и водитель — `ReceivingOrderTransport` (shared primary key с заявкой);
- дополнительные операции — `ReceivingOrderRequestedService`;
- накладные — `Waybill.receivingOrder`, через них вагоны, контейнеры и товары.

Особенности: `documentConfirmed` — трёхзначный признак (`null` не обработан, `true` подтверждён, `false` отклонён); `ktkNumberUnknown` отмечает отсутствие известного номера КТК; поля плательщика и станций относятся к контейнерной площадке и ЖД.

## ShippingOrder — заявка на вывоз

Полные правила специализации: [business-rules/shipping-orders.md](../business-rules/shipping-orders.md). Технический паспорт: [ShippingOrder](catalog/entities/shippingorder/ShippingOrder.md).

Назначение: планирование вывоза груза с терминала. Помимо общих полей хранит договор, валюту, плановую/фактическую дату, грузополучателя и адрес, вид вывоза и `fillingType`.

Состав агрегата:

- товары — `ShippingOrderGood`;
- грузовые места — `ShippingOrderCargo` и `ShippingOrderBlackbox`;
- контейнеры и их состав — `ShippingOrderContainer`, `ShippingOrderContainerItem`;
- вагоны и количественные строки — `ShippingOrderRailwayCarriage`, `ShippingOrderRailwayCarriageQty`;
- количественные строки контейнеров — `ShippingOrderContainerQty`;
- транспорт — `ShippingOrderTransport`;
- услуги и ЭТРАН — `ShippingOrderRequestedService`, `ShippingOrderEtranInvoice`, `ShippingOrderEtsngCode`.

`fillingType`: `ALL` — известны вагоны и КТК; `RAILWAY_CARRIAGE` — только вагоны; `CONTAINER` — только КТК; `NONE` — оба номера неизвестны; `NONE_CONTAINER` — без номера КТК. Последний вариант допустим только для `CONTAINER + VEHICLE`.

## ServiceOrder — заявка на услугу

Полные правила специализации: [business-rules/service-orders.md](../business-rules/service-orders.md). Технический паспорт: [ServiceOrder](catalog/entities/serviceorder/ServiceOrder.md).

Назначение: выполнить отдельную операцию над контейнерами. Сейчас тип услуги один — `CHANGE_OWNER`. Заявка содержит клиента, услугу, комментарий, статус и время выполнения; контейнеры связаны через `ServiceOrderContainer`.

## Общие инварианты

- ЖД-транспорт разрешён только для контейнерной площадки.
- Для складской площадки и автомобиля обязателен `deliveryType`.
- При создании транспортной заявки переданный клиентом статус игнорируется: сервис устанавливает `DRAFT`.
- Номер создаётся механизмом `EntitySequence(ORDER)` и не изменяется.
- Ссылки на клиента, площадку и вид транспорта помечены как неизменяемые на уровне JPA.
