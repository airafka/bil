# Реестр экранов ALIS

Реестр показывает, какие пользовательские экраны уже подтверждены снимками, с какими бизнес-объектами и backend-контурами они предположительно связаны и что ещё нужно получить для полной трассировки. Наличие одноимённого endpoint не доказывает, что именно его вызывает frontend.

## Источники снимков

| Код | Файл | SHA-256 | Содержание | Доказательность |
|---|---|---|---|---|
| `UI-SNAPSHOT-001` | `/Users/ilnur/Downloads/докум.docx` | `4d8a322894d178471765a16f3f3f23ba4742abeba1112a4c9c3d7343dee97d14` | Меню и экран групп пользователей | `EXTERNAL_SNAPSHOT` |
| `UI-SNAPSHOT-002` | `/Users/ilnur/Downloads/ckfql.docx` | `d0896ae57cd040b078b3434250bb22f74506064896c5a9392327a2beb9b5329b` | Реестры заявок, настройка столбцов, клиенты, отчёт остатков КТК, карточки поставки и рейса | `EXTERNAL_SNAPSHOT` |

Отдельным проектным источником служит [ALIS Design System](design-system/README.md) в Figma. Она подтверждает состав спроектированных компонентов и визуальных состояний, но не заменяет снимок работающего экрана, frontend source или network trace.

Второй Figma-файл — [«Заявки на поставку»](figma/receiving-orders.md) — содержит сценарные макеты для трёх допустимых комбинаций площадки/транспорта, четырёх складских видов поставки, статусных ошибок и накладных ЭТРАН. Он также является `EXTERNAL_SNAPSHOT` проектного намерения, а не runtime-доказательством.

Оба файла созданы 22.09.2026. Стенд, URL, роль пользователя и версии frontend/backend не установлены. Значения конкретных организаций, ФИО, телефонов, государственных номеров и контейнеров не переносятся в библиотеку: они не нужны для описания интерфейса и могут содержать чувствительные рабочие данные.

## Реестр

| Экран | Путь меню | Бизнес-объект | Кандидатный backend-контур | Снимок | Паспорт | Приоритет |
|---|---|---|---|---|---|---|
| Заявки на поставку | Заявки → Заявки на поставку | `ReceivingOrder` | `/receivingorder`, `ReceivingOrderDto` | Есть | [Реестры заявок](screens/order-lists.md) | Высокий |
| Заявки на вывоз | Заявки → Заявки на вывоз | `ShippingOrder` | `/shippingorder`, `ShippingOrderDto` | Есть | [Реестры заявок](screens/order-lists.md) | Высокий |
| Форма заявки на вывоз | Из реестра вывоза | `ShippingOrder` и 12 дочерних моделей | root, good/cargo/blackbox/transport, container/wagon/ETRAN/qty API | Нет | [Создание и редактирование](screens/shipping-order-create-edit.md) | Высокий |
| Форма заявки на услугу | Предполагаемый реестр сервисных заявок | `ServiceOrder`, выбранные КТК и владельцы | `/service-order`, scoped `/container`, accept | Нет | [Создание, выбор КТК и выполнение](screens/service-order-create-edit.md) | Высокий |
| Карточка заявки на поставку | Из реестра поставок | `ReceivingOrder` и дочерние данные | `/receivingorder/{id}`, дочерние container/good/cargo/transport/Waybill API | Есть | [Карточка](screens/receiving-order-card.md), [вкладки и действия](screens/receiving-order-tabs-and-actions.md), [создание и редактирование](screens/receiving-order-create-edit.md) | Высокий |
| Рейс | Справочники → Рейсы | `Route`, заявки и shipping plan/fact | `/routes/{id}`, orders/assign/status/plan/fact/report API | Есть | [Карточка](screens/route-card.md), [секции и действия](screens/route-tabs-and-actions.md) | Высокий |
| Клиенты | Справочники → Контрагенты → Клиенты | `Client` | `/client`, `ClientDto` | Есть | [Клиенты](screens/clients.md) | Средний |
| Остатки контейнеров | Отчёты → Остатки контейнеров | Аналитическая проекция остатков КТК | Superset dataset/dashboard; точный источник не установлен | Есть | [Отчёт остатков](screens/container-remains-report.md) | Высокий |
| Группы пользователей | Настройки → Группы пользователей | Keycloak group + роли + client scope | UserGroup API, точный request не установлен | Есть | [Группы пользователей](screens/user-groups.md) | Высокий |
| Настройка столбцов | Действие в табличных реестрах | Пользовательское представление таблицы | Возможна локальная либо серверная настройка | Есть | [Общее поведение таблиц](screens/order-lists.md#настройка-таблицы) | Средний |
| Заявки на услуги | Заявки → Заявки на услуги | `ServiceOrder` | `/serviceorder` | Нет | Нет | Высокий |
| Накладные | Заявки → Накладные | Предположительно `Waybill` / ЭТРАН | Waybill API | Нет | Нет | Высокий |
| Пользователи | Настройки → Пользователи | User / Keycloak identity | User API | Нет | Нет | Средний |
| Роли | Настройки → Роли | Role / permission | Role API | Нет | Нет | Средний |
| Номенклатуры | Справочники → Номенклатуры | Предположительно `ClientGood` | `/clientgood` | Нет | Нет | Средний |
| КТК | Справочники → КТК | `Container` | Container API | Нет | Нет | Средний |
| Вагоны | Справочники → Вагоны | `RailwayCarriage` | Railway carriage API | Нет | Нет | Средний |
| Транспортные средства | Справочники → Транспортные средства | `ClientVehicle` | `/clientvehicle` | Нет | Нет | Средний |
| Водители | Справочники → Водители | `ClientDriver` | `/clientdriver` | Нет | Нет | Средний |

## Карта подтверждения

```mermaid
flowchart LR
    SNAP[Скриншот] --> VISIBLE[Подписи, поля и состояние]
    SOURCE[Backend source] --> CONTRACT[Endpoint, DTO, permission и правило]
    FRONT[Frontend source] --> REQUEST[Route, component и request]
    TRACE[Network trace] --> ACTUAL[Фактический вызов на стенде]
    VISIBLE --> PASSPORT[Паспорт экрана]
    CONTRACT --> PASSPORT
    REQUEST --> PASSPORT
    ACTUAL --> PASSPORT
```

Сейчас для новых экранов доступны первые два входа. Поэтому UI-поле можно сопоставить с полем DTO по смыслу и типу, но весь маршрут `экран → frontend request → endpoint` помечается `INFERENCE`.

## Следующие материалы

1. ~~frontend repository~~ — получен 01.10.2026, актуализирован 07.10.2026 (commit `971288126`), UI-правила заявок, рейсов, справочников, администрирования и накладных — 14.10.2026 (commit `ab02fa985`); для заявок на поставку, вывоз и услугу правила и запросы сведены в [UI-правила заявок](../business-rules/order-ui-rules-as-is.md), остальные экраны ещё не сверены;
2. HAR/network trace открытия списка, карточки, вкладок и выполнения действий;
3. роль пользователя и client scope для каждого снимка;
4. снимки форм создания/редактирования, меню строки и ошибок;
5. идентификатор Superset dashboard, dataset и правила row-level security.
