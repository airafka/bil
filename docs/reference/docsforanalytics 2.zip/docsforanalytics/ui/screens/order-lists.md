# Реестры заявок на поставку и вывоз

Экраны дают пользователю операционный список заявок, переход к карточке, создание новой заявки, сортировку, постраничный просмотр и настройку состава таблицы. Снимки подтверждают внешний вид и показанные значения; точные frontend routes и HTTP-вызовы не предоставлены.

## Паспорт

| Атрибут | Поставка | Вывоз |
|---|---|---|
| Путь меню | Заявки → Заявки на поставку | Заявки → Заявки на вывоз |
| UI-основание | `UI-SNAPSHOT-002`, 22.09.2026 | `UI-SNAPSHOT-002`, 22.09.2026 |
| Бизнес-объект | `ReceivingOrder` | `ShippingOrder` |
| Список | `POST /receivingorder/page` | `POST /shippingorder/page` |
| Response DTO | [ReceivingOrderDto](../../dto/catalog/receivingorder/ReceivingOrderDto.md) | [ShippingOrderDto](../../dto/catalog/shippingorder/ShippingOrderDto.md) |
| Permission backend | `RECEIVING_ORDER:READ` | `SHIPPING_ORDER:READ` |
| Frontend route | `/receiving-orders` (`SOURCE_CONFIRMED`) | `/shipping-orders` (`SOURCE_CONFIRMED`) |

Endpoint списка подтверждён frontend source (см. [раздел ниже](#подтверждение-по-frontend-source)). Серверный контур заявок описан в [order API](../../api/order-api.md), правила поставки — в [receiving-orders](../../business-rules/receiving-orders.md), вывоза — в [shipping-orders](../../business-rules/shipping-orders.md).

## Поля таблиц

| UI-колонка | ReceivingOrderDto | ShippingOrderDto | Наблюдение |
|---|---|---|---|
| Номер заявки | `number` | `number` | Ссылка/переход нужно подтвердить frontend |
| Клиент | `client` | `client` | На снимке отображается наименование |
| Дата и время поступления / вывоза | `planReceivingDateTime` | `plannedShippingDateTime` | Плановое, а не фактическое время — сопоставление по названию DTO |
| Площадка | `terminalArea` | `terminalArea` | На снимке значение сокращается по ширине |
| Вид транспорта | `transportType` | `transportType` | Видны «Авто» и «ЖД» |
| Дата создания | `createdAt` | `createdAt` | В UI показана только дата |
| Рейс | `route` | `route` | В таблице показан номер рейса либо `—` |
| Комментарий | `comment` | `comment` | Длинное значение обрезается |
| Статус | `orderStatus` | `orderStatus` | Цветная метка с русским переводом enum |
| Статус документов | `documentConfirmed` | На снимке вывоза нет | Отдельное измерение, не статус заявки |

## Статусы

Переводы подтверждены enum `OrderStatus` текущего commit:

| Код | UI-подпись | Видна на снимках |
|---|---|---|
| `DRAFT` | Черновик | Да |
| `ON_REVIEW` | На проверке | Да, поставка |
| `ACCEPTED` | Подтверждена | Да |
| `IN_PROGRESS` | В работе | Да, поставка |
| `DONE` | Выполнена | Да, вывоз |
| `REJECTED` | Отмена | Нет |

Для поставки `documentConfirmed=false` визуально показан как «Не обработаны». Отображение `true` и `null`, а также правило пустой метки требуют проверки; это нельзя смешивать с `orderStatus`.

## Действия и пагинация

| Элемент | Что подтверждено | Что требует проверки |
|---|---|---|
| «Создать» | Кнопка видна | Route, форма, permission и обязательные поля |
| Кнопка со стрелкой вверх | Иконка видна | Экспорт, импорт либо другое действие |
| Заголовки | Видны индикаторы сортировки | Поддерживаемые server-side fields и default order |
| Меню `…` | Есть в каждой строке | Состав действий и условия по статусу/permission |
| Пагинация | 25 строк; сотни страниц | Точный total, zero-based page и сохранение размера |
| Настройка | Иконка в заголовке справа | Хранение настройки и применимость к каждому реестру |

## Настройка таблицы

Отдельный снимок показывает панель «Управление столбцами»:

- столбцы можно включать/скрывать флажком и менять местами перетаскиванием;
- доступны высоты строк `S`, `M`, `L`, выбран `M`;
- есть сброс настроек;
- варианты «Без иерархии / С иерархией» видимы, но выглядят недоступными;
- показаны столбцы `№`, «Номер заявки», «Клиент», дата/время вывоза, площадка, вид транспорта, дата создания и рейс.

Не установлено, сохраняется ли настройка в браузере или через серверный UserSetting, общая ли она для поставки и вывоза и зависит ли от пользователя.

```mermaid
flowchart TD
    OPEN[Открыть реестр] --> PAGE[Загрузить страницу с filter и paging]
    PAGE --> TABLE[Показать заявки]
    TABLE --> SORT[Сортировка]
    TABLE --> NEXT[Следующая страница]
    TABLE --> CONFIG[Настроить столбцы]
    TABLE --> ROW[Открыть заявку или меню строки]
    CONFIG --> SAVE{Где хранится?}
    SAVE -->|не установлено| GAP[Frontend trace / UserSetting]
```

## Кандидатные требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-ORDER-LIST-001` | Статус заявки и статус обработки документов должны иметь отдельные подписи, фильтры и легенду | `PROPOSAL` |
| `UIR-ORDER-LIST-002` | Обрезанное значение должно быть доступно полностью без открытия режима редактирования | `PROPOSAL` |
| `UIR-ORDER-LIST-003` | Сортировка, фильтры, page size и настройка столбцов должны иметь документированное правило сохранения | `PROPOSAL` |
| `UIR-ORDER-LIST-004` | Меню строки должно учитывать одновременно status transition, permission и client scope | `PROPOSAL` |
| `UIR-ORDER-LIST-005` | Экран должен различать empty result, 403, network/server error и отсутствие отдельных nullable-значений | `PROPOSAL` |

## Вопросы аналитику

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-ORDER-LIST-001` | Что делает кнопка со стрелкой вверх: экспорт, импорт или другое действие? | Product/frontend owner |
| `GAP-UI-ORDER-LIST-002` | Какие фильтры доступны и где они показаны? | Пользователь процесса / frontend owner |
| `GAP-UI-ORDER-LIST-003` | Как отображаются `documentConfirmed=true` и `null`? | Владелец документооборота |
| `GAP-UI-ORDER-LIST-004` | Какие действия входят в меню строки для каждого статуса? | Владелец процесса |
| `GAP-UI-ORDER-LIST-005` | Где и на какой срок сохраняется конфигурация столбцов? | Frontend owner |

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `971288126` (07.10.2026; первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

| Вопрос / элемент | Ответ по frontend | Источник |
|---|---|---|
| Доступ к экрану | Маршрут закрыт `PermissionRoute` с `ReceivingOrder`/`ShippingOrder` уровня `READ` | `src/app/routes/MainRoutes.tsx` |
| `GAP-UI-ORDER-LIST-001` — кнопка в шапке | В шапке две кнопки: выгрузка реестра в Excel (`POST /report/receiving-order/download` / `/report/shipping-order/download`) и «Создать» (при `CREATE`). Импорта в реестре нет, поэтому кнопка со стрелкой — выгрузка (`INFERENCE` по составу шапки) | [ReceivingOrderTable](../../../../src/features/ReceivingOrder/UI/ReceivingOrderTable/ReceivingOrderTable.tsx) |
| `GAP-UI-ORDER-LIST-002` — фильтры | Фильтры в заголовках столбцов: номер (только цифры), клиент, плановая дата, площадка, транспорт, дата создания, рейс, комментарий, статус, статус документов. Тип фильтра — выбор из значений (dictionary) | [configs](../../../../src/features/ReceivingOrder/UI/ReceivingOrderTable/configs.tsx) |
| `GAP-UI-ORDER-LIST-003` — `documentConfirmed` | Только для `CONTAINER + VEHICLE`: «подтверждён» / «не подтверждён» / «не обработан» (`null`); иначе прочерк — [`UI-ORDER-009`](../../business-rules/order-ui-rules-as-is.md#общие-правила) | `src/shared/helpers/order.ts` |
| `GAP-UI-ORDER-LIST-004` — меню строки | «Открыть» (при `READ`) и «Копировать» (при `*.Copy` BUTTON `DELETE`). Статус на меню не влияет. Боковая панель строки: «Редактировать» — только `DRAFT` + `WRITE`, «Подробнее» — при `READ` | `ReceivingOrderTable.tsx`, `config/drawerConfig.tsx` |
| Копирование | Диалог с режимами «полное»/«частичное»; для `CONTAINER + RAILWAY` доступно только частичное — совпадает с серверным запретом full copy для ЖД ([копирование](../../business-rules/order-copying.md)). UI требует `*.Copy` уровня `DELETE`, сервер — `READ` | `src/features/OrderCopyContent/helpers.ts` |
| `GAP-UI-ORDER-LIST-005` — столбцы | Настройка хранится на сервере: `GET/POST /usersetting/tablecolumns-receivingordertablestore` (вывоз — `tablecolumns-shippingordertablestore`), то есть привязана к пользователю, а не к браузеру; срок не ограничен ([настройки пользователя](../../business-rules/user-settings-as-is.md)) | `src/shared/hooks/useColumnSettings/index.ts` |
