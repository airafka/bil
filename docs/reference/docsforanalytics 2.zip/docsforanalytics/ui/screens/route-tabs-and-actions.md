# Карточка рейса: секции, заявки и действия

Документ связывает карточку рейса с Route API, DTO, permissions, серверным lifecycle, заявками, планом/фактом и отчётами. Видимые поля и вкладки основаны на `UI-SNAPSHOT-002`; наличие макета «Создание нового рейса» — на [Figma заявок на поставку](../figma/receiving-orders.md); серверное поведение проверено на commit `22fac945e8116d04972ccc87b06b2303acf7a561`.

Frontend source и HAR отсутствуют. Поэтому endpoint существует со статусом `SOURCE_CONFIRMED`, а его использование конкретной кнопкой или вкладкой — `INFERENCE`.

## Паспорт доказательности

| Утверждение | Статус | Основание |
|---|---|---|
| В карточке есть вкладки «Основное» и «Заявки» | `EXTERNAL_SNAPSHOT` | `UI-SNAPSHOT-002`, 22.09.2026 |
| Figma предусматривает создание рейса из сценариев поставки | `EXTERNAL_SNAPSHOT` | Figma `H9pcFGKBkZcIKXPH3O9W5H` |
| Route API, DTO, permissions и lifecycle существуют | `SOURCE_CONFIRMED` | Java source текущего commit |
| Карточка вызывает перечисленные requests | `SOURCE_CONFIRMED` (frontend) для запросов из [раздела ниже](#подтверждение-по-frontend-source) | frontend `ab02fa985` |
| План/факт и отчёты доступны из этой карточки | `SOURCE_CONFIRMED` (frontend) | Только для рейсов вывоза с контейнерной площадки, только чтение |

## Границы агрегата

```mermaid
flowchart TD
    ROUTE[Route] --> MAIN[Основное]
    ROUTE --> ORDERS[Заявки]
    ROUTE --> STATE[Lifecycle]
    ROUTE --> REPORTS[Отчёты]
    ROUTE --> CHAIN[Cargo chain]
    ORDERS --> RECEIVING[ReceivingOrder]
    ORDERS --> SHIPPING[ShippingOrder]
    SHIPPING --> PLAN[План: вагоны и КТК]
    SHIPPING --> FACT[Факт: ЖД или авто]
    STATE --> OUTBOUND[Outbound при ACCEPTED]
```

`Route.routeType` выбирает только одно направление: `RECEIVING` («Поставка») либо `SHIPPING` («Вывоз»). Один рейс не должен смешивать заявки двух направлений.

## Начальная загрузка и «Основное»

| Candidate request | DTO | Permission | Назначение |
|---|---|---|---|
| `GET /routes/{id}` | [RouteDetailedDto](../../dto/catalog/route/RouteDetailedDto.md) | `ROUTE:READ` | Шапка и основная вкладка |
| `PUT /routes/{id}` | [RouteUpdateDto](../../dto/catalog/route/RouteUpdateDto.md) | `ROUTE:WRITE` | Редактирование разрешённых полей |
| `POST /routes/{id}/partial-copy` | `RouteDetailedDto` | `ROUTE_COPY:READ` | Новый черновик без заявок и даты |

### Поля и источник

| UI-поле | DTO.field | Подтверждённая семантика |
|---|---|---|
| Номер рейса | `number` | Генерируется сервером/БД |
| Вид транспорта | `transportType` | `VEHICLE` или `RAILWAY` |
| Площадка | `terminalArea` | Ссылка на терминальную площадку |
| Статус | `status` | `RouteStatus` с отдельным lifecycle |
| Тип рейса | `routeType` | `RECEIVING` или `SHIPPING` |
| Дата и время | `dataTime` | Один `Instant`; серверного конца интервала нет |
| Перевозчик / экспедитор | `clientRelatedEntity` | Условно обязателен для авто |
| ФИО водителя | `clientDriver.name`/`code` | Из [ClientDriverShortDto](../../dto/catalog/clientdriver/ClientDriverShortDto.md) |
| Номер телефона | `clientDriver.phoneNumber` | Подтверждённое nested-поле |
| Номер доверенности | `clientDriver.POANumber` | JSON использует необычный регистр `POANumber` |
| Номер ТС | `clientVehicle.code` | Из [ClientVehicleShortDto](../../dto/catalog/clientvehicle/ClientVehicleShortDto.md) |
| Страховка | `clientVehicle.insuranceNumber` | Подтверждённое nested-поле |
| Прицеп / номер прицепа | `clientVehicle.withTrailer`, `trailerNumber` | Подтверждённые nested-поля |
| Комментарий | `comment` | В БД максимум 200 символов, DTO длину не валидирует |

Рабочий снимок показывает временной интервал, но `RouteDetailedDto` содержит только `dataTime`. До frontend trace конец интервала нельзя объявлять полем backend: это может быть форматирование, вычисление или дополнительный источник.

### Создание и редактирование

`POST /routes` использует [RouteCreationDto](../../dto/catalog/route/RouteCreationDto.md). Обязательны `routeType`, `dataTime`, `terminalArea`, `transportType`. Для `VEHICLE` сервис дополнительно требует перевозчика, водителя и ТС; `RAILWAY` допустим только для площадки `CONTAINER`.

Update имеет только обязательный `body.id` и меняет `dataTime`, автомобильные ссылки и `comment`. `routeType`, площадка, транспорт и статус через этот endpoint неизменяемы. Controller игнорирует `{id}` в URL и обновляет по `body.id`; равенство path/body не проверяется.

У update неоднородная null-семантика: `dataTime=null` означает «не менять», `comment=null` очищает комментарий, а пропуск автомобильной ссылки способен привести к `NullPointerException`. UI не должен строить partial request без подтверждённого контракта каждого поля.

## Вкладка «Заявки»

### Чтение

| Candidate endpoint | DTO | Состояние |
|---|---|---|
| `POST /routes/{routeId}/orders` | [RouteClientOrderReportDto](../../dto/catalog/route/RouteClientOrderReportDto.md) | Актуальный read-model, группирует заявки по клиенту |
| `POST /routes/{routeId}/orders/meta/{fieldName}` | `IdsCodeDto[]` | Meta для фильтров таблицы |
| `POST /routes/{id}/orders/page` | [OrderRouteDetailDto](../../dto/catalog/route/OrderRouteDetailDto.md) | `DEPRECATED`; не выбирать для нового UI без причины совместимости |
| `GET /routes/{id}/assign` | [AssignOrderDto](../../dto/catalog/route/AssignOrderDto.md) | Только UUID уже назначенных заявок |

Актуальный grouped DTO содержит номер рейса, клиентов и их заявки. Для заявки доступны `id`, номер, тип, статус, плановая/фактическая дата и дата создания. Заявка без клиента не попадает в grouped response, поэтому пустой список не всегда означает отсутствие связанной строки в БД.

### Назначение и снятие

| Действие | Endpoint | Permission | Серверный эффект |
|---|---|---|---|
| Назначить | `POST /routes/{id}/assign` + `AssignOrderDto` | `ROUTE:CREATE` | `order.route=id`, `needTransport=false`; для авто создаётся/заменяется transport заявки |
| Снять | `DELETE /routes/{id}/assign` + `AssignOrderDto` | `ROUTE:DELETE` | `order.route=null`; для авто удаляется transport |

Назначение допускается для заявок `DRAFT`/`ON_REVIEW`, требует совпадения площадки и транспорта, а также грузоотправителя для поставки или грузополучателя для вывоза. Однако:

- неизвестный UUID или UUID заявки другого направления молча игнорируется;
- занятая заявка может быть перенесена из другого рейса;
- старый рейс после переноса не синхронизируется;
- unassign не проверяет, что заявка принадлежит рейсу из URL;
- unassign не возвращает `needTransport=true`;
- после снятия автомобильная transport-строка удаляется независимо от того, кто её создал.

```mermaid
flowchart LR
    PICK[Выбрать заявки] --> CHECK{Совместимы?}
    CHECK -->|нет| ERR[Показать конкретную заявку и причину]
    CHECK -->|да| ASSIGN[Назначить рейсу]
    ASSIGN --> REFRESH[Перечитать рейс и заявки]
    REFRESH --> SHOW[Показать фактический результат]
    SHOW --> UNASSIGN[Снять назначение]
    UNASSIGN --> WARN[Предупредить об удалении transport<br/>и needTransport=false]
```

UI должен сверять фактический response/readback, а не считать все отправленные UUID успешно назначенными.

## Статусы и действия

| Действие | Endpoint | Permission | Предусловия и эффект |
|---|---|---|---|
| Отправить на проверку | `POST /routes/{id}/change-status/review` | `ROUTE_SEND_REVIEW:DELETE` | Дата и минимум одна заявка; review каждой заявки; рейс → `ON_REVIEW` |
| Подтвердить | `POST /routes/{id}/change-status/accept` | `ROUTE_SEND_ACCEPT:DELETE` | Дата и минимум одна заявка; accept каждой заявки; рейс → `ACCEPTED`; outbound |
| Отменить | `PUT /routes/{id}/reject` | `ROUTE_REJECT:DELETE` | Каскадный reject всех заявок; рейс → `REJECTED` |
| Удалить | `DELETE /routes/{id}` | `ROUTE:DELETE` | Только `DRAFT`/`ON_REVIEW` и полностью пустой рейс; soft delete |
| Копировать | `POST /routes/{id}/partial-copy` | `ROUTE_COPY:READ` | Новый `DRAFT`, без заявок и `dataTime` |

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> ON_REVIEW: review
    DRAFT --> ACCEPTED: accept
    DRAFT --> REJECTED: reject
    ON_REVIEW --> ACCEPTED: accept
    ON_REVIEW --> REJECTED: reject
    ACCEPTED --> IN_PROGRESS: синхронизация заявок
    ACCEPTED --> REJECTED: reject
    IN_PROGRESS --> DONE: синхронизация заявок
    IN_PROGRESS --> REJECTED: reject
    DONE --> REJECTED: reject
```

Повтор перехода в тот же статус разрешён. Повторный accept повторно валидирует заявки и способен создать повторный outbound, поэтому кнопку нельзя считать безопасно идемпотентной: при ожидании ответа она должна блокироваться, а повтор после сетевой ошибки требует проверки результата.

Review/accept транзакционны относительно рейса и его заявок: ошибка одной заявки откатывает весь вызов. Строка рейса при этом явно не блокируется. Reject строку рейса блокирует; для receiving-заявок он также снимает связи с Waybill. Отмена `DONE → REJECTED` разрешена backend и требует отдельного бизнес-подтверждения в UI.

Автоматическая синхронизация может изменить статус рейса назад без transition map: назначение черновика выполненному рейсу либо снятие всех заявок способно вернуть рейс в `DRAFT`. UI после любой операции состава должен перечитывать статус.

## План и факт заявок на вывоз

Эти endpoints относятся только к содержимому `SHIPPING`-рейса. На снимке карточки соответствующие секции не показаны; их размещение в UI — `OPEN_QUESTION`.

| Секция | Data endpoint | Ответ |
|---|---|---|
| План вагонов | `POST /routes/{routeId}/shipping-order/railway-carriage` | [RouteShippingOrderRailwayCarriageDto](../../dto/catalog/route/RouteShippingOrderRailwayCarriageDto.md) |
| План КТК/груза | `POST /routes/{routeId}/shipping-order/container` | [RouteShippingOrderContainerDto](../../dto/catalog/route/RouteShippingOrderContainerDto.md) |
| ЖД-факт | `POST /routes/{routeId}/shipping-order/fact` | [RouteShippingOrderContainerFactDto](../../dto/catalog/route/RouteShippingOrderContainerFactDto.md) |
| Авто-факт | `POST /routes/{routeId}/shipping-order/auto/fact` | [RouteShippingOrderContainerFactByOrderDto](../../dto/catalog/route/RouteShippingOrderContainerFactByOrderDto.md) |

Для каждой data-секции существует отдельный meta endpoint. Data и meta строятся разными путями и могут расходиться по `fillingType`, deleted, nullable связям и дубликатам. ЖД-факт включает КТК независимо от `FINISHED`, авто-факт — только `FINISHED`. Подробности приведены в [плане/факте рейса](../../business-rules/route-shipping-plan-fact-as-is.md).

Неверный или receiving route способен дать пустой `200`, а не явную ошибку типа. UI должен скрывать shipping-секции по `routeType`, но не подменять этим серверную проверку.

## Cargo chain

`GET /routes/{id}/cargo-chain` возвращает route → shipping orders → вагоны → КТК → cargo и защищён `ROUTE:READ`. Для `RECEIVING` сервер возвращает оболочку рейса без receiving cargo hierarchy, потому что сервис всегда выбирает `ShippingOrder`.

Следовательно, cargo-chain нельзя использовать как универсальный источник вкладки «Заявки» или деталей поставочного рейса.

## Отчёты

| Действие | Endpoint | Permission | Ограничение |
|---|---|---|---|
| Узнать доступные PDF | `GET /report/route/{id}/available` | `ROUTE_REPORT:READ` | Возвращает только доступные типы, без причины отказа |
| Скачать ТН PDF | `POST /report/route/{id}/th/download` | `ROUTE_REPORT_TH:READ` | Только подходящий shipping/container/vehicle рейс с одной заявкой и допустимым КТК |
| Excel карточки | `POST /report/route/{id}/download` | `ROUTE:READ` | Direct UUID; client/deleted restriction не подтверждён |
| Excel заявок | `POST /report/route/{id}/orders/download` | `ROUTE:READ` | Использует deprecated detail service |
| Excel реестра | `POST /report/route/download` | `ROUTE:READ` | Игнорирует UI-фильтр и загружает весь доступный набор |

Availability — подсказка, а не резервирование: download повторно проверяет состояние. UI должен обрабатывать изменение доступности между запросами и не скрывать техническую причину под видом «файл отсутствует».

## Ошибки и навигация

| Проблема | Целевая секция | Ожидаемая реакция UI |
|---|---|---|
| Нет даты рейса | «Основное» | Открыть `dataTime` и показать server code/сообщение |
| Авто без перевозчика/водителя/ТС | «Основное» | Выделить все отсутствующие ссылки |
| Пустой рейс при review/accept (`Route.IsEmpty`) | «Заявки» | Открыть назначение заявок |
| Ошибка review/accept конкретной заявки | «Заявки» | Показать номер заявки, её статус и ссылку в карточку |
| Несовместимы площадка/транспорт/сторона | Диалог назначения | Не закрывать выбор; выделить проблемные заявки |
| Недопустимый status transition | Панель действий | Не показывать raw `500`; вывести текущий/целевой статус и обновить карточку |
| Ошибка одного plan/fact request | Соответствующая таблица | Partial error, не скрывать как empty |
| `403` | Текущая секция | Forbidden, а не пустой список |
| Отчёт стал недоступен | Меню отчётов | Обновить availability и объяснить причину, если backend её отдаёт |

## Доступ и согласованность

List/page/meta обогащают `RouteFilter` client restriction и скрывают `deleted`. Прямые UUID-операции — detail, update, assign/unassign, статусы, reject, copy, cargo-chain и часть отчётов — читают рейс напрямую; явная client row-level проверка в рассмотренном сервисе не найдена. Method permission не доказывает доступ к конкретному рейсу.

Soft-deleted рейс может оставаться доступным по известному UUID для detail и lifecycle. UI не должен считать `404` единственным возможным признаком удаления и не должен давать действие только на основании полученного DTO без серверной проверки.

Plan/fact nested responses собираются несколькими DAO-вызовами без общей транзакции RouteService. При конкурентном изменении возможен смешанный snapshot.

## Компоненты Figma

| Зона | Candidate components | Необходимые состояния |
|---|---|---|
| Основное | `Input`, `Dropdown`, `Date picker`, `TextArea` | view/edit, required, disabled, invalid, server error |
| Статус/действия | `Badge`, `Button`, `Tooltip`, `Pop-up` | disabled reason, submitting, destructive cascade confirmation |
| Заявки | `Table`, `Search`, `Checkbox`, `Pagination` | selectable, incompatible, already assigned, partial success/error |
| План/факт | `Tab`, `Table`, `Dropdown` | route-type gating, loading, empty, partial error, stale warning |
| Отчёты | `Button`, `Dropdown`, `Preloader`, `Message` | availability loading, generating, streaming error |

Макет «Создание нового рейса» встречается в складском, авто-КТК и ЖД-КТК сценариях поставки. Это подтверждает проектное намерение создавать рейс из контекста заявки, но не показывает, выполняется ли затем отдельный `/assign` и что происходит при частичном успехе create без assign.

## Требования для ТЗ

| ID | Требование | Состояние |
|---|---|---|
| `UIR-ROUTE-TRACE-001` | Карточка должна перечитывать Route и заявки после assign/unassign и смены статуса | `PROPOSAL` |
| `UIR-ROUTE-TRACE-002` | Create Route из заявки должен явно обрабатывать две операции: создание рейса и назначение заявки | `PROPOSAL` |
| `UIR-ROUTE-TRACE-003` | UI должен показывать результат назначения по фактически возвращённому/readback набору UUID | `PROPOSAL` |
| `UIR-ROUTE-TRACE-004` | Unassign должен предупреждать об удалении transport и текущем невосстановлении `needTransport` | `PROPOSAL` |
| `UIR-ROUTE-TRACE-005` | Review/accept должны показывать агрегированные ошибки по каждой заявке и не менять UI-статус до успешного ответа | `PROPOSAL` |
| `UIR-ROUTE-TRACE-006` | Повторная отправка accept должна блокироваться до проверки результата предыдущего запроса | `PROPOSAL` |
| `UIR-ROUTE-TRACE-007` | Reject должен перечислять затрагиваемые заявки и предупреждать receiving-сценарий о снятии Waybill | `PROPOSAL` |
| `UIR-ROUTE-TRACE-008` | План/факт должны показываться только для `SHIPPING` и соответствующего вида транспорта | `PROPOSAL` |
| `UIR-ROUTE-TRACE-009` | Empty, forbidden и partial error должны быть различимы для заявок и plan/fact | `PROPOSAL` |
| `UIR-ROUTE-TRACE-010` | UI и backend должны проверять равенство path ID и `RouteUpdateDto.id` | `PROPOSAL` |
| `UIR-ROUTE-TRACE-011` | Доступ к прямому UUID рейса должен учитывать client row-level scope и `deleted` | `PROPOSAL` |
| `UIR-ROUTE-TRACE-012` | Меню отчётов должно учитывать отдельные permissions и повторную проверку availability при скачивании | `PROPOSAL` |

## Вопросы аналитику и владельцам

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-ROUTE-TRACE-001` | Какой request фактически загружает вкладку «Заявки»? | Frontend owner |
| `GAP-UI-ROUTE-TRACE-002` | Откуда UI получает конец временного интервала при одном `dataTime`? | Frontend/backend owner |
| `GAP-UI-ROUTE-TRACE-003` | Должно ли создание рейса из заявки быть атомарным с assign? | Product/backend owner |
| `GAP-UI-ROUTE-TRACE-004` | Разрешён ли перенос заявки из другого рейса или требуется явное подтверждение? | Транспортный бизнес-владелец |
| `GAP-UI-ROUTE-TRACE-005` | Нужно ли unassign восстанавливать `needTransport` и сохранять ручной transport? | Транспортный бизнес-владелец |
| `GAP-UI-ROUTE-TRACE-006` | Разрешена ли пользователю отмена выполненного рейса и какие последствия должны быть обратимы? | Process owner |
| `GAP-UI-ROUTE-TRACE-007` | Где в интерфейсе расположены plan/fact и cargo-chain, если они используются? | Product/frontend owner |
| `GAP-UI-ROUTE-TRACE-008` | Какие отчёты должны быть доступны из карточки и как показывать причину недоступности ТН? | Product/report owner |
| `GAP-UI-ROUTE-TRACE-009` | Должен ли route detail скрывать soft-deleted и чужой по client scope рейс? | Security/business owner |
| `GAP-UI-ROUTE-TRACE-010` | Как обрабатывать повторный accept после timeout, чтобы не создать повторный outbound? | Integration/backend owner |

## Что нужно для подтверждения runtime

1. HAR открытия карточки, вкладки заявок и меню отчётов.
2. HAR create-from-order, assign, unassign, review, accept, reject и повтор после timeout.
3. Frontend route/component source или production source maps.
4. Role/client matrix для прямого UUID и каждой операции.
5. Снимки validation, cascade confirmation, empty, forbidden, partial error и report generation.

После получения доказательств candidate mappings переводятся из `INFERENCE` в `SOURCE_CONFIRMED`/`RUNTIME_CONFIRMED` либо удаляются.

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `ab02fa985` (14.10.2026; ранее `971288126`, первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

| Вкладка / действие | Запросы | Условие |
|---|---|---|
| Основное | `GET /routes/{id}`, `POST /routes`, `PUT /routes/{id}` | правка — `DRAFT` + `Route` `WRITE` |
| Заявки | `POST /routes/{id}/orders`; кандидаты — `POST /receivingorder/page` или `/shippingorder/page` с фильтром площадка + транспорт + `DRAFT`; `POST`/`DELETE /routes/{id}/assign`. С 14.10.2026 все назначенные заявки стоят в начале списка выбора, колонки фильтруются локально ([`UI-ROUTE-015`](../../business-rules/route-ui-rules-as-is.md#правила)) | рейс в `DRAFT` |
| Вагоны | `POST /routes/{id}/shipping-order/railway-carriage` | вывоз, `CONTAINER + RAILWAY` |
| Количество КТК | `POST /routes/{id}/shipping-order/container` | вывоз с контейнерной площадки |
| Просмотр (план/факт) | `POST /routes/{id}/shipping-order/fact` или `.../auto/fact` | вывоз с контейнерной площадки, просмотр |
| Документы | `GET /report/route/{id}/available`, `POST /report/route/{id}/th/download` | авто-вывоз, `Route.Report` `DELETE` |
| Отправить | `POST /routes/{id}/change-status/accept` | `DRAFT` + `Route.SendToAccept` |
| Отменить | `PUT /routes/{id}/reject` | см. [`UI-ROUTE-009`](../../business-rules/route-ui-rules-as-is.md#правила) |
| Копировать (реестр) | `POST /routes/{id}/partial-copy` | `Route.Copy` |
| Excel рейса | `POST /report/route/{id}/download` | вкладка «Заявки» |

`change-status/review` и `GET /routes/{id}/cargo-chain` UI не вызывает.

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-ROUTE-TRACE-001` | `POST /routes/{id}/orders` |
| `GAP-UI-ROUTE-TRACE-002` | UI добавляет к `dataTime` 1 час |
| `GAP-UI-ROUTE-TRACE-003` | Не атомарно: из заявки рейс создаётся отдельным `POST /routes`, назначение — отдельным `assign` при сохранении вкладки |
| `GAP-UI-ROUTE-TRACE-004` | UI переносу не препятствует и не предупреждает — [`UI-RDIFF-01`](../../business-rules/route-ui-rules-as-is.md#реестр-расхождений-ui--backend) |
| `GAP-UI-ROUTE-TRACE-006` | В карточке отмена недоступна только для `REJECTED`; в реестре — без проверки статуса |
| `GAP-UI-ROUTE-TRACE-007` | План/факт — вкладки «Вагоны», «Количество КТК», «Просмотр»; cargo-chain в UI не используется |
| `GAP-UI-ROUTE-TRACE-008` | Только ТН (`ContainerTN`); при недоступности вкладка «Документы» просто не показывается, причина не выводится |
| `GAP-UI-ROUTE-TRACE-010` | Защиты от повторного нажатия кроме блокировки кнопки на время запроса нет |
