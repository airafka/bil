# Форма заявки на услугу

Документ описывает пользовательский поток `ServiceOrder`: создание черновика, выбор КТК, изменение корня, выполнение услуги и просмотр результата. Он связывает предполагаемые секции формы с API, DTO, permissions, транзакциями и ошибками.

Backend сверён с commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Отдельный screenshot или Figma-flow заявки на услугу не предоставлен. Поэтому серверная логика имеет статус `SOURCE_CONFIRMED`, а расположение секций и подписи — `PROPOSAL`. Screen→request подтверждён frontend source `971288126` — см. [раздел ниже](#подтверждение-по-frontend-source).

## Бизнес-смысл

Сейчас поддерживается одна услуга — `CHANGE_OWNER`, «смена владельца КТК». Клиент заявки является новым владельцем всех выбранных контейнеров после выполнения.

`ServiceOrder` не является транспортной заявкой. У неё нет площадки, транспорта, рейса, review/reject и статусов транспортного заказа. Жизненный цикл содержит только `DRAFT → DONE`.

```mermaid
flowchart TD
    NEW[Создать заявку] --> DRAFT[ServiceOrder DRAFT]
    DRAFT --> ROOT[Клиент + CHANGE_OWNER + комментарий]
    DRAFT --> SELECT[Выбрать КТК по текущему ContainerOwner]
    SELECT --> CHECK{Есть минимум один КТК?}
    CHECK -->|нет| ERROR[Ошибка accept; остаётся DRAFT]
    CHECK -->|да| ACCEPT[Выполнить услугу]
    ACCEPT --> OWNER[Владельцы КТК = клиент заявки]
    OWNER --> HISTORY[История при фактической смене]
    HISTORY --> DONE[DONE + completionAt]
    DONE --> OUT[SERVICE_ORDER_CHAIN_PACKAGE]
```

## Предлагаемая композиция формы

| Секция | Содержание | Режим `DRAFT` | Режим `DONE` |
|---|---|---|---|
| Шапка | Номер, статус, даты создания/выполнения | Номер/статус read-only | Всё read-only |
| Основное | Клиент, услуга, комментарий | Услуга и комментарий меняются; клиент после create read-only | Read-only |
| Выбранные КТК | Контейнер, текущий владелец | Полная замена выбранного набора | Только просмотр |
| Доступные КТК | Поиск по контейнеру и владельцу | Добавление доступных owner-записей | Недоступно |
| Выполнение | Кнопка accept и итог операции | Доступна при permission; сервер требует минимум один КТК | Недоступна |
| Интеграция | Состояние outbound | В корневом DTO отсутствует | Желательно отдельное состояние доставки; текущий read API его не возвращает |

## Корневая форма

Create: [ServiceOrderCreationDto](../../dto/service-order/ServiceOrderCreationDto.md). Update: [ServiceOrderUpdateDto](../../dto/service-order/ServiceOrderUpdateDto.md). Ответ: [ServiceOrderDto](../../dto/service-order/ServiceOrderDto.md).

| Поле | Create | Update | Фактическая семантика |
|---|---:|---:|---|
| `id` | Серверное | Обязательно | Update проверяет равенство path ID и `body.id` |
| `client` | Обязательно, вложенный `id` валидируется | Поля нет | Новый владелец выбранных КТК; после создания не меняется |
| `service` | Обязательно | Обязательно | Единственное значение `CHANGE_OWNER` |
| `comment` | Необязательно | Необязательно | Может быть заменён или очищен; DB ограничивает длину 1000, DTO длину не проверяет |
| `number` | Серверное | — | Общая последовательность заявок; DB содержит unique/check |
| `status` | Серверное `DRAFT` | — | Меняется только accept: `DRAFT → DONE` |
| `createdAt` | Серверное | — | Отображается из response |
| `completionAt` | `null` | — | Устанавливается сервером при успешном accept |
| `containerQuantity` | Нет в request | — | Обогащается для page; одиночный `GET /{id}` отдельно это поле не обогащает |

Create и update — разные контракты: update не должен повторно отправлять клиента. После `DONE` update запрещён. При единственном enum-значении UI может показывать услугу как фиксированное поле, но request всё равно обязан содержать `service=CHANGE_OWNER`.

## API формы и permissions

| Действие | Endpoint | Permission | Примечание |
|---|---|---|---|
| Создать | `POST /service-order/` | `SERVICE_ORDER:CREATE` | Возвращает DRAFT с ID/номером |
| Загрузить | `GET /service-order/{id}` | `SERVICE_ORDER:READ` | Отдельная row-level client-проверка в найденной цепочке не подтверждена |
| Изменить | `PUT /service-order/{id}` | `SERVICE_ORDER:WRITE` | Только DRAFT; path/body ID должны совпасть |
| Удалить | `DELETE /service-order/{id}` | `SERVICE_ORDER:DELETE` | Только DRAFT; физически удаляет связи, затем корень |
| Показать выбранные КТК | `POST /service-order/{id}/container/page` | `SERVICE_ORDER:READ` | Доступно и после DONE |
| Показать редактор выбора | `POST .../container/edit/page` | `SERVICE_ORDER:READ` | Только DRAFT; выбранные и доступные owner-записи |
| Meta выбора | `POST .../container/edit/meta/{fieldName}` | `SERVICE_ORDER:READ` | Поддерживает `client` и `container` |
| Заменить выбор | `PUT /service-order/{id}/container` | `SERVICE_ORDER:WRITE` | Только DRAFT; полная синхронизация под lock |
| Выполнить | `POST /service-order/{id}/accept` | отдельный `SERVICE_ORDER_ACCEPT` | Body отсутствует; проверяется сохранённый агрегат |

Permission `ServiceOrderAccept` является отдельной кнопкой/веткой доступа. Наличие `WRITE` не означает права выполнения, а наличие accept-права не заменяет READ для отображения формы.

## Выбор КТК

Тело `PUT .../container` — полный желаемый список [ServiceOrderContainerSaveDto](../../dto/catalog/serviceordercontainer/ServiceOrderContainerSaveDto.md).

| Поле элемента | Назначение |
|---|---|
| `id` | Сохранить уже существующую связь `ServiceOrderContainer` |
| `containerOwnerId` | Добавить КТК через запись его текущего владельца |

Должно быть задано хотя бы одно поле. Если заданы оба, сервер рассматривает элемент как существующую связь по `id` и игнорирует `containerOwnerId`. Повторы ID и owner ID сворачиваются множествами. Пустой список допустим и удаляет весь выбор.

КТК доступен для добавления, когда:

1. для него существует текущий `ContainerOwner`;
2. текущий владелец отличается от клиента заявки;
3. КТК не выбран в другой заявке на услугу со статусом `DRAFT`.

Завершённая заявка `DONE` не блокирует следующую смену владельца. Выбор осуществляется по `containerOwnerId`, а сохраняется связь с физическим `Container`; это важно для названий полей и payload ТЗ.

```mermaid
sequenceDiagram
    actor U as Пользователь
    participant UI as Форма
    participant SO as ServiceOrder API
    participant CO as Container selection API
    U->>SO: POST /service-order/
    SO-->>UI: DRAFT + id
    UI->>CO: POST edit/page
    CO-->>UI: выбранные + доступные ContainerOwner
    U->>UI: Меняет выбор
    UI->>CO: PUT полный список id/containerOwnerId
    CO->>CO: lock заявки, validate, remove, add
    CO-->>UI: актуальный выбранный список
```

`saveSelected` транзакционный. Если новый owner отсутствует или уже недоступен, выполненные внутри вызова удаления откатываются. Это не даёт атомарности со старым отдельным update корня: сохранение комментария и набора КТК — два HTTP-запроса.

## Выполнение услуги

`POST /service-order/{id}/accept` не принимает текущий выбор из UI. Он блокирует заявку и читает сохранённые связи:

1. статус должен быть ровно `DRAFT`;
2. должен существовать минимум один `ServiceOrderContainer`;
3. владелец каждого КТК меняется на клиента заявки;
4. при реальной смене создаётся `ContainerOwnerHistory`;
5. устанавливаются `DONE` и `completionAt=now`;
6. создаётся одна outbound-строка `SERVICE_ORDER_CHAIN_PACKAGE`.

Смена владельцев, история, статус, время и outbound фиксируются одной транзакцией. Фактическая отправка в Datareon `/serviceOrder` происходит позднее, до пяти попыток, и не возвращается в `ServiceOrderDto`.

Повторный accept после успешного выполнения не создаёт второй outbound штатно, но возвращает общий HTTP `500`, а не предметный `409/400`. После неизвестного сетевого результата UI должен сначала перечитать заявку: `DONE` означает, что бизнес-транзакция завершилась, даже если ответ клиенту потерян.

## Состояния и ошибки формы

| Состояние | Ожидаемое поведение UI |
|---|---|
| Новый root сохраняется | Блокировать повтор create; к выбору КТК переходить только после ID |
| Нет доступных КТК | Empty-state объясняет: нет владельца, уже владеет клиент или занят другим DRAFT; точная причина API сейчас не возвращается построчно |
| Пустой выбор | Разрешить сохранить пустой DRAFT, но блокировать/объяснять accept; сервер всё равно повторно проверяет |
| Dirty root / selection | Учитывать независимо; не объявлять всю форму сохранённой после успеха только одного request |
| Полная очистка | Для `PUT []` запросить подтверждение, поскольку удаляются все связи |
| Partial save | Root update мог пройти, selection — нет, и наоборот; перечитать обе части |
| `400` | DTO, пустой accept или недоступный owner; сохранить DRAFT и пользовательский ввод |
| `403` | Нет permission либо заявка уже DONE для edit/delete; перейти в read-only |
| `404` | Заявка, связь или owner исчезли; перечитать набор, не повторять старый payload автоматически |
| `409` | Дублирующаяся пара заявка+КТК; перечитать выбранные |
| `500` на accept | Может означать повтор/неверный статус; сначала `GET`, затем показывать результат, не повторять вслепую |

## Конкурентность

- Два сохранения выбора одной заявки сериализуются lock-ом root.
- Accept и сохранение выбора одной заявки также сериализуются.
- Update/delete не используют тот же lock и не имеют optimistic `@Version`.
- Два разных DRAFT блокируют разные root-строки. DB не запрещает одному КТК одновременно оказаться в двух разных DRAFT; уникальна только пара `(service_order_id, container_id)`.
- Доступность владельца проверяется при выборе, но не повторяется как ожидание прежнего владельца непосредственно перед accept.

Для безопасного ТЗ нужен expected-owner/version token либо уникальное ограничение/lock на участие КТК в активной заявке. Простое скрытие занятого КТК в UI не закрывает race.

## Риски для проверки ТЗ

1. Клиент заявки — не фильтр, а целевой новый владелец.
2. `containerOwnerId` нужен для добавления, `ServiceOrderContainer.id` — для сохранения существующей связи.
3. `PUT []` полностью очищает выбор.
4. Accept работает по БД, а не по несохранённым checkbox UI.
5. `containerQuantity` может отсутствовать/отличаться в одиночном GET и page response.
6. Повторный accept оформляется как `500`.
7. Успешный `DONE` не означает успешную доставку Datareon.
8. Один КТК может быть конкурентно выбран в два разных DRAFT.
9. Direct-ID read/scoped paths не имеют подтверждённой client row-level проверки.
10. Физическое удаление заявки допустимо только в DRAFT и не удаляет сам КТК/владельца.

## Требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-SERVICE-FORM-001` | После create форма получает ID DRAFT и только затем разрешает выбор КТК | `PROPOSAL` |
| `UIR-SERVICE-FORM-002` | Клиент подписывается как будущий владелец, а не только заказчик услуги | `PROPOSAL` |
| `UIR-SERVICE-FORM-003` | Для `CHANGE_OWNER` UI показывает текущего и будущего владельца каждого КТК | `PROPOSAL` |
| `UIR-SERVICE-FORM-004` | Выбранные связи и доступные owner-записи хранят разные ID и не смешиваются в payload | `PROPOSAL` |
| `UIR-SERVICE-FORM-005` | Пустой список и удаление заявки требуют подтверждения с описанием фактического эффекта | `PROPOSAL` |
| `UIR-SERVICE-FORM-006` | Root и selection имеют независимые dirty/saving/error/saved состояния | `PROPOSAL` |
| `UIR-SERVICE-FORM-007` | Accept запускается после успешного сохранения выбора и всё равно обрабатывает server validation | `PROPOSAL` |
| `UIR-SERVICE-FORM-008` | После неизвестного accept UI сначала перечитывает статус и не отправляет повтор вслепую | `PROPOSAL` |
| `UIR-SERVICE-FORM-009` | После DONE форма read-only показывает `completionAt` и итогового владельца каждого КТК | `PROPOSAL` |
| `UIR-SERVICE-FORM-010` | Право accept проверяется отдельно от CREATE/WRITE/DELETE и отражается в доступности действия | `PROPOSAL` |
| `UIR-SERVICE-FORM-011` | Конфликт доступности КТК приводит к refresh выбора с сохранением остальных отмеченных строк | `PROPOSAL` |
| `UIR-SERVICE-FORM-012` | Для заявки на услугу создаётся отдельный versioned Figma-flow со всеми empty/error/conflict/DONE состояниями | `PROPOSAL` |

## Вопросы аналитику и владельцам

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-SERVICE-FORM-001` | Должен ли клиент называться «Новый владелец» и можно ли его менять после выбора КТК? | Бизнес-аналитик |
| `GAP-UI-SERVICE-FORM-002` | Нужен ли preview списка «старый владелец → новый владелец» перед accept? | Бизнес-владелец |
| `GAP-UI-SERVICE-FORM-003` | Должен ли сервер повторно проверять ожидаемого старого владельца при accept? | Архитектор/backend owner |
| `GAP-UI-SERVICE-FORM-004` | Как исключается конкурентный выбор одного КТК в два DRAFT? | Архитектор/DB owner |
| `GAP-UI-SERVICE-FORM-005` | Нужна ли отмена/компенсация уже выполненной смены владельца? | Process owner |
| `GAP-UI-SERVICE-FORM-006` | Следует ли показывать outbound delivery status и ручной retry? | Integration/business owner |
| `GAP-UI-SERVICE-FORM-007` | Какой HTTP-код и машинный error code должны заменять `500` повторного accept/path-body mismatch? | API owner |
| `GAP-UI-SERVICE-FORM-008` | Должен ли direct GET и scoped container API ограничиваться клиентами пользователя? | Security owner |
| `GAP-UI-SERVICE-FORM-009` | Планируются ли другие `ServiceOrderType`, требующие иных полей и lifecycle? | Product owner |
| `GAP-UI-SERVICE-FORM-010` | Где находится актуальный макет и к какому релизу он относится? | Product/design owner |

## Связанные документы

- [Полный lifecycle AS-IS](../../business-rules/service-order-lifecycle.md)
- [Краткие бизнес-правила](../../business-rules/service-orders.md)
- [Карта валидации](../../business-rules/order-validation.md#заявка-на-услугу-корневой-request)
- [ServiceOrderContainer DTO](../../dto/catalog/serviceordercontainer/ServiceOrderContainerDto.md)
- [История владельца](../../entities/catalog/entities/containerownerhistory/ContainerOwnerHistory.md)

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `971288126` (07.10.2026; первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

| Элемент | Frontend |
|---|---|
| Маршруты | `/service-orders`, `/service-order/create`, `/service-order/:id`; доступ — `ServiceOrder` `READ`, создание — `ServiceOrder` `CREATE` на маршруте `create` |
| Вкладки | «Основное» и «КТК» |
| Запросы | `POST /service-order/page`, `GET /service-order/{id}`, `POST /service-order/`, `PUT /service-order/{id}`, `POST /service-order/{id}/container/page`, `POST /service-order/{id}/container/edit/page`, `PUT /service-order/{id}/container`, `POST /service-order/{id}/accept`, `DELETE /service-order/{id}` (только очистка брошенного черновика) |
| Правила | [`UI-SRV-001…004`](../../business-rules/order-ui-rules-as-is.md#заявка-на-услугу) |

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-SERVICE-FORM-001` | Поле называется «Клиент»; менять его можно только в мастере создания, после создания оно заблокировано |
| `GAP-UI-SERVICE-FORM-002` | Отдельного preview «старый → новый владелец» перед подтверждением нет: кнопка «Подтвердить» сразу вызывает accept без диалога |
| `GAP-UI-SERVICE-FORM-009` | Во frontend зашит единственный тип `CHANGE_OWNER` |
