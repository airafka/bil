# Карточка заявки на поставку: вкладки и действия

Документ связывает видимые вкладки карточки заявки на поставку с backend-контрактами, DTO, permissions и серверной валидацией. Вид вкладок подтверждён снимком `UI-SNAPSHOT-002`, сценарные варианты — [продуктовым Figma-файлом](../figma/receiving-orders.md), а поля и порядок записи формы — отдельным документом [создания и редактирования](receiving-order-create-edit.md). Серверные правила сверены с исходниками на commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Frontend source и HAR не предоставлены, поэтому связь конкретной вкладки с HTTP-запросом имеет статус `INFERENCE`.

Краткий паспорт основной вкладки находится в [карточке заявки](receiving-order-card.md), бизнес-правила — в [заявке на поставку](../../business-rules/receiving-orders.md), полный API — в [order API](../../api/order-api.md).

## Граница доказательности

| Утверждение | Статус | Основание |
|---|---|---|
| В карточке есть вкладки «Основное», «Рейсы», «КТК», «Груз», «Просмотр» | `EXTERNAL_SNAPSHOT` | `UI-SNAPSHOT-002` от 22.09.2026 |
| Перечисленные endpoints, DTO, permissions и проверки существуют в backend | `SOURCE_CONFIRMED` | Java source на зафиксированном commit |
| Конкретная вкладка вызывает указанный endpoint | `SOURCE_CONFIRMED` (frontend) для вкладок из [раздела ниже](#подтверждение-по-frontend-source); прочие строки — `INFERENCE` | frontend `ab02fa985` |
| Loading, empty, error, сохранение выбранной вкладки и навигация к ошибке реализованы | `OPEN_QUESTION` | На снимке эти состояния отсутствуют |
| Компоненты Figma используются в production frontend | `INFERENCE` | Дизайн-система просмотрена, frontend source отсутствует |

## Предлагаемая композиция карточки

```mermaid
flowchart TD
    OPEN[Открыть карточку] --> ROOT[Загрузить ReceivingOrder]
    ROOT --> MAIN[Основное]
    ROOT --> ROUTE[Рейсы]
    ROOT --> KTK[КТК]
    ROOT --> CARGO[Груз]
    ROOT --> PREVIEW[Просмотр]
    MAIN --> REVIEW[Отправить на проверку]
    ROUTE --> ROUTE_DATA[Route / ReceivingOrderTransport]
    KTK --> CONTAINERS[Контейнеры и содержимое]
    CARGO --> GOODS[Товары / грузовые места / blackbox]
    PREVIEW --> TOTALS[Детальная сводка]
    REVIEW --> VALIDATE[Проверка всего агрегата]
    VALIDATE -->|ошибка| ERROR_TAB[Открыть вкладку с проблемой]
    VALIDATE -->|успех| ON_REVIEW[Статус ON_REVIEW]
```

Эта схема задаёт требуемую пользовательскую связность. Она не доказывает, что текущий frontend загружает вкладки именно так.

## Начальная загрузка

| Candidate request | Ответ | Permission | Возможное использование | Ограничение доказательства |
|---|---|---|---|---|
| `GET /receivingorder/{id}` | [ReceivingOrderDto](../../dto/catalog/receivingorder/ReceivingOrderDto.md) | `RECEIVING_ORDER:READ` | Шапка и «Основное» | Фактический request UI неизвестен |
| `GET /receivingorder/{id}/preview` | [ReceivingOrderDetailedDto](../../dto/catalog/receivingorder/ReceivingOrderDetailedDto.md) | `RECEIVING_ORDER:READ` | «Просмотр» и агрегированные итоги | На снимке detailed-поля не показаны |

Корневой DTO не содержит списки всех дочерних строк. Если интерфейс отображает их одновременно, ему нужны отдельные запросы. Между такими запросами нет подтверждённого общего snapshot: данные могут быть получены в разные моменты.

## Матрица вкладок

### «Основное»

| Аспект | AS-IS backend / требование UI |
|---|---|
| Чтение | Candidate `GET /receivingorder/{id}` → [ReceivingOrderDto](../../dto/catalog/receivingorder/ReceivingOrderDto.md) |
| Сохранение | Candidate `PUT /receivingorder/{id}` + [ReceivingOrderUpdateDto](../../dto/catalog/receivingorder/ReceivingOrderUpdateDto.md) |
| Permission | `RECEIVING_ORDER:READ` / `RECEIVING_ORDER:WRITE` |
| Request validation | `id`, `client`, `contract`, `terminalArea`, `transportType`, `orderStatus` обязательны; `storagePeriod`, если задан, неотрицательный |
| Review validation | Обязательны `currency`, `planReceivingDateTime`; для `CONTAINER` также `shipper` |
| Критическое расхождение | Controller объявляет `{id}`, но не принимает его параметром и сервис обновляет объект по `body.id`. UI должен отправлять совпадающий ID, а backend должен явно проверять равенство path/body |
| Состояния | Нужны skeleton/loading, ошибка корня, forbidden, read-only и dirty-form confirmation |

Полная обязательность полей описана в [карте валидации](../../business-rules/order-validation.md#поставка-корневой-request).

### «Рейсы»

В корневом `ReceivingOrder` хранится одна nullable-ссылка `route`, а не коллекция. Поэтому множественное число в названии вкладки не подтверждает возможность нескольких рейсов.

| Candidate request / поле | Permission | Назначение | Доказательность |
|---|---|---|---|
| `ReceivingOrderDto.route` | `RECEIVING_ORDER:READ` | Текущий связанный рейс | `SOURCE_CONFIRMED` для DTO |
| `GET /routes/{id}` | `ROUTE:READ` | Детали одного рейса | `SOURCE_CONFIRMED` (frontend) |
| `GET /routes/{id}/assign` | `ROUTE:READ` | Получение уже назначенных рейсу заявок | `INFERENCE` |
| `POST /routes/{id}/assign` + `AssignOrderDto` | `ROUTE:CREATE` | Назначить заявку рейсу | `SOURCE_CONFIRMED` (frontend) |
| `DELETE /routes/{id}/assign` + `AssignOrderDto` | `ROUTE:DELETE` | Снять назначение | `SOURCE_CONFIRMED` (frontend) |
| ~~`/receivingordertransport/...` + `ReceivingOrderTransportDto`~~ | — | *(удалено KIS-4093, коммит `d30d77ad`, 24 сентября 2026)* Отдельной транспортной строки заявки больше нет; `carrier`/`clientVehicle`/`clientDriver` хранятся только на самом [Route](../../entities/catalog/entities/route/Route.md) | — |

Назначение разрешено сервером только для заявки в `DRAFT` или `ON_REVIEW`, сверяет площадку и вид транспорта, для поставки требует грузоотправителя, устанавливает `needTransport=false`. Утверждение «для автомобиля создаёт либо заменяет транспортную строку» относилось к уже удалённой `receiving_order_transport` и требует перепроверки на актуальном `RouteService.assign` (открытый пункт). Подробности и риски снятия связи приведены в [lifecycle рейса](../../business-rules/route-lifecycle-as-is.md).

### «КТК»

| Данные / операция | Candidate endpoint | DTO | Permission |
|---|---|---|---|
| Страница контейнеров | `POST /receivingordercontainer/page` | [ReceivingOrderContainerDto](../../dto/catalog/receivingordercontainer/ReceivingOrderContainerDto.md) | `ReceivingOrder.ReceivingOrderContainer:READ` |
| Preview контейнеров | `POST /receivingordercontainer/preview` | [ReceivingOrderContainerPreviewDto](../../dto/catalog/receivingordercontainer/ReceivingOrderContainerPreviewDto.md) | `ReceivingOrder.ReceivingOrderContainer:READ` |
| Пакет create/update/delete | `POST /receiving-order/{receivingOrderId}/receiving-order-container/batch` | create/update DTO → список `ReceivingOrderContainerDto` | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER:DELETE` |
| Сгруппированное содержимое КТК | `POST /receiving-order/{receivingOrderId}/receiving-order-container-item/list` | [ContainerItemListResponseGroupDto](../../dto/catalog/receivingordercontainer/ContainerItemListResponseGroupDto.md) | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER_ITEM:READ` |
| Пакет строк содержимого | `POST /receiving-order/{receivingOrderId}/receiving-order-container-item/batch` | [ReceivingOrderContainerItemDto](../../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemDto.md) | `RECEIVING_ORDER_RECEIVING_ORDER_CONTAINER_ITEM:DELETE` |

Scoped V2 batch-контроллеры принудительно подставляют `receivingOrderId` из URL в add/update DTO. Уровень `DELETE` на комбинированной create/update/delete операции означает, что пользователь без максимального уровня не сможет выполнить даже пакет только с добавлениями; UI не должен выводить доступность этой формы только из отдельных `CREATE`/`WRITE` прав legacy API.

При review/accept на контейнерной площадке сервер проверяет наличие КТК для автомобильной ветки, вес и владельца известного КТК, согласованность `empty` с наличием items и, при feature flag, занятость КТК другой активной поставкой. При accept для `CONTAINER + VEHICLE` неизвестный номер КТК запрещён. Для `CONTAINER + RAILWAY` отдельная проверка наличия хотя бы одного КТК в текущую карту валидаторов не включена.

### «Груз»

Состав вкладки должен зависеть от `deliveryType`, а не быть одной неизменной таблицей. Figma отдельно проектирует четыре складских сценария: «По номенклатуре», «По контейнерам», «По номенклатуре с контейнерами без детализации» и «…с детализацией»; их candidate mapping приведён в [инвентаризации макетов](../figma/receiving-orders.md#складской-сценарий).

| `deliveryType` | Требуемые данные | Candidate API / DTO |
|---|---|---|
| `BY_GOOD` | Одна или более товарных строк | `/receivingordergood/...`, [ReceivingOrderGoodDto](../../dto/catalog/receivingordergood/ReceivingOrderGoodDto.md) |
| `BY_CARGO` | Строка blackbox | `/receivingorderblackbox/...`; permission использует общий `ReceivingOrder:*` |
| `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` | Товары и общее число грузовых мест | `/receivingordergood/...` и `GET/POST/PUT /receivingorder/{id}/total-cargo-quantity`, [ReceivingOrderTotalCargoQuantityDto](../../dto/catalog/receivingorder/ReceivingOrderTotalCargoQuantityDto.md) |
| `BY_GOOD_WITH_CARGO_WITH_DETAILS` | Товары и детальные грузовые места | `/receivingordergood/...`, `/receivingordercargo/...`, [ReceivingOrderCargoDto](../../dto/catalog/receivingordercargo/ReceivingOrderCargoDto.md) |

Для товаров при review/accept сервер требует `plannedQuantity`, `price` и `totalPrice` больше нуля. Для детального груза обязательна ссылка `cargo`; отрицательные количества отклоняются, но нулевые и `null` фактически допускаются, несмотря на названия ошибок `Missing*`.

У `POST /receivingordercargo/preview` найдены два source-level дефекта:

- endpoint защищён permission `ShippingOrder.ShippingOrderCargo:READ`, а не receiving-order permission;
- Java-метод возвращает `ReceivingOrderCargoPreviewDto`, но OpenAPI annotation объявляет `ShippingOrderCargoPreviewDto`.

До исправления UI может получить `403` при корректных правах на поставку, а клиент, сгенерированный по OpenAPI, — неверный тип ответа.

### «Просмотр»

| Candidate source | Что предоставляет | Ограничение |
|---|---|---|
| `GET /receivingorder/{id}/preview` | Корневая детальная DTO и агрегированные итоги | Не доказано, что это request вкладки |
| `POST /receivingordercontainer/preview` | Представление контейнеров | Отдельный запрос и permission |
| `POST /receivingordercargo/preview` | Представление грузовых мест | Неверные permission и OpenAPI schema, описанные выше |
| `POST /receivingorder/{id}/waybill-railway-carriages/page` | Вагоны, сгруппированные по накладным | Только для ЖД-сценария |
| `POST /receivingorder/{id}/waybill-containers/page` | КТК по накладной/вагону | Только для ЖД-сценария |
| `POST /receivingorder/{id}/waybill-products/page` | Товары по накладной | Только для ЖД-сценария |

«Просмотр» следует трактовать как сводку перед сменой статуса, пока бизнес-владелец не подтвердит печатное назначение. Если вкладка собирается из нескольких запросов, нужно либо показывать время актуальности частей, либо предоставить единый серверный snapshot.

## ЖД-накладные — отсутствующая точка входа

Для `CONTAINER + RAILWAY` review требует хотя бы одну связанную накладную и хотя бы один вагон этой накладной. Backend предоставляет:

- `POST /receivingorder/{id}/waybills` → список [WaybillShortDto](../../dto/catalog/waybill/WaybillShortDto.md);
- `PUT /receivingorder/{id}/waybills` + [WaybillSelectionDto](../../dto/catalog/waybill/WaybillSelectionDto.md) → заменить связи;
- три grouped page endpoint для вагонов, контейнеров и товаров.

На снимке отдельной вкладки «Накладные» нет. Если эти операции не размещены внутри «КТК» или «Просмотр», пользователь не сможет устранить validation error непосредственно из карточки. Название поля `waybill` на основной вкладке означает строковый номер транспортной накладной и не заменяет связь с сущностями ЭТРАН `Waybill`.

## Действия карточки

| UI-действие | Backend | Условие / эффект | Риск для UI |
|---|---|---|---|
| Редактировать | `PUT /receivingorder/{id}` | Bean Validation + update сервиса | Path/body ID mismatch; часть полей после создания неизменяема |
| Отправить | `PUT /receivingorder/{id}/review` | Блокировка, проверка перехода и всего агрегата, статус `ON_REVIEW` | Ошибка может относиться к другой вкладке |
| Отклонить / отменить | `PUT /receivingorder/{id}/reject` | Статус `REJECTED`, удаление всех связей с Waybill | Нужны подтверждение и предупреждение о потере связей |
| Принять | Публичный endpoint не найден | `ReceivingOrderService.accept(id)` существует и валидирует строже review | Кнопка не должна проектироваться без согласованного API и permission |
| Подтвердить документы | `PUT /receivingorder/{id}/confirm-document` | Только `ACCEPTED`/`IN_PROGRESS`, только из `null`, outbound на каждый КТК | Повторно изменить решение нельзя |
| Не подтвердить документы | `PUT /receivingorder/{id}/unconfirm-document` | Те же ограничения, значение `false` | Требуется ясное необратимое подтверждение |
| Частичная копия | `POST /receivingorder/{id}/partial-copy` | Создаёт новую заявку | Permission `RECEIVING_ORDER_COPY:READ` |
| Полная копия | `POST /receivingorder/{id}/full-copy` | Создаёт новую заявку с дочерними данными | Нужно открыть ID новой заявки и показать результат |

Повторный вызов review для уже `ON_REVIEW` и reject для уже `REJECTED` формально проходит общую проверку равенства текущего и целевого статуса. UI не должен использовать повторный вызов как обычный refresh; идемпотентность побочных эффектов нужно подтвердить отдельно.

## Маршрутизация ошибок по вкладкам

| Серверная проблема | Целевая вкладка | Ожидаемая реакция UI |
|---|---|---|
| Нет валюты, плановой даты или грузоотправителя | «Основное» | Открыть вкладку, выделить поле, сохранить server error code |
| Нет транспортной строки | «Рейсы» или отдельная транспортная секция | Показать действие создания/назначения; точное место согласовать |
| Нет товаров, цены, количества или суммы | «Груз» | Открыть строку с ошибкой, не терять введённые данные |
| Нет blackbox или общего количества мест | «Груз» | Переключить UI по `deliveryType` и показать нужный редактор |
| Нет КТК, веса, владельца, items; КТК занят или номер неизвестен | «КТК» | Открыть проблемный КТК и конкретную строку |
| Нет накладной или вагона накладной | «КТК»/«Просмотр» либо новая «Накладные» | Предоставить прямой путь к привязке Waybill |
| Тип вагона `UNDEFINED` при accept | ЖД-секция | Показать накладную и вагон, а не только общий toast |
| `403` дочернего endpoint | Текущая вкладка | Состояние forbidden вместо пустой таблицы |
| Ошибка одного из нескольких preview requests | «Просмотр» | Partial-error с повтором конкретного запроса; не выдавать неполную сводку за полную |

Тексты и коды ошибок перечислены в [каталоге ошибок](../../business-rules/order-errors.md#только-поставка). UI должен сохранять машинный код для диагностики, а пользователю показывать предметное объяснение и способ исправления.

## Компоненты ALIS Design System

| Зона карточки | Candidate components | Обязательные состояния |
|---|---|---|
| Навигация | `Navbar`, `Sidebar`, `Breadcrumbs` | active, collapsed, forbidden destination |
| Статус и действия | `Badge`, `Button`, `Tooltip`, `Pop-up` | status semantic, disabled reason, submitting, destructive confirmation |
| Вкладки | `Tab`, `Divider` | active, error marker, unread/changed marker, keyboard focus |
| Основная форма | `Input`, `Dropdown`, `Date picker`, `Checkbox`, `TextArea` | view/edit, required, invalid, disabled, server error |
| Таблицы дочерних данных | `Table`, `Pagination`, `Search`, `Dropdown` | loading, empty, filtered empty, partial error, read-only |
| Обратная связь | `Message`, `Preloader`, `Pop-up` | success, warning, validation, forbidden, retry |

Это проектное сопоставление с [каталогом компонентов](../design-system/component-inventory.md), а не подтверждение импорта компонентов в frontend.

## Требования для ТЗ

| ID | Требование | Состояние |
|---|---|---|
| `UIR-REC-TRACE-001` | Каждая вкладка должна иметь явно зафиксированные request, DTO, permission, loading, empty, forbidden и error states | `PROPOSAL` |
| `UIR-REC-TRACE-002` | «Отправить» должно запускаться после сохранения изменений и при ошибке открывать соответствующую вкладку/строку | `PROPOSAL` |
| `UIR-REC-TRACE-003` | Наличие и режим вкладок «КТК» и «Груз» должны определяться комбинацией `terminalArea`, `transportType` и `deliveryType` | `PROPOSAL` |
| `UIR-REC-TRACE-004` | Для ЖД-поставки карточка должна предоставлять путь к привязке Waybill и исправлению данных вагона | `PROPOSAL` |
| `UIR-REC-TRACE-005` | UI и backend должны отклонять несовпадающие path ID и `ReceivingOrderUpdateDto.id` | `PROPOSAL` |
| `UIR-REC-TRACE-006` | Отклонение должно предупреждать об удалении связей с накладными и требовать подтверждения | `PROPOSAL` |
| `UIR-REC-TRACE-007` | Preview не должен показываться как полный, если один из дочерних запросов завершился ошибкой | `PROPOSAL` |
| `UIR-REC-TRACE-008` | Ошибки дочерних permissions должны отображаться как forbidden, а не как пустые данные | `PROPOSAL` |
| `UIR-REC-TRACE-009` | Вкладка «Рейсы» должна быть переименована в единственное число либо модель множественных связей должна быть подтверждена и реализована | `PROPOSAL` |
| `UIR-REC-TRACE-010` | Машинный код серверной ошибки должен сохраняться в диагностике и сопоставляться с понятным текстом и действием пользователя | `PROPOSAL` |

## Вопросы аналитику и владельцам

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-REC-TRACE-001` | Какие фактические requests выполняются при открытии карточки и каждой вкладки? | Frontend owner |
| `GAP-UI-REC-TRACE-002` | «Просмотр» — экран проверки, печатная форма или сводка перед отправкой? | Product owner |
| `GAP-UI-REC-TRACE-003` | Где пользователь ЖД-поставки связывает накладные и исправляет вагон? | Логист / product owner |
| `GAP-UI-REC-TRACE-004` | Почему вкладка «Рейсы» во множественном числе при одном `route_id`? | Product/backend owner |
| `GAP-UI-REC-TRACE-005` | Какая секция владеет `ReceivingOrderTransport`: «Основное», «Рейсы» или отдельная форма? | Product owner |
| `GAP-UI-REC-TRACE-006` | Разрешено ли отклонять принятую/выполняемую заявку через карточку и кто имеет такое право? | Владелец процесса |
| `GAP-UI-REC-TRACE-007` | Нужна ли пользователю операция accept; если да, какой endpoint, permission и роль её выполняют? | Backend/security/process owner |
| `GAP-UI-REC-TRACE-008` | Должно ли решение по документам быть необратимым или требуется корректировка с аудитом? | Владелец процесса |
| `GAP-UI-REC-TRACE-009` | Требуется ли единый согласованный snapshot для вкладки «Просмотр»? | Backend/product owner |
| `GAP-UI-REC-TRACE-010` | Какой frontend route, build и роль пользователя соответствуют `UI-SNAPSHOT-002`? | Frontend/deployment owner |

## Что нужно для подтверждения runtime

1. HAR открытия карточки и последовательного переключения всех вкладок.
2. HAR редактирования, review, reject, ошибок review и подтверждения документов.
3. Frontend route/component source либо production source maps.
4. Матрица ролей с видимостью кнопок и фактическими `403`.
5. Снимки loading, empty, validation, forbidden, partial preview error и destructive confirmation.

После получения этих материалов candidate mappings переводятся из `INFERENCE` в `SOURCE_CONFIRMED` или `RUNTIME_CONFIRMED`, а неподтвердившиеся связи удаляются.

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `ab02fa985` (14.10.2026; ранее `971288126`, первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

### Запросы вкладок

| Вкладка | Когда видна | Запросы |
|---|---|---|
| Основное | всегда | `GET /receivingorder/{id}`; сохранение `POST /receivingorder/` / `PUT /receivingorder/{id}` |
| Рейс | контейнерные заявки; складские — при `needTransport=false` | `GET /routes/{id}` (текущий рейс, закреплён первым — с 14.10.2026, `370ad3c96`), список рейсов-кандидатов, `POST`/`DELETE /routes/{id}/assign`, создание рейса `POST /routes` |
| Накладные (ЖД) | `CONTAINER + RAILWAY` | выбор `POST waybill/for-receiving-order/page`, привязка `PUT /receivingorder/{id}/waybills`, чтение `POST /receivingorder/{id}/waybills` |
| Вагоны / КТК / груз накладных (ЖД) | `CONTAINER + RAILWAY` | `POST /receivingorder/{id}/waybill-railway-carriages/page`, `.../waybill-containers/page`, `.../waybill-products/page`; правка владельцев КТК — `PUT /receivingorder/{id}/waybill-containers/owners` |
| КТК и содержимое (авто) | `CONTAINER + VEHICLE` | список `POST /receiving-order/{id}/receiving-order-container-item/list`; запись — `POST /receiving-order/{id}/receiving-order-container/batch` и `.../receiving-order-container-item/batch` |
| Товары / грузовые места | `WAREHOUSE` по `deliveryType` | `receivingordergood`, `receivingorderblackbox`, `receivingordercargo` (построчные V1 create/update/delete); общее количество — `PUT /receivingorder/{id}/total-cargo-quantity` |
| Просмотр | режим просмотра | `GET /receivingorder/{id}/preview` |
| Печать | просмотр + права на отчёты | `GET /report/order/{id}/available`, `POST /report/receivingorder/{mx1,m7}/{id}/download` |

### Ответы на вопросы

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-REC-TRACE-001` | См. таблицу выше |
| `GAP-UI-REC-TRACE-002` | «Просмотр» — сводка заявки только для чтения из `/preview`, с кнопкой отмены; печатные формы вынесены в отдельную вкладку «Печать» |
| `GAP-UI-REC-TRACE-003` | Во вкладке «Накладные»: пользователь выбирает накладные из списка `waybill/for-receiving-order/page` и привязывает их к заявке; вагоны и КТК подтягиваются из накладных, редактируются только владельцы КТК. С 14.10.2026 все привязанные накладные стоят в начале списка выбора, у колонок есть локальные текстовые фильтры (`999b26824`, KIS-4863), а кандидаты включают накладные со статусом «Работа с документом окончена» (backend `059d5f5a`, KIS-4861) — [`UI-WB-011`](../../business-rules/waybill-ui-rules-as-is.md#правила) |
| `GAP-UI-REC-TRACE-004` | Рейс один; см. [карточку поставки](receiving-order-card.md#подтверждение-по-frontend-source) |
| `GAP-UI-REC-TRACE-005` | `ReceivingOrderTransport` во frontend не используется (сущность удалена в KIS-4093); транспорт задаётся рейсом |
| `GAP-UI-REC-TRACE-006` | Кнопка отмены видна в любом статусе при праве `ReceivingOrder.Reject`; ограничение по статусу — только серверное ([`UI-DIFF-09`](../../business-rules/order-ui-rules-as-is.md#реестр-расхождений-ui--backend)) |
| `GAP-UI-REC-TRACE-007` | Отдельного accept заявки в UI нет; accept выполняется через рейс |
| `GAP-UI-REC-TRACE-010` | Маршрут `/receiving-order/:id`; снимок сделан на сборке до KIS-4735 (на нём есть «Отправить»), build и роль по-прежнему неизвестны |
