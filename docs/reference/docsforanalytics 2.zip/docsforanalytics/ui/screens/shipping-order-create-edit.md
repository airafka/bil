# Создание и редактирование заявки на вывоз

Документ связывает варианты формы `ShippingOrder` с корневым и дочерними API, DTO, `deliveryType`, `fillingType`, серверной валидацией и порядком сохранения. Он предназначен для подготовки и автоматической проверки ТЗ.

Backend сверён с commit `22fac945e8116d04972ccc87b06b2303acf7a561`. В предоставленных Word-снимках виден реестр вывоза, но отдельная форма не показана; продуктовый Figma-файл относится к заявкам на поставку. Поэтому UI-композиция, подписи и screen→request для вывоза имеют статус `OPEN_QUESTION`/`INFERENCE`, а не переносятся с поставки по аналогии.

## Граница доказательности

| Утверждение | Статус | Основание |
|---|---|---|
| Корневой и дочерние endpoints, DTO, validators и permissions существуют | `SOURCE_CONFIRMED` | Backend source на зафиксированном commit |
| В рабочем UI есть реестр заявок на вывоз | `EXTERNAL_SNAPSHOT` | `UI-SNAPSHOT-002` |
| Состав формы и вызываемые endpoints | `SOURCE_CONFIRMED` (frontend) — см. [раздел ниже](#подтверждение-по-frontend-source) | frontend `ab02fa985` |
| Формы для всех `fillingType` реализованы; переключение типа после создания запрещено | `SOURCE_CONFIRMED` (frontend) | Partial states на стенде не проверялись |

## Две независимые классификации

`deliveryType` описывает складской груз. `fillingType` выбирает номерную или количественную модель вагонов/КТК. Эти поля нельзя объединять в один «тип заявки».

```mermaid
flowchart TD
    ROOT[ShippingOrder] --> AREA{terminalArea + transportType}
    AREA -->|WAREHOUSE + VEHICLE| DELIVERY{deliveryType}
    DELIVERY --> DG[BY_GOOD]
    DELIVERY --> DB[BY_CARGO]
    DELIVERY --> DGC[BY_GOOD_WITH_CARGO_WITH_DETAILS]
    AREA -->|CONTAINER + VEHICLE| AUTO{КТК}
    AUTO --> AK[Номерные КТК]
    AUTO --> ANC[NONE_CONTAINER<br/>один порожний без номера]
    AREA -->|CONTAINER + RAILWAY| FILLING{fillingType}
    FILLING --> ALL[ALL<br/>номера вагонов и КТК]
    FILLING --> RC[RAILWAY_CARRIAGE<br/>номера вагонов]
    FILLING --> CT[CONTAINER<br/>номера КТК]
    FILLING --> NONE[NONE<br/>без номеров]
```

Для `WAREHOUSE + VEHICLE` сервер требует `deliveryType`. Вне этой комбинации create нормализует его в `null`. `NONE_CONTAINER` разрешён только для `CONTAINER + VEHICLE`. Для `CONTAINER + RAILWAY` пустой `fillingType` нормализуется в `ALL`; JPA `@PrePersist` также подставляет `ALL` при `null`.

Серверная проверка не ограничивает прочие значения `fillingType` комбинацией площадки/транспорта. Поэтому UI не должен считать все значения enum бизнес-допустимыми для авто или склада только потому, что request принят. Целевая матрица требует решения аналитика.

## Матрица состава формы

| Комбинация | Выбор | Номерные данные | Плановые данные | Review/accept требует |
|---|---|---|---|---|
| Склад + авто | `BY_GOOD` | товары | — | транспорт, минимум один товар; количество, цена и сумма > 0 |
| Склад + авто | `BY_CARGO` | складской `ShippingOrderBlackbox` | — | транспорт и минимум одно грузовое место |
| Склад + авто | `BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары + `ShippingOrderCargo` | — | транспорт, товары и детальные грузовые места |
| КТК + авто | обычный номерной сценарий | `ShippingOrderContainer` + items | — | транспорт, минимум один КТК, свойства и согласованность `empty/items` |
| КТК + авто | `NONE_CONTAINER` | — | ровно один `ShippingOrderContainerQty` | `quantity=1`, `empty=true`, `items=[]` |
| КТК + ЖД | `ALL` | ETRAN membership, вагоны, КТК | — | ETRAN, вагоны; у каждого вагона ETRAN; свойства КТК |
| КТК + ЖД | `RAILWAY_CARRIAGE` | вагоны | `ShippingOrderContainerQty` | вагоны; свойства имеющихся КТК; отдельное требование наличия qty валидатором не подтверждено |
| КТК + ЖД | `CONTAINER` | КТК без номерных вагонов | `ShippingOrderRailwayCarriageQty` | минимум одна qty-строка вагонов; свойства имеющихся КТК |
| КТК + ЖД | `NONE` | — | `ShippingOrderRailwayCarriageQty` + `ShippingOrderContainerQty` | минимум одна qty-строка вагонов; наличие qty КТК accept-validator отдельно не проверяет |

Таблица разделяет intended plan/fact model по [сводной integrity-карте](../../database/shipping-order-integrity-map.md). Она также показывает пробелы текущего validator: отсутствие проверки не следует превращать в бизнес-разрешение без подтверждения.

## Корень формы: create и update

Create использует [ShippingOrderCreationDto](../../dto/shipping-order/ShippingOrderCreationDto.md), update — [ShippingOrderUpdateDto](../../dto/shipping-order/ShippingOrderUpdateDto.md).

| UI-поле / JSON | Create | Update DTO | Фактическая серверная семантика |
|---|---:|---:|---|
| `id` | Серверное | Обязательно | Target ищется по `body.id`; path `{id}` не сверяется |
| `orderStatus` | Обязательно | Обязательно | Create заменяет значение на `DRAFT`; обычный update статус не меняет |
| `client` | Обязательно | Обязательно | После create не меняется |
| `contract` | Обязательно | Обязательно | Может меняться; принадлежность договору клиента в root service не подтверждена |
| `terminalArea` | Обязательно | Обязательно | После create не меняется; ЖД разрешена только для `CONTAINER` |
| `transportType` | Обязательно | Обязательно | После create не меняется |
| `deliveryType` | Условно | Поле присутствует | При create обязателен для склада+авто; обычный update новое значение не переносит |
| `fillingType` | Необязательно | Поле присутствует | Create сохраняет/нормализует; обычный update новое значение не переносит |
| `plannedShippingDateTime` | Необязательно | Необязательно | Update меняет/очищает; обязательно перед review/accept |
| `currency` | Необязательно | DTO допускает `null` | Обязательна перед review; update с `null` способен упасть при разыменовании `currency.id` |
| `contact` | Необязательно | Необязательно | Меняется только при non-null; очистка не подтверждена |
| `comment` | Необязательно | Необязательно | Может быть очищен |
| `consignee` | Необязательно | Необязательно | Для `CONTAINER` обязателен перед review; проверяются роль и принадлежность клиенту; `null` очищает адрес |
| `consigneeAddress` | Необязательно | Необязательно | Присланное значение игнорируется: сохраняется `addressFact` выбранного грузополучателя |
| `route` | Необязательно | Необязательно | Может меняться; это одна ссылка на рейс |
| `needTransport` | Необязательно | Поле присутствует | Обычный update не переносит значение |

На update-форме клиент, площадка, транспорт, `deliveryType`, `fillingType` и `needTransport` нельзя показывать как обычные сохраняемые поля: request DTO создаёт ложное ожидание изменяемости. ID в URL и body UI обязан сверять до отправки.

## Дочерние редакторы

| Секция | Candidate API | DTO / request-обязательность | Ключевая серверная логика |
|---|---|---|---|
| Автотранспорт | *(удалено KIS-4093, коммит `d30d77ad`, 24 сентября 2026)* `/shippingordertransport/...` и `ShippingOrderTransportCreationDto` больше не существуют | `consignee`/`consigneeAddress` слиты `COALESCE` в корневой DTO заявки (конфликт root/transport-версий, описанный ранее, снят — поле теперь одно); `carrier`/ТС/водитель — через назначение [Route](../../entities/catalog/entities/route/Route.md) | Проверка при accept — `route != null`, а не наличие отдельной transport-строки |
| Товар | `/shippingordergood/...`, scoped batch | [ShippingOrderGoodCreationDto](../../dto/catalog/shippingordergood/ShippingOrderGoodCreationDto.md): заявка, товар, `plannedQuantity>0`, `price>=0`, `totalPrice>=0`; `batch` optional в DTO, `batchUnknown` (с 13.10.2026, `8ee1ab68`, KIS-4841) | Review требует цену и сумму строго > 0. С 13.10.2026 (`8ee1ab68`, KIS-4841) при add/update service требует партию или `batchUnknown=true` для товара с партионным учётом (`OrderGood.MissingBatch`), запрещает `batchUnknown` с партией или без учёта — см. [товарную строку](../../database/shipping-order-good-as-is.md); раньше партию проверял только UI |
| Складское место | `/shippingorderblackbox/...` | [ShippingOrderBlackboxCreationDto](../../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxCreationDto.md): заявка, непустой `cargo` до 100 | Используется только `BY_CARGO` |
| Детальный груз | `/shippingordercargo/...`, batch | [ShippingOrderCargoCreationDto](../../dto/catalog/shippingordercargo/ShippingOrderCargoCreationDto.md): заявка, товар, `cargo`; размеры/количества при наличии `>=0` | Нулевые и `null` количества проходят текущую проверку; cross-parent consistency требует отдельного контроля |
| Номерной вагон | scoped `/shipping-order/{id}/shipping-order-railway-carriage/merge` | [ShippingOrderRailwayCarriageMergeDto](../../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageMergeDto.md) | Full desired list; permission уровня `DELETE`; `ALL` группирует вагоны под ETRAN |
| План вагонов | `/shipping-order/{id}/shipping-order-railway-carriage-qty/merge` | [ShippingOrderRailwayCarriageQtyDto](../../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyDto.md) | Только `CONTAINER/NONE`; `quantity=0` проходит DTO, но нарушает SQL `>0`; merge source-level неатомарен |
| Номерной КТК | scoped `/shipping-order/{id}/shipping-order-container/merge` | [ShippingOrderContainerMergeDto](../../dto/catalog/shippingordercontainer/ShippingOrderContainerMergeDto.md) | Full desired list; permission `DELETE`; для `CONTAINER` есть отдельный `/unnumbered/merge` variant |
| План КТК | `/shipping-order/{id}/shipping-order-container-qty/merge` | [ShippingOrderContainerQtyDto](../../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyDto.md): quantity, type, empty, items | Только `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER`; parent+items merge транзакционный |
| Содержимое планового КТК | nested `items` qty DTO | [ShippingOrderEtsngCodeDto](../../dto/catalog/shippingorderetsngcode/ShippingOrderEtsngCodeDto.md) | На `items` нет `@Valid`; `weight=0` проходит DTO, но SQL требует `>0` |
| ETRAN membership | scoped `.../shipping-order-etran-invoice/merge` | [ShippingOrderEtranInvoiceMergeDto](../../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceMergeDto.md) | Не равно global ETRAN; membership и вагонные ссылки должны быть согласованы |
| Содержимое номерного КТК | container item API | [ShippingOrderContainerItemCreationDto](../../dto/catalog/shippingordercontainer/ShippingOrderContainerItemCreationDto.md): заявка, КТК, `wightGross` | Опечатка `wight*` является фактическим JSON/Java contract; positivity не валидируется DTO |

### Условная валидация номерного КТК

Class-level `ValidShippingOrderContainer` повторяет правила поставки:

- `empty` обязательно;
- при `ktkNumberUnknown=true` остальные условные поля validator не требует;
- при известном номере обязательны `container.id` и `customsClearance`;
- для известного непорожнего КТК обязательны `dangerClass.id` и `sealType.id`;
- review проверяет положительный вес, владельца и согласованность `empty` с items;
- неизвестный номер допустим на review, но запрещён при accept.

## Переключение `fillingType`: текущий AS-IS

Обычный `PUT /shippingorder/{id}` не сохраняет новое значение `fillingType`. Даже если значение было бы изменено другим writer-ом, найденной автоматической очистки несовместимых строк нет.

| Переход | Данные, которые должны стать неактивными или быть преобразованы |
|---|---|
| `ALL → RAILWAY_CARRIAGE` | Номерные КТК → плановые qty КТК; решить судьбу ETRAN membership |
| `ALL → CONTAINER` | Номерные вагоны → qty вагонов; решить судьбу wagon→ETRAN links |
| `ALL → NONE` | Оба номерных набора → обе qty-модели |
| `RAILWAY_CARRIAGE ↔ CONTAINER` | Поменять plan/fact модель одновременно для вагонов и КТК |
| Любой ЖД-тип → авто `NONE_CONTAINER` | Недопустимо без смены неизменяемого transport type; требуется новая заявка или отдельная операция |

Физическая БД не обеспечивает взаимоисключение plan/fact. Stale rows могут сохраниться, а route chain package экспортирует физические и qty-строки без фильтра по текущему `fillingType`. До появления атомарной серверной операции UI должен блокировать смену типа после создания и предлагать создание новой/копирование заявки.

## Порядок сохранения

```mermaid
sequenceDiagram
    actor U as Пользователь
    participant UI as Форма вывоза
    participant ROOT as ShippingOrder API
    participant CHILD as Child merge/CRUD API
    participant REVIEW as Review validator
    U->>UI: Выбирает классификацию
    UI->>ROOT: POST /shippingorder/
    ROOT-->>UI: id + status=DRAFT + normalized fields
    loop Секции выбранной модели
        UI->>CHILD: CRUD или full-replace merge
        CHILD-->>UI: success / error
    end
    UI->>REVIEW: PUT /shippingorder/{id}/review
    REVIEW->>REVIEW: Читает сохранённый агрегат
    REVIEW-->>UI: ON_REVIEW или список кодов
```

1. Сначала сохраняется root и получается ID.
2. Затем сохраняются транспорт и только дочерние части выбранной модели.
3. Merge endpoints трактуют вход как полный желаемый список: пропущенные строки удаляются, а `[]` может означать полную очистку.
4. Review запускается после завершения всех writes и читает БД, а не несохранённое состояние UI.
5. Единой транзакции всей формы нет. Более того, wagon qty merge имеет отдельный source-level transaction gap, тогда как container qty merge транзакционный.

## Состояния формы

| Состояние | Требуемое поведение |
|---|---|
| Dirty | Отдельно учитывать root и каждую full-replace секцию; предупреждать перед закрытием |
| Root pending / duplicate | Один in-flight create; child writes только после ID; idempotency key не подтверждён |
| Partial save | Показать сохранённые секции и ссылку на DRAFT; перечитать спорную секцию до retry |
| Merge preview | Перед full-replace показать добавления/изменения/удаления; особенно при `[]` |
| Validation `400` | Сопоставить ошибку с полем/строкой; различать DTO `>=0` и DB `>0` |
| `403` | Read-only с объяснением permission/status; merge требует максимальный уровень `DELETE` |
| Unknown network outcome | Read-back перед повтором, чтобы не продублировать create и не стереть список повторным merge |
| Scenario mismatch | Не скрывать stale секцию без решения: блокировать review и предложить явную очистку/возврат |
| Concurrent edit | Optimistic version в DTO не найдена; предупреждать о last-write-wins/full-replace риске |

## Маршрутизация server errors

Полный перечень находится в [каталоге ошибок](../../business-rules/order-errors.md).

| Код / группа | Секция исправления |
|---|---|
| `ShippingOrder.InvalidTerminalAreaTransportType`, `.MissingDeliveryType`, `.InvalidFillingType` | Основное / классификация |
| `ShippingOrder.MissingCurrency`, `.MissingPlannedShippingDateTime`, `.MissingConsignee` | Основное |
| `ShippingOrder.InvalidConsigneeClient`, `.InvalidConsigneeRole` | Грузополучатель |
| `ShippingOrder.MissingTransport` | Рейс / транспорт |
| `ShippingOrder.MissingGoods`, `ShippingOrderGood.Missing*` | Номенклатура |
| `ShippingOrder.MissingBlackbox`, `.MissingCargos`, `.MissingCargo`, `ShippingOrderCargo.Missing*` | Складские грузовые места |
| `ShippingOrder.MissingContainers`, `.InvalidNoneContainerData` | КТК / план КТК |
| `ShippingOrderContainer.*.MissingWeight`, `.MissingOwnerContainer`, `ShippingOrder.ItemsMissingForContainers`, `.EmptyContainerCantHaveItems`, `.ContainerAlreadyInUse`, `.KtkNumberUnknown` | Номерной КТК и items |
| `ShippingOrder.MissingEtranInvoice`, `.MissingRailwayCarriages`, `.MissingRailwayCarriageEtranInvoice` | ЭТРАН / вагоны / план вагонов |

Review объединяет коды строкой через `", "`. Для надёжной навигации форме нужен структурированный массив ошибок с section, row/object ID и field; текущий формат этого не гарантирует.

## Риски для проверки ТЗ

1. `fillingType`, `deliveryType` и `needTransport` есть в update DTO, но обычный update их не переносит.
2. Plan/fact строки могут сосуществовать; БД не обеспечивает соответствие текущему `fillingType`.
3. Root и дочерние секции не имеют общей транзакции; wagon qty merge дополнительно неатомарен source-level.
4. `quantity=0`/`weight=0` местами проходит Bean Validation, но нарушает SQL `>0`.
5. Full-replace merge использует permission `DELETE` и способен удалить отсутствующие во входе строки.
6. `consigneeAddress` root вычисляется сервером; transport хранит отдельную, менее проверенную копию consignee/address.
7. `PUT /shippingorder/{id}` доверяет `body.id`.
8. Публичный accept endpoint не найден, хотя сервис реализован.
9. Review не требует qty КТК для всех ЖД-веток, где plan/fact-модель предполагает их наличие.
10. Route/outbound consumers по-разному выбирают plan/fact и могут экспортировать stale данные.

## Требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-SHIP-FORM-001` | До дочерних секций форма создаёт root, получает ID и показывает сохранённый `DRAFT` | `PROPOSAL` |
| `UIR-SHIP-FORM-002` | `deliveryType` и `fillingType` показываются как разные классификации с отдельными пояснениями | `PROPOSAL` |
| `UIR-SHIP-FORM-003` | UI допускает только согласованную матрицу площадка×транспорт×тип, а не все enum-значения | `PROPOSAL` |
| `UIR-SHIP-FORM-004` | После create классифицирующие поля read-only до появления атомарной операции смены модели | `PROPOSAL` |
| `UIR-SHIP-FORM-005` | Номерные и qty-редакторы взаимоисключаются по `fillingType`; скрытые stale данные не игнорируются молча | `PROPOSAL` |
| `UIR-SHIP-FORM-006` | Перед merge показывается diff; пустой список требует подтверждения полной очистки | `PROPOSAL` |
| `UIR-SHIP-FORM-007` | Required-маркеры различают DTO-, DB- и review-required ограничения | `PROPOSAL` |
| `UIR-SHIP-FORM-008` | После partial/unknown result UI перечитывает root и затронутую секцию перед retry | `PROPOSAL` |
| `UIR-SHIP-FORM-009` | Review выполняется только после всех writes и маршрутизирует ошибки в root/goods/cargo/КТК/вагоны/ETRAN | `PROPOSAL` |
| `UIR-SHIP-FORM-010` | ID URL/body и parent IDs каждой дочерней строки проверяются клиентом до запроса | `PROPOSAL` |
| `UIR-SHIP-FORM-011` | UI использует фактические имена `wightGross/wightNet` только в transport contract, но показывает корректные бизнес-подписи | `PROPOSAL` |
| `UIR-SHIP-FORM-012` | Для формы должен быть создан отдельный Figma flow с версиями AS-IS/TO-BE и всеми состояниями | `PROPOSAL` |

## Вопросы аналитику и владельцам системы

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-SHIP-FORM-001` | Какие `fillingType` допустимы для склада и КТК+авто, кроме специального `NONE_CONTAINER`? | Бизнес-аналитик |
| `GAP-UI-SHIP-FORM-002` | Должны ли `RAILWAY_CARRIAGE` и `NONE` обязательно иметь `ContainerQty`, хотя accept это не проверяет? | ЖД-бизнес-владелец |
| `GAP-UI-SHIP-FORM-003` | Как пользователь меняет `deliveryType/fillingType`, если обычный update их не сохраняет? | Product/backend owner |
| `GAP-UI-SHIP-FORM-004` | При смене модели старые строки удаляются, мигрируются или смена запрещается? | Архитектор/бизнес-аналитик |
| `GAP-UI-SHIP-FORM-005` | Какой V1/V2/batch/merge API является целевым для каждой секции? | Backend/frontend owner |
| `GAP-UI-SHIP-FORM-006` | Требуется ли атомарный aggregate save или saga/idempotency protocol? | Архитектор |
| `GAP-UI-SHIP-FORM-007` | Должны ли quantity/weight быть строго `>0` во всех DTO и UI? | Бизнес-аналитик/backend owner |
| `GAP-UI-SHIP-FORM-008` | Какой из root и transport consignee/address является source of truth? | Бизнес-владелец |
| `GAP-UI-SHIP-FORM-009` | Через какой публичный endpoint и permission выполняется accept? | Process/backend owner |
| `GAP-UI-SHIP-FORM-010` | Где находятся актуальные макеты create/edit вывоза и к какому релизу относятся? | Product/design owner |

## Связанные документы

- [Бизнес-правила вывоза](../../business-rules/shipping-orders.md)
- [Карта обязательности](../../business-rules/order-validation.md#вывоз-корневой-request)
- [Физический корень](../../database/shipping-order-root-as-is.md)
- [Сводная integrity-карта](../../database/shipping-order-integrity-map.md)
- [План вагонов](../../database/shipping-order-railway-carriage-qty-as-is.md)
- [План КТК](../../database/shipping-order-container-qty-as-is.md)
- [Route plan/fact](../../business-rules/route-shipping-plan-fact-as-is.md)

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `ab02fa985` (14.10.2026; ранее `971288126`, первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

Поля, обязательность и зависимости основной формы — в [UI-правилах заявок](../../business-rules/order-ui-rules-as-is.md#вывоз-основная-форма), состав вкладок по `fillingType` — в [матрице вкладок](../../business-rules/order-ui-rules-as-is.md#состав-вкладок-карточки).

| Секция | API |
|---|---|
| Основное | `POST /shippingorder/`, `PUT /shippingorder/{id}` |
| Товары, грузовые места с детализацией | batch: `POST /shippingordergood/{id}/batch`, `POST /shippingordercargo/{id}/batch` |
| Blackbox | `shippingorderblackbox` V1 create/delete |
| КТК, содержимое КТК, номерные/безномерные вагоны, количество КТК и вагонов | merge: `PUT /shipping-order/{id}/shipping-order-{container,container-item,railway-carriage,railway-carriage-qty,container-qty}/merge`, а также `.../container/unnumbered/merge` и `.../railway-carriage/unnumbered/merge`; чтение — соответствующие `/list` |
| ЭТРАН | `POST /shippingorder/{id}/shipping-order-etran-invoice/merge`; новая накладная — `POST /etraninvoice/`. Текущие связи читаются полностью постраничным `POST shippingorderetraninvoice/page` (с 09.10.2026, `74362d4bb`; раньше только первые 25); после загрузки вагонов из Excel связи перечитываются ([`UI-ORDER-013`](../../business-rules/order-ui-rules-as-is.md#общие-правила), [`UI-ORDER-015`](../../business-rules/order-ui-rules-as-is.md#общие-правила)) |

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-SHIP-FORM-001` | Для склада `fillingType` не задаётся (`null`). Для КТК+авто — `ALL` или `NONE_CONTAINER`; для КТК+ЖД — `ALL`, `RAILWAY_CARRIAGE`, `CONTAINER`, `NONE` |
| `GAP-UI-SHIP-FORM-003`, `004` | В UI `deliveryType` и `fillingType` после создания заблокированы — сменить модель нельзя, вопрос удаления строк не возникает |
| `GAP-UI-SHIP-FORM-005` | См. таблицу выше |
| `GAP-UI-SHIP-FORM-007` | Нет: товар — `>= 0`, `packageQuantity` — пусто или `>= 0`; вес содержимого КТК обязателен, но без проверки знака ([`UI-DIFF-06`](../../business-rules/order-ui-rules-as-is.md#реестр-расхождений-ui--backend)) |
| `GAP-UI-SHIP-FORM-008` | UI работает только с корневыми `consignee`/`consigneeAddress`; при смене грузополучателя адрес заменяется его `addressFact` |
| `GAP-UI-SHIP-FORM-009` | Accept заявки в UI нет; заявка подтверждается через accept рейса ([`UI-ROUTE-008`](../../business-rules/route-ui-rules-as-is.md#правила)) |
