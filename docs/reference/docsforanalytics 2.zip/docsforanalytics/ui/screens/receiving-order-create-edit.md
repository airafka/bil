# Создание и редактирование заявки на поставку

Документ связывает шесть спроектированных в Figma вариантов формы поставки с корневым `ReceivingOrder`, дочерними DTO, серверной валидацией, permissions и порядком сохранения. Это карта для подготовки ТЗ и проверки требований LLM, а не доказательство фактической реализации frontend.

Backend сверён с commit `22fac945e8116d04972ccc87b06b2303acf7a561`. Макеты просмотрены в live Figma-файле [«Заявки на поставку»](../figma/receiving-orders.md) 23.09.2026. Frontend source, HAR и версия Figma/release не предоставлены, поэтому конкретный screen→request помечается `INFERENCE`.

## Граница доказательности и версии интерфейса

| Утверждение | Статус | Основание |
|---|---|---|
| В Figma есть создание/просмотр/редактирование для склада+авто, КТК+авто и КТК+ЖД | `EXTERNAL_SNAPSHOT` | Живой продуктовый Figma-файл |
| В складской ветке спроектированы четыре способа описания состава | `EXTERNAL_SNAPSHOT` | Именованные группы Figma |
| Root и дочерние endpoints, DTO, permissions и validators существуют | `SOURCE_CONFIRMED` | Backend source на зафиксированном commit |
| Экран вызывает перечисленные endpoints | `SOURCE_CONFIRMED` (frontend) — см. [раздел ниже](#подтверждение-по-frontend-source) | frontend `971288126` |
| Autosave, восстановление черновика, защита от повторной отправки и единый rollback реализованы | `OPEN_QUESTION` | В Figma и backend aggregate endpoint не найдены |

Рабочий снимок и продуктовый макет показывают разные композиции вкладок. В `UI-SNAPSHOT-002` видны «Основное», «Рейсы», «КТК», «Груз», «Просмотр». На просмотренном Figma-холсте видны проектные зоны «Основное», «Рейс», «Номенклатура», «Контейнеры», «Просмотр», «Документы». Это следует считать расхождением версий источников, а не объединять в подтверждённую AS-IS навигацию.

## Шесть вариантов формы

| Сценарий | Корневые признаки | Состав после создания корня | Review/accept проверяет |
|---|---|---|---|
| Склад, авто, по номенклатуре | `WAREHOUSE + VEHICLE + BY_GOOD` | `ReceivingOrderGood` | Транспорт и минимум один товар; количество, цена и сумма > 0 |
| Склад, авто, по контейнерам | `WAREHOUSE + VEHICLE + BY_CARGO` | `ReceivingOrderBlackbox` | Транспорт и минимум одно складское грузовое место |
| Склад, авто, номенклатура + контейнеры без детализации | `WAREHOUSE + VEHICLE + BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` | товары + `totalCargoQuantity` | Транспорт, товары и общее количество мест |
| Склад, авто, номенклатура + контейнеры с детализацией | `WAREHOUSE + VEHICLE + BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары + `ReceivingOrderCargo` | Транспорт, товары и детальные грузовые места |
| Контейнерная площадка, авто | `CONTAINER + VEHICLE`; `deliveryType` нормализуется в `null` | транспорт + `ReceivingOrderContainer` + items | Транспорт, КТК, вес, владелец и согласованность `empty/items`; неизвестный номер запрещён при accept |
| Контейнерная площадка, ЖД | `CONTAINER + RAILWAY`; `deliveryType` нормализуется в `null` | Waybill → вагоны → КТК/товары накладной | Waybill и вагон; свойства имеющихся КТК; при accept тип вагона не `UNDEFINED` |

Термин «контейнер» в складских макетах не равен железнодорожному/морскому КТК. Для `BY_CARGO` backend использует `ReceivingOrderBlackbox`, для детализированной складской ветки — `ReceivingOrderCargo`, а для контейнерной площадки — `ReceivingOrderContainer`.

```mermaid
flowchart TD
    START[Новая поставка] --> AREA{Площадка}
    AREA -->|WAREHOUSE| WV[Только VEHICLE]
    WV --> TYPE{deliveryType}
    TYPE --> GOOD[BY_GOOD<br/>товары]
    TYPE --> BOX[BY_CARGO<br/>blackbox]
    TYPE --> TOTAL[GOOD + общее число мест]
    TYPE --> DETAIL[GOOD + детальные Cargo]
    AREA -->|CONTAINER| TRANSPORT{transportType}
    TRANSPORT --> AUTO[VEHICLE<br/>транспорт + КТК/items]
    TRANSPORT --> RAIL[RAILWAY<br/>Waybill + вагоны + КТК]
```

## Корень формы: поля, lookup и изменяемость

Create использует [ReceivingOrderCreationDto](../../dto/receiving-order/ReceivingOrderCreationDto.md), update — [ReceivingOrderUpdateDto](../../dto/receiving-order/ReceivingOrderUpdateDto.md), общие поля — [ReceivingOrderBaseDto](../../dto/receiving-order/ReceivingOrderBaseDto.md).

| UI-поле / JSON | Create | Update | Lookup / серверное правило |
|---|---:|---:|---|
| `id` | Нет, выдаёт сервер | Обязательно в body | Update ищет запись по `body.id`; `{id}` URL контроллер не сверяет |
| `client` | Обязательно | Обязательно, но фактически не меняется | `IdDto`; клиент задаёт область данных и доступные договоры/товары |
| `contract` | Обязательно | Обязательно, может меняться | `IdDto`; сервер разыменовывает договор и пересобирает обязательные заказанные услуги при create |
| `terminalArea` | Обязательно | Обязательно, но фактически не меняется | Значим `code`: `WAREHOUSE`/`CONTAINER` |
| `transportType` | Обязательно | Обязательно, но фактически не меняется | `VEHICLE`/`RAILWAY`; ЖД разрешена только для `CONTAINER` |
| `deliveryType` | Условно обязательно | Условно обязательно | Обязательно только для `WAREHOUSE + VEHICLE`; иначе сервер create сбрасывает `null` |
| `orderStatus` | Формально обязательно | Обязательно | При create входное значение игнорируется и сохраняется `DRAFT` |
| `planReceivingDateTime` | Необязательно | Необязательно | Необходимо перед review/accept |
| `currency` | Необязательно | DTO допускает отсутствие | Необходимо перед review/accept; update с `null` небезопасен из-за разыменования `currency.id` |
| `storagePeriod` | Необязательно | Необязательно | Если задан, `>= 0` |
| `shipper` | Необязательно | Необязательно | Необходим перед review/accept для `CONTAINER`; update допускает очистку |
| `contact` | Необязательно | Необязательно | Update меняет только при непустом объекте, поэтому очистка через этот request не подтверждена |
| `comment`, `needTransport`, `route`, `waybill` | Необязательно | Необязательно | `route` — одна ссылка; строковый `waybill` не заменяет связь с сущностью ЭТРАН `Waybill` |
| `payerId`, `departureStationId`, `destinationStationId` | Условно | Полей нет | Только create; обязательны для `CONTAINER + RAILWAY`, если `RAILWAY_FIELDS_REQUIRED=true` |
| `carrier` | Deprecated | Deprecated | Mapper игнорирует; использовать `shipper` или дочерний transport по смыслу |

На форме редактирования площадку, вид транспорта и клиента следует показывать read-only, пока отдельное серверное изменение не подтверждено. Для `PUT /receivingorder/{id}` UI обязан отправлять `body.id`, совпадающий с ID открытой карточки; это компенсирует, но не устраняет серверный gap path/body.

## Дочерние редакторы и обязательность request DTO

Корневой DTO не содержит транспорт, товары, грузовые места, КТК и накладные. Они сохраняются отдельными запросами.

| Редактор | Candidate write API | DTO и обязательные поля request | Дополнительная серверная семантика |
|---|---|---|---|
| Транспорт | *(удалено KIS-4093, коммит `d30d77ad`, 24 сентября 2026)* `POST/PUT /receivingordertransport/*` и `ReceivingOrderTransportCreationDto` больше не существуют | `shipper`/`waybill` перенесены на корневой DTO заявки; `carrier`/`clientVehicle`/`clientDriver` теперь определяются через назначение [Route](../../entities/catalog/entities/route/Route.md) (`RouteController`), а не отдельным DTO транспорта заявки | Проверка при accept — `route != null`, а не наличие отдельной transport-строки |
| Товар | `/receivingordergood/...`, включая batch endpoints | [ReceivingOrderGoodCreationDto](../../dto/catalog/receivingordergood/ReceivingOrderGoodCreationDto.md): заявка, `clientGood`, `plannedQuantity > 0`, `price >= 0`, `totalPrice >= 0`; `batch` optional в DTO, `batchUnknown` (с 13.10.2026, `8ee1ab68`, KIS-4841) | Review строже DTO: `price` и `totalPrice` должны быть > 0. С 13.10.2026 (`8ee1ab68`, KIS-4841) при add/update service требует партию или `batchUnknown=true` для товара с партионным учётом (`OrderGood.MissingBatch`), запрещает `batchUnknown` с партией или без учёта — см. [товарную строку](../../database/receiving-order-good-as-is.md); раньше партию проверял только UI |
| Складское место `BY_CARGO` | `/receivingorderblackbox/...` | [ReceivingOrderBlackboxCreationDto](../../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxCreationDto.md): заявка и непустой `cargo`, максимум 100 | Это не КТК и не детальный `ReceivingOrderCargo` |
| Детальное грузовое место | `/receivingordercargo/...` | [ReceivingOrderCargoCreationDto](../../dto/catalog/receivingordercargo/ReceivingOrderCargoCreationDto.md): заявка, товар, непустой `cargo`; числовые поля, если заданы, `>= 0` | `barcode` скрыт; `goodPackage` optional; cross-parent consistency не обеспечена DTO |
| Общее число мест | `GET/POST/PUT /receivingorder/{id}/total-cargo-quantity` | [ReceivingOrderTotalCargoQuantityDto](../../dto/catalog/receivingorder/ReceivingOrderTotalCargoQuantityDto.md) | Используется только в ветке без детализации |
| КТК | legacy `/receivingordercontainer/...` либо scoped batch `/receiving-order/{orderId}/receiving-order-container/batch` | [ReceivingOrderContainerCreationDto](../../dto/catalog/receivingordercontainer/ReceivingOrderContainerCreationDto.md): заявка и `empty`; условные поля ниже | Scoped batch требует permission уровня `DELETE` даже для add/update |
| Содержимое КТК | legacy `/receivingordercontaineritem/...` либо scoped `/receiving-order/{orderId}/receiving-order-container-item/batch` | [ReceivingOrderContainerItemCreationDto](../../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemCreationDto.md): заявка, КТК, `wightGross`; прочее optional | В DTO сохранено опечатанное имя JSON/Java `wightGross`; отрицательные значения Bean Validation не запрещает |
| Накладные ЖД | `PUT /receivingorder/{id}/waybills` | [WaybillSelectionDto](../../dto/catalog/waybill/WaybillSelectionDto.md) | Заменяет набор связей; review затем читает Waybill и вагоны из БД |

### Условная обязательность КТК

Для `ReceivingOrderContainerCreationDto` действует class-level validator:

- `empty` обязательно всегда;
- если `ktkNumberUnknown=true`, validator не требует `container`, `customsClearance`, `dangerClass` и `sealType`;
- если номер известен, обязательны `container.id` и `customsClearance`;
- для известного непорожнего КТК дополнительно обязательны `dangerClass.id` и `sealType.id`;
- каждый `sealNumbers[]`, если список задан, должен быть непустой строкой длиной до 50;
- при review/accept отдельно проверяются вес, владелец и согласованность `empty` с items.

## Lookup и inline-create

| Поле / действие Figma | Candidate источник | Что требуется зафиксировать в frontend/TЗ |
|---|---|---|
| Клиент → договор → товар | Справочники Client, Contract, ClientGood | Зависимые lookup очищаются при смене родителя; нельзя сохранять ID из прежнего клиента |
| Партия товара | Batch API; в Figma есть «Создание новой партии» | Permission, обязательные даты/код, результат create и автоматическая установка новой партии в строку |
| Новый складской контейнер/место | Blackbox/Cargo в зависимости от `deliveryType` | Термин и endpoint должны определяться сценарием, а не одной подписью «контейнер» |
| Новый КТК | Container catalog + ReceivingOrderContainer | Создание справочного КТК и добавление его в заявку — разные бизнес-операции; атомарность не подтверждена |
| Новый рейс | `POST /routes`, затем `POST /routes/{id}/assign` | Две операции и риск «рейс создан, но заявка не назначена» описаны в [карточке рейса](route-tabs-and-actions.md) |
| Новый тип ЗПУ | Справочник типа пломбы/ЗПУ | Точный endpoint, permission и владелец справочника не установлены |
| Накладная ЭТРАН | `/waybill/for-receiving-order/page`, затем bulk link | Фильтр доступных накладных, client scope и защита от перепривязки требуют подтверждения |

После успешного inline-create модальное окно должно вернуть ID и отображаемое имя, установить значение в исходную форму и сохранить остальные несохранённые поля. Закрытие/ошибка дочерней формы не должны очищать основной черновик.

## Порядок сохранения и граница транзакции

```mermaid
sequenceDiagram
    actor U as Пользователь
    participant UI as Форма
    participant ROOT as ReceivingOrder API
    participant CHILD as Дочерние API
    participant REVIEW as Review validator
    U->>UI: Заполняет общие поля
    UI->>ROOT: POST /receivingorder/
    ROOT-->>UI: ReceivingOrderDto, id, status=DRAFT
    loop Каждая секция
        UI->>CHILD: create/update/delete с receivingOrder.id
        CHILD-->>UI: локальный success или error
    end
    UI->>REVIEW: PUT /receivingorder/{id}/review
    REVIEW->>REVIEW: Читает весь сохранённый агрегат
    alt Есть ошибки
        REVIEW-->>UI: коды ошибок агрегата
        UI->>UI: открыть секцию и сохранить DRAFT
    else Валидно
        REVIEW-->>UI: status=ON_REVIEW
    end
```

1. Сначала создаётся только корень и получается `receivingOrder.id`.
2. Затем независимо сохраняются транспорт и состав выбранного сценария.
3. Для ЖД отдельно выбираются/привязываются Waybill; вагоны и КТК берутся из агрегата накладной.
4. Review вызывается только после успешной синхронизации всех изменённых секций.
5. Review не валидирует текущую клиентскую форму: он повторно читает сохранённый агрегат из БД.

Единого backend endpoint и общей транзакции «сохранить всю экранную форму» не найдено. Успешный root или ранняя дочерняя операция не откатывается при ошибке следующего запроса. Нормальный результат такой ошибки — существующий `DRAFT` с частично сохранёнными данными, а не возврат к состоянию «заявка не создана».

## Состояния формы и повторные запросы

| Состояние | Требуемое поведение |
|---|---|
| Dirty | При закрытии, смене заявки или сценария предупредить о несохранённых изменениях; отдельно учитывать dirty-секции |
| Root create pending | Заблокировать повторную отправку; не начинать child writes до получения ID |
| Duplicate submit | Использовать один in-flight request; create не имеет подтверждённого idempotency key |
| Partial save | Показать, какие секции сохранены; оставить ссылку на созданный `DRAFT`; повторять только неуспешные/изменённые операции |
| Validation `400` | Привязать Bean Validation к конкретному полю/строке; не стирать другие секции |
| Review error | Разобрать список кодов, открыть нужную секцию и сохранить статус `DRAFT` |
| `403` | Перевести форму в read-only и объяснить недостаток permission/недопустимый статус, не маскировать как отсутствие данных |
| `404` | Сообщить об удалённом/недоступном объекте; не предлагать бесконечный retry |
| Network/unknown | Результат мутации считать неопределённым: сначала перечитать root/секцию, затем решать о повторе |
| Conflict/stale data | Явного optimistic version в DTO нет; перед перезаписью показать свежие данные и риск last-write-wins |

Backend разрешает изменение заявки только в редактируемых статусах (`DRAFT`, а для `ON_REVIEW` — при специальном разрешении). Видимость кнопки не заменяет серверную permission/status проверку.

## Маршрутизация server errors

Полный каталог — [ошибки заявок](../../business-rules/order-errors.md). В UI префикс `X` раскрывается как `ReceivingOrder`.

| Код / группа | Секция исправления |
|---|---|
| `ReceivingOrder.InvalidTerminalAreaTransportType`, `*.MissingDeliveryType` | Основное / выбор сценария |
| `ReceivingOrder.MissingCurrency`, `ReceivingOrder.MissingPlannedReceivingDateTime`, `ReceivingOrder.MissingShipper` | Основное |
| `ReceivingOrder.MissingTransport` | Рейс / транспорт |
| `ReceivingOrder.MissingGoods`, `ReceivingOrderGood.MissingPlannedQuantity`, `.MissingPrice`, `.MissingTotalPrice` | Номенклатура / груз |
| `ReceivingOrder.MissingCargos`, `ReceivingOrder.MissingCargo`, `ReceivingOrderCargo.Missing*Quantity` | Детальные грузовые места |
| `ReceivingOrder.MissingContainers`, `ReceivingOrderContainer.MissingOwnerContainer`, `.MissingWeight` | Контейнеры |
| `ReceivingOrder.ItemsMissingForContainers`, `ReceivingOrder.EmptyContainerCantHaveItems`, `ReceivingOrder.ContainerAlreadyInUse` | КТК и его содержимое |
| `<orderNumber>.ReceivingOrderContainer.KtkNumberUnknown` | Известный номер КТК перед accept авто-заявки |
| Ошибка отсутствия Waybill/вагона; `ReceivingOrder.UndefinedRailwayCarriageType` | Документы / накладная / вагон |

Некоторые review errors объединяются одной строкой через `", "`. Клиенту нельзя полагаться только на человекочитаемый текст: нужен стабильный машинный массив `{code, field/section, objectId}`, которого в текущем контракте не подтверждено.

## Риски, которые LLM должна учитывать при проверке ТЗ

1. Root create и заполнение состава — не атомарная операция.
2. DTO-обязательность и review-обязательность различаются: например, нулевая цена проходит DTO, но блокирует review.
3. `PUT /receivingorder/{id}` доверяет `body.id`, а не path ID.
4. Смена площадки, транспорта и клиента после create не поддержана обычным update, даже если поля присутствуют в DTO.
5. `payerId` и станции есть только в create DTO; общей формы их последующего изменения нет.
6. Nullable `currency` формально допустима DTO, но небезопасна в update-коде.
7. Строка `waybill` корня и связь с сущностью `Waybill` — разные данные.
8. V2 batch контейнеров/items требует permission `DELETE` для смешанной операции.
9. Scoped batch подставляет root ID из URL, а часть legacy операций принимает parent ID из body; формы нельзя смешивать без явной политики.
10. Figma и рабочий snapshot относятся к неустановленным версиям и расходятся по вкладкам.

## Требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-REC-FORM-001` | До ввода состава форма должна создать корень, получить ID и явно показать сохранённый `DRAFT` | `PROPOSAL` |
| `UIR-REC-FORM-002` | Форма должна выбирать один из шести сценариев и показывать только соответствующие дочерние редакторы | `PROPOSAL` |
| `UIR-REC-FORM-003` | Required-маркеры должны различать request-required и review-required поля | `PROPOSAL` |
| `UIR-REC-FORM-004` | При update ID в URL и body должны совпадать; расхождение блокируется до запроса | `PROPOSAL` |
| `UIR-REC-FORM-005` | Клиент, площадка и транспорт после create отображаются read-only до появления согласованной серверной операции смены | `PROPOSAL` |
| `UIR-REC-FORM-006` | Каждая дочерняя секция должна иметь независимые saving/saved/error/dirty состояния | `PROPOSAL` |
| `UIR-REC-FORM-007` | После partial failure UI сохраняет ссылку на DRAFT, перечитывает спорную секцию и не повторяет успешные create вслепую | `PROPOSAL` |
| `UIR-REC-FORM-008` | Review запускается только после завершения всех текущих writes и маршрутизирует каждый код к исправляемой секции | `PROPOSAL` |
| `UIR-REC-FORM-009` | Inline-create возвращает новый ID в исходное поле, сохраняя несохранённый контекст основной формы | `PROPOSAL` |
| `UIR-REC-FORM-010` | UI должен различать складское грузовое место, детальный Cargo и КТК в терминах и API | `PROPOSAL` |
| `UIR-REC-FORM-011` | Повтор create/review блокируется на время запроса; после неопределённого ответа сначала выполняется read-back | `PROPOSAL` |
| `UIR-REC-FORM-012` | Источник макета, release frontend/backend и статус AS-IS/TO-BE должны показываться в паспорте flow | `PROPOSAL` |

## Вопросы аналитику, дизайну и разработке

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-REC-FORM-001` | Какая из двух композиций вкладок относится к текущему production release? | Product/frontend owner |
| `GAP-UI-REC-FORM-002` | Подтверждены ли шесть scenario→enum mappings и термин «контейнер» в складских ветках? | Бизнес-аналитик |
| `GAP-UI-REC-FORM-003` | Есть ли autosave и как пользователь восстанавливает частично созданный DRAFT? | Frontend/product owner |
| `GAP-UI-REC-FORM-004` | Какой API разрешает изменять payer/станции после создания ЖД-заявки? | Backend/process owner |
| `GAP-UI-REC-FORM-005` | Кто вычисляет `totalPrice`, округление и валюту: пользователь, frontend или backend? | Финансовый/бизнес-владелец |
| `GAP-UI-REC-FORM-006` | Какой из legacy/scoped batch API является целевым для КТК и items? | Backend/frontend owner |
| `GAP-UI-REC-FORM-007` | Какой endpoint и permission используются для inline-создания партии, КТК и типа ЗПУ? | Backend/frontend owner |
| `GAP-UI-REC-FORM-008` | Должно ли изменение сценария удалять несовместимые дочерние строки или блокироваться? | Бизнес-аналитик |
| `GAP-UI-REC-FORM-009` | Нужен ли единый aggregate-save endpoint/idempotency key для безопасного retry? | Архитектор/backend owner |
| `GAP-UI-REC-FORM-010` | В каком структурированном формате UI должен получать несколько review errors и object IDs? | API/frontend owner |

## Связанные документы

- [Вкладки и действия карточки](receiving-order-tabs-and-actions.md)
- [Карточка поставки](receiving-order-card.md)
- [Карта валидации](../../business-rules/order-validation.md)
- [Бизнес-правила поставки](../../business-rules/receiving-orders.md)
- [Типы заявок](../../business-rules/order-types.md)
- [Физическая модель корня](../../database/receiving-order-root-as-is.md)
- [Продуктовые макеты Figma](../figma/receiving-orders.md)

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `971288126` (07.10.2026; первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

Поля, обязательность и зависимости основной формы сведены в [UI-правилах заявок](../../business-rules/order-ui-rules-as-is.md#поставка-основная-форма).

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-REC-FORM-001` | Текущая сборка: «Основное», «Рейс», затем вкладки по типу (см. [матрицу вкладок](../../business-rules/order-ui-rules-as-is.md#состав-вкладок-карточки)), «Просмотр», «Печать». Отдельной вкладки «Документы» у заявки на поставку нет |
| `GAP-UI-REC-FORM-002` | Четыре складских вида (`BY_GOOD`, `BY_CARGO`, `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`, `BY_GOOD_WITH_CARGO_WITH_DETAILS`) и две контейнерные ветки реализованы как отдельные наборы вкладок |
| `GAP-UI-REC-FORM-003` | Autosave нет. Каждая вкладка сохраняется при переходе к следующей (в мастере — кнопка «Далее»); основная форма при создании сразу создаёт `DRAFT`. Незавершённый черновик открывается из реестра в режиме редактирования |
| `GAP-UI-REC-FORM-004` | Ни один: станция отправления после создания заблокирована, а станция назначения и плательщик редактируются в UI, но `ReceivingOrderUpdateDto` их не принимает — [`UI-DIFF-07`](../../business-rules/order-ui-rules-as-is.md#реестр-расхождений-ui--backend) |
| `GAP-UI-REC-FORM-005` | `totalPrice` считает frontend: `plannedQuantity × price`, без округления, и отправляет в запросе. Валюта — только `RUB` |
| `GAP-UI-REC-FORM-006` | Для КТК+авто — scoped batch: `POST /receiving-order/{id}/receiving-order-container/batch` и `.../receiving-order-container-item/batch`. Legacy `receivingordercontainer`/`...item` create/update во frontend объявлены, но не вызываются |
| `GAP-UI-REC-FORM-007` | Партия — `POST /batch/`, КТК — `POST /container/`, тип ЗПУ — `POST /sealtype/` (права — соответствующих справочников) |
| `GAP-UI-REC-FORM-008` | Сменить сценарий нельзя: площадка, транспорт и вид поставки блокируются после создания |
| `GAP-UI-REC-FORM-010` | UI разбирает массив ошибок валидации (module, errorCode, тип заявки) и показывает их списком; отдельно выделяются зарезервированные КТК |
