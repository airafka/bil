# Экран Группы пользователей

Экран предназначен для просмотра и администрирования групп пользователей ALIS. По backend AS-IS группа связывает Keycloak membership, пользовательские роли и доступные клиентские организации, но не является самостоятельной JPA-сущностью группы в ALIS.

## Паспорт

| Атрибут | Значение |
|---|---|
| Путь в меню | Настройки → Группы пользователей |
| UI-основание | `EXTERNAL_SNAPSHOT`, `докум.docx`, 22.09.2026 |
| Backend-основание | `SOURCE_CONFIRMED`, commit `22fac945e8116d04972ccc87b06b2303acf7a561` |
| Frontend route/component | `/usergroup`, `/usergroup/create`, `/usergroup/:id` — `src/features/Administration/UserGroup` (`SOURCE_CONFIRMED`) |
| Runtime network trace | Не выполнялся |
| Основная бизнес-роль | `ROLE-ACCESS-ADMIN` — кандидат, не подтверждённая оргроль |

## Пользовательская цель

Предполагаемая цель — создать или выбрать группу и управлять связанными пользователями, техническими ролями и доступными клиентами. Скриншот подтверждает только список, кнопку «Создать» и меню строки; содержимое форм и действий контекстного меню не показано.

## Что видно на снимке

| Элемент | Наблюдение | Доказательность |
|---|---|---|
| Заголовок | Окончание заголовка соответствует «…пользователей»; выбран пункт «Группы пользователей» | `EXTERNAL_SNAPSHOT` |
| Кнопка | «+ Создать» | `EXTERNAL_SNAPSHOT` |
| Таблица | Видна колонка «Описание», сортировка и кнопка настройки/фильтра колонок | `EXTERNAL_SNAPSHOT` |
| Строка | Для каждой строки доступно меню `…` | `EXTERNAL_SNAPSHOT` |
| Пагинация | Выбор 25 строк и переход между страницами | `EXTERNAL_SNAPSHOT` |
| Название/код группы | На снимке надёжно не видны | `OPEN_QUESTION` |
| Empty/loading/error | Не показаны | `OPEN_QUESTION` |

## Наблюдаемая классификация групп

Описания строк используют несколько несовместимых оснований:

| Тип группировки | Пример из snapshot | Риск |
|---|---|---|
| Уровень доступа | Полные права; только просмотр заявок и отчётов | Group смешивается с permission profile |
| Функциональный модуль | Документооборот; промышленная безопасность; экономическая эффективность | Неясна связь с бизнес-ролью и scope данных |
| Операционный контур | Клиентский сервис контейнерной площадки / складского комплекса | Не определены действия и клиенты |
| Команда/организация | Команды и сотрудники клиента | Организационная принадлежность смешивается с правами |
| Учебная аудитория | Студенты отдельных модулей | Временный lifecycle и дата окончания не видны |

Одна группа может быть удобным техническим контейнером, но её описание не заменяет явные business role, permission profile, client scope и срок действия.

## Кандидатная трассировка экрана к backend

Связь экрана с backend `UserGroup*Controller` подтверждена frontend source — см. [раздел ниже](#подтверждение-по-frontend-source).

| UI-действие | Candidate endpoint | DTO / response | Permission AS-IS |
|---|---|---|---|
| Загрузить страницу | `POST /usergroup/page` | `FilterWithPaging<KeycloakGroupFilter>` → `Page<UserGroupDto>` | `USER_GROUP/READ` |
| Создать | `POST /usergroup` | [UserGroupCreationDto](../../dto/catalog/usergroup/UserGroupCreationDto.md) → [UserGroupDetailedDto](../../dto/catalog/usergroup/UserGroupDetailedDto.md) | `USER_GROUP/CREATE` |
| Открыть карточку | `GET /usergroup/{groupId}` | [UserGroupDetailedDto](../../dto/catalog/usergroup/UserGroupDetailedDto.md) | `USER_GROUP/READ` |
| Изменить | `PUT /usergroup/{groupId}` | [UserGroupUpdateDto](../../dto/catalog/usergroup/UserGroupUpdateDto.md) | `USER_GROUP/WRITE` |
| Фильтр/meta колонки | `POST /usergroup/meta/{fieldName}` | `KeycloakGroupFilter` → `IdsCodeDto` | `USER_GROUP/READ` |
| Пользователи группы | `/usergroup/{groupId}/user*` | [UserUserGroupCreationDto](../../dto/catalog/usergroup/UserUserGroupCreationDto.md), [GroupUserDto](../../dto/catalog/usergroup/GroupUserDto.md) | CREATE/DELETE/READ |
| Клиенты группы | `/usergroup/{groupId}/client*` | [ClientUserGroupCreationDto](../../dto/catalog/clientusergroup/ClientUserGroupCreationDto.md), `IdCodeDto` | CREATE/DELETE/READ |
| Роли пользователей группы | `/usergroup/{groupId}/role*` | [UserRoleUpdateDto](../../dto/catalog/usergroup/UserRoleUpdateDto.md), [UserRoleDto](../../dto/catalog/usergroup/UserRoleDto.md) | READ; set использует DELETE |

Полный backend AS-IS: [группы пользователей и client restriction](../../business-rules/user-groups-client-restriction-as-is.md), декларативный каталог: [UserGroupController](../../api/endpoints-generated.md#usergroupcontroller).

## Реальная модель за экраном

```mermaid
flowchart LR
    UI[Экран группы] --> KC[Keycloak group]
    KC --> MEMBERS[User membership]
    MEMBERS --> ROLES[Realm roles пользователей]
    UI --> CUG[(client_user_group)]
    CUG --> CLIENT[Доступные Client ID]
    ROLES --> METHOD[Method permission]
    CLIENT --> ROWS[Client row scope]
    METHOD --> ACCESS[Фактический доступ]
    ROWS --> ACCESS
```

- сама группа и membership находятся в Keycloak;
- ALIS хранит связи `group_id + client_id`;
- роли и permission forest отвечают за доступ к действиям;
- client-group связи ограничивают доступные клиентские данные;
- изменение группы не гарантирует мгновенное изменение уже выданного JWT.

Это подтверждает, что экран администрирует несколько системных механизмов, а не один простой справочник.

## Source-level риски, важные для UI

| Риск backend | Требование к интерфейсу |
|---|---|
| Create/update последовательно меняют Keycloak, роли и ALIS client links без общей транзакции | Показывать частичный сбой и не сообщать общий успех, пока не подтверждены все шаги |
| Path `{groupId}` в нескольких write/read путях не гарантирует фактический target из body/filter | Frontend должен передавать одинаковый group ID и проверять response; backend всё равно требует исправления |
| Добавление клиентов использует replace-set semantics, а не append | UI должен явно показывать полный итоговый список и предупреждать об удаляемых связях |
| Изменение membership/roles может быть видно не одновременно из-за Keycloak/JWT/cache | После сохранения объяснять необходимость обновления токена или показывать состояние синхронизации |
| Пустое пересечение client IDs способно снять predicate в отдельных read paths | UI не является защитой; требуется server-side safe deny |
| `/role/all` не имеет method `@Secure` в source | Не полагаться на скрытую вкладку как security control |

## Кандидатные требования к экрану

| ID | Требование | Состояние |
|---|---|---|
| `UIR-GROUP-001` | В списке всегда показывать уникальное имя группы и описание отдельными колонками | `PROPOSAL` |
| `UIR-GROUP-002` | Показывать тип назначения группы: access profile, организация, модуль, учебная/временная | `PROPOSAL` |
| `UIR-GROUP-003` | В карточке разнести вкладки «Пользователи», «Роли» и «Доступные клиенты» | `PROPOSAL` |
| `UIR-GROUP-004` | Перед replace клиентских связей показывать добавляемые и удаляемые значения | `PROPOSAL` |
| `UIR-GROUP-005` | После сохранения показывать результат отдельно для Keycloak group, membership, roles и client scope | `PROPOSAL` |
| `UIR-GROUP-006` | Запрещать уход со страницы при частично сохранённом состоянии без инструкции восстановления | `PROPOSAL` |
| `UIR-GROUP-007` | Показывать владельца группы, назначение и срок действия для временных/учебных групп | `PROPOSAL` |
| `UIR-GROUP-008` | Действия и строки должны иметь явные forbidden/loading/empty/error состояния | `PROPOSAL` |
| `UIR-GROUP-009` | Отображаемая доступность кнопки не заменяет server-side permission и client-scope validation | `PROPOSAL` |
| `UIR-GROUP-010` | Для изменения доступа вести audit: кто, когда, что добавил и удалил | `PROPOSAL` |

## Вопросы для восстановления контракта UI

| ID | Вопрос | Кому адресовать |
|---|---|---|
| `GAP-UI-GROUP-001` | Какие колонки есть в таблице кроме «Описание» и почему они не видны на снимке? | Frontend owner / автор снимка |
| `GAP-UI-GROUP-002` | Какие действия находятся в меню `…`? | Frontend owner |
| `GAP-UI-GROUP-003` | Какие поля и вкладки содержит форма создания/редактирования? | Frontend owner / Access admin |
| `GAP-UI-GROUP-004` | Группа задаёт роли всем участникам или хранит роли каждого пользователя отдельно? | Access admin / Product owner |
| `GAP-UI-GROUP-005` | Добавление клиента в UI означает append или полную замену набора? | Product owner; backend сейчас делает replace |
| `GAP-UI-GROUP-006` | Как UI сообщает частичный сбой Keycloak/ALIS и как выполняется восстановление? | Frontend + backend + support |
| `GAP-UI-GROUP-007` | Когда пользователь получает новые права: сразу, после refresh token или повторного входа? | Keycloak owner |
| `GAP-UI-GROUP-008` | Кто является владельцем группы и кто имеет право её удалить/деактивировать? | Access governance owner |
| `GAP-UI-GROUP-009` | Есть ли audit изменений membership, roles и client scope? | ИБ / support |
| `GAP-UI-GROUP-010` | Какие группы временные и каков их lifecycle/срок действия? | Access admin / владельцы модулей |

## Acceptance-набор для будущей проверки

1. Пользователь без `USER_GROUP/READ` не видит данные даже при прямом URL.
2. Пользователь с READ, но без CREATE/WRITE/DELETE, не получает соответствующих действий и получает server-side отказ при прямом запросе.
3. Create с пустым именем показывает validation и не оставляет частично созданные связи.
4. Update отправляет один и тот же group ID в path и body.
5. Изменение клиентов явно проверяется как replace либо append согласно согласованному правилу.
6. Partial failure показывает, какой слой изменился, и предлагает безопасное восстановление.
7. После изменения ролей проверяется старый и новый JWT.
8. Empty client scope даёт safe deny, а не полный список клиентов.
9. Пагинация, сортировка и фильтры сохраняют выбранные критерии после возврата из карточки.
10. Все изменения доступа попадают в согласованный audit.

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `ab02fa985` (14.10.2026; ранее `971288126`, первично `62e1edfb`). Правила — в [UI-правилах администрирования](../../business-rules/admin-ui-rules-as-is.md#группы-пользователей).

| Действие | Запрос |
|---|---|
| Реестр | `POST /usergroup/page` |
| Карточка | `GET /usergroup/{id}`, `POST /usergroup/{id}/user/page`, `/role/page`, `/client/page` |
| Создание / сохранение | `POST /usergroup/`, `PUT /usergroup/{id}` с полными списками `users`, `clients`, `userRoles` |
| Удаление участника / клиента | `DELETE /usergroup/{groupId}/user/{userId}`, `DELETE /usergroup/{groupId}/client/{clientId}` |
| Закрытие незавершённого мастера | `DELETE /usergroup/{id}` — **на сервере отсутствует** ([`UI-ADIFF-01`](../../business-rules/admin-ui-rules-as-is.md#реестр-расхождений-ui--backend)) |

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-GROUP-001` | Колонки реестра — «Наименование» и «Описание»; фильтр по обеим (`POST /usergroup/meta/{name,description}`; фильтр по описанию — с 09.10.2026, `e183a6f0b`, KIS-4247, [`UI-ADM-017`](../../business-rules/admin-ui-rules-as-is.md#группы-пользователей)) |
| `GAP-UI-GROUP-002` | «Открыть» и «Редактировать» (при `User` `WRITE`) |
| `GAP-UI-GROUP-003` | Вкладки «Основное» (наименование, описание — оба обязательны), «Пользователи и роли», «Клиенты» |
| `GAP-UI-GROUP-004` | Роли задаются для каждого пользователя отдельно (строка «пользователи → роли»); на сервере это прямые realm roles пользователя |
| `GAP-UI-GROUP-005` | Замена набора: в режиме редактирования UI отправляет полный список клиентов; в режиме просмотра есть точечное удаление |
| `GAP-UI-GROUP-006` | Отдельной обработки частичного сбоя нет: показывается ошибка сервера, состав перечитывается |
| `GAP-UI-GROUP-008` | Удаления/деактивации группы в UI нет; право на раздел — path `User`, а не `UserGroup` ([`UI-ADIFF-02`](../../business-rules/admin-ui-rules-as-is.md#реестр-расхождений-ui--backend)) |
