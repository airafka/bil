# Карточка рейса

Карточка показывает рейс как операционный объект с собственным статусом, временем, площадкой, типом, перевозчиком, водителем и транспортом. Это подтверждает, что Route имеет lifecycle и предметно не является обычной неизменяемой НСИ, хотя в меню расположен среди справочников. Детальная связь вкладок, assign/unassign, статусов, plan/fact и отчётов приведена в [расширенной трассировке](route-tabs-and-actions.md).

## Паспорт

| Атрибут | Значение |
|---|---|
| Путь | Справочники → Рейсы → Рейс №… |
| UI-основание | `UI-SNAPSHOT-002`, 22.09.2026 |
| Endpoint | `GET /routes/{id}` (`SOURCE_CONFIRMED` frontend) |
| DTO | [RouteDetailedDto](../../dto/catalog/route/RouteDetailedDto.md) |
| Permission backend | `ROUTE:READ` |
| Серверная логика | [Lifecycle рейса](../../business-rules/route-lifecycle-as-is.md) |
| Frontend route | `/routes`, `/route/create`, `/route/:id` (`SOURCE_CONFIRMED`) |

## Вкладки и поля

| UI-элемент | Кандидат DTO.field | Комментарий |
|---|---|---|
| Основное | `RouteDetailedDto` | Показана |
| Заявки | Отдельный orders endpoint | Не открыта; возможны `/routes/{routeId}/orders` или deprecated `/orders/page` |
| Номер рейса | `number` | Системный номер |
| Вид транспорта | `transportType` | На снимке «Авто» |
| Площадка | `terminalArea` | Терминальная зона |
| Статус | `status` | На снимке «Подтвержден»; enum `ACCEPTED` имеет описание «Подтверждено» |
| Тип рейса | `routeType` | На снимке «Поставка» |
| Дата и время | `dataTime` | UI показывает интервал, DTO содержит один `Instant`; источник конца интервала не установлен |
| Перевозчик / экспедитор | `clientRelatedEntity` | Связанный контрагент |
| Номер ТС | `clientVehicle` | Вложенный short DTO |
| Номер телефона | Вероятно `clientDriver` или связанный контакт | Точный источник не установлен |
| Наличие прицепа / номер прицепа | `clientVehicle` | Nested fields требуют трассировки |
| ФИО водителя-экспедитора | `clientDriver` | Персональные значения не фиксируются |
| Номер страховки / доверенности | `clientDriver` или `clientVehicle` | Точный owner поля нужно проверить |
| Комментарий | `comment` | Свободный текст |

## Действия

На снимке видна только иконка запрета. По frontend source это `PUT /routes/{id}/reject` с подтверждением в диалоге; иконка видна при `Route.Reject` BUTTON `DELETE` и статусе не `REJECTED` (`SOURCE_CONFIRMED`). Сервер каскадно отклоняет заявки, но текст диалога об этом отдельно не предупреждает — требование `UIR-ROUTE-CARD-002` остаётся открытым.

```mermaid
flowchart TD
    CARD[Карточка рейса] --> MAIN[Основное]
    CARD --> ORDERS[Заявки]
    MAIN --> ROUTE[RouteDetailedDto]
    ORDERS --> ORDER_API[POST /routes/id/orders]
    CARD --> REJECT[Иконка отмены]
    REJECT --> WARN[Предупреждение о каскадном отклонении]
    WARN --> API[PUT /routes/id/reject]
```

## Кандидатные требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-ROUTE-CARD-001` | Route должен быть представлен как операционный объект с lifecycle, а не как статический справочник | `PROPOSAL` |
| `UIR-ROUTE-CARD-002` | Отмена рейса должна до подтверждения перечислять затрагиваемые заявки и каскадный эффект | `PROPOSAL` |
| `UIR-ROUTE-CARD-003` | UI должен объяснять интервал времени и его отличие от единственного `dataTime` backend DTO | `PROPOSAL` |
| `UIR-ROUTE-CARD-004` | Вкладка «Заявки» должна показывать тип заявки, номер, клиента, статус и причину недоступности действия | `PROPOSAL` |

## Вопросы аналитику

| ID | Вопрос | Владелец |
|---|---|---|
| `GAP-UI-ROUTE-CARD-001` | Из какого поля формируется конец интервала времени рейса? | Backend/frontend owner |
| `GAP-UI-ROUTE-CARD-002` | Какой endpoint и DTO использует вкладка «Заявки»? | Frontend owner |
| `GAP-UI-ROUTE-CARD-003` | Иконка запрета действительно отклоняет рейс и все заявки? Есть ли подтверждение? | Владелец транспортного процесса |
| `GAP-UI-ROUTE-CARD-004` | Почему Route размещён в «Справочниках» и планируется ли перенос? | Product owner |

## Подтверждение по frontend source

Сверено с `alis-frontend` `dev`, commit `971288126` (07.10.2026; первично `62e1edfb`). Статус ниже — `SOURCE_CONFIRMED` по frontend source; он не доказывает, что эта сборка развернута на стенде снимка.

| Вопрос | Ответ по frontend |
|---|---|
| `GAP-UI-ROUTE-CARD-001` | Конец интервала backend не передаёт: UI показывает `dataTime` и `dataTime + 1 час` |
| `GAP-UI-ROUTE-CARD-002` | `POST /routes/{id}/orders` → `RouteClientOrderReportDto` (заявки, сгруппированные по клиенту) |
| `GAP-UI-ROUTE-CARD-003` | Да, после подтверждения; см. выше |

Остальные действия и права рейса — в [UI-правилах рейсов](../../business-rules/route-ui-rules-as-is.md).
