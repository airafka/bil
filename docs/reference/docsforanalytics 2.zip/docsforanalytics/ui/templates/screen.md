# Шаблон паспорта экрана

Шаблон используется для описания одного экрана ALIS. Неподтверждённые связи помечаются `INFERENCE` или `OPEN_QUESTION`; снимок не подменяет frontend source и runtime trace.

## Назначение

- Путь в меню:
- Пользовательская цель:
- Бизнес-объект:
- Основные роли:

## Паспорт доказательности

| Атрибут | Значение |
|---|---|
| UI-основание | файл, дата, hash, `EXTERNAL_SNAPSHOT` |
| Frontend route/component | путь или `OPEN_QUESTION` |
| Runtime trace | стенд, роль, дата или «не выполнялся» |
| Backend source | commit, controller/service |

## Отображаемые поля

| UI-поле | Бизнес-смысл | Кандидат DTO.field | Источник истины | Обязательность / null | Доказательность |
|---|---|---|---|---|---|
| | | | | | |

## Действия

| Действие | Условие видимости | Кандидатный endpoint | Request / response DTO | Permission / scope | Эффект | Доказательность |
|---|---|---|---|---|---|---|
| | | | | | | |

## Состояния

Описать normal, loading, empty, validation error, server error, forbidden, not found, partial failure и stale data.

## Блок-схема

```mermaid
flowchart TD
    OPEN[Пользователь открывает экран] --> LOAD[Загрузка]
    LOAD -->|успех| VIEW[Данные]
    LOAD -->|пусто| EMPTY[Пустое состояние]
    LOAD -->|403| FORBIDDEN[Нет доступа]
    LOAD -->|ошибка| ERROR[Ошибка и повтор]
    VIEW --> ACTION[Действие]
    ACTION --> RESULT[Обновлённое состояние]
```

## Требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-AREA-001` | | `PROPOSAL` / `BUSINESS_CONFIRMED` |

## Вопросы

| ID | Вопрос | Владелец | Что закроет вопрос |
|---|---|---|---|
| `GAP-UI-AREA-001` | | | |

