# Интерфейс ALIS

Раздел связывает пользовательские экраны с бизнес-объектами, действиями, ролями, permissions, API, DTO и серверными правилами. Он не восстанавливает поведение интерфейса по одному скриншоту и не выдаёт видимость пункта меню за доказательство доступности backend endpoint.

## Достоверность UI-материалов

| Основание | Что можно утверждать | Что нельзя утверждать |
|---|---|---|
| Скриншот / Word | Наличие видимого элемента, подпись, расположение и показанное состояние на момент снимка | Все состояния, фактический обработчик, permission, production-актуальность |
| Frontend source | Route, component, request, обработка состояния и ошибок | Что эта сборка развернута у пользователя |
| Backend source | Endpoint, DTO, validation, service и permission AS-IS | Что UI действительно вызывает этот endpoint |
| Runtime-проверка | Фактическое поведение выбранного стенда и пользователя | Поведение других ролей/стендов без отдельной проверки |

Метки `EXTERNAL_SNAPSHOT`, `SOURCE_CONFIRMED`, `INFERENCE` и `OPEN_QUESTION` определены в [модели доказательности](../business/evidence-model.md).

## Текущие материалы

| Документ | Содержание | Состояние |
|---|---|---|
| [Карта навигации](navigation-as-is.md) | Видимое меню ALIS, предметная классификация и предложение по структуре | Snapshot от 22.09.2026; версия приложения не установлена |
| [Реестр экранов](screen-inventory.md) | Покрытие снимками, бизнес-объекты, кандидатные backend-контуры и приоритеты | Два Word snapshot; frontend source `971288126` для заявок и рейсов (UI-правила и паспорта с изменениями диапазона — `ab02fa985`) |
| [Дизайн-система](design-system/README.md) | Figma-источник, 24 группы компонентов, состояния и границы применимости | Live Figma review от 23.09.2026; component metadata недоступна |
| [Каталог компонентов](design-system/component-inventory.md) | Все страницы, функциональная классификация и пробелы | Визуальная инвентаризация |
| [Компоненты на экранах](design-system/screen-component-map.md) | Candidate mapping design component → наблюдаемый экран | `INFERENCE` без frontend source |
| [Макеты заявок на поставку](figma/receiving-orders.md) | Сценарии склад/авто, КТК/авто, КТК/ЖД, ошибки статусов и зоны ЭТРАН | Live Figma review; реализация не подтверждена |
| [Группы пользователей](screens/user-groups.md) | Первый паспорт экрана с кандидатной трассировкой к API и рисками | Screenshot + backend source; frontend source не предоставлен |
| [Реестры заявок](screens/order-lists.md) | Поставка, вывоз, статусы, DTO-поля и настройка таблиц | Screenshot + backend + frontend source; screen→request подтверждён |
| [Карточка поставки](screens/receiving-order-card.md) | Основные реквизиты, вкладки и действия | Screenshot + backend + frontend source; снимок старше KIS-4735 |
| [Вкладки и действия поставки](screens/receiving-order-tabs-and-actions.md) | Детальная трассировка «Основное»/«Рейсы»/«КТК»/«Груз»/«Просмотр», ошибок review и дочерних API | Backend + frontend source; screen→request подтверждён |
| [Создание и редактирование поставки](screens/receiving-order-create-edit.md) | Шесть сценариев формы, поля/DTO, lookup, порядок сохранения, partial failure и server errors | Figma + backend + frontend source; flow подтверждён |
| [Создание и редактирование вывоза](screens/shipping-order-create-edit.md) | `deliveryType`/`fillingType`, номерные и плановые модели, merge, смена сценария и ошибки | Backend + frontend source; макеты отсутствуют |
| [Форма заявки на услугу](screens/service-order-create-edit.md) | Смена владельца КТК, выбор по ContainerOwner, accept/DONE, outbound и конфликты | Backend + frontend source; макет отсутствует |
| [Карточка рейса](screens/route-card.md) | Рейс, логистика, заявки и каскадная отмена | Screenshot + backend + frontend source |
| [Секции и действия рейса](screens/route-tabs-and-actions.md) | Assign/unassign, review/accept/reject, shipping plan/fact, cargo-chain и отчёты | Backend + frontend source; screen→request подтверждён |
| [Клиенты](screens/clients.md) | Реестр клиентских организаций | Screenshot + backend + frontend source |
| [Остатки контейнеров](screens/container-remains-report.md) | Встроенный Superset-отчёт и пробелы RLS/freshness | Только внешние snapshot |
| [UI-правила заявок](../business-rules/order-ui-rules-as-is.md) | Вкладки, обязательность полей, кнопки по статусу/праву, endpoints и расхождения с backend для поставки, вывоза и услуги | Frontend source `ab02fa985` (14.10.2026; ранее `971288126`); `screen→request` для этих экранов подтверждён |
| [UI-правила рейсов](../business-rules/route-ui-rules-as-is.md) | Создание, назначение заявок, отправка/отмена, копирование, вкладки плана/факта и документов, расхождения прав с backend | Frontend source `ab02fa985` (14.10.2026; ранее `971288126`) |
| [UI-правила справочников](../business-rules/dictionary-ui-rules-as-is.md) | Клиенты, договоры, контрагенты, водители, ТС, номенклатура, КТК и вагоны: формы, права, удаление, расхождения с DTO | Frontend source `ab02fa985` (14.10.2026; ранее `971288126`) |
| [UI-правила администрирования](../business-rules/admin-ui-rules-as-is.md) | Пользователи, группы, роли и дерево прав: формы, состав группы, сохранение прав, расхождения с backend | Frontend source `ab02fa985` (14.10.2026; ранее `971288126`) |
| [UI-правила накладных ЭТРАН](../business-rules/waybill-ui-rules-as-is.md) | Реестры входящих/исходящих/архива, карточка накладной, привязка к ЖД-поставке | Frontend source `ab02fa985` (14.10.2026; ранее `971288126`) |
| [Шаблон паспорта экрана](templates/screen.md) | Единый состав полей, действий, состояний и доказательств | Готов к применению |

## Структура паспорта экрана

Каждый экран описывается по единой схеме:

1. путь в меню и пользовательская цель;
2. бизнес-роль и client/data scope;
3. отображаемые объекты и поля;
4. доступные действия и условия их видимости;
5. фильтры, сортировка и пагинация;
6. состояния loading, empty, error, forbidden и partial failure;
7. candidate frontend route/component;
8. API, DTO, permission и серверное правило;
9. source of truth для показанных данных;
10. расхождения, требования и открытые вопросы.

## Правило трассировки

```mermaid
flowchart LR
    NAV[Пункт меню] --> SCREEN[Экран]
    SCREEN --> GOAL[Пользовательская цель]
    GOAL --> ROLE[Бизнес-роль]
    SCREEN --> ACTION[Действие]
    ACTION --> PERM[Permission + data scope]
    ACTION --> API[Endpoint]
    API --> DTO[DTO]
    API --> RULE[Серверное правило]
    RULE --> DATA[Entity / DB]
    ACTION --> STATE[Loading / empty / error / success]
```

Связь считается подтверждённой только при наличии frontend source или runtime network trace. Сопоставление по одинаковому названию экрана и endpoint маркируется `INFERENCE`.

## Базовые требования к UI-документации

| ID | Требование | Состояние |
|---|---|---|
| `UIR-DOC-001` | Каждый снимок должен иметь дату, стенд, версию frontend/backend и роль пользователя | `PROPOSAL` |
| `UIR-DOC-002` | Для действия фиксируются видимость, permission, data scope и фактический request | `PROPOSAL` |
| `UIR-DOC-003` | AS-IS снимок и план следующего релиза хранятся раздельно | `PROPOSAL` |
| `UIR-DOC-004` | Отсутствующий на снимке пункт нельзя объявлять отсутствующим в продукте без проверки другой роли | `PROPOSAL` |
| `UIR-DOC-005` | Название экрана должно использовать канонический термин из [glossary](../business/glossary.md) | `PROPOSAL` |

## Следующее наполнение

После получения скриншотов или screen recording последовательно описываются:

1. ЖД-накладные;
2. роли и пользователи;
3. основные справочники;
4. остальные Superset-отчёты.

Компоненты и состояния для этих экранов выбираются через [ALIS Design System](design-system/README.md), а сценарии поставки уточняются по [продуктовым макетам](figma/receiving-orders.md). Связь обоих Figma-файлов с фактическим frontend подтверждается отдельно.
