# Каталог компонентов ALIS Design System

Каталог перечисляет все страницы Figma-файла и фиксирует только визуально подтверждённые группы. Названия variants и точные property definitions считаются неподтверждёнными до получения inspect/API metadata.

## Сводка страниц

| № | Страница | Назначение | Наблюдаемое содержание | Состояние описания |
|---:|---|---|---|---|
| 1 | Welcome page | Вход в дизайн-систему | Instruction, Thumbnail; ссылки на design elements и компоненты | Служебная |
| 2 | Styleguide | Визуальные основы | Цветовые шкалы, typography и другие базовые образцы | Требуется выгрузка tokens/styles |
| 3 | Page divider | Разделитель списка страниц | В UI выглядит как разделительная строка; отдельный холст не подтверждён | Служебная |
| 4 | Badge | Короткий статус, категория или removable tag | `Badge_item`, `Badge_action`, цветовые состояния, текст, крестик и action/icon | Визуально просмотрено |
| 5 | Background | Фон/overlay | Светлая подложка и тёмный overlay-образец | Правила применения не описаны |
| 6 | Button | Действия и вкладки | Text button, icon button, select button, `Tab_Item`, `Tab`, несколько размеров/состояний | Визуально просмотрено |
| 7 | Breadcrumbs and avatar | Путь и профиль | Breadcrumbs и avatar в общем верхнем контуре | Детали плохо читаются без inspect |
| 8 | Chevron | Направляющий индикатор | Набор chevron-элементов | Размеры/направления требуют metadata |
| 9 | Checkbox | Выбор | Квадратный checkbox, круглый radio-подобный выбор, checked/unchecked/disabled/error, несколько размеров, indeterminate | Визуально просмотрено |
| 10 | Date and time picker | Ввод даты и времени | Поля, calendar, single/range-подобные состояния, календарные ячейки и time choices | Визуально просмотрено |
| 11 | Dropdown | Выбор из списка | Поля разных состояний, single/multiple list, options и примеры списков | Визуально просмотрено |
| 12 | Divider | Разделение содержимого | Страница существует; слой при чтении неоднозначен | Требуется повторный inspect |
| 13 | Icons | Иконографика | Группы `40×40`, `24×24`, `20×20`, `18×18`, `16×16`, `14×14`, `8×8`; файловые и предметные icons | Визуально просмотрено |
| 14 | Input | Однострочный ввод | Label, placeholder/value, icon, helper/error и состояния normal/focus/disabled/error | Визуально просмотрено |
| 15 | Logo | Идентификация ALIS | Концепция логотипа и отдельный блок Logo; несколько представлений | Требуется указать approved-версию |
| 16 | Message | Результат и уведомление | Несколько notification/banner/toast-подобных представлений и примеры статусов операций/файлов | Семантика вариантов требует metadata |
| 17 | Navbar | Верхняя навигация | Верхняя панель и avatar/profile action | Визуально просмотрено |
| 18 | Progress bar | Ход операции | Линейные progress/skeleton-подобные состояния | Значения и indeterminate требуют metadata |
| 19 | Pagination | Переход по страницам | Стрелки, номер страницы, компактный и полный pager, «Строк на странице» | Визуально просмотрено |
| 20 | Preloader | Ожидание | Отдельный loading-компонент | На холсте плохо различим; metadata нужна |
| 21 | Search | Поиск | Поле с иконкой/очисткой, suggestions с названием и путём, loading result | Визуально просмотрено |
| 22 | Sidebar | Основная навигация | Expanded/collapsed представления, группы/подпункты, иконки, Logo и нижний version/build блок | Визуально просмотрено |
| 23 | Pop-up | Modal/confirmation/form | Несколько размеров и типов содержимого, подтверждения и формы; две Pop-up-группы и legacy `old` | Визуально просмотрено; legacy не формализован |
| 24 | Scrollbar | Прокрутка | Отдельный Scroll-компонент | Толщина/оси/states требуют metadata |
| 25 | Table | Табличные реестры | Header/cell/row primitives, сортировка/фильтр, selection, hierarchy и сложные table compositions | Визуально просмотрено |
| 26 | TextArea | Многострочный ввод | Label/value/helper/error и состояния ввода | Визуально просмотрено |
| 27 | Tooltip | Контекстная подсказка | Тёмные tooltip-варианты, разные положения, примеры над кнопками/таблицей | Визуально просмотрено |

## Функциональная классификация

```mermaid
flowchart TD
    DS[ALIS Design System] --> FOUNDATION[Основы]
    DS --> INPUT[Ввод и выбор]
    DS --> ACTION[Действия]
    DS --> NAV[Навигация]
    DS --> DATA[Данные]
    DS --> FEEDBACK[Обратная связь]
    DS --> BRAND[Бренд]

    FOUNDATION --> STYLE[Styleguide]
    FOUNDATION --> BG[Background / Divider / Scrollbar]
    INPUT --> IN[Input / TextArea / Search]
    INPUT --> SELECT[Checkbox / Dropdown / Date and time picker]
    ACTION --> BTN[Button / Chevron]
    NAV --> NB[Navbar / Sidebar / Breadcrumbs]
    NAV --> PAG[Pagination / Tabs]
    DATA --> TABLE[Table]
    DATA --> BADGE[Badge]
    FEEDBACK --> MSG[Message / Tooltip / Pop-up]
    FEEDBACK --> LOAD[Progress bar / Preloader]
    BRAND --> LOGO[Logo / Icons]
```

## Наблюдаемые состояния и пробелы

| Группа | Подтверждено визуально | Не подтверждено |
|---|---|---|
| Button | Текстовые и icon actions, primary/secondary-подобные варианты, select и tabs | Имена props, hover/focus keyboard, loading, permission-driven hidden/disabled |
| Badge | Несколько semantic colors, removable/action варианты | Каноническое соответствие цвет → бизнес-статус |
| Checkbox | Checkbox/radio, checked, unchecked, disabled, error, indeterminate, размеры | Required validation и keyboard/focus behavior |
| Input/TextArea | Normal, focus, disabled, error-подобные состояния, label/helper | Validation timing, max length, masks, null/empty semantics |
| Dropdown | Single/multiple-подобные списки и состояния поля | Async loading, pagination/search, empty/error, selected-item limit |
| Date/time | Input и календарные/time варианты | Timezone, locale, min/max, interval rules, invalid/rejected values |
| Table | Примитивы и составные таблицы, hierarchy/selection/filter-like controls | Server/client sorting, column persistence, empty/error/loading, virtual scroll |
| Pagination | Compact/full, arrows, page size | Zero/one-based mapping, total changes, unavailable page |
| Search | Suggestions, path, clear и loading | Scope, debounce, min length, no-result/error и permission filtering |
| Pop-up | Несколько размеров/сценариев | Modal vs non-modal, focus trap, destructive confirmation, dirty-close behavior |
| Message | Несколько визуальных типов | Severity taxonomy, lifetime, retry/details и screenreader announcement |
| Tooltip | Позиции и примеры | Trigger, delay, mobile/keyboard behavior и запрет важной информации только в tooltip |
| Sidebar | Expanded/collapsed и вложенные пункты | Permission filtering, current route, persistence и overflow |

## Выявленные проблемы качества дизайн-источника

| ID | Наблюдение | Риск для документации и разработки |
|---|---|---|
| `GAP-UI-DS-001` | Не все страницы содержат блок `Описание` | Назначение и ограничения приходится выводить по картинке |
| `GAP-UI-DS-002` | `Page divider` виден в списке, но не подтверждён как самостоятельный компонент | Ошибочная инвентаризация служебной структуры как product component |
| `GAP-UI-DS-003` | Страница `Checkbox` включает круглый radio-подобный control | Неясно, это один component set или смешение Checkbox и Radio |
| `GAP-UI-DS-004` | На `Pop-up` присутствует группа `old` без migration note | Новые макеты могут продолжить использовать legacy-вариант |
| `GAP-UI-DS-005` | В Figma нет доступной машинной связи semantic color badge с `OrderStatus`/`RouteStatus` | Цвет может расходиться между макетами и реализацией |
| `GAP-UI-DS-006` | Не получены variables/styles и bindings | Нельзя доказать token consistency и темизацию |
| `GAP-UI-DS-007` | Не получены component properties и variant names | Нельзя построить точный контракт Figma → frontend props |
| `GAP-UI-DS-008` | Не получены prototype reactions | Нельзя считать переходы/overlay behavior подтверждённым UX-сценарием |
| `GAP-UI-DS-009` | Визуальная матрица не показывает единообразно loading/empty/error/forbidden для составных компонентов | ТЗ может пропустить обязательные состояния экрана |

