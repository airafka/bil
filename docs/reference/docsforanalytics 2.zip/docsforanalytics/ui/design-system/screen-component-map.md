# Связь компонентов Figma с экранами ALIS

Матрица показывает, из каких элементов дизайн-системы собраны уже наблюдавшиеся экраны. Это не доказательство фактического frontend import: для него нужен исходный код или runtime component tree.

## Матрица

| Экран | Наблюдаемые компоненты Figma | Бизнес-смысл | Главный пробел |
|---|---|---|---|
| Реестр заявок на поставку/вывоз | Navbar, Sidebar, Button, Table, Badge, Pagination, Tooltip, Scrollbar | Найти заявку, понять статус, создать/открыть/обработать | Filters, row menu и сохранение столбцов не прослежены до variants |
| Настройка столбцов | Pop-up/overlay, Checkbox, Button, Table controls | Выбрать видимые поля, порядок и высоту строк | Не найден отдельный именованный Column manager component |
| Карточка поставки | Navbar, Sidebar, Breadcrumbs, Button, Tab, Badge, Tooltip, Divider | Просмотреть заявку и выполнить status action | Не подтверждены hidden/disabled/error states кнопок |
| Карточка рейса | Navbar, Sidebar, Breadcrumbs, Tab, Badge, Button, Pop-up | Просмотреть логистику и заявки, отклонить рейс | Нет подтверждённого destructive confirmation pattern |
| Клиенты | Navbar, Sidebar, Breadcrumbs, Button, Table, Badge, Pagination | Управлять справочником клиентских организаций | Active badge не сопоставлен с backend active field |
| Остатки контейнеров | Navbar, Sidebar + встроенные Superset controls | Анализировать остатки КТК | Внутренние controls отчёта могут не использовать ALIS Design System |
| Группы пользователей | Navbar, Sidebar, Button, Table, Pagination, Pop-up | Управлять группами, ролями и client scope | Формы и partial failure states отсутствуют на снимке |

## Сборка типового реестра

```mermaid
flowchart TD
    SHELL[Navbar + Sidebar] --> HEAD[Breadcrumbs + заголовок]
    HEAD --> ACTIONS[Button / Tooltip]
    ACTIONS --> FILTERS[Search + Dropdown + Checkbox + Date picker]
    FILTERS --> GRID[Table + Scrollbar]
    GRID --> STATUS[Badge]
    GRID --> PAGE[Pagination]
    GRID --> MODAL[Pop-up]
    SHELL --> FEEDBACK[Preloader + Message]
```

## Сборка типовой карточки

```mermaid
flowchart TD
    SHELL[Navbar + Sidebar] --> CRUMB[Breadcrumbs + avatar]
    CRUMB --> TITLE[Заголовок + Badge]
    TITLE --> ACT[Button + Tooltip]
    TITLE --> TABS[Tab]
    TABS --> FORM[Input / Dropdown / Date picker / Checkbox / TextArea]
    FORM --> DIV[Divider]
    FORM --> MODAL[Pop-up подтверждения]
    FORM --> FEEDBACK[Preloader / Message]
```

## Правило для нового ТЗ

Для каждого элемента будущего экрана аналитик должен указать не только название компонента, но и:

1. бизнес-смысл поля или действия;
2. variant/state дизайн-системы;
3. editable/read-only/hidden/disabled условие;
4. обязательность и момент валидации;
5. источник значения и формат;
6. permission и client scope;
7. endpoint и DTO;
8. loading, empty, error и retry;
9. результат и изменение состояния;
10. отличие от текущего AS-IS, если это TO-BE.

## Кандидатные требования

| ID | Требование | Состояние |
|---|---|---|
| `UIR-DS-MAP-001` | Новый экран должен использовать существующий компонент либо документировать причину нового варианта | `PROPOSAL` |
| `UIR-DS-MAP-002` | Badge status обязан иметь таблицу `business value → backend enum → UI label → semantic color` | `PROPOSAL` |
| `UIR-DS-MAP-003` | Disabled control не заменяет permission check; скрытие, блокировка и серверный запрет документируются отдельно | `PROPOSAL` |
| `UIR-DS-MAP-004` | Каждая таблица должна явно определить columns, sorting, filters, selection, hierarchy, pagination и persistence | `PROPOSAL` |
| `UIR-DS-MAP-005` | Destructive action должен использовать согласованный Pop-up с описанием последствий и ошибкой выполнения | `PROPOSAL` |
| `UIR-DS-MAP-006` | Loading/empty/error/forbidden/partial состояния должны проектироваться как часть сценария, а не добавляться после реализации | `PROPOSAL` |

## Вопросы владельцу дизайна и frontend

| ID | Вопрос | Требуемый ответ |
|---|---|---|
| `GAP-UI-DS-MAP-001` | Какие Figma-компоненты фактически реализованы один к одному во frontend? | Component → repository path/export |
| `GAP-UI-DS-MAP-002` | Какие компоненты опубликованы как library и какие являются только демонстрационными frames? | Published component keys/status |
| `GAP-UI-DS-MAP-003` | Какой компонент используется для настройки столбцов таблицы? | Name, variants и persistence contract |
| `GAP-UI-DS-MAP-004` | Какая матрица semantic colors применяется для заявок, рейсов, документов и активности справочника? | Согласованная status-color table |
| `GAP-UI-DS-MAP-005` | Где определены empty, forbidden, server error и partial failure states составных экранов? | Figma nodes/patterns либо новое требование |
| `GAP-UI-DS-MAP-006` | Какие элементы страницы `Pop-up/old` запрещены для новых макетов и чем заменяются? | Deprecation/migration policy |

