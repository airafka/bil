# API ALIS

Раздел предназначен для восстановления HTTP-контракта без повторного чтения контроллеров.

## Состав

- [Полный каталог endpoints](endpoints-generated.md) — mappings из controller packages, охваченных текущим `ComponentConfiguration.@ComponentScan`, path/query/header/body/model-form параметры, required/default/валидация, consumes/produces, response status, OpenAPI responses, enum, permissions и ссылки на DTO/Java handler.
- [API заявок и серверная логика](order-api.md) — ручное описание поведения поставки, вывоза, сервисных заявок и дочерних ресурсов.
- [API клиентов, договоров и условий услуг](client-contract-api.md) — ручная серверная логика, обязательные поля, фильтры, риски и Mermaid-блок-схемы.
- [API клиентских справочников](client-reference-api.md) — номенклатура, виды, контрагенты, водители, транспорт, цифровые марки и enum endpoints.
- [Корневые Excel-выгрузки заявок V1/V2](../business-rules/order-excel-exports-as-is.md) — четыре download endpoints, request filters, permissions, client scope, collectors, XLSX-поля и streaming errors.
- [Дочерние Excel-выгрузки поставки, часть 1](../business-rules/receiving-order-child-excel-exports-as-is.md) — V1/V2 для blackbox, cargo, container и container-item с filter/predicate и template gap.
- [Дочерние Excel-выгрузки поставки, часть 2](../business-rules/receiving-order-child-excel-exports-part2-as-is.md) — V1/V2 для goods, requested services, Waybill и вагонов, включая последствия KIS-3631.
- [Дочерние Excel-выгрузки вывоза, часть 1](../business-rules/shipping-order-child-excel-exports-as-is.md) — V1/V2 для blackbox, cargo, КТК и содержимого КТК, включая scope и XLSX expressions.
- [Дочерние Excel-выгрузки вывоза, часть 2](../business-rules/shipping-order-child-excel-exports-part2-as-is.md) — V1/V2 для товаров, услуг, связанных накладных ЭТРАН и вагонов.
- [Права доступа к отчётам заявок](../business-rules/order-report-access-as-is.md) — method permissions PDF/Excel, role forest, availability/direct asymmetry и client/row-level scope.
- [Роли и разрешения, часть 1 AS-IS](../business-rules/roles-permissions-as-is.md) — 17 WMS endpoints, DTO, Keycloak roles, `RolePermission` tree, inheritance/cache и source-level gaps.
- [Группы пользователей и доступные клиенты, часть 2 AS-IS](../business-rules/user-groups-client-restriction-as-is.md) — group/user/role/client endpoints, Keycloak membership и ограничение client ID при чтении.
- [Настройки пользователя AS-IS](../business-rules/user-settings-as-is.md) — три endpoints, личные/default значения JSONB, замена по key и source-level owner/migration risks.
- [Профиль пользователя и сводка прав AS-IS](../business-rules/user-profile-permissions-as-is.md) — четыре UserInfo endpoints, JWT/Keycloak profile, permissions summary и доступные клиенты.
- [Обязательность полей заявок](../business-rules/order-validation.md) — Bean Validation, межполевая и агрегатная валидация.
- [Каталог DTO](../dto/README.md) — ручные бизнес-паспорта и полный generated-каталог структурных контрактов.

## Как использовать как контекст GPT

Для проверки ТЗ не обязательно загружать весь технический каталог. Минимальный набор для заявки:

1. [типы заявок](../business-rules/order-types.md);
2. [статусы](../business-rules/order-statuses.md);
3. [валидация](../business-rules/order-validation.md);
4. документ специализации: [поставка](../business-rules/receiving-orders.md), [вывоз](../business-rules/shipping-orders.md) или [услуга](../business-rules/service-orders.md);
5. [API заявок](order-api.md);
6. паспорта только тех DTO, которые меняются в ТЗ.

`endpoints-generated.md` следует подключать целиком только для поиска неизвестного endpoint. После нахождения достаточно оставить секцию нужного контроллера.

Для ТЗ по клиентским данным достаточно подключить [API клиентов и договоров](client-contract-api.md), [API клиентских справочников](client-reference-api.md) и паспорта непосредственно изменяемых DTO. Оба ручных документа содержат ссылки на исходные entities и соседние процессы.

## Достоверность и обновление

История изменений, найденных после обновления ветки, ведётся в [журнале сверки с репозиторием](../traceability/repository-change-log.md). В ручных документах рядом с изменённым правилом указывается полный hash содержательного коммита.

Технический каталог генерируется из исходников:

```bash
python3 docs/docsforanalytics/api/generate_endpoint_catalog.py
```

Генератор читает область контроллеров из [`ComponentConfiguration`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ComponentConfiguration.java#L17). В текущем коде это 119 ALIS-контроллеров и четыре WMS-контроллера из пакетов `permission`/`role`; настроенный пакет `wms.controller.user` не содержит Java-контроллеров. Остальные WMS controller packages автоматически не включаются.

Генератор не интерпретирует бизнес-логику сервиса. Он фиксирует только то, что доказуемо декларациями в исходнике и конфигурации: происхождение/FQCN контроллера, HTTP-метод и путь, параметры Spring MVC, required/default, Bean Validation на параметре, consumes/produces, Java response, `@ResponseStatus`/`ResponseEntity`, `@ApiResponse`, enum из сигнатуры, method-level `@Secure`, class-level profile/condition и handler. Связанные DTO раскрываются отдельными паспортами, включая member nested-типы.

`required` у параметра не означает обязательность каждого JSON-поля. Состав тела, JSON required/null-policy и Bean Validation нужно читать в связанном DTO-паспорте. Отсутствие content/schema у `@ApiResponse` показывается явно. Каталог не доказывает фактическую регистрацию в Spring context, доступность через reverse proxy, ответы exception advice или ветвления внутри handler. Семантика транзакции, проверки БД, нормализация и интеграционные эффекты описываются вручную в доменных документах.

Ручные доменные документы дополнительно содержат Mermaid-блок-схемы. Диаграмма является кратким представлением описанного рядом кода, а не отдельным источником требований.

Технические паспорта DTO обновляются отдельно:

```bash
python3 docs/docsforanalytics/scripts/generate_dto_docs.py
```
