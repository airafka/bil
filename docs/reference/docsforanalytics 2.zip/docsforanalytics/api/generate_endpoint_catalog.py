#!/usr/bin/env python3
"""Generate a searchable HTTP endpoint inventory from Spring controllers.

The output is intentionally technical: business semantics are maintained in
hand-written documents next to the generated inventory.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
COMPONENT_CONFIGURATION = ROOT / "web-layer/src/main/java/ru/korusconsulting/alis/config/ComponentConfiguration.java"
API_REST_CONTROLLER = ROOT / "web-layer/src/main/java/ru/korusconsulting/alis/controller/ApiRestController.java"
JAVA_ROOTS = (
    ROOT / "web-layer/src/main/java",
    ROOT / "db-layer/src/main/java",
    ROOT / "wms-layer/src/main/java",
)
OUTPUT = Path(__file__).with_name("endpoints-generated.md")
DTO_CATALOG = ROOT / "docs/docsforanalytics/dto/catalog"

MAPPING_RE = re.compile(r"@(Get|Post|Put|Delete|Patch)Mapping\b")
CLASS_RE = re.compile(r"public\s+class\s+(\w+)")
PUBLIC_METHOD_RE = re.compile(r"\bpublic\s+(?!class\b)")


@dataclass(frozen=True)
class Endpoint:
    controller: str
    source: Path
    line: int
    http_method: str
    paths: tuple[str, ...]
    request_body: str
    response: str
    permission: str
    handler: str
    controller_fqcn: str = ""
    origin: str = "ALIS"
    scan_package: str = ""
    activation_annotations: tuple[str, ...] = ()
    parameters: tuple["HttpParameter", ...] = ()
    consumes: tuple[str, ...] = ()
    produces: tuple[str, ...] = ()
    response_status: str = "200 OK (Spring MVC default)"
    api_responses: tuple["ApiResponseDeclaration", ...] = ()


@dataclass(frozen=True)
class HttpParameter:
    location: str
    wire_name: str
    java_name: str
    java_type: str
    required: str
    default: str
    validation: tuple[str, ...] = ()


@dataclass(frozen=True)
class ApiResponseDeclaration:
    code: str
    description: str
    media_types: tuple[str, ...] = ()
    schemas: tuple[str, ...] = ()
    use_return_type_schema: bool = False


@dataclass(frozen=True)
class ControllerScope:
    scan_package: str
    configured_package: str
    source_root: Path
    origin: str


def balanced_end(text: str, open_at: int, opening: str = "(", closing: str = ")") -> int:
    depth = 0
    in_string = False
    escaped = False
    for index in range(open_at, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == opening:
            depth += 1
        elif char == closing:
            depth -= 1
            if depth == 0:
                return index + 1
    return len(text)


def annotation_text(text: str, at: int) -> tuple[str, int]:
    name = re.match(r"@[\w.]+", text[at:])
    if not name:
        return "", at
    name_end = at + name.end()
    paren = name_end
    while paren < len(text) and text[paren].isspace():
        paren += 1
    if paren >= len(text) or text[paren] != "(":
        return text[at:name_end], name_end
    end = balanced_end(text, paren)
    return text[at:end], end


def quoted_values(annotation: str) -> tuple[str, ...]:
    return tuple(re.findall(r'"([^"\n]+)"', annotation))


def annotation_argument(annotation: str, name: str) -> str | None:
    match = re.search(rf"\b{re.escape(name)}\s*=", annotation)
    if not match:
        return None
    start = match.end()
    while start < len(annotation) and annotation[start].isspace():
        start += 1
    depth = 0
    in_string = escaped = False
    for index in range(start, len(annotation)):
        char = annotation[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "({[":
            depth += 1
        elif char in ")}]":
            if depth == 0:
                return normalize_space(annotation[start:index])
            depth -= 1
        elif char == "," and depth == 0:
            return normalize_space(annotation[start:index])
    return normalize_space(annotation[start:]).rstrip(")")


def expression_values(expression: str | None) -> tuple[str, ...]:
    if not expression:
        return ()
    value = expression.strip()
    if value.startswith("{") and value.endswith("}"):
        value = value[1:-1]
    result: list[str] = []
    start = depth = 0
    in_string = escaped = False
    for index, char in enumerate(value):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "({[":
            depth += 1
        elif char in ")}]":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            result.append(normalize_space(value[start:index]))
            start = index + 1
    result.append(normalize_space(value[start:]))
    return tuple(item for item in result if item)


def mapping_values(annotation: str, name: str) -> tuple[str, ...]:
    return expression_values(annotation_argument(annotation, name))


def mapping_paths(annotation: str) -> tuple[str, ...]:
    expression = annotation_argument(annotation, "path") or annotation_argument(annotation, "value")
    if expression:
        values = expression_values(expression)
        return tuple(value[1:-1] if value.startswith('"') and value.endswith('"') else value for value in values)
    if "=" not in annotation:
        return quoted_values(annotation)
    return ()


def class_mapping_annotation(prefix: str) -> str:
    candidates: list[tuple[int, str]] = []
    for name in ("RequestMapping", "ApiRestController"):
        for match in re.finditer(rf"@{name}\b", prefix):
            annotation, _ = annotation_text(prefix, match.start())
            candidates.append((match.start(), annotation))
    return max(candidates, default=(-1, ""))[1]


def component_scan_packages(source: str) -> tuple[str, ...]:
    match = re.search(r"@ComponentScan\b", source)
    if not match:
        return ()
    annotation, _ = annotation_text(source, match.start())
    packages = []
    for value in quoted_values(annotation):
        if value == "ru.korusconsulting.alis":
            packages.append("ru.korusconsulting.alis.controller")
        elif ".controller." in value or value.endswith(".controller"):
            packages.append(value)
    return tuple(dict.fromkeys(packages))


def controller_scopes() -> tuple[ControllerScope, ...]:
    source = COMPONENT_CONFIGURATION.read_text(encoding="utf-8")
    scopes: list[ControllerScope] = []
    for scan_package in component_scan_packages(source):
        if scan_package.startswith("ru.korusconsulting.alis."):
            java_root = ROOT / "web-layer/src/main/java"
            configured_package = "ru.korusconsulting.alis"
            origin = "ALIS"
        elif scan_package.startswith("ru.korusconsulting.wms."):
            java_root = ROOT / "wms-layer/src/main/java"
            configured_package = scan_package
            origin = "WMS"
        else:
            continue
        scopes.append(ControllerScope(
            scan_package=scan_package,
            configured_package=configured_package,
            source_root=java_root / Path(*scan_package.split(".")),
            origin=origin,
        ))
    return tuple(scopes)


def discover_controller_sources(
    scopes: tuple[ControllerScope, ...] | None = None,
) -> list[tuple[Path, ControllerScope]]:
    result: list[tuple[Path, ControllerScope]] = []
    for scope in scopes or controller_scopes():
        if not scope.source_root.exists():
            continue
        for source in sorted(scope.source_root.rglob("*Controller*.java")):
            result.append((source, scope))
    return result


def class_base_path(prefix: str) -> str:
    paths = mapping_paths(class_mapping_annotation(prefix))
    return paths[0] if paths else ""


def join_path(base: str, child: str) -> str:
    if not base and not child:
        return "/"
    return "/" + "/".join(part.strip("/") for part in (base, child) if part.strip("/"))


def normalize_space(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def extract_signature(text: str, start: int) -> tuple[str, int]:
    public = PUBLIC_METHOD_RE.search(text, start)
    if not public:
        return "", start
    brace = text.find("{", public.start())
    if brace < 0:
        return "", start
    return normalize_space(text[public.start():brace]), brace


def split_parameters(parameters: str) -> list[str]:
    parts: list[str] = []
    start = 0
    angle = paren = 0
    for index, char in enumerate(parameters):
        if char == "<":
            angle += 1
        elif char == ">":
            angle = max(0, angle - 1)
        elif char == "(":
            paren += 1
        elif char == ")":
            paren = max(0, paren - 1)
        elif char == "," and angle == 0 and paren == 0:
            parts.append(parameters[start:index])
            start = index + 1
    parts.append(parameters[start:])
    return parts


def parameter_annotations(parameter: str) -> list[tuple[str, str, int, int]]:
    result: list[tuple[str, str, int, int]] = []
    position = 0
    while True:
        match = re.search(r"@[\w.]+", parameter[position:])
        if not match:
            break
        start = position + match.start()
        annotation, end = annotation_text(parameter, start)
        simple_name = match.group(0)[1:].rsplit(".", 1)[-1]
        result.append((simple_name, normalize_space(annotation), start, end))
        position = max(end, start + 1)
    return result


def strip_parameter_annotations(parameter: str, annotations: list[tuple[str, str, int, int]]) -> str:
    result = parameter
    for _, _, start, end in reversed(annotations):
        result = result[:start] + " " + result[end:]
    return normalize_space(re.sub(r"\bfinal\b", "", result))


def unquote(value: str) -> str:
    value = value.strip()
    return value[1:-1] if len(value) >= 2 and value.startswith('"') and value.endswith('"') else value


def parse_parameters(signature: str) -> tuple[HttpParameter, ...]:
    open_paren = signature.find("(")
    close_paren = signature.rfind(")")
    if open_paren < 0 or close_paren < open_paren:
        return ()
    result: list[HttpParameter] = []
    location_by_annotation = {
        "PathVariable": "path",
        "RequestParam": "query",
        "RequestHeader": "header",
        "CookieValue": "cookie",
        "RequestBody": "body",
        "RequestPart": "part",
        "ModelAttribute": "model/form",
    }
    required_by_default = {"PathVariable", "RequestParam", "RequestHeader", "CookieValue", "RequestBody", "RequestPart"}
    for raw_parameter in split_parameters(signature[open_paren + 1:close_paren]):
        parameter = raw_parameter.strip()
        if not parameter:
            continue
        annotations = parameter_annotations(parameter)
        cleaned = strip_parameter_annotations(parameter, annotations)
        declaration = re.match(r"(.+?)\s+(\w+)$", cleaned)
        if not declaration:
            continue
        java_type, java_name = normalize_space(declaration.group(1)), declaration.group(2)
        transport = next(
            ((name, value) for name, value, _, _ in annotations if name in location_by_annotation),
            None,
        )
        if transport:
            annotation_name, annotation = transport
            location = location_by_annotation[annotation_name]
            name_expression = annotation_argument(annotation, "name") or annotation_argument(annotation, "value")
            if not name_expression and "=" not in annotation:
                quoted = quoted_values(annotation)
                name_expression = f'"{quoted[0]}"' if quoted else None
            wire_name = java_name if location in {"body", "model/form"} else unquote(name_expression or java_name)
            required_expression = annotation_argument(annotation, "required")
            default_expression = annotation_argument(annotation, "defaultValue")
            if required_expression:
                required = required_expression
            elif default_expression and annotation_name in {"RequestParam", "RequestHeader", "CookieValue"}:
                required = "false (задан defaultValue)"
            elif annotation_name in required_by_default:
                required = "true (Spring default)"
            else:
                required = "не применимо"
            default = unquote(default_expression) if default_expression else "—"
        else:
            location = "other/unclassified"
            wire_name = java_name
            required = "не задано"
            default = "—"
        validation_names = {
            "Valid", "Validated", "NotNull", "NotBlank", "NotEmpty", "Size", "Min", "Max",
            "Positive", "PositiveOrZero", "Negative", "NegativeOrZero", "Pattern", "Email",
            "Past", "PastOrPresent", "Future", "FutureOrPresent", "Nullable", "NonNull",
        }
        validation = tuple(
            value for name, value, _, _ in annotations if name in validation_names
        )
        result.append(HttpParameter(
            location=location,
            wire_name=wire_name,
            java_name=java_name,
            java_type=java_type,
            required=required,
            default=default,
            validation=validation,
        ))
    return tuple(result)


def request_body_type(signature: str) -> str:
    for parameter in parse_parameters(signature):
        if parameter.location == "body":
            return parameter.java_type
    return "—"


def return_and_handler(signature: str) -> tuple[str, str]:
    match = re.match(r"public\s+(.+?)\s+(\w+)\s*\(", signature)
    if not match:
        return "?", "?"
    return match.group(1), match.group(2)


def permission_between(text: str) -> str:
    match = re.search(r"@Secure\b", text)
    if not match:
        return "не указан"
    annotation, _ = annotation_text(text, match.start())
    permission = re.search(r"permission\s*=\s*Permission\.([A-Z0-9_]+)", annotation)
    permission_name = re.search(r'permissionName\s*=\s*"([^"]+)"', annotation)
    access = re.search(r"accessLevel\s*=\s*PermissionLevel\.([A-Z]+)", annotation)
    name = permission.group(1) if permission else permission_name.group(1) if permission_name else "custom"
    return name + (f"/{access.group(1)}" if access else "")


def class_activation_annotations(prefix: str) -> tuple[str, ...]:
    values: list[str] = []
    for match in re.finditer(r"@(Profile|Conditional[A-Za-z0-9_]*)\b", prefix):
        annotation, _ = annotation_text(prefix, match.start())
        values.append(normalize_space(annotation))
    return tuple(dict.fromkeys(values))


def response_status(method_metadata: str, response_type: str = "") -> str:
    match = re.search(r"@ResponseStatus\b", method_metadata)
    if not match:
        if re.search(r"\bResponseEntity\s*(?:<|$)", response_type):
            return "определяется ResponseEntity/handler"
        return "200 OK (Spring MVC default)"
    annotation, _ = annotation_text(method_metadata, match.start())
    value = annotation_argument(annotation, "code") or annotation_argument(annotation, "value")
    if value:
        return value
    shorthand = re.search(r"@ResponseStatus\s*\(\s*([^,)]+)", annotation)
    return normalize_space(shorthand.group(1)) if shorthand else "аннотация без явного значения"


def parse_api_responses(method_metadata: str) -> tuple[ApiResponseDeclaration, ...]:
    result: list[ApiResponseDeclaration] = []
    position = 0
    while True:
        match = re.search(r"@ApiResponse\b", method_metadata[position:])
        if not match:
            break
        start = position + match.start()
        annotation, end = annotation_text(method_metadata, start)
        code = unquote(annotation_argument(annotation, "responseCode") or "не задан")
        description = unquote(annotation_argument(annotation, "description") or "—")
        media_types = tuple(dict.fromkeys(
            unquote(value)
            for value in re.findall(r"\bmediaType\s*=\s*(\"[^\"]+\"|[\w.]+)", annotation)
        ))
        schemas = tuple(dict.fromkeys(
            re.findall(r"\bimplementation\s*=\s*([\w.]+)\.class", annotation)
        ))
        use_return_type_schema = bool(re.search(r"\buseReturnTypeSchema\s*=\s*true", annotation))
        result.append(ApiResponseDeclaration(
            code=code,
            description=description,
            media_types=media_types,
            schemas=schemas,
            use_return_type_schema=use_return_type_schema,
        ))
        position = max(end, start + 1)
    return tuple(result)


def effective_mapping_values(method_annotation: str, class_annotation: str, name: str) -> tuple[str, ...]:
    method_values = mapping_values(method_annotation, name)
    if method_values:
        return method_values
    class_values = mapping_values(class_annotation, name)
    if class_values:
        return class_values
    if class_annotation.startswith("@ApiRestController"):
        source = API_REST_CONTROLLER.read_text(encoding="utf-8")
        default = re.search(rf"\bString\[\]\s+{re.escape(name)}\s*\(\)\s+default\s+([^;]+);", source)
        return expression_values(default.group(1)) if default else ()
    return ()


def parse_controller(source: Path, scope: ControllerScope | None = None) -> list[Endpoint]:
    text = source.read_text(encoding="utf-8")
    package_match = re.search(r"^\s*package\s+([\w.]+);", text, re.M)
    class_match = CLASS_RE.search(text)
    if not class_match:
        return []
    controller = class_match.group(1)
    controller_fqcn = f"{package_match.group(1)}.{controller}" if package_match else controller
    class_prefix = text[:class_match.start()]
    base_path = class_base_path(class_prefix)
    class_mapping = class_mapping_annotation(class_prefix)
    activation_annotations = class_activation_annotations(class_prefix)
    matches = list(MAPPING_RE.finditer(text))
    endpoints: list[Endpoint] = []
    previous_method_end = class_match.end()
    for index, mapping in enumerate(matches):
        annotation, annotation_end = annotation_text(text, mapping.start())
        next_mapping = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        signature, method_body_start = extract_signature(text, annotation_end)
        public_at = text.find("public ", annotation_end, next_mapping)
        if not signature or public_at < 0:
            continue
        method_metadata = text[previous_method_end:public_at]
        response, handler = return_and_handler(signature)
        child_paths = mapping_paths(annotation) or ("",)
        parameters = parse_parameters(signature)
        endpoints.append(Endpoint(
            controller=controller,
            source=source,
            line=text.count("\n", 0, mapping.start()) + 1,
            http_method=mapping.group(1).upper(),
            paths=tuple(join_path(base_path, child) for child in child_paths),
            request_body=request_body_type(signature),
            response=response,
            permission=permission_between(method_metadata),
            handler=handler,
            controller_fqcn=controller_fqcn,
            origin=scope.origin if scope else ("WMS" if ".wms." in controller_fqcn else "ALIS"),
            scan_package=scope.scan_package if scope else (package_match.group(1) if package_match else ""),
            activation_annotations=activation_annotations,
            parameters=parameters,
            consumes=effective_mapping_values(annotation, class_mapping, "consumes"),
            produces=effective_mapping_values(annotation, class_mapping, "produces"),
            response_status=response_status(method_metadata, response),
            api_responses=parse_api_responses(method_metadata),
        ))
        previous_method_end = balanced_end(text, method_body_start, "{", "}")
    return endpoints


def java_links(value: str, class_index: dict[str, Path], dto_docs: dict[str, Path]) -> str:
    escaped = value.replace("|", "\\|")
    names = sorted(
        set(re.findall(r"\b[A-Z][A-Za-z0-9_]*(?:\.[A-Z][A-Za-z0-9_]*)*\b", value)),
        key=len,
        reverse=True,
    )
    for name in names:
        dto_page = dto_docs.get(name) or dto_docs.get(name.rsplit(".", 1)[-1])
        if dto_page:
            relative = Path("../dto/catalog") / dto_page.relative_to(DTO_CATALOG)
            escaped = re.sub(rf"\b{re.escape(name)}\b", f"[{name}]({relative.as_posix()})", escaped)
            continue
        source = class_index.get(name)
        if not source:
            continue
        relative = Path("../../..") / source.relative_to(ROOT)
        escaped = re.sub(rf"\b{re.escape(name)}\b", f"[{name}]({relative.as_posix()})", escaped)
    return f"`{escaped}`" if not names and escaped != "—" else escaped


def build_dto_doc_index() -> dict[str, Path]:
    if not DTO_CATALOG.exists():
        return {}
    pages: dict[str, list[Path]] = {}
    for page in DTO_CATALOG.rglob("*.md"):
        if page.name == "README.md":
            continue
        pages.setdefault(page.stem, []).append(page)
    return {name: matches[0] for name, matches in pages.items() if len(matches) == 1}


def build_class_index() -> dict[str, Path]:
    candidates: dict[str, list[Path]] = {}
    for root in JAVA_ROOTS:
        if not root.exists():
            continue
        for source in root.rglob("*.java"):
            candidates.setdefault(source.stem, []).append(source)
    return {name: paths[0] for name, paths in candidates.items() if len(paths) == 1}


def enum_constants(java_type: str, class_index: dict[str, Path]) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Return source-declared constants for enum types present in a Java signature."""
    result: list[tuple[str, tuple[str, ...]]] = []
    for name in dict.fromkeys(re.findall(r"\b[A-Z][A-Za-z0-9_]*\b", java_type)):
        source = class_index.get(name)
        if not source:
            continue
        text = source.read_text(encoding="utf-8")
        declaration = re.search(rf"\benum\s+{re.escape(name)}\b[^{{]*{{", text)
        if not declaration:
            continue
        opening = text.find("{", declaration.start())
        enum_end = balanced_end(text, opening, "{", "}")
        body = text[opening + 1:enum_end - 1]
        depth = 0
        in_string = escaped = False
        constants_end = len(body)
        for index, char in enumerate(body):
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char in "({[":
                depth += 1
            elif char in ")}]":
                depth = max(0, depth - 1)
            elif char == ";" and depth == 0:
                constants_end = index
                break
        constants_block = re.sub(r"/\*.*?\*/|//[^\n]*", " ", body[:constants_end], flags=re.S)
        constants: list[str] = []
        start = depth = 0
        in_string = escaped = False
        parts: list[str] = []
        for index, char in enumerate(constants_block):
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char in "({[":
                depth += 1
            elif char in ")}]":
                depth = max(0, depth - 1)
            elif char == "," and depth == 0:
                parts.append(constants_block[start:index])
                start = index + 1
        parts.append(constants_block[start:])
        for part in parts:
            candidate = re.sub(r"^(?:\s*@\w+(?:\([^)]*\))?\s*)+", "", part).strip()
            constant = re.match(r"([A-Z][A-Z0-9_]*)\b", candidate)
            if constant:
                constants.append(constant.group(1))
        if constants:
            result.append((name, tuple(constants)))
    return tuple(result)


def escape_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def render_values(values: tuple[str, ...]) -> str:
    return "<br>".join(f"`{escape_cell(unquote(value))}`" for value in values) or "—"


def render_enum_constants(java_type: str, class_index: dict[str, Path]) -> str:
    groups = enum_constants(java_type, class_index)
    if not groups:
        return ""
    return "<br>".join(
        f"enum `{name}`: {', '.join(f'`{value}`' for value in values)}"
        for name, values in groups
    )


def render_parameters(
    parameters: tuple[HttpParameter, ...],
    class_index: dict[str, Path],
    dto_docs: dict[str, Path],
) -> str:
    if not parameters:
        return "—"
    result: list[str] = []
    for parameter in parameters:
        java_type = java_links(parameter.java_type, class_index, dto_docs)
        details = f"`{parameter.location}:{parameter.wire_name}` — {java_type}; required: `{parameter.required}`"
        enum_values = render_enum_constants(parameter.java_type, class_index)
        if enum_values:
            details += f"; {enum_values}"
        if parameter.default != "—":
            details += f"; default: `{parameter.default}`"
        if parameter.validation:
            validation = ", ".join(f"`{escape_cell(value)}`" for value in parameter.validation)
            details += f"; validation: {validation}"
        result.append(details)
    return "<br>".join(result)


def render_api_responses(
    responses: tuple[ApiResponseDeclaration, ...],
    class_index: dict[str, Path],
    dto_docs: dict[str, Path],
) -> str:
    if not responses:
        return "не объявлены"
    result: list[str] = []
    for response in responses:
        value = f"`{response.code}` — {escape_cell(response.description)}"
        if response.media_types:
            value += f"; media: {render_values(response.media_types)}"
        if response.schemas:
            schemas = ", ".join(java_links(schema, class_index, dto_docs) for schema in response.schemas)
            value += f"; schema: {schemas}"
        if response.use_return_type_schema:
            value += "; schema: return type"
        if not response.media_types and not response.schemas and not response.use_return_type_schema:
            value += "; content/schema: не указаны"
        elif response.media_types and not response.schemas and not response.use_return_type_schema:
            value += "; schema: не указана"
        result.append(value)
    return "<br>".join(result)


def render(endpoints: list[Endpoint], scopes: tuple[ControllerScope, ...] | None = None) -> str:
    scopes = scopes or controller_scopes()
    class_index = build_class_index()
    dto_docs = build_dto_doc_index()
    grouped: dict[str, list[Endpoint]] = {}
    for endpoint in endpoints:
        grouped.setdefault(endpoint.controller_fqcn or endpoint.controller, []).append(endpoint)
    origin_counts = {
        origin: len({item.controller_fqcn or item.controller for item in endpoints if item.origin == origin})
        for origin in sorted({item.origin for item in endpoints})
    }
    parameter_counts: dict[str, int] = {}
    for item in endpoints:
        for parameter in item.parameters:
            parameter_counts[parameter.location] = parameter_counts.get(parameter.location, 0) + 1
    configuration_relative = Path("../../..") / COMPONENT_CONFIGURATION.relative_to(ROOT)

    lines = [
        "# Каталог HTTP endpoints",
        "",
        "> Файл сгенерирован из Spring-контроллеров. Не редактировать вручную; запустить `python3 docs/docsforanalytics/api/generate_endpoint_catalog.py`.",
        "",
        f"Контроллеров: **{len(grouped)}**. Mapping-методов: **{len(endpoints)}**. Один mapping-метод с несколькими путями показан одной строкой.",
        f"По исходникам: {', '.join(f'**{count} {origin}-контроллеров**' for origin, count in origin_counts.items())}.",
        f"Параметров методов: **{sum(parameter_counts.values())}** ({', '.join(f'{name}: {count}' for name, count in sorted(parameter_counts.items()))}). OpenAPI `@ApiResponse`: **{sum(len(item.api_responses) for item in endpoints)}**.",
        "",
        f"Каталог фиксирует mappings, найденные в исходниках пакетов из [`ComponentConfiguration.@ComponentScan`]({configuration_relative.as_posix()}#L17). Это не подтверждение регистрации endpoint в работающем приложении. Серверная бизнес-логика заявок описана вручную в [API заявок](order-api.md), обязательность полей — в [карте валидации](../business-rules/order-validation.md).",
        "",
        "## Область сканирования",
        "",
        "| Происхождение | Пакет контроллеров | Основание включения | Контроллеров с mapping |",
        "|---|---|---|---:|",
    ]
    for scope in scopes:
        count = len({
            item.controller_fqcn or item.controller
            for item in endpoints
            if item.scan_package == scope.scan_package
        })
        lines.append(
            f"| {scope.origin} | `{scope.scan_package}` | `@ComponentScan(\"{scope.configured_package}\")` | {count} |"
        )
    lines.extend([
        "",
        "## Обозначения",
        "",
        "- `required` — значение параметра Spring-аннотации либо её default. Оно не заменяет Bean Validation и бизнес-проверки.",
        "- `model/form` означает binding через `@ModelAttribute`; состав multipart/form полей раскрывается в связанном DTO.",
        "- `other/unclassified` — параметр Java-метода без распознанной transport-аннотации, например servlet response; генератор не угадывает источник значения.",
        "- `consumes`/`produces` берутся из method mapping, затем из class mapping. Для `@ApiRestController` учитываются defaults, объявленные в исходнике этой аннотации.",
        "- Составные Java-типы сохраняются в сигнатуре, DTO и доступные локальные классы получают ссылки; для enum дополнительно перечисляются константы из исходника.",
        "- OpenAPI responses отражают только `@ApiResponse`; фактические ответы exception advice и ветвлений handler этим не доказываются.",
        "- Status берётся из `@ResponseStatus`; для `ResponseEntity` помечается как определяемый handler, иначе показан обычный успешный default Spring MVC `200 OK`. Код всё ещё может быть изменён servlet API, advice, фильтром или ошибкой выполнения.",
        "- `не указан` означает отсутствие `@Secure` непосредственно у метода; это не доказывает публичный доступ, так как защита может применяться глобально.",
        "- Ссылки на DTO ведут в технический каталог DTO, откуда доступен Java-источник; ссылки на filter ведут к Java-классам.",
        "- ALIS/WMS означает происхождение Java-класса, а не отдельный deployed-сервис.",
        "- Контроллер найден в package, охваченном `@ComponentScan`; profile/condition, итоговый Spring context, reverse proxy и фактическая доступность маршрута не проверялись.",
        "",
    ])
    for controller_fqcn in sorted(grouped):
        items = grouped[controller_fqcn]
        source = items[0].source
        source_relative = Path("../../..") / source.relative_to(ROOT)
        lines.extend([
            f"## `{items[0].controller}`",
            "",
            f"- **Java FQCN:** `{controller_fqcn}`",
            f"- **Происхождение:** {items[0].origin}",
            f"- **Основание включения:** package `{items[0].scan_package}` охвачен `ComponentConfiguration.@ComponentScan`",
            f"- **Class-level profile/condition:** {', '.join(f'`{value}`' for value in items[0].activation_annotations) if items[0].activation_annotations else 'не найдены непосредственно на классе'}",
            "- **Статус:** mapping найден в исходнике; runtime-регистрация не проверена",
            f"Источник: [{source.name}]({source_relative.as_posix()})",
            "",
            "| Метод | Путь | Параметры | Consumes | Java response / status | Produces | OpenAPI responses | Permission | Handler |",
            "|---|---|---|---|---|---|---|---|---|",
        ])
        for item in items:
            paths = "<br>".join(f"`{path}`" for path in item.paths)
            parameters = render_parameters(item.parameters, class_index, dto_docs)
            response = java_links(item.response, class_index, dto_docs)
            response_enums = render_enum_constants(item.response, class_index)
            if response_enums:
                response += f"<br>{response_enums}"
            response += f"<br>status: `{item.response_status}`"
            api_responses = render_api_responses(item.api_responses, class_index, dto_docs)
            handler = f"[`{item.handler}()`]({source_relative.as_posix()}#L{item.line})"
            lines.append(
                f"| `{item.http_method}` | {paths} | {parameters} | {render_values(item.consumes)} "
                f"| {response} | {render_values(item.produces)} | {api_responses} "
                f"| `{item.permission}` | {handler} |"
            )
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    scopes = controller_scopes()
    endpoints: list[Endpoint] = []
    for source, scope in discover_controller_sources(scopes):
        endpoints.extend(parse_controller(source, scope))
    OUTPUT.write_text(render(endpoints, scopes), encoding="utf-8")
    print(f"Generated {OUTPUT.relative_to(ROOT)}: {len(endpoints)} mappings")


if __name__ == "__main__":
    main()
