# API заявок и серверная логика

Документ описывает HTTP-контур `ReceivingOrder`, `ShippingOrder`, `ServiceOrder` и их дочерних ресурсов. Полный построчный список всех mapping-методов находится в [сгенерированном каталоге](endpoints-generated.md); здесь зафиксирована семантика операций. PDF `MX-1`, `M-7`, `MX-3`, `ContainerTN`, Packing List и общий availability разобраны в [PDF-контуре заявок](../business-rules/order-pdf-reports-as-is.md), четыре корневые Excel-выгрузки V1/V2 — в [Excel-контуре заявок](../business-rules/order-excel-exports-as-is.md), receiving child exports — в [первой](../business-rules/receiving-order-child-excel-exports-as-is.md) и [второй](../business-rules/receiving-order-child-excel-exports-part2-as-is.md) частях, shipping child exports — в [первой](../business-rules/shipping-order-child-excel-exports-as-is.md) и [второй](../business-rules/shipping-order-child-excel-exports-part2-as-is.md) частях. Связанный основной контур `Route` описан в [lifecycle AS-IS](../business-rules/route-lifecycle-as-is.md), shipping plan/fact/meta — в [трассировке read-моделей](../business-rules/route-shipping-plan-fact-as-is.md), а пять PDF/Excel endpoints рейса — в [отчётном контуре рейса](../business-rules/route-reports-as-is.md).

## Общий конвейер запроса

Права на PDF и Excel endpoints, роль `@Secure`/`@Secures` и граница между permission метода и доступом к данным клиента сведены в [матрице прав отчётов заявок](../business-rules/order-report-access-as-is.md).

```mermaid
flowchart TD
    A[HTTP request] --> B[Jackson: JSON → DTO или filter]
    B --> C[Bean Validation]
    C -->|ошибка| X[400 Validation problems]
    C --> D[Проверка method-level permission]
    D -->|нет доступа| Y[Ошибка авторизации]
    D --> E[Controller: path ID → DTO/filter<br/>если это реализовано handler-ом]
    E --> F[Service transaction]
    F --> G[Mapping DTO → model<br/>и разрешение ссылок через DAO]
    G --> H[Статусные и предметные проверки]
    H -->|ошибка| Z[400 / 404 / conflict]
    H --> I[add / update / soft delete / merge]
    I --> J[Пересчёт агрегатов]
    J --> K{Сценарий требует outbound?}
    K -->|да| L[Создать outbound data / chain package]
    K -->|нет| M[Без исходящего сообщения]
    L --> N[Response DTO]
    M --> N
```

Обязательные поля и порядок ошибок подробно описаны в [карте валидации](../business-rules/order-validation.md). Коды review/accept — в [каталоге ошибок](../business-rules/order-errors.md).

## Общие виды read endpoints

| Суффикс | Request | Результат | Серверная логика |
|---|---|---|---|
| `/all` или `/list` | filter либо `FilterWithPaging<Filter>`; иногда body optional | Список кратких/полных DTO | Обогащение фильтра правами и клиентским контекстом, выборка без page либо scoped list |
| `/page` | `FilterWithPaging<Filter>` | `Page<Dto>` | Фильтрация, сортировка, пагинация, mapping сущностей |
| `/meta/{fieldName}` | filter/page context | `List<IdsCodeDto>` | Уникальные значения колонки для фильтра UI; неизвестное поле может дать not found |
| `GET /{id}` | UUID в path | Один DTO | Поиск доступной неудалённой записи и mapping |
| `/preview` | filter или UUID | Detailed/preview DTO | Расширенная выборка и вычисляемые агрегаты |

`POST` у read endpoint не означает изменение данных: он используется, чтобы передать сложный filter в body.

## Жизненный цикл корневой заявки

```mermaid
flowchart LR
    A[Создание] --> B[DRAFT]
    B -->|review| C[ON_REVIEW]
    B -->|accept разрешён сервисом| D[ACCEPTED]
    B -->|reject| E[REJECTED]
    C -->|accept| D
    C -->|reject| E
    D -->|возврат разрешён enum| B
    D -->|событие TOS/WMS| F[IN_PROGRESS]
    D -->|служебный переход| G[DONE]
    D -->|reject| E
    F -->|завершение| G
    F -->|reject| E
    G -->|поздний reject разрешён enum| E
```

Схема показывает разрешения enum-модели поставки и вывоза, но не гарантирует наличие публичного endpoint для каждого перехода. Детали — в [статусах заявок](../business-rules/order-statuses.md). Сервисная заявка имеет отдельный упрощённый сценарий `DRAFT → DONE` через accept.

## Корень поставки `/receivingorder`

Полная таблица: [`ReceivingOrderController`](endpoints-generated.md#receivingordercontroller). Контракты: [create](../dto/receiving-order/ReceivingOrderCreationDto.md), [update](../dto/receiving-order/ReceivingOrderUpdateDto.md), [response](../dto/receiving-order/ReceivingOrderDto.md), [detailed](../dto/receiving-order/ReceivingOrderDetailedDto.md).

| Endpoint | Request / response | Серверная логика |
|---|---|---|
| `POST /receivingorder/` | `ReceivingOrderCreationDto` → `ReceivingOrderDto` | Mapping ссылок; сервер ставит `DRAFT`, проверяет и нормализует комбинацию; генерирует UUID/номер; сохраняет корень; создаёт обязательные услуги договора |
| `PUT /receivingorder/{id}` | `ReceivingOrderUpdateDto` → `ReceivingOrderDto` | Фактически ищет по `body.id`; проверяет право изменения текущего статуса; обновляет разрешённые поля и ссылки; path ID методом не читается |
| `PUT /receivingorder/{id}/review` | без body → DTO | Блокирует строку; проверяет переход в `ON_REVIEW`; запускает `ReceivingOrderAcceptValidator(..., false)`; сохраняет новый статус |
| `PUT /receivingorder/{id}/reject` | без body → DTO | Блокирует строку; проверяет переход в `REJECTED`; ставит статус; удаляет связи заявки с накладными |
| `GET|POST /receivingorder/{id}/total-cargo-quantity` | path/filter → `ReceivingOrderTotalCargoQuantityDto` | Читает общее количество грузовых мест; POST применяет filter |
| `PUT /receivingorder/{id}/total-cargo-quantity` | `ReceivingOrderTotalCargoQuantityDto` | Разрешено для `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`; меняет агрегированное количество |
| `PUT .../confirm-document` / `unconfirm-document` | без body → detailed | Только `ACCEPTED`/`IN_PROGRESS`; однократная фиксация решения; создаётся `CONFIRM_DOCS` по контейнерам |
| `POST|PUT /receivingorder/{id}/waybills` | filter либо [WaybillSelectionDto](../dto/catalog/waybill/WaybillSelectionDto.md) | Читает либо полностью заменяет набор связанных накладных; серверный алгоритм и legacy API разобраны в [Waybill/ЭТРАН AS-IS](../business-rules/waybill-etran-as-is.md) |
| `POST .../waybill-{railway-carriages|containers|products}/page` | соответствующий filter | Группированное чтение содержимого связанных накладных |
| `POST .../{partial-copy|full-copy}` | без body → detailed | Создаёт новый `DRAFT`; состав копии и запрет full copy для ЖД описаны в [правилах копирования](../business-rules/order-copying.md) |

Сервисный `accept(UUID)` существует, но public mapping в `ReceivingOrderController` отсутствует. Он блокирует заявку, проверяет переход и полный accept-validator, ставит `ACCEPTED`, затем создаёт outbound, если не используется route chain package.

## Корень вывоза `/shippingorder`

Полная таблица: [`ShippingOrderController`](endpoints-generated.md#shippingordercontroller). Контракты: [create](../dto/shipping-order/ShippingOrderCreationDto.md), [update](../dto/shipping-order/ShippingOrderUpdateDto.md), [response](../dto/shipping-order/ShippingOrderDto.md), [detailed](../dto/shipping-order/ShippingOrderDetailedDto.md).

| Endpoint | Request / response | Серверная логика |
|---|---|---|
| `POST /shippingorder/` | `ShippingOrderCreationDto` → `ShippingOrderDto` | Разрешает ссылки; проверяет грузополучателя; ставит `DRAFT`; нормализует `deliveryType`/`fillingType`; генерирует UUID/номер; создаёт обязательные услуги |
| `PUT /shippingorder/{id}` | `ShippingOrderUpdateDto` → `ShippingOrderDto` | Фактически использует `body.id`; проверяет изменяемость статуса; обновляет разрешённые поля; проверяет роль и клиента грузополучателя; path ID не читается |
| `PUT /shippingorder/{id}/review` | без body → DTO | Блокировка, проверка перехода, `ShippingOrderAcceptValidator(..., false)`, статус `ON_REVIEW` |
| `PUT /shippingorder/{id}/reject` | без body → DTO | Блокировка, проверка перехода, статус `REJECTED` |
| `POST /shippingorder/unnumbered/{page|meta/...}` | `ShippingOrderFilter` | Legacy-представление заявок, у которых `fillingType != ALL` |
| `POST .../{partial-copy|full-copy}` | без body → detailed | Создание нового `DRAFT` по белому списку; full copy для ЖД запрещён |

Сервисный `accept(UUID)` существует, но public mapping отсутствует. После полной агрегатной проверки он ставит `ACCEPTED` и создаёт outbound при выключенном route chain package.

## Сервисная заявка `/service-order`

Полная таблица: [`ServiceOrderController`](endpoints-generated.md#serviceordercontroller). Контракты: [create](../dto/service-order/ServiceOrderCreationDto.md), [update](../dto/service-order/ServiceOrderUpdateDto.md), [response](../dto/service-order/ServiceOrderDto.md). Ручной сквозной разбор всех корневых и контейнерных endpoints: [lifecycle ServiceOrder](../business-rules/service-order-lifecycle.md).

| Endpoint | Request / response | Серверная логика |
|---|---|---|
| `POST /service-order/` | `ServiceOrderCreationDto` → DTO | Генерирует UUID/номер, ставит `DRAFT`, сохраняет `client`, `service`, `comment` |
| `PUT /service-order/{id}` | `ServiceOrderUpdateDto` → DTO | Требует совпадения path ID и `body.id`; только `DRAFT`; меняет `service` и `comment` |
| `DELETE /service-order/{id}` | без body → DTO | Только `DRAFT`; сначала удаляет связи `ServiceOrderContainer`, затем заявку |
| `POST /service-order/{id}/accept` | без body → DTO | Блокирует заявку; требует `DRAFT` и минимум один контейнер; меняет владельцев КТК на клиента; ставит `DONE/completionAt`; создаёт outbound chain package |

## Дочерние ресурсы поставки

Каждая ссылка на контроллер открывает исчерпывающую таблицу его endpoints и DTO.

| Ресурс / контроллер | Базовый путь | Запись | Существенная серверная логика |
|---|---|---|---|
| [Blackbox](endpoints-generated.md#receivingorderblackboxcontroller) | `/receivingorderblackbox` | creation/update DTO, bulk create | Только для изменяемой заявки; после записи/удаления пересчитывает агрегаты корня |
| [Товары](endpoints-generated.md#receivingordergoodcontroller) | `/receivingordergood` | create/update, batch, multiple | Проверяет статус родителя; разрешает ссылки товара/партии; пересчитывает суммы и количество |
| [Грузы](endpoints-generated.md#receivingordercargocontroller) | `/receivingordercargo` | create/update, upsert-and-delete, multiple | Проверяет статус; связывает груз с товарной строкой; пересчитывает агрегаты; `preview` ошибочно защищён shipping permission |
| [Контейнеры legacy](endpoints-generated.md#receivingordercontainercontroller) | `/receivingordercontainer` | CRUD, bulk, upsert-and-delete | Проверяет статус; разрешает КТК/владельца; обновляет вес и итоги заявки |
| [Контейнеры scoped](endpoints-generated.md#receivingordercontainercontrollerv2) | `/receiving-order/{id}/receiving-order-container` | `BatchModificationDto<CreationDto,UpdateDto>` | Controller принудительно подставляет receiving order из path в add/update; batch применяет add/update/delete в одном вызове |
| [Items legacy](endpoints-generated.md#receivingordercontaineritemcontroller) | `/receivingordercontaineritem` | CRUD, upsert-and-delete | Проверяет статус родителя; после изменения пересчитывает контейнер и заявку |
| [Items scoped](endpoints-generated.md#receivingordercontaineritemcontrollerv2) | `/receiving-order/{id}/receiving-order-container-item` | list, batch | Группированное чтение; path ID подставляется в изменения; batch синхронизирует набор |
| [Накладные/ЭТРАН](endpoints-generated.md#receivingorderetraninvoicecontroller) | `/receivingorderetraninvoice` | операции над связью Waybill | Фактический источник — `Waybill`; данные вагонов/КТК/товаров принадлежат накладной; [ручная серверная трассировка](../business-rules/waybill-etran-as-is.md#связь-с-заявкой-на-поставку) |
| [Вагоны](endpoints-generated.md#receivingorderrailwaycarriagecontroller) | `/receivingorderrailwaycarriage` | преимущественно read/preview | После KIS-3631 фактические вагоны поставки читаются через `WaybillRailwayCarriage` |
| [Заказанные услуги](endpoints-generated.md#receivingorderrequestedservicecontroller) | `/receivingorderrequestedservice` | CRUD, multiple | Проверяет статус; системные обязательные строки создаются при create корня; цены и итоги пересчитываются |
| [Транспорт](endpoints-generated.md#receivingordertransportcontroller) | `/receivingordertransport` | create/update, read | One-to-one использует shared ID заявки; нужен для review/accept авто-сценария |

## Дочерние ресурсы вывоза

| Ресурс / контроллер | Базовый путь | Запись | Существенная серверная логика |
|---|---|---|---|
| [Blackbox legacy](endpoints-generated.md#shippingorderblackboxcontroller), [scoped read](endpoints-generated.md#shippingorderblackboxcontrollerv2) | `/shippingorderblackbox`, `/shipping-order/{id}/shipping-order-blackbox` | legacy CRUD/multiple | Нужен при `BY_CARGO`; проверяет статус; пересчитывает агрегаты |
| [Товары legacy](endpoints-generated.md#shippingordergoodcontroller), [scoped](endpoints-generated.md#shippingordergoodcontrollerv2) | `/shippingordergood`, `/shipping-order/{id}/shipping-order-good` | CRUD, batch, multiple | Проверяет статус; batch синхронизирует набор в рамках path order |
| [Грузы legacy](endpoints-generated.md#shippingordercargocontroller), [scoped](endpoints-generated.md#shippingordercargocontrollerv2) | `/shippingordercargo`, `/shipping-order/{id}/shipping-order-cargo` | CRUD, batch/upsert | Нужны для detailed delivery type; изменение пересчитывает агрегаты |
| [Контейнеры legacy](endpoints-generated.md#shippingordercontainercontroller), [scoped](endpoints-generated.md#shippingordercontainercontrollerv2) | `/shippingordercontainer`, `/shipping-order/{id}/shipping-order-container` | CRUD и merge/batch | Проверяет статус; связывает КТК, владельца и вагон; merge заменяет актуальный набор |
| [Items legacy](endpoints-generated.md#shippingordercontaineritemcontroller), [scoped](endpoints-generated.md#shippingordercontaineritemcontrollerv2) | `/shippingordercontaineritem`, `/shipping-order/{id}/shipping-order-container-item` | CRUD и merge | Пересчитывает контейнер и заявку; scoped merge синхронизирует набор; preview-meta принудительно ограничен контейнерами, связанными с вагоном |
| [Количество КТК](endpoints-generated.md#shippingordercontainerqtycontroller) | `/shipping-order/{id}/shipping-order-container-qty` | merge | Используется для безномерных КТК; для `NONE_CONTAINER` ровно одна пустая строка quantity=1 без ЕТСНГ; проверяются дубли сигнатур |
| [ЭТРАН legacy](endpoints-generated.md#shippingorderetraninvoicecontroller), [merge](endpoints-generated.md#shippingorderetraninvoicecontrollerv2), [scoped read](endpoints-generated.md#shippingorderetraninvoicecontrollerv2read) | legacy и `/shipping-order/{id}/...` | CRUD/upsert/merge | Синхронизирует документы заявки; при `ALL` документ требуется review/accept и вагон должен быть с ним связан |
| [Вагоны legacy](endpoints-generated.md#shippingorderrailwaycarriagecontroller), [scoped](endpoints-generated.md#shippingorderrailwaycarriagecontrollerv2) | legacy и `/shipping-order/{id}/shipping-order-railway-carriage` | CRUD/upsert/merge | Проверяет статус; поддерживает numbered и unnumbered представления; merge синхронизирует набор |
| [Количество вагонов](endpoints-generated.md#shippingorderrailwaycarriageqtycontroller) | `/shipping-order/{id}/shipping-order-railway-carriage-qty` | merge | Используется при `fillingType=CONTAINER/NONE`; синхронизирует количественные строки |
| [Заказанные услуги](endpoints-generated.md#shippingorderrequestedservicecontroller) | `/shippingorderrequestedservice` | CRUD/multiple | Проверяет статус; системные строки создаются из договора; пересчитывает стоимость заявки |
| [Транспорт](endpoints-generated.md#shippingordertransportcontroller) | `/shippingordertransport` | create/update, read | One-to-one с заявкой; обязателен для авто-сценария перед review/accept |

## Контейнеры сервисной заявки

[`ServiceOrderContainerController`](endpoints-generated.md#serviceordercontainercontroller) работает по пути `/service-order/{serviceOrderId}/container`.

- `/page` читает уже выбранные контейнеры.
- `/edit/page` и `/edit/meta/{fieldName}` показывают доступные для выбора КТК с другими текущими владельцами.
- `PUT` принимает `List<ServiceOrderContainerSaveDto>` и полностью заменяет выбор. Каждый элемент должен содержать `id` существующей связи либо `containerOwnerId`; операция разрешена только в `DRAFT`.
- Пустой список допустим и очищает выбор. Новые КТК выбираются по текущему `ContainerOwner`; владелец должен отличаться от клиента заявки, а КТК не должен находиться в другой заявке `DRAFT`.

## CRUD, batch, upsert и merge

| Механизм | Семантика |
|---|---|
| Обычный create | Создаёт одну дочернюю строку; parent обычно указан в DTO |
| Обычный update | Изменяет строку, как правило идентифицированную `body.id`; наличие `{id}` в URL не гарантирует, что он используется |
| Delete | Для большинства дочерних сущностей применяется generic remove и модель мягкого удаления; точную физическую семантику определяет entity/DAO |
| `multipleaddition` / `multipleupdate` | Последовательно/пакетно применяет однотипные DTO; это не означает замену полного набора |
| `upsertAndDelete` | Входной список трактуется как желаемое состояние в границах parent filter: существующие обновляются, новые добавляются, отсутствующие удаляются |
| `BatchModificationDto` | Явно разделяет `add`, `update`, `delete`; scoped controller подставляет parent ID из path |
| `merge` | Синхронизирует представление ресурса для одной заявки и возвращает актуальный набор; может выполнять специальные проверки дублей и filling type |

## Побочные эффекты дочерних изменений

Для товаров, грузов, КТК, items и заказанных услуг сервисы после add/update/remove пересчитывают зависимые totals корня или контейнера. Эти операции не переводят заявку в новый статус и обычно не формируют исходящий пакет немедленно: в коде нескольких дочерних сервисов прежние outbound-вызовы отключены, а основной outbound формируется на accept корня.

## Изменения после pull 9 сентября 2026

- `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18` добавил `POST /shipping-order/{shippingOrderId}/shipping-order-container-item/preview/meta/{fieldName}`. Endpoint создаёт отсутствующий wrapper/filter, подставляет заявку из path и оставляет только items контейнеров со связью на `ShippingOrderRailwayCarriage`.
- Тот же коммит исправил разрешение meta-полей `grossweight → wightGross` и `netweight → wightNet` у `ShippingOrderContainerItem`.
- Тот же коммит изменил смысл фильтра рода вагона: `railwayCarriageType` и alias `type` проверяют `railwayCarriage.type.code`; поле/ключ `sort` относится к `railwayCarriage.sort` отдельно.
- Тот же коммит добавил специальное meta-поле `etsngcode` для контейнеров накладной. Коды читаются из `WaybillProduct`; ID результата — ID контейнеров той же накладной.
- `6557b9e88da7c933ea9a5c892884a8ef9e09f559` исправил meta planned date в маршрутах: для вывоза используется JPA-поле `plannedShippingDateTime`, для поставки — `planReceivingDateTime`.

Полный аудит диапазона и merge-коммиты: [журнал сверки](../traceability/repository-change-log.md#pull-от-9-сентября-2026-года).

Любое ТЗ на дочерний endpoint должно поэтому описывать не только сохраняемое поле, но и:

1. какой parent ID является источником истины — path или body;
2. допустимые статусы родителя;
3. заменяется весь набор или одна строка;
4. какие totals пересчитываются;
5. влияет ли изменение на review/accept validator;
6. нужен ли новый немедленный outbound или достаточно accept-сценария.
