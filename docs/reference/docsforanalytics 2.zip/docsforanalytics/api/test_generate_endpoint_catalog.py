#!/usr/bin/env python3
"""Regression checks for configured endpoint source scopes."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import generate_endpoint_catalog as generator  # noqa: E402


class EndpointScopeTest(unittest.TestCase):
    def test_mapping_paths_do_not_treat_consumes_as_a_route(self) -> None:
        annotation = '@PostMapping(path = "/event", consumes = "application/json")'

        self.assertEqual(("/event",), generator.mapping_paths(annotation))
        self.assertEqual(("/short",), generator.mapping_paths('@GetMapping("/short")'))
        self.assertEqual(
            ("/first", "/second"),
            generator.mapping_paths('@GetMapping({"/first", "/second"})'),
        )

    def test_parameter_contract_covers_all_supported_spring_locations(self) -> None:
        parameters = generator.parse_parameters(
            """public void sample(
                @PathVariable("id") UUID value,
                @RequestParam(name = "mode", defaultValue = "FULL") String mode,
                @RequestHeader(value = EXTERNAL_ID_HEADER, required = false) String guid,
                @CookieValue(name = "session", required = false) String session,
                @RequestBody(required = false) @Valid EventDto body,
                @RequestPart("file") MultipartFile file,
                @ModelAttribute @Valid ExcelParsingFileDto form,
                HttpServletResponse response)"""
        )

        self.assertEqual(
            ("path", "query", "header", "cookie", "body", "part", "model/form", "other/unclassified"),
            tuple(item.location for item in parameters),
        )
        self.assertEqual("id", parameters[0].wire_name)
        self.assertEqual("true (Spring default)", parameters[0].required)
        self.assertEqual("false (задан defaultValue)", parameters[1].required)
        self.assertEqual("FULL", parameters[1].default)
        self.assertEqual("EXTERNAL_ID_HEADER", parameters[2].wire_name)
        self.assertEqual("false", parameters[2].required)
        self.assertEqual("false", parameters[3].required)
        self.assertEqual("false", parameters[4].required)
        self.assertEqual(("@Valid",), parameters[4].validation)
        self.assertEqual("true (Spring default)", parameters[5].required)
        self.assertEqual("не применимо", parameters[6].required)
        self.assertEqual(("@Valid",), parameters[6].validation)

    def test_method_media_types_override_class_and_custom_annotation_defaults(self) -> None:
        class_annotation = '@ApiRestController(path = "/sample", name = "sample")'

        self.assertEqual(
            ("MediaType.APPLICATION_JSON_VALUE",),
            generator.effective_mapping_values('@GetMapping("/all")', class_annotation, "produces"),
        )
        self.assertEqual(
            ("MediaType.MULTIPART_FORM_DATA_VALUE",),
            generator.effective_mapping_values(
                '@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)',
                class_annotation,
                "consumes",
            ),
        )

    def test_openapi_responses_preserve_errors_media_and_schema(self) -> None:
        responses = generator.parse_api_responses(
            """@Operation(responses = {
                @ApiResponse(responseCode = "200", description = "OK",
                    content = @Content(mediaType = "application/json",
                        schema = @Schema(implementation = ResultDto.class))),
                @ApiResponse(responseCode = "400", description = "Validation problems"),
                @ApiResponse(responseCode = "default", description = "Other",
                    useReturnTypeSchema = true)
            })"""
        )

        self.assertEqual(("200", "400", "default"), tuple(item.code for item in responses))
        self.assertEqual(("application/json",), responses[0].media_types)
        self.assertEqual(("ResultDto",), responses[0].schemas)
        self.assertTrue(responses[2].use_return_type_schema)

    def test_response_status_supports_named_and_shorthand_forms(self) -> None:
        self.assertEqual(
            "HttpStatus.CREATED",
            generator.response_status("@ResponseStatus(code = HttpStatus.CREATED)"),
        )
        self.assertEqual(
            "HttpStatus.NO_CONTENT",
            generator.response_status("@ResponseStatus(HttpStatus.NO_CONTENT)"),
        )
        self.assertEqual(
            "200 OK (Spring MVC default)",
            generator.response_status("", "ResultDto"),
        )
        self.assertEqual(
            "определяется ResponseEntity/handler",
            generator.response_status("", "ResponseEntity<ResultDto>"),
        )

    def test_enum_values_are_expanded_from_java_source(self) -> None:
        values = generator.enum_constants("AccrualBase[]", generator.build_class_index())

        self.assertEqual((("AccrualBase", ("QUANTITY", "VOLUME")),), values)

    def test_component_scan_selects_only_configured_controller_packages(self) -> None:
        packages = generator.component_scan_packages(
            """
            @ComponentScan(value = {
                "ru.korusconsulting.alis",
                "ru.korusconsulting.wms.controller.permission",
                "ru.korusconsulting.wms.controller.role",
                "ru.korusconsulting.wms.controller.user",
                "ru.korusconsulting.wms.controller.dictionary",
                "ru.korusconsulting.wms.service.role"
            })
            """
        )

        self.assertEqual(
            (
                "ru.korusconsulting.alis.controller",
                "ru.korusconsulting.wms.controller.permission",
                "ru.korusconsulting.wms.controller.role",
                "ru.korusconsulting.wms.controller.user",
                "ru.korusconsulting.wms.controller.dictionary",
            ),
            packages,
        )
        self.assertNotIn("ru.korusconsulting.wms.service.role", packages)

    def test_current_configuration_discovers_four_wms_controllers(self) -> None:
        discovered = generator.discover_controller_sources()
        wms = [(source, scope) for source, scope in discovered if scope.origin == "WMS"]

        self.assertEqual(4, len(wms))
        self.assertEqual(
            {
                "PermissionPathController.java",
                "RolePermissionController.java",
                "RoleController.java",
                "UserRoleController.java",
            },
            {source.name for source, _ in wms},
        )
        self.assertFalse(any("dictionary" in scope.scan_package or "uom" in scope.scan_package for _, scope in wms))

    def test_wms_endpoint_keeps_fqcn_origin_and_scan_package(self) -> None:
        scope = next(
            scope for scope in generator.controller_scopes()
            if scope.scan_package == "ru.korusconsulting.wms.controller.role"
        )
        source = scope.source_root / "RoleController.java"
        endpoints = generator.parse_controller(source, scope)

        self.assertEqual(7, len(endpoints))
        self.assertTrue(all(item.origin == "WMS" for item in endpoints))
        self.assertTrue(all(item.scan_package == scope.scan_package for item in endpoints))
        self.assertTrue(all(item.controller_fqcn == "ru.korusconsulting.wms.controller.role.RoleController" for item in endpoints))
        self.assertTrue(all(not item.activation_annotations for item in endpoints))

    def test_datareon_event_exposes_optional_header_body_and_declared_errors(self) -> None:
        scope = next(scope for scope in generator.controller_scopes() if scope.origin == "ALIS")
        source = scope.source_root / "datareon/DatareonController.java"
        endpoint = next(item for item in generator.parse_controller(source, scope) if item.handler == "handleEvent")

        self.assertEqual(("/datareon/event",), endpoint.paths)
        self.assertEqual(("header", "body"), tuple(item.location for item in endpoint.parameters))
        self.assertEqual("false", endpoint.parameters[0].required)
        self.assertEqual("true (Spring default)", endpoint.parameters[1].required)
        self.assertEqual(("@Valid",), endpoint.parameters[1].validation)
        self.assertEqual(("200", "400", "406"), tuple(item.code for item in endpoint.api_responses))

    def test_template_upload_is_model_form_and_multipart(self) -> None:
        scope = next(scope for scope in generator.controller_scopes() if scope.origin == "ALIS")
        source = scope.source_root / "template/TemplateController.java"
        endpoint = next(
            item for item in generator.parse_controller(source, scope)
            if item.handler == "uploadShippingOrder"
        )

        self.assertEqual("model/form", endpoint.parameters[0].location)
        self.assertEqual("ExcelParsingFileDto", endpoint.parameters[0].java_type)
        self.assertEqual(("@Valid",), endpoint.parameters[0].validation)
        self.assertEqual(("MediaType.MULTIPART_FORM_DATA_VALUE",), endpoint.consumes)
        self.assertEqual(("OrderParsingResultDto",), endpoint.api_responses[0].schemas)

    def test_class_level_condition_is_preserved(self) -> None:
        prefix = '@Profile("prod")\n@ConditionalOnProperty(name = "feature.enabled")\n@RestController\n'

        self.assertEqual(
            ('@Profile("prod")', '@ConditionalOnProperty(name = "feature.enabled")'),
            generator.class_activation_annotations(prefix),
        )

    def test_indented_package_declaration_keeps_alis_fqcn(self) -> None:
        scope = next(scope for scope in generator.controller_scopes() if scope.origin == "ALIS")
        source = scope.source_root / "receivingordergood/ReceivingOrderGoodController.java"
        endpoints = generator.parse_controller(source, scope)

        self.assertTrue(endpoints)
        self.assertTrue(all(
            item.controller_fqcn
            == "ru.korusconsulting.alis.controller.receivingordergood.ReceivingOrderGoodController"
            for item in endpoints
        ))

    def test_configured_empty_user_package_remains_visible_scope(self) -> None:
        scope = next(
            scope for scope in generator.controller_scopes()
            if scope.scan_package == "ru.korusconsulting.wms.controller.user"
        )

        self.assertFalse(scope.source_root.exists())
        self.assertEqual([], generator.discover_controller_sources((scope,)))


if __name__ == "__main__":
    unittest.main()
