# API клиентов, договоров и условий оказания услуг

Документ связывает HTTP endpoints, DTO, фильтры, сервисный слой и модель БД для цепочки «клиент → договор → условия и тарифы». Описание подтверждено текущими controller, service, mapper, predicate и entity-классами.

> Статус: **реализовано**, если явно не указано «Риск» или «Вопрос». Актуальность проверки: 9 сентября 2026 года.

Актуальные inbound `POST /datareon/contractor` и `/datareon/contract` имеют отдельные validation/transaction semantics и разобраны в [Контрагенты ЭДО](../business-rules/contractor-edo-datareon-as-is.md) и [Договоры ЭДО](../business-rules/contract-edo-datareon-as-is.md). Обязательные prerequisites Company/Currency имеют только read endpoints, а источник их runtime-наполнения в репозитории не найден; отдельная трассировка приведена в [Company и Currency для договоров](../business-rules/company-currency-contract-prerequisites-as-is.md). Внутренние Client/Contract DTO не проходят повторную Bean Validation: contractor update откатывается из-за `code=null`, а contract всегда создаёт новую строку даже при повторе `edoId`. Обычный пользовательский CRUD ниже не следует переносить на интеграционные endpoints.

## Граница домена

```mermaid
flowchart LR
    CL[Client<br/>клиент] -->|1:N| CO[Contract<br/>договор]
    CO -->|N:1| CP[Company<br/>наша организация]
    CO -->|N:1| CU[Currency<br/>валюта]
    CO -->|1:N| TS[TermOfService<br/>условие оказания услуг]
    TS -->|N:1| TA[TerminalArea<br/>площадка]
    TS -->|1:N| TR[TermOfRequestedService<br/>услуга по заявке]
    TS -->|1:N| TP[TermOfPeriodicService<br/>периодическая услуга]
    TR -->|N:1| SV1[Service]
    TP -->|N:1| SV2[Service]
    TP -->|N:1| FR[FrequencyOfServices]
    CL --> AA[AdditionalAgreement<br/>доп. соглашение]
    CO --> AA
    CP --> AA
    CU --> AA
```

Ключевой смысл связей:

- `Client` — контрагент, для которого заключаются договоры;
- `Contract` связывает клиента, организацию ALIS, валюту, тип и срок действия договора;
- `TermOfService` задаёт действие договора на конкретной терминальной площадке;
- `TermOfRequestedService` задаёт услугу, тариф, тип клиентской заявки, способ расчёта и обязательность;
- `TermOfPeriodicService` задаёт услугу, тариф и периодичность;
- `AdditionalAgreement` существует как отдельная сущность, но публичный API этого контроллера предоставляет только чтение страницы.

## Общий конвейер CRUD

```mermaid
flowchart TD
    A[HTTP request] --> B{Есть @Secure?}
    B -->|да| C[Проверка permission и accessLevel]
    B -->|нет| D[Переход к handler]
    C -->|доступ запрещён| E[Ошибка авторизации]
    C -->|доступ разрешён| D
    D --> F{Request DTO помечен @Valid?}
    F -->|ошибка Bean Validation| G[400 Validation problems]
    F -->|валидно| H[MapStruct: DTO → entity/filter]
    H --> I[Service: доменные проверки и подготовка связей]
    I -->|ID связи не найден| J[404 Not found]
    I -->|нарушение бизнес-проверки| G
    I --> K[DAO / QueryDSL / JPA]
    K -->|unique или integrity violation| L[406 / UniqueViolationException]
    K --> M[MapStruct: entity → response DTO]
    M --> N[200 JSON]
```

Для операций `add` базовый сервис выполняет `modelCreation → preAdd → prepareModelToAdd → dao.add → postAdd → toDetailedDto` в транзакции. Для `update`: поиск существующей записи → `modelUpdate → preUpdate → prepareModelToUpdate → dao.update → postUpdate → toDetailedDto`.

## 1. Клиенты `/client`

### Endpoints и DTO

| Метод и путь | Request | Response | Доступ | Реализованная логика |
|---|---|---|---|---|
| `POST /client/all` | `FilterWithPaging<ClientFilter>`; body объявлен optional | `List<CommonDto>` | method-level `@Secure` отсутствует | Ограничение выборки по пользователю, фильтрация, пагинация, short mapping. |
| `POST /client/page` | `FilterWithPaging<ClientFilter>` | `Page<ClientDto>` | `CLIENT:READ` | Ограничение по пользователю, QueryDSL-фильтр, страница полных DTO. |
| `POST /client/meta/{fieldName}` | `FilterWithPaging<ClientMetaFilter>` | `List<IdsCodeDto>` | `CLIENT:READ` | Очищает и разрешает путь поля, применяет фильтр и user restriction, возвращает варианты значений. Неизвестное поле приводит к ошибке. |
| `GET /client/{id}` | path `UUID id` | `ClientDto` | `CLIENT:READ` | Ищет запись по ID; при отсутствии — `NotFoundException`. |
| `POST /client/` | [ClientCreationDto](../dto/catalog/client/ClientCreationDto.md) | [ClientDto](../dto/catalog/client/ClientDto.md) | `CLIENT:CREATE` | Валидирует DTO, создаёт модель, при пустом `syncId` присваивает ID клиента, сохраняет и ставит запись в очередь исходящей интеграции. |
| `PUT /client/{id}` | [ClientUpdateDto](../dto/catalog/client/ClientUpdateDto.md) | [ClientDto](../dto/catalog/client/ClientDto.md) | `CLIENT:WRITE` | Если body `id = null`, подставляет path ID; если оба ID заданы и не совпадают, базовый сервис отклоняет запрос. Обновляет перечисленные поля. |
| `POST /client/synchronize` | нет | нет | method-level `@Secure` отсутствует | Синхронно запрашивает WMS `GET /hs/ExchangeNSI/Clients`, пропускает элементы без `syncId` и уже известные `syncId`, остальные добавляет по одному; ошибки отдельных записей только логируются. |

Controller: [ClientController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/client/ClientController.java). Service: [ClientService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/client/ClientService.java).

### Обязательные поля создания и обновления

`ClientUpdateDto` наследует все ограничения `ClientCreationDto`; дополнительно принимает `id`, который контроллер может заполнить из path.

| JSON-поле | Обязательно | Проверка |
|---|---:|---|
| `active` | да | `@NotNull` |
| `code` | да | непустая строка, максимум 100 символов |
| `name` | да | непустая строка |
| `addressFact` | да | непустая строка |
| `inn` | да | непустая строка из 10 или 12 цифр |
| `kpp` | да | непустая строка из 9 цифр |
| `okpo` | нет | если непустое — 10 цифр |
| `ogrn` | нет | если непустое — 13 или 15 цифр |
| `addressLegal` | да | непустая строка |
| `syncId`, `email`, `phoneNumber`, `edoId`, `signatoryName`, `signatoryPosition` | нет | специальных Bean Validation constraints нет |

### Логика изменения клиента

```mermaid
flowchart TD
    A[POST create или PUT update] --> B[Bean Validation Client DTO]
    B -->|ошибка| X[400]
    B --> C{Операция}
    C -->|create| D[Map DTO → Client]
    D --> E{syncId отсутствует?}
    E -->|да| F[syncId = generated client id]
    E -->|нет| G[Сохранить переданный syncId]
    F --> H[INSERT client]
    G --> H
    H --> I[Создать outbound integration record]
    C -->|update| J[Разрешить path/body id]
    J -->|ID не совпадают| Y[IllegalArgumentException]
    J --> K[Загрузить Client по ID]
    K --> L{ИНН или КПП изменились<br/>и новый INN не null?}
    L -->|да| M[Посчитать клиентов с парой ИНН + КПП]
    M -->|count > 0| Z[DuplicateEntityException]
    M -->|count = 0| N[Скопировать поля и UPDATE]
    L -->|нет| N
```

Особенности фильтра `ClientFilter`: поиск поддерживает `syncId`, `edoId`, телефон, email, фактический адрес, ИНН, КПП и `hasContractType`. Последний параметр строит `EXISTS` по договорам клиента заданного типа.

Риски и расхождения:

- **Риск:** у `POST /client/all` body помечен как необязательный, но `BaseService.getAllShort` сразу обращается к `filter.getFilter()`. Если другой инфраструктурный слой не создаёт пустой wrapper, запрос без body завершится ошибкой, а не выдачей полного списка.
- **Риск:** явная проверка уникальности пары ИНН/КПП находится в update-ветке. В показанном `ClientService` при create такая проверка не вызывается; итог зависит от ограничений БД.
- **Риск доступа:** у `/client/all` и `/client/synchronize` нет method-level `@Secure`. Это не доказывает, что endpoint публичный: общая security-конфигурация должна проверяться отдельно, но предметного permission на методе нет.

## 2. Договоры `/contract`

### Endpoints и DTO

| Метод и путь | Request | Response | Доступ | Реализованная логика |
|---|---|---|---|---|
| `POST /contract/all` | `FilterWithPaging<ContractFilter>`; body объявлен optional | `List<ContractDto>` | method-level `@Secure` отсутствует | User restriction, фильтрация, пагинация и short mapping, который в этом сервисе также имеет тип `ContractDto`. |
| `POST /contract/page` | `FilterWithPaging<ContractFilter>` | `Page<ContractDto>` | `CLIENT_CONTRACT:READ` | Возвращает страницу договоров. |
| `POST /contract/meta/{fieldName}` | `FilterWithPaging<ContractMetaFilter>` | `List<IdsCodeDto>` | `CLIENT_CONTRACT:READ` | Возвращает значения выбранного meta-поля в области фильтра. |
| `GET /contract/{id}` | path `UUID id` | [ContractDto](../dto/catalog/contract/ContractDto.md) | `CLIENT_CONTRACT:READ` | Возвращает договор либо 404. |
| `POST /contract/` | [ContractCreationDto](../dto/catalog/contract/ContractCreationDto.md) | [ContractDto](../dto/catalog/contract/ContractDto.md) | `CLIENT_CONTRACT:CREATE` | Проверяет DTO и даты, разрешает ссылки на клиента/организацию/валюту через БД, задаёт defaults и сохраняет. |
| `PUT /contract/{id}` | [ContractUpdateDto](../dto/catalog/contract/ContractUpdateDto.md) | [ContractDto](../dto/catalog/contract/ContractDto.md) | `CLIENT_CONTRACT:WRITE` | Подставляет path ID, если body ID отсутствует; отклоняет несовпадение; проверяет даты, заново разрешает FK и копирует поля. |

Controller: [ContractController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/contract/ContractController.java). Service: [ContractService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/contract/ContractService.java).

### Обязательные поля договора

| JSON-поле | Обязательно | Проверка / смысл |
|---|---:|---|
| `code` | да | непустая строка, максимум 100 символов |
| `name` | да | непустая строка |
| `active` | да | `@NotNull`; серверный default `true` при `null` практически недостижим для валидного HTTP-запроса |
| `client` | да | объект `{ "id": UUID }`; вложенный ID также `@NotNull` |
| `company` | да | объект `{ "id": UUID }`; вложенный ID также `@NotNull` |
| `currency` | да | объект `{ "id": UUID }`; вложенный ID также `@NotNull` |
| `contractDate` | да | `Instant` |
| `contractType` | да | enum `ContractType` |
| `validFrom` | да | `Instant` |
| `validTo` | да | `Instant`; не может быть раньше `validFrom` |
| `syncId`, `edoId` | нет | при create пустой `syncId` заменяется ID нового договора |

### Создание и обновление договора

```mermaid
flowchart TD
    A[ContractCreationDto / ContractUpdateDto] --> B[Bean Validation]
    B -->|ошибка| X[400]
    B --> C{validTo раньше validFrom?}
    C -->|да| Y[ValidationException → ошибка валидации]
    C -->|нет| D[Найти Client по client.id]
    D -->|нет записи| Z[404]
    D --> E[Найти Company по company.id]
    E -->|нет записи| Z
    E --> F[Найти Currency по currency.id]
    F -->|нет записи| Z
    F --> G{create?}
    G -->|да| H[active default true при null<br/>syncId = id при null]
    G -->|нет| I[Скопировать code, name, active,<br/>EDO, даты, тип и связи]
    H --> J[INSERT contract]
    I --> K[UPDATE contract]
    J --> L[ContractDto]
    K --> L
```

Фильтр поддерживает вложенный `client`, `contractType`, диапазоны `validFrom`, `validTo`, `contractDate`, `contractCode`, `currency` и `active`. Условие `contractCode` реализовано через `contains`; детали регистра зависят от QueryDSL/БД.

Риски и расхождения:

- **Риск:** `/contract/all` повторяет проблему optional body и немедленного разыменования wrapper в базовом сервисе.
- **Риск доступа:** у `/contract/all` отсутствует method-level `@Secure`.
- **Наблюдение:** в update валюта загружается из БД безусловно, затем тот же вызов повторяется внутри проверки `currency != null`. На контракт ответа это не влияет, но это лишнее обращение к БД.

## 3. Дополнительные соглашения `/additionalagreement`

| Метод и путь | Request | Response | Доступ | Реализованная логика |
|---|---|---|---|---|
| `POST /additionalagreement/page` | `FilterWithPaging<AdditionalAgreementFilter>` | `Page<AdditionalAgreementDto>` | `CLIENT_ADDITIONAL_AGREEMENT:READ` | Только чтение страницы через базовый сервис, predicate и mapper. |

Controller: [AdditionalAgreementController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/additionalagreement/AdditionalAgreementController.java). DTO: [AdditionalAgreementDto](../dto/catalog/additionalagreement/AdditionalAgreementDto.md). Entity: [AdditionalAgreement](../entities/catalog/entities/additionalagreement/AdditionalAgreement.md).

```mermaid
flowchart LR
    A[POST /additionalagreement/page] --> B[Bean Validation wrapper/filter]
    B --> C[Добавить user restriction]
    C --> D[AdditionalAgreementPredicate]
    D --> E[По умолчанию active = true]
    E --> F[AND: numbers / contracts / currencies]
    F --> G[AND: validFrom / validTo]
    G --> H[Page из additional_agreement]
    H --> I[AdditionalAgreementDto]
```

Фильтр:

- `active` — список `SearchBoolean`; default — один элемент `true`;
- `numbers`, `contracts`, `currencies` — списки точных значений для `IN`;
- `validFrom`, `validTo` — `SearchDate`;
- все переданные условия соединяются через `AND`; каждый элемент списка `active` тоже добавляется отдельным `AND`.

Риски и расхождения:

- **Реализовано:** в контроллере нет create, update, get-by-id или delete endpoints. Нельзя проектировать изменение допсоглашения через этот API без нового серверного контракта.
- **Расхождение:** entity после миграции хранит связь `client`, а response DTO по-прежнему называет поле `legalEntity`. В `AdditionalAgreementMapper` нет явного `client → legalEntity` mapping. Следовательно, автогенерируемый MapStruct mapper не обязан заполнить `legalEntity`; это поле требует runtime-теста или исправления mapping.
- **Вопрос:** entity и БД требуют `client`, `company`, `contract`, `currency`, даты и `active`, но входного DTO публичного endpoint нет. Необходимо определить источник создания записей — миграция, интеграция или пока не реализованный API.

## 4. Условия оказания услуг `/termofservice`

| Метод и путь | Request | Response | Доступ | Логика |
|---|---|---|---|---|
| `POST /termofservice/all` | `FilterWithPaging<TermOfServiceFilter>`; body optional | `List<IdCodeDto>` | method-level `@Secure` отсутствует | Короткий список. |
| `POST /termofservice/page` | `FilterWithPaging<TermOfServiceFilter>` | `Page<TermOfServiceDto>` | `TERM_OF_SERVICE:READ` | Страница условий. |
| `POST /termofservice/meta/{fieldName}` | `FilterWithPaging<TermOfServiceMetaFilter>` | `List<IdsCodeDto>` | `TERM_OF_SERVICE:READ` | Значения meta-поля. |
| `GET /termofservice/{id}` | path ID | [TermOfServiceDto](../dto/catalog/termofservice/TermOfServiceDto.md) | `TERM_OF_SERVICE:READ` | Детальная запись; mapper дополнительно выводит клиента и валюту из договора. |
| `POST /termofservice/` | [TermOfServiceCreationDto](../dto/catalog/termofservice/TermOfServiceCreationDto.md) | [TermOfServiceDto](../dto/catalog/termofservice/TermOfServiceDto.md) | `TERM_OF_SERVICE:CREATE` | Создание; `active` нормализуется в `true` только при точном `Boolean.TRUE`, иначе `false`; пустой `syncId` заменяется случайным UUID. |
| `PUT /termofservice/{id}` | [TermOfServiceUpdateDto](../dto/catalog/termofservice/TermOfServiceUpdateDto.md) | [TermOfServiceDto](../dto/catalog/termofservice/TermOfServiceDto.md) | `TERM_OF_SERVICE:WRITE` | Ищет запись по `body.id`, при смене договора загружает новый договор, копирует поля. Path ID handler не принимает и не сверяет. |

Обязательны `code` (непустой, до 100), `contract.id`, `terminalArea`, `validFrom`, `indefinitely`; для update обязателен `id`. `validTo`, `active`, `name` и `syncId` не обязательны.

```mermaid
flowchart TD
    A[TermOfService DTO] --> B[Проверить code, contract.id,<br/>terminalArea, validFrom, indefinitely]
    B -->|ошибка| X[400]
    B --> C{create или update}
    C -->|create| D[active = DTO.active == true]
    D --> E{syncId пуст?}
    E -->|да| F[Сгенерировать UUID]
    E -->|нет| G[Оставить syncId]
    F --> H[INSERT]
    G --> H
    C -->|update| I[Загрузить запись по body.id]
    I --> J{contract.id изменился?}
    J -->|да| K[Загрузить новый Contract]
    J -->|нет| L[Оставить существующий Contract]
    K --> M[Скопировать code, active, даты,<br/>indefinitely, terminalArea]
    L --> M
    M --> N[UPDATE]
```

Риски и расхождения:

- **Риск целостности:** нет явной проверки `validTo >= validFrom` и согласованности `indefinitely` с `validTo`.
- **Риск ID:** `PUT /termofservice/{id}` содержит path variable, но handler не принимает её. Фактически обновляется `body.id`; path может указывать на другую запись и не участвует в проверке.
- **Риск:** short endpoint с optional body имеет ту же потенциальную проблему null wrapper.
- **Наблюдение:** inherited-поле `name` принимается DTO, но entity `TermOfService` основана на `BaseIdActiveCode` и собственного `name` не имеет.

## 5. Услуги по заявке `/termofrequestedservice`

| Метод и путь | Request | Response | Доступ | Логика |
|---|---|---|---|---|
| `POST /termofrequestedservice/all` | filter wrapper; body optional | `List<TermOfRequestedServiceShortDto>` | method-level `@Secure` отсутствует | Короткий DTO; `code` берётся из связанной услуги. |
| `POST /termofrequestedservice/page` | filter wrapper | `Page<TermOfRequestedServiceDto>` | `TERM_OF_SERVICE_TERM_OF_REQUESTED_SERVICE:READ` | По умолчанию исключает `deleted = true`. |
| `POST /termofrequestedservice/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | то же `:READ` | Meta values. |
| `GET /termofrequestedservice/{id}` | path ID | [TermOfRequestedServiceDto](../dto/catalog/termofrequestedservice/TermOfRequestedServiceDto.md) | то же `:READ` | Возвращает услугу и вычисленное mapper-поле `serviceOfMeasure`. |
| `POST /termofrequestedservice/` | [TermOfRequestedServiceCreationDto](../dto/catalog/termofrequestedservice/TermOfRequestedServiceCreationDto.md) | detailed DTO | то же `:CREATE` | Создаёт запись с `deleted = false`. |
| `PUT /termofrequestedservice/{id}` | [TermOfRequestedServiceUpdateDto](../dto/catalog/termofrequestedservice/TermOfRequestedServiceUpdateDto.md) | detailed DTO | то же `:WRITE` | Обновляет запись по `body.id`; при смене услуги/условия загружает новые связи; path ID не сверяется. |
| `DELETE /termofrequestedservice/{id}` | path ID | detailed DTO | то же `:DELETE` | Soft delete: устанавливает `deleted = true` и обновляет строку. |

Обязательны `syncId`, `termOfService.id`, `service.id`, `clientOrderType`, `calculationMethod`, `rate > 0`; для update обязателен `id`. Поле `required` — primitive boolean: при отсутствии в JSON становится `false`; аннотация `@NotNull` на primitive не добавляет реальной проверки наличия.

Фильтр поддерживает вложенное условие оказания услуг, `clientOrderType`, `required`, `calculationMethod` и `deleted`; default `deleted = false` скрывает удалённые строки.

## 6. Периодические услуги `/termofperiodicservice`

| Метод и путь | Request | Response | Доступ | Логика |
|---|---|---|---|---|
| `POST /termofperiodicservice/all` | filter wrapper; body optional | `List<CommonDto>` | method-level `@Secure` отсутствует | Короткий список. |
| `POST /termofperiodicservice/page` | filter wrapper | `Page<TermOfPeriodicServiceDto>` | `TERM_OF_SERVICE_TERM_OF_PERIODIC_SERVICE:READ` | По умолчанию исключает `deleted = true`. |
| `POST /termofperiodicservice/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | то же `:READ` | Meta values. |
| `GET /termofperiodicservice/{id}` | path ID | [TermOfPeriodicServiceDto](../dto/catalog/termofperiodicservice/TermOfPeriodicServiceDto.md) | то же `:READ` | Detailed DTO, включая `serviceOfMeasure` связанной услуги. |
| `POST /termofperiodicservice/` | [TermOfPeriodicServiceCreationDto](../dto/catalog/termofperiodicservice/TermOfPeriodicServiceCreationDto.md) | detailed DTO | то же `:CREATE` | Создаёт запись с `deleted = false`. |
| `PUT /termofperiodicservice/{id}` | [TermOfPeriodicServiceUpdateDto](../dto/catalog/termofperiodicservice/TermOfPeriodicServiceUpdateDto.md) | detailed DTO | то же `:WRITE` | Обновляет по `body.id`, разрешает изменившиеся service, termOfService и frequencyOfServices; path ID не сверяется. |
| `DELETE /termofperiodicservice/{id}` | path ID | detailed DTO | то же `:DELETE` | Soft delete через `deleted = true`. |

Обязательны `syncId`, `service.id`, `termOfService.id`, `frequencyOfServices.id`, `rate > 0`; для update обязателен `id`.

```mermaid
flowchart TD
    A[Услуга внутри TermOfService] --> B{Тип настройки}
    B -->|По заявке| C[TermOfRequestedService]
    C --> D[Service + clientOrderType]
    D --> E[calculationMethod + required + rate]
    B -->|Периодическая| F[TermOfPeriodicService]
    F --> G[Service + frequencyOfServices + rate]
    C --> H{DELETE endpoint}
    F --> H
    H --> I[deleted = true]
    I --> J[Строка остаётся в БД]
    J --> K[Default filter deleted = false<br/>скрывает строку]
```

Общие риски двух дочерних справочников:

- `PUT .../{id}` не использует path ID и доверяет обязательному `body.id`;
- `syncId` обязателен по DTO, поэтому сервисный fallback `syncId = entity.id` при `null` недостижим для обычного валидного HTTP-запроса;
- inherited-поля `code`, `name`, `active` присутствуют во входных DTO через `BaseNamedCreationDto`, но entities наследуют `BaseEditable` и этих бизнес-полей не содержат; клиенту API не следует рассчитывать на их сохранение;
- short endpoints объявляют optional body, хотя базовый сервис требует ненулевой wrapper;
- у short endpoints отсутствует method-level permission-аннотация.

## Сквозной сценарий настройки тарифа

```mermaid
flowchart TD
    A[Создать или выбрать Client] --> B[Создать Contract]
    B --> C{Все FK существуют<br/>и validTo >= validFrom?}
    C -->|нет| X[400 или 404]
    C -->|да| D[Создать TermOfService<br/>для договора и площадки]
    D --> E{Как начисляется услуга?}
    E -->|По клиентской заявке| F[Создать TermOfRequestedService]
    F --> G[Задать order type,<br/>calculation method, required, rate]
    E -->|Периодически| H[Создать TermOfPeriodicService]
    H --> I[Задать frequency и rate]
    G --> J[Настройка доступна downstream-логике]
    I --> J
```

Эта схема показывает только конфигурационный контур. Она **не доказывает**, что при создании конкретной заявки сервер автоматически выберет именно эти записи: такое влияние должно быть подтверждено в сервисах заявок и описано отдельной трассировкой.

## Матрица ошибок

| Условие | Ожидаемый технический исход |
|---|---|
| Нарушена Bean Validation DTO | `400 Bad Request` |
| `validTo < validFrom` у договора | `ValidationException`; отображение в HTTP зависит от global exception handler |
| Не найден основной ID или ID связанной сущности | `NotFoundException`, обычно 404 |
| Path ID и body ID не совпадают у клиента/договора | `IllegalArgumentException` |
| Конфликт уникальности/целостности при add/update | `UniqueViolationException`; controllers документируют 406 |
| Удалена requested/periodic service | Физического DELETE нет; запись помечается `deleted = true` |

## Источники и связанные документы

- [Полный generated-каталог endpoints](endpoints-generated.md)
- [API клиентских справочников](client-reference-api.md)
- [Generated-каталог DTO](../dto/catalog/README.md)
- [Client entity](../entities/catalog/entities/client/Client.md)
- [Contract entity](../entities/catalog/entities/contract/Contract.md)
- [TermOfService entity](../entities/catalog/entities/termofservice/TermOfService.md)
- [TermOfRequestedService entity](../entities/catalog/entities/termofrequestedservice/TermOfRequestedService.md)
- [TermOfPeriodicService entity](../entities/catalog/entities/termofperiodicservice/TermOfPeriodicService.md)

## Вопросы для владельца системы

1. Должны ли list endpoints без `@Secure` быть доступны без предметного permission?
2. Должен ли optional body действительно работать, и где создаётся пустой `FilterWithPaging`, если body отсутствует?
3. Нужно ли сверять path ID с body ID во всех `PUT` endpoints условий и тарифов?
4. Каковы правила дат `TermOfService`: допустимы ли `validTo < validFrom`, `indefinitely = true` вместе с заполненным `validTo`?
5. Каким процессом создаются и изменяются `AdditionalAgreement`?
6. Должно ли поле ответа называться `client`, либо mapper обязан явно заполнять историческое имя `legalEntity`?
