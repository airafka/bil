# API клиентских справочников и серверная логика

Документ описывает номенклатуру клиента, клиентские виды номенклатуры, связанных контрагентов, водителей, транспорт и цифровые марки. Для каждого endpoint указаны фактические DTO, permissions, обязательные поля, фильтры, эффекты сервисного слоя и выявленные расхождения.

> Статус: **реализовано**, если правило явно не помечено как «Риск», «Расхождение» или «Вопрос». Актуальность проверки: 9 сентября 2026 года.

## Граница домена

```mermaid
flowchart LR
    C[Client] -->|1:N| CGT[ClientGoodType<br/>вид номенклатуры клиента]
    C -->|1:N| CG[ClientGood<br/>номенклатура]
    CGT -->|0..1:N| CG
    CG --> U[UnitOfMeasure]
    CG --> GT[GoodType]
    CG --> DC[DangerClass]
    CG --> TR[TempRegime]
    CG --> GG[GoodGroup]
    CG -->|1:N| DS[ClientGoodDigitalSign<br/>цифровая марка]
    DS --> TP[TransportPackage]
    DS --> PT[ProductType]
    C -->|1:N| RE[ClientRelatedEntity<br/>контрагент клиента]
    C -->|1:N| DR[ClientDriver]
    C -->|1:N| VH[ClientVehicle]
    VH --> VB[VehicleBrand]
    VH --> VT[VehicleType]
    VH --> LT[LoadingType]
```

## Общие свойства API

- Стандартный набор controller-методов: `/all`, `/page`, `/meta/{fieldName}`, `GET /{id}`, create и update.
- `/all`, `/page` и `/meta` проходят через `FilterEnrichService.addUserRestriction`, поэтому выборка ограничивается доступным пользователю клиентским контекстом.
- Create и update выполняются транзакционно через `BaseService`.
- Нарушение Bean Validation обычно даёт 400; отсутствующая сущность или ссылка — 404; нарушение ограничения БД преобразуется в `UniqueViolationException`, для которого controllers декларируют 406.
- Ни в одном из описанных CRUD-контроллеров нет публичного DELETE endpoint.

## 1. Номенклатура клиента `/clientgood`

### Endpoints

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientgood/all` | `FilterWithPaging<ClientGoodFilter>`; body optional | [List&lt;ClientGoodShortDto&gt;](../dto/catalog/clientgood/ClientGoodShortDto.md) | `CLIENT_GOOD:READ` | Короткий список; поле `isVariable` берётся из связанного `clientGoodType`. |
| `POST /clientgood/page` | `FilterWithPaging<ClientGoodFilter>` | [Page&lt;ClientGoodDto&gt;](../dto/catalog/clientgood/ClientGoodDto.md) | `CLIENT_GOOD:READ` | Обычная страница с user restriction. |
| `POST /clientgood/hierarchy` | `FilterWithPaging<ClientGoodFilter>` | [Page&lt;ClientGoodHierarchyDto&gt;](../dto/catalog/clientgood/ClientGoodHierarchyDto.md) | `CLIENT_GOOD:READ` | Строит дерево групп, вкладывает номенклатуру в узлы и рекурсивно считает `totalElements`. |
| `POST /clientgood/meta/{fieldName}` | `FilterWithPaging<ClientGoodMetaFilter>` | `List<IdsCodeDto>` | `CLIENT_GOOD:READ` | Возвращает значения meta-поля в рамках фильтра. |
| `GET /clientgood/{id}` | path ID | [ClientGoodDto](../dto/catalog/clientgood/ClientGoodDto.md) | `CLIENT_GOOD:READ` | Detailed DTO либо 404. |
| `POST /clientgood/` | [ClientGoodCreationDto](../dto/catalog/clientgood/ClientGoodCreationDto.md) | [ClientGoodDto](../dto/catalog/clientgood/ClientGoodDto.md) | `CLIENT_GOOD:CREATE` | Генерирует ID и `codeKis`, задаёт defaults, сохраняет, обновляет флаг вида номенклатуры и ставит номенклатуру в outbound-очередь. |
| `PUT /clientgood/{id}` | [ClientGoodUpdateDto](../dto/catalog/clientgood/ClientGoodUpdateDto.md) | [ClientGoodDto](../dto/catalog/clientgood/ClientGoodDto.md) | `CLIENT_GOOD:WRITE` | Загружает запись по `body.id`, обновляет связи и поля, ограничивает изменение видов учёта после использования в заявках, создаёт outbound update. Path ID не используется. |

Controller: [ClientGoodController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientgood/ClientGoodController.java). Service: [ClientGoodService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientgood/ClientGoodService.java). Entity: [ClientGood](../entities/catalog/entities/clientgood/ClientGood.md).

### Обязательные поля

| JSON-поле | Обязательно | Проверка / действие |
|---|---:|---|
| `code` | да | `@NotBlank`, максимум 100 символов |
| `client` | да | `IdDto`; обязательны объект и `id` |
| `unitOfMeasure` | да | `IdDto`; обязательны объект и `id` |
| `batchAccountingType` | да | enum `BatchAccountingType` |
| `serialAccountingType` | да | enum `SerialAccountingType` |
| `dangerClass` | да | `IdDto`; обязательны объект и `id` |
| `goodGroup` | да | `IdDto`; обязательны объект и `id` |
| `clientGoodType`, `goodType`, `tempRegime` | нет | ссылки могут отсутствовать |
| `shelfLife`, `price` | нет | если заполнены — не меньше нуля |
| `name`, `active`, `item`, `gtin`, `description` | нет | дополнительных DTO constraints нет |
| `id` | только update | обязательный `UUID`; path ID его не заменяет |

Create defaults:

- `id` генерируется mapper-ом;
- `codeKis` генерируется entity sequence;
- `syncId = id`;
- `usedInOrders = false`;
- `price = 0`, если цена не передана;
- `active = true` только при точном `Boolean.TRUE`; отсутствующее значение превращается в `false`.

### Иерархия групп

```mermaid
flowchart TD
    A[POST /clientgood/hierarchy] --> B[Получить pageInfo и ClientGoodFilter]
    B --> C{Фильтр номенклатуры непустой?}
    C -->|нет| D[Выбрать страницу корневых групп<br/>со всеми потомками]
    C -->|да| E[Выбрать корневые группы и пути,<br/>содержащие подходящую номенклатуру]
    D --> F[Создать DTO-узел для каждой группы]
    E --> F
    F --> G[Ограничить номенклатуру ID выбранных групп]
    G --> H[Сгруппировать ClientGood по goodGroup.id]
    H --> I[Связать parent → children]
    I --> J[Рекурсивно вычислить totalElements]
    J --> K[Page корневых узлов]
```

Фильтр поддерживает клиента, единицу измерения, класс опасности, системный и клиентский виды, активность, `syncId`, `codeKis`, артикул и группу. Для `item` при `byOr=true` predicate ищет совпадение в `item` **или** `name`; иначе — только в `item`.

### Изменение и защита учётных настроек

```mermaid
flowchart TD
    A[PUT /clientgood/{id}] --> B[Найти ClientGood по body.id]
    B --> C[Разрешить изменившиеся FK через DAO]
    C --> D{usedInOrders = true?}
    D -->|нет| E[Можно изменить batchAccountingType<br/>и serialAccountingType]
    D -->|да| F[Сохранить прежние виды учёта]
    E --> G[Обновить остальные поля]
    F --> G
    G --> H[UPDATE]
    H --> I[Outbound update]
```

Риски и расхождения:

- **Риск ID:** path `{id}` в update не принимается handler-ом; источником истины является обязательный `body.id`.
- **Дефект-кандидат `tempRegime`:** если в update передан тот же температурный режим, что уже сохранён, ветка `else` устанавливает `tempRegime = null`. Сохранение прежнего значения фактически может очистить связь.
- **Риск согласованности `hasClientGoods`:** при create флаг связанного `ClientGoodType` устанавливается в `true`; при изменении `clientGoodType` в update старый и новый типы не пересчитываются.
- **Риск optional body:** `/all` допускает отсутствие body, но базовый `getAllShort` разыменовывает wrapper.

## 2. Виды номенклатуры клиента `/clientgoodtype`

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientgoodtype/all` | filter wrapper; body optional | `List<ClientGoodTypeDto>` | method-level `@Secure` отсутствует | Short mapping имеет тот же тип, что full DTO. |
| `POST /clientgoodtype/page` | filter wrapper | `Page<ClientGoodTypeDto>` | `CLIENT_GOOD_TYPE:READ` | Страница видов номенклатуры. |
| `POST /clientgoodtype/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | `CLIENT_GOOD_TYPE:READ` | Meta values. |
| `GET /clientgoodtype/{id}` | path ID | [ClientGoodTypeDto](../dto/catalog/clientgoodtype/ClientGoodTypeDto.md) | `CLIENT_GOOD_TYPE:READ` | Detailed DTO либо 404. |
| `POST /clientgoodtype/` | [ClientGoodTypeCreationDto](../dto/catalog/clientgoodtype/ClientGoodTypeCreationDto.md) | [ClientGoodTypeDto](../dto/catalog/clientgoodtype/ClientGoodTypeDto.md) | `CLIENT_GOOD_TYPE:CREATE` | Создание типа. |
| `PUT /clientgoodtype/{id}` | [ClientGoodTypeUpdateDto](../dto/catalog/clientgoodtype/ClientGoodTypeUpdateDto.md) | [ClientGoodTypeDto](../dto/catalog/clientgoodtype/ClientGoodTypeDto.md) | `CLIENT_GOOD_TYPE:WRITE` | Обновление по `body.id`; path ID не используется. |

Обязательны `code`, `client.id`, `syncId`, `isVariable`; для update также `id`. `name`, `active`, `clientSyncId` не обязательны.

```mermaid
flowchart TD
    A[ClientGoodType] --> B{hasClientGoods?}
    B -->|false| C[Разрешить изменение client и isVariable]
    B -->|true| D[Оставить client и isVariable прежними]
    C --> E[Обновить code, name, active, clientSyncId]
    D --> E
    E --> F[Сохранить]
    G[Создание ClientGood с этим типом] --> H[hasClientGoods = true]
```

Особенности:

- `hasClientGoods` вычисляется не запросом при чтении, а хранится в таблице и меняется сервисом номенклатуры;
- несмотря на защиту части полей, `active` обновляется после условной ветки и поэтому изменяется даже при `hasClientGoods = true`;
- `syncId` обязателен в DTO, поэтому fallback `syncId = entity.id` при `null` недостижим для валидного HTTP-запроса;
- `/all` не имеет method-level `@Secure` и сохраняет риск optional body;
- update идентифицируется только через `body.id`.

Controller: [ClientGoodTypeController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientgoodtype/ClientGoodTypeController.java). Service: [ClientGoodTypeService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientgoodtype/ClientGoodTypeService.java). Entity: [ClientGoodType](../entities/catalog/entities/clientgoodtype/ClientGoodType.md).

## 3. Контрагенты клиента `/clientrelatedentity`

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientrelatedentity/all` | filter wrapper; body optional | [List&lt;ClientRelatedEntityShortDto&gt;](../dto/catalog/clientrelatedentity/ClientRelatedEntityShortDto.md) | method-level `@Secure` отсутствует | Короткий список. |
| `POST /clientrelatedentity/page` | filter wrapper | [Page&lt;ClientRelatedEntityListDto&gt;](../dto/catalog/clientrelatedentity/ClientRelatedEntityListDto.md) | `CLIENT_RELATED_ENTITY:READ` | Использует отдельный list mapping. |
| `POST /clientrelatedentity/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | `CLIENT_RELATED_ENTITY:READ` | Meta values. |
| `GET /clientrelatedentity/{id}` | path ID | [ClientRelatedEntityDto](../dto/catalog/clientrelatedentity/ClientRelatedEntityDto.md) | `CLIENT_RELATED_ENTITY:READ` | Detailed DTO либо 404. |
| `POST /clientrelatedentity/` | [ClientRelatedEntityCreationDto](../dto/catalog/clientrelatedentity/ClientRelatedEntityCreationDto.md) | [ClientRelatedEntityDto](../dto/catalog/clientrelatedentity/ClientRelatedEntityDto.md) | `CLIENT_RELATED_ENTITY:CREATE` | Обрезает пробелы адресов, превращает пустые адреса в `null`, генерирует случайный `syncId`, сохраняет и создаёт outbound. |
| `PUT /clientrelatedentity/{id}` | [ClientRelatedEntityUpdateDto](../dto/catalog/clientrelatedentity/ClientRelatedEntityUpdateDto.md) | detailed DTO | `CLIENT_RELATED_ENTITY:WRITE` | Обновляет по `body.id`, всегда заново загружает клиента, нормализует адреса и создаёт outbound update. Path ID не используется. |

Обязательны `code`, `client.id`, `isShipper`, `isConsignee`, `isCarrier`; для update — `id`. `name`, `active`, ИНН, КПП и адреса опциональны.

Фактическая проверка ИНН/КПП слабее названия ошибки:

- `inn` — любое содержимое длиной до 12 символов, не только цифры;
- `kpp` — любое содержимое длиной до 9 символов;
- строка `message` содержит буквальный текст `CLIENT_RELATED_ENTITY_INVALID_INN/KPP`, а не значение объявленной Java-константы.

```mermaid
flowchart LR
    A[ClientRelatedEntity] --> B{Роли}
    B --> C[isShipper<br/>грузоотправитель]
    B --> D[isConsignee<br/>грузополучатель]
    B --> E[isCarrier<br/>перевозчик]
    C --> F[Может выбираться транспортными заявками]
    D --> F
    E --> F
```

Риски и расхождения:

- поле `legalEntity` осталось во входном и выходном DTO, но отсутствует в текущей entity после перехода на `Client`; явного mapping нет, поэтому на его сохранение и заполнение рассчитывать нельзя;
- DTO не требует хотя бы одну роль `true`: запись со всеми тремя `false` проходит Bean Validation;
- update использует `body.id`, а не path ID;
- `/all` не имеет method-level `@Secure` и имеет риск null wrapper.

Controller: [ClientRelatedEntityController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientrelatedentity/ClientRelatedEntityController.java). Service: [ClientRelatedEntityService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientrelatedentity/ClientRelatedEntityService.java). Entity: [ClientRelatedEntity](../entities/catalog/entities/clientrelatedentity/ClientRelatedEntity.md).

## 4. Водители `/clientdriver`

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientdriver/all` | filter wrapper; body optional | [List&lt;ClientDriverShortDto&gt;](../dto/catalog/clientdriver/ClientDriverShortDto.md) | method-level `@Secure` отсутствует | Короткий список. |
| `POST /clientdriver/page` | filter wrapper | `Page<ClientDriverDto>` | `CLIENT_DRIVER:READ` | Страница водителей. |
| `POST /clientdriver/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | `CLIENT_DRIVER:READ` | Meta values. |
| `GET /clientdriver/{id}` | path ID | [ClientDriverDto](../dto/catalog/clientdriver/ClientDriverDto.md) | `CLIENT_DRIVER:READ` | Detailed DTO либо 404. |
| `POST /clientdriver/` | [ClientDriverCreationDto](../dto/catalog/clientdriver/ClientDriverCreationDto.md) | [ClientDriverDto](../dto/catalog/clientdriver/ClientDriverDto.md) | `CLIENT_DRIVER:CREATE` | При пустом `syncId` присваивает ID, сохраняет и создаёт outbound. |
| `PUT /clientdriver/{id}` | [ClientDriverUpdateDto](../dto/catalog/clientdriver/ClientDriverUpdateDto.md) | detailed DTO | `CLIENT_DRIVER:WRITE` | Обновляет по `body.id`, разрешает нового клиента при смене связи, нормализует `active` и создаёт outbound update. |

Обязательны `code`, `client.id`, `phoneNumber`, `passportNumber`, `passportIssuedBy`; для update — `id`. Даты паспорта/удостоверения, номер удостоверения, `POANumber`, `POAValidTo`, `syncId` и `active` необязательны по DTO.

Риски:

- текущая миграционная схема устанавливает `passport_issued_date NOT NULL`, но DTO не помечает `passportIssuedDate` обязательным; запрос может пройти Bean Validation и упасть на уровне БД;
- нет межполевой проверки полноты водительского удостоверения или доверенности и проверки сроков;
- update использует `body.id`, path ID игнорируется;
- `/all` не имеет method-level `@Secure` и имеет риск null wrapper.

Controller: [ClientDriverController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientdriver/ClientDriverController.java). Service: [ClientDriverService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientdriver/ClientDriverService.java). Entity: [ClientDriver](../entities/catalog/entities/clientdriver/ClientDriver.md).

## 5. Транспорт клиента `/clientvehicle`

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientvehicle/all` | filter wrapper; body optional | [List&lt;ClientVehicleShortDto&gt;](../dto/catalog/clientvehicle/ClientVehicleShortDto.md) | method-level `@Secure` отсутствует | Короткий список. |
| `POST /clientvehicle/page` | filter wrapper | `Page<ClientVehicleDto>` | `CLIENT_VEHICLE:READ` | Страница транспорта. |
| `POST /clientvehicle/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | `CLIENT_VEHICLE:READ` | Meta values. |
| `GET /clientvehicle/{id}` | path ID | [ClientVehicleDto](../dto/catalog/clientvehicle/ClientVehicleDto.md) | `CLIENT_VEHICLE:READ` | Detailed DTO либо 404. |
| `POST /clientvehicle/` | [ClientVehicleCreationDto](../dto/catalog/clientvehicle/ClientVehicleCreationDto.md) | [ClientVehicleDto](../dto/catalog/clientvehicle/ClientVehicleDto.md) | `CLIENT_VEHICLE:CREATE` | При пустом `syncId` присваивает ID, сохраняет и создаёт outbound. |
| `PUT /clientvehicle/{id}` | [ClientVehicleUpdateDto](../dto/catalog/clientvehicle/ClientVehicleUpdateDto.md) | detailed DTO | `CLIENT_VEHICLE:WRITE` | Обновляет по `body.id`, разрешает изменившиеся ссылки, копирует признаки и создаёт outbound update. |

Обязательны:

- `code` — непустой, максимум 100 символов;
- объекты `client` и `vehicleBrand`;
- `refrigerator`, `withTrailer`, `typeOwnershipTransport`;
- `trailerNumber` — только при `withTrailer = true`;
- `id` — для update.

`vehicleType`, `loadingType`, `syncId`, `trailerNumber` при отсутствии прицепа, `insuranceNumber` и `active` опциональны. Важно: `client` и `vehicleBrand` имеют тип `IdCodeDto`; `@Valid` не делает вложенный `id` обязательным, потому что в самом `IdCodeDto` на `id` нет `@NotNull`.

```mermaid
flowchart TD
    A[ClientVehicle DTO] --> B{withTrailer = true?}
    B -->|да| C{trailerNumber заполнен?}
    C -->|нет| X[400 ClientVehicle.TrailerNumber.RequiredWhenWithTrailer]
    C -->|да| D[Продолжить]
    B -->|нет или null| D
    D --> E[Разрешить Client и VehicleBrand]
    E --> F[Опционально VehicleType и LoadingType]
    F --> G[Сохранить]
    G --> H[Outbound]
```

Фильтр поддерживает клиента, код, тип, марку, вид загрузки, вид собственности, наличие прицепа, рефрижератор и активность.

Дефекты-кандидаты update:

- если существующий `loadingType` отсутствует, переданный новый `loadingType` не загружается, а связь снова устанавливается в `null`;
- если существующий `loadingType` заполнен, а в update передан `null`, код обращается к `updateModel.getLoadingType().getId()` и может завершиться `NullPointerException`;
- update не сверяет path ID с `body.id`;
- `/all` не имеет method-level `@Secure` и имеет риск null wrapper.

Controller: [ClientVehicleController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientvehicle/ClientVehicleController.java). Service: [ClientVehicleService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientvehicle/ClientVehicleService.java). Entity: [ClientVehicle](../entities/catalog/entities/clientvehicle/ClientVehicle.md).

## 6. Цифровые марки `/clientgooddigitalsign`

| Метод и путь | Request | Response | Доступ | Серверное поведение |
|---|---|---|---|---|
| `POST /clientgooddigitalsign/page` | `FilterWithPaging<ClientGoodDigitalSignFilter>` | `Page<ClientGoodDigitalSignDto>` | `CLIENT_GOOD_DIGITAL_SIGN:READ` | Страница; default filter показывает только `active = true`. |
| `POST /clientgooddigitalsign/meta/{fieldName}` | meta filter wrapper | `List<IdsCodeDto>` | то же `:READ` | Meta values. |
| `POST /clientgooddigitalsign/all` | filter wrapper; body optional | `List<IdCodeDto>` | то же `:READ` | Короткий список; code сущности равен `barcode`. |
| `GET /clientgooddigitalsign/{id}` | path ID | [ClientGoodDigitalSignDto](../dto/catalog/clientgooddigitalsign/ClientGoodDigitalSignDto.md) | то же `:READ` | Detailed DTO либо 404. |
| `POST /clientgooddigitalsign/` | [ClientGoodDigitalSignCreationDto](../dto/catalog/clientgooddigitalsign/ClientGoodDigitalSignCreationDto.md) | detailed DTO | то же `:CREATE` | Генерирует ID через базовый mapper и сохраняет. Специализированных post-add эффектов нет. |
| `PUT /clientgooddigitalsign/{id}` | [ClientGoodDigitalSignUpdateDto](../dto/catalog/clientgooddigitalsign/ClientGoodDigitalSignUpdateDto.md) | detailed DTO | то же `:WRITE` | Сверяет path ID с обязательным `body.id`, обновляет связи, barcode и active. |

Обязателен только непустой `barcode`; для update обязателен `id`. `clientGood` имеет `@Valid`, но не `@NotNull`, а `transportPackage` и `productType` не имеют даже каскадной проверки. `active` — primitive boolean и при отсутствии в JSON принимает `false`.

```mermaid
flowchart LR
    CG[ClientGood] --> DS[DigitalSign]
    DS -->|getCode| BC[barcode]
    DS --> TP[TransportPackage optional]
    DS --> PT[ProductType optional]
    GM[GoodMovement optional] --> DS
    OS[outOfStock] --> DS
    API[Create/update DTO] -. не содержит .-> GM
    API -. не содержит .-> OS
```

Риски и ограничения:

- entity и БД требуют `clientGood`, но create DTO допускает `clientGood = null`; ошибка обнаружится позднее на persistence-уровне;
- API create/update не управляет `goodMovement` и `outOfStock`, хотя фильтр и entity эти поля поддерживают;
- отсутствует DTO-валидация максимальной длины `barcode`, тогда как БД ограничивает его 200 символами;
- short endpoint допускает отсутствующий body, сохраняя общий риск null wrapper.

Controller: [ClientGoodDigitalSignController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/clientgooddigitalsign/ClientGoodDigitalSignController.java). Service: [ClientGoodDigitalSignService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/clientgooddigitalsign/ClientGoodDigitalSignService.java). Entity: [ClientGoodDigitalSign](../entities/catalog/entities/clientgooddigitalsign/ClientGoodDigitalSign.md).

## 7. Enum endpoints

### `GET /ownershiptype/all`

Возвращает все значения `OwnershipType`; method-level `@Secure` отсутствует.

| Enum | Отображаемое имя | Числовой code |
|---|---|---:|
| `OWNED` | Собственность | 1 |
| `JOINT_OWNERSHIP` | Совместная собственность супругов | 2 |
| `RENTAL` | Аренда | 3 |
| `LEASING` | Лизинг | 4 |
| `FREE_USE` | Безвозмездное пользование | 5 |

### `POST /clientordertype/all`

Возвращает `RECEIVING` (поставка), `SHIPMENT` (вывоз), `OPERATION` (операция); method-level `@Secure` отсутствует. Этот enum используется в `TermOfRequestedService` для привязки тарифа к типу клиентской заявки.

## Сквозное использование в заявке

```mermaid
flowchart TD
    A[Client] --> B[Выбор номенклатуры ClientGood]
    B --> C[Товарная строка поставки или вывоза]
    A --> D[Выбор ClientRelatedEntity по роли]
    D --> E[Shipper / Consignee / Carrier]
    A --> F[Выбор ClientDriver]
    A --> G[Выбор ClientVehicle]
    F --> H[Transport заявки]
    G --> H
    E --> H
    B --> I[Партии, упаковки, остатки и цифровые марки]
```

Схема показывает структурную зависимость справочников от заявок. Конкретные обязательные роли и поля определяются типом заявки, транспортом, способом заполнения и review/accept-валидацией; см. [API заявок](order-api.md) и [валидацию заявок](../business-rules/order-validation.md).

## Матрица идентификаторов update

```mermaid
flowchart TD
    A[PUT request] --> B{Контроллер}
    B -->|ClientGood, ClientGoodType,<br/>RelatedEntity, Driver, Vehicle| C[Path ID не передан в handler]
    C --> D[Поиск и update по body.id]
    B -->|ClientGoodDigitalSign| E[Path ID и body.id переданы BaseService]
    E -->|совпадают| F[Update]
    E -->|не совпадают| G[IllegalArgumentException]
```

При проектировании нового API единый безопасный вариант — либо всегда подставлять path ID при пустом `body.id` и затем сверять, либо убрать ID из body и использовать только path. Текущее поведение неоднородно.

## Вопросы для владельца системы

1. Следует ли исправить update `tempRegime` у `ClientGood` и `loadingType` у `ClientVehicle` как дефекты?
2. Нужно ли пересчитывать `ClientGoodType.hasClientGoods` при переносе номенклатуры между типами?
3. Должны ли `legalEntity` в DTO контрагента и старые названия полей окончательно замениться на `client`?
4. Обязателен ли `passportIssuedDate` на уровне API так же, как в БД?
5. Должен ли `ClientGoodDigitalSign.clientGood` быть `@NotNull`, а `barcode` иметь `@Size(max = 200)`?
6. Нужно ли унифицировать path/body ID и доступ к `/all` endpoints?

## Связанные документы

- [API клиентов, договоров и условий услуг](client-contract-api.md)
- [API заявок](order-api.md)
- [Полный generated-каталог endpoints](endpoints-generated.md)
- [Каталог DTO](../dto/catalog/README.md)
