# `waybill_railway_carriage`: вагон в накладной, физическая модель AS-IS (часть 10)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java controller/service/JPA, SQL/cumulative migrations и test sources. Это **source-level модель**, а не снимок применённой БД. Корень накладной описан отдельно в [физической модели `waybill`](waybill-root-as-is.md), дочерний КТК — в [физической модели `waybill_container`](waybill-container-as-is.md), полный integration flow — в [Waybill и входящий ЭТРАН](../business-rules/waybill-etran-as-is.md).

## Граница сущности: справочник вагона и участие в накладной

[`WaybillRailwayCarriage`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillrailwaycarriage/WaybillRailwayCarriage.java) — не сам физический вагон, а его участие в конкретной накладной. Обязательная ссылка `railway_carriage_id` ведёт на глобальный [`RailwayCarriage`](../entities/catalog/entities/railway/RailwayCarriage.md), переиспользуемый разными накладными.

| Где хранится | Поля | Семантика |
|---|---|---|
| `railway_carriage` | номер, тип, модель, грузоподъёмность, тара, оси, длина, объём, ремонт и другие характеристики | Текущее глобальное описание физического вагона; после KIS-3234 номер `code` уникален. |
| `waybill_railway_carriage` | `ownership`, `renter`, `previously_transported`, `gross_weight`, `net_weight`, `place_count` | Snapshot конкретной накладной; runtime-update этих полей не найден. |
| `waybill_railway_carriage.status` | `UPLOADED`, `FINISHED`, потенциально `CANCELED`, либо `NULL` | Операционный статус ALIS/TOS, а не характеристика вагона ЭТРАН. |

Изменение глобального `RailwayCarriage` меняет справочные характеристики во всех read-моделях, которые идут по FK; snapshot-поля участия при этом не пересчитываются. В ТЗ эти два уровня нельзя объединять в один редактируемый объект.

## SQL-контракт

Initial table создана migration [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql), затем KIS-3631 добавил status и недостающий update audit.

| Java-поле | Колонка / SQL | Обязательность и связь | Источник / изменение |
|---|---|---|---|
| `id` | `UUID PRIMARY KEY` | NOT NULL через PK | UUID entity lifecycle. |
| `waybill` | `waybill_id UUID` | `NOT NULL REFERENCES waybill ON DELETE CASCADE` | ЭТРАН, Excel либо migration; runtime reparent не найден. |
| `railwayCarriage` | `railway_carriage_id UUID` | `NOT NULL REFERENCES railway_carriage(id)` | Разрешается по номеру вагона. `ON DELETE` не задан. |
| `ownership`, `renter`, `previouslyTransported` | nullable `VARCHAR` | Нет CHECK/FK | Snapshot входной накладной; legacy migration их не переносит. |
| `grossWeight`, `netWeight` | nullable `NUMERIC(16,3)` | Нет CHECK | Snapshot ЭТРАН; единицы отдельно схемой не закреплены. |
| `placeCount` | nullable `INTEGER` | Нет CHECK | Snapshot ЭТРАН. |
| `status` | nullable `VARCHAR` | Нет DEFAULT/CHECK | При создании остаётся null; позднее integration flows пишут enum name. |
| audit | `created_at TIMESTAMP NOT NULL DEFAULT ...`, `created_by VARCHAR(50) NOT NULL`, nullable `updated_at`, `updated_by VARCHAR(50)` | `updated_*` добавлены позже | `BaseEditable`/auditing. |

Есть только явный неуникальный индекс по `waybill_id`. В просмотренной цепочке нет индекса по `railway_carriage_id`, `UNIQUE(waybill_id, railway_carriage_id)` и проверок неотрицательных масс/количества. Поэтому база допускает две строки одного вагона в одной накладной. При фактическом дубле repository-метод, возвращающий `Optional` по этой паре, способен завершиться ошибкой множественного результата.

## Пути создания

### Импорт ЭТРАН / Datareon

[`WaybillDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java) при **первом** `waybill_identifier`:

1. ищет или создаёт глобальный вагон по номеру;
2. обновляет его общие характеристики из входа;
3. создаёт отдельный WRC со snapshot-полями;
4. сохраняет дочерние `waybill_container` и ЗПУ в той же транзакции.

Повтор сообщения по существующему identifier меняет только root `Waybill.status`: вагоны не сверяются и не дополняются. Внутри одного нового payload нет проверки уникальности пары; повторённый номер может породить несколько WRC.

### Railway Excel

[`ReceivingOrderRailwayCarriageParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderRailwayCarriageParser.java) ищет WRC по паре Waybill/глобальный вагон и создаёт его только при отсутствии. Snapshot-поля и status остаются null. Это application-level find-then-insert без DB UNIQUE/lock, поэтому конкурентный импорт не защищён.

Для отсутствующей накладной parser строит manual Waybill без `waybillIdentifier`, тогда как исходный SQL объявляет `waybill_identifier INTEGER NOT NULL UNIQUE`; последующего снятия NOT NULL в просмотренной цепочке не найдено. Успешность этой ветки на реальной схеме не подтверждена и требует отдельного integration test/applied-schema check.

### Перенос legacy-данных

[`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) переносит активные старые строки только как `waybill_id`, `railway_carriage_id` и create audit. Она использует `NOT EXISTS` по паре, но не создаёт constraint; snapshot и status у перенесённой строки остаются null. Сопоставление накладной идёт по неуникальному `waybill.number`, поэтому фактическую однозначность нужно проверять на данных.

## Статус и серверная логика

[`TaskStatus`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/integration/TaskStatus.java) содержит `UPLOADED`, `FINISHED`, `CANCELED`, однако найденные WRC writers используют первые два:

- успешный receiving transport manifest ставит `UPLOADED` всем WRC того же физического вагона в поставке и схлопывает их груз; экспорт railway route package ставит `UPLOADED` всем WRC всех поставок рейса;
- inbound [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) блокирует строку и ставит `FINISHED`; повтор для уже завершённой строки не меняет её;
- первый завершённый вагон может задать фактическое время приёмки, а завершение всех вагонов при отсутствии receiving containers может закрыть поставку.

Repository-проверка «все завершены» реализована как отсутствие строк `status != FINISHED`. В SQL/JPQL сравнение с `NULL` даёт UNKNOWN, поэтому строки с null не блокируют результат; пустой набор также считается завершённым. Проверка «первый вагон» ищет только другие строки со status `FINISHED` и тоже игнорирует null. Это важно для legacy/Excel/import rows, где status изначально null; ожидаемое business-правило необходимо подтвердить и закрепить тестами.

## Read API, DTO и фильтры

Новый [`WaybillRailwayCarriageController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybillrailwaycarriage/WaybillRailwayCarriageController.java) публикует только page/meta/get с `Permission.WAYBILL`. Compatibility [`ReceivingOrderRailwayCarriageController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingorderrailwaycarriage/ReceivingOrderRailwayCarriageController.java) сохраняет `/all`, `/page`, `/{id}`, DELETE и два preview; `/all` не имеет `@Secure` непосредственно на методе, поэтому фактическую защиту gateway/runtime нужно проверять отдельно.

| Ответ | Что отдаёт | Существенное ограничение |
|---|---|---|
| [`WaybillRailwayCarriageDto`](../dto/catalog/waybillrailwaycarriage/WaybillRailwayCarriageDto.md) | id/audit, глобальный `RailwayCarriageDto`, ownership, previouslyTransported, compatibility refs на ReceivingOrder/Waybill | Не содержит `status`, renter, массы и placeCount; три legacy-поля mapper намеренно оставляет null. |
| [`WaybillRailwayCarriageDetailedDto`](../dto/catalog/waybillrailwaycarriage/WaybillRailwayCarriageDetailedDto.md) | Добавляет renter, gross/net weight, placeCount | Также не содержит `status`. |
| [`WaybillCarriageViewDto`](../dto/catalog/waybill/WaybillCarriageViewDto.md) в grouped preview | Номер/тип/модель/грузоподъёмность/ремонт и строковый status | Это отдельная составная read-модель, не CRUD DTO. |

[`WaybillRailwayCarriageFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillrailwaycarriage/WaybillRailwayCarriageFilter.java) поддерживает вложенный Waybill, справочные поля вагона, ownership/date/status/search и compatibility body `receivingOrder.id`. Поле `deleted=false` унаследовано из старого контракта, но entity не реализует soft-delete и predicate его не применяет; менять его в запросе бессмысленно.

## Удаление и каскады

WRC не реализует `SoftDeletable`, поэтому compatibility `DELETE /receivingorderrailwaycarriage/{id}` вызывает **физическое** удаление. FK удаляет `waybill_container`, а следующий FK — их `waybill_zpu`. Root Waybill и глобальный RailwayCarriage сохраняются.

После generic remove [`WaybillRailwayCarriageService.postRemove`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybillrailwaycarriage/WaybillRailwayCarriageService.java) пытается soft-delete связанные `ReceivingOrderContainer`, найденные через `WaybillContainer.container.id`, после чего их сервисы пересчитывают totals/items/services. Порядок вызывает source-level риск: если ORM flush физического WRC и DB cascade выполнится до post-remove subquery, связующие WaybillContainer уже исчезнут и выборка станет пустой. Прямого integration test этой последовательности не найдено, поэтому это **не доказанный production-дефект**, а обязательная проверка перед опорой на cleanup.

```mermaid
flowchart TD
    I[Datareon first import] --> G[Find or create global RailwayCarriage]
    X[Railway Excel] --> G
    G --> W[(waybill_railway_carriage)]
    B[(waybill)] -->|NOT NULL, ON DELETE CASCADE| W
    W --> C[(waybill_container)]
    C --> Z[(waybill_zpu)]
    E[Successful outbound] -->|UPLOADED for all same physical wagon rows| W
    T[CARRIAGE_ARRIVED] -->|FINISHED| W
    D[Legacy DELETE WRC] -->|physical delete| W
    D -->|DB cascade| C
    C -->|DB cascade| Z
    D -. postRemove lookup; order needs test .-> R[Soft-delete matching ReceivingOrderContainer]
```

## Проверки, пробелы и история

Test sources подтверждают `FINISHED` после receiving event и `UPLOADED`/схлопывание одного физического вагона в manifest export. Не найдены прямые тесты duplicate pair, null semantics `allCarriagesFinished`, нового WRC read controller, Excel-created Waybill с обязательным identifier и полного DELETE cascade/postRemove. Тесты в этом подэтапе **не запускались**.

Основные повлиявшие commits: `feb37a42` (initial Waybill/WRC schema и importer, 2026-02-13), `ce939d57` и `443ae69a` (KIS-3631 migration/controller/domain merge, 2026-03/04), `1378d120` (domain/audit alignment, 2026-04-01), `cd8ab542`/`42eee4ee` (scoped meta и nested filtering, 2026-08). История Git не доказывает, что migration chain применена на конкретной среде.
