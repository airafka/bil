# `shipping_order_container_item`: содержимое КТК вывоза, физическая модель AS-IS (часть 21)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Это **source-level реконструкция**, не проверка применённой БД. Parent КТК — в [модели `shipping_order_container`](shipping-order-container-as-is.md); root totals — в [модели `shipping_order`](shipping-order-root-as-is.md). Контур почти буквально зеркален [`receiving_order_container_item`](receiving-order-container-item-as-is.md) — большинство миграций общие для обеих `_container_item`-таблиц; ниже отмечены только отличия и подтверждённые NPE-риски.

## HTTP → DTO → service

[`ShippingOrderContainerItemController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontaineritem/ShippingOrderContainerItemController.java) — обычный CRUD (`POST /`, `PUT /{id}`, `DELETE /{id}`, `GET /{id}`, `/all`, `/page`, `/preview`) плюс явно `@Operation(deprecated = true)` `POST /{shippingOrderId}` (`upsertAndDelete` по deprecated overload с `UUID orderId`, как и у parent-контейнера). Современный merge-путь лежит в самом сервисе (`merge`/`getList`), вызываемом с V2-контроллера КТК-контура.

[`CreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemCreationDto.md) требует `shippingOrder.id`, `shippingOrderContainer.id` (`@NotNull @Valid`) и `wightGross BigDecimal @NotNull`; `etsngCode`, `description`, `price`, `wightNet`, `quantityPlace` — optional, без `@Positive/@PositiveOrZero`, precision/scale или проверки `wightNet ≤ wightGross` — то же отсутствие Bean Validation, что и у receiving-аналога. [`UpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemUpdateDto.md) добавляет `UUID id` без `@NotNull`; `PUT /{id}` не принимает `@PathVariable id`, лукап — по body `id`.

[`ShippingOrderContainerItemService.prepareModelToAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerItemService.java) загружает `shippingOrder` и `shippingOrderContainer` по отдельности через свои DAO — **без** проверки, что `shippingOrderContainer.shippingOrder.id == shippingOrder.id` из запроса. SQL имеет два независимых FK, не composite constraint на пару. Cross-parent insert (item ссылается на контейнер другой заявки) технически проходит FK-валидацию; практический outcome для totals — см. ниже. Отдельно, если `description` пустой/`null`, сервис автозаполняет его из `etsngCode.getName()` — небольшое, но реальное поведение по умолчанию, не описанное в DTO.

## SQL-колонки и изменения

[`ALG-646 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240904_ALG-646_add_table_shipping_order_container_item.sql) задал `shipping_order_id`, `shipping_order_container_id`, `etsng_code_id`, `description`, `price` все **`NOT NULL`** — заметно строже, чем итоговое состояние. `wight_gross`/`wight_net`/`quantity_place` в исходной таблице **не существовали вовсе**: их вместе со снятием `NOT NULL` на `price` добавил тот же общий changeset [`KIS-2003`](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251112_KIS-2003_refactoring_excel_template.sql), что и у receiving (`wight_gross NUMERIC(15,3) NOT NULL DEFAULT 0`, `wight_net`/`quantity_place NUMERIC(15,3) NULL`) — то же унаследованное написание `wight` вместо `weight`. [`KIS-282`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250306_KIS-282_drop_not_null.sql) снял `NOT NULL` с `description` тем же changeset для обеих таблиц. [`KIS-2906`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260205_KIS-2906_remove_not_null_constrains_for_etsng_code.sql) снял `NOT NULL` с `etsng_code_id` — тоже одновременно для receiving и shipping. Отдельного business `UNIQUE`, `CHECK` или non-PK индекса для этой таблицы не найдено.

## Два независимых writer'а и NPE в parent-контейнере

После add/update/soft-remove сервис вызывает **оба** пересчёта:

1. `calculateAndSetFields(shippingOrderId)` — читает активные item-строки **по `item.shippingOrder.id`** и пишет **root**: `shipping_order.total_goods_price = sum(price)`, `shipping_order.total_weight = sum(wightGross)` (null пропускается, старт с нуля).
2. `calculateAndSetShippingOrderContainerFields(orderContainerId)` — читает активные item-строки **по `item.shippingOrderContainer.id`** и пишет **parent**: `shipping_order_container.weight = container.getWeight() + sum(wightGross)`.

Второй метод **не содержит null-guard**: `orderContainer.getContainer().getWeight()` разыменовывается напрямую. Для КТК с `ktkNumberUnknown=true` (где, как задокументировано в [модели `shipping_order_container`](shipping-order-container-as-is.md#sql-колонки-и-изменения), `container` остаётся `null`) любое добавление/изменение/удаление item-строки в таком контейнере вызывает `NullPointerException` при пересчёте parent weight. Показательно, что тот же файл [`ShippingOrderContainerItemMapper.calculatePreviewNetWeight`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerItemMapper.java) — **read-only** путь превью — явно проверяет `container != null`/`container.getWeight() != null` перед тем же вычитанием: паттерн защиты в кодовой базе есть, но не применён в persistence-side пересчёте. Это точное зеркало уже задокументированного для receiving-контура риска («parent container=null» в [`receiving_order_container_item`](receiving-order-container-item-as-is.md#порядок-persisted-calculations-и-конфликт-источников)), подтверждённое здесь отдельно по shipping source.

Отсутствие composite-проверки `item.shippingOrderContainer.shippingOrder.id == item.shippingOrder.id` (см. выше) означает: root-writer #1 фильтрует по одному FK, а parent-writer #2 — по другому. Cross-parent строка (если создана) попадёт в totals одной заявки и в вес контейнера, физически принадлежащего FK-структурой другой заявке — тот же вывод, что и у receiving, здесь не переисследовался отдельным тестом.

### Три конкурирующих writer'а `total_weight` заявки на вывоз

С учётом этого документа, root-поле `shipping_order.total_weight` теперь имеет **три** независимых Java-writer'а с разными формулами и областью действия:

| Writer | Источник суммы |
|---|---|
| [`ShippingOrderCargoService`](shipping-order-cargo-as-is.md#stored-root-totals-и-побочный-пересчёт-услуг) | `sum(ShippingOrderCargo.weight)` по активным cargo-строкам заявки |
| [`ShippingOrderContainerService`](shipping-order-container-as-is.md#stored-totals-и-ktknumberunknown-флаг-заявки) | `sum(ShippingOrderContainer.weight)` по активным parent-контейнерам заявки (сам `weight` контейнера, в свою очередь, — производная величина) |
| `ShippingOrderContainerItemService` (этот документ) | `sum(ShippingOrderContainerItem.wightGross)` по активным item-строкам **напрямую**, без тары контейнера |

Формула #3 не совпадает с формулой #2 (у #2 в сумму входит tare контейнера, у #3 — нет), и обе потенциально применимы к одной и той же container-заявке, поскольку добавление/изменение item-строки перезаписывает root `total_weight` тем же вызовом, которым обновляется вес контейнера. Итоговое сохранённое значение зависит от того, какой сервис выполнялся последним в цепочке одного HTTP-запроса, а не от единого authoritative правила. Аналогичное конкурирование `total_goods_price` уже описано между [`ShippingOrderGoodService`](shipping-order-good-as-is.md#stored-root-totals) и этим item-writer'ом.

```mermaid
flowchart TD
    D[Item DTO: order/container refs, price, wightGross/Net, places] --> M[Mapper: new UUID, autofill description from ETSNG]
    M --> S[Service: root status check, independent order/container lookups]
    S --> I[(shipping_order_container_item)]
    I --> R[Filter active items by item.shippingOrder.id]
    R --> RT[(shipping_order.total_goods_price / total_weight — writer 3 of 3)]
    I --> P[Filter active items by item.shippingOrderContainer.id]
    P --> PT["parent.weight = container.getWeight() + sum(wightGross) — NO null-guard"]
    PT -.ktkNumberUnknown container=null.-> NPE[NullPointerException]
    PREVIEW[toPreviewDto.calculatePreviewNetWeight: guarded] -.contrast.-> PT
```

## Что подтверждают tests, но не их запуск

- [`ShippingOrderContainerItemServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerItemServiceIntegrationTest.java) проверяет пересчёт root totals при add/update/remove — но не пересчёт parent container weight, не cross-parent сценарий и не `ktkNumberUnknown`-контейнер.
- [`ShippingOrderContainerItemDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerItemDaoServiceTest.java) — DAO-уровень.
- Не найдено: прямой тест на NPE при добавлении item-строки в контейнер с `container=null`; тест конфликта между тремя `total_weight`-writer'ами; тест cross-parent (item.shippingOrder ≠ item.shippingOrderContainer.shippingOrder).
- Тесты не запускались; их наличие не подтверждает применённую схему или фактическое исключение в runtime.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog` и applied constraints/индексы в развернутой БД.
2. Нужен прямой тест: создать `ShippingOrderContainer` с `ktkNumberUnknown=true` (container=null), затем добавить/обновить/удалить `ShippingOrderContainerItem` — подтвердить или опровергнуть NPE в `calculateAndSetShippingOrderContainerFields`.
3. Нужно перенести null-guard из `calculatePreviewNetWeight` (read-only mapper) в persistence-side пересчёт веса контейнера, либо явно решить, что item-строки в контейнерах с неизвестным номером не должны создаваться логикой приложения (тогда нужна отдельная явная проверка, а не полагание на порядок операций).
4. Нужно определить единственный authoritative writer для `total_weight` заявки на вывоз среди трёх конкурирующих (cargo/container/container-item), и аналогично — для `total_goods_price` среди двух (good/container-item).
5. Нужна composite-проверка (или хотя бы явный source-level lookup), что `shippingOrderContainer.shippingOrder.id` совпадает с request `shippingOrder.id`, прежде чем полагаться на раздельные FK как на гарантию целостности.

## Чек-лист изменения таблицы

1. Для новых полей, зависящих от nullable-ссылок (`container` в parent), переносить существующий в read-side null-guard (`calculatePreviewNetWeight`) в persistence-side пересчёты, а не оставлять их рассинхронизированными.
2. Для root-полей с более чем одним writer'ом (`total_weight`, `total_goods_price`) — перед добавлением нового источника явно задокументировать порядок вызовов и то, какой вариант заявки какой writer использует.
3. Для двух независимых FK, логически образующих одну сущность (item → order, item → container → order), добавлять composite-проверку принадлежности на уровне сервиса, если целостность важна для ТЗ.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [КТК заявки на вывоз: физическая модель AS-IS](shipping-order-container-as-is.md)
- [Номенклатура заявки на вывоз: физическая модель AS-IS](shipping-order-good-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](shipping-order-cargo-as-is.md)
- [Содержимое КТК поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-container-item-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderContainerItem](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainerItem.md)
