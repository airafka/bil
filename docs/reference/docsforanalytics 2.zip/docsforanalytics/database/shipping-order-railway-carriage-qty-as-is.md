# `shipping_order_railway_carriage_qty`: плановое количество вагонов, физическая модель AS-IS (часть 27)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations, accept-validator, route read/meta, route chain package exporter и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Таблица описывает плановое количество вагонов без их номеров; физические вагонные строки разобраны в [части 25](shipping-order-railway-carriage-as-is.md).

## Назначение и граница с физическими вагонами

Для железнодорожной заявки используются две взаимоисключающие на уровне текущего UI/service сценария модели:

| `ShippingOrder.fillingType` | Источник вагонов для accept/read | Роль этой таблицы |
|---|---|---|
| `ALL` | `shipping_order_railway_carriage` | Не используется; заданы номера вагонов и КТК. |
| `RAILWAY_CARRIAGE` | `shipping_order_railway_carriage` | Не используется; заданы номера вагонов. |
| `CONTAINER` | `shipping_order_railway_carriage_qty` | Обязательна хотя бы одна строка; номера вагонов не заданы. |
| `NONE` | `shipping_order_railway_carriage_qty` | Обязательна хотя бы одна строка; номера вагонов и КТК не заданы. |
| `NONE_CONTAINER` | Не относится к железнодорожной комбинации | [`OrderCombinationValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/validator/ordercombination/OrderCombinationValidator.java) разрешает этот тип только для `CONTAINER + VEHICLE`. |

Сервис qty разрешает запись только для `CONTAINER` и `NONE`. Однако смена `fillingType` корня не сопровождается найденной очисткой старых qty-строк. Поэтому физически обе модели могут сосуществовать, хотя accept и route read выберут только одну из них.

## Endpoint → DTO → service

Контроллер [`ShippingOrderRailwayCarriageQtyController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyController.java) публикует только scoped V2 API. Основной transport DTO — [`ShippingOrderRailwayCarriageQtyDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyDto.md); внутренние DTO — [`CreationDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyCreationDto.md) и [`UpdateDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyUpdateDto.md).

| Endpoint | DTO / результат | Реализованная логика и ограничения |
|---|---|---|
| `POST /shipping-order/{shippingOrderId}/shipping-order-railway-carriage-qty/list` | optional filter → `Dto[]` | READ. Controller принудительно задаёт path-заявку; service отдельно проверяет доступность корня через user restriction и обогащает дочерний фильтр. Filling type при чтении не проверяется. |
| `POST .../meta/{fieldName}` | required paged filter → meta values | READ. `type` преобразуется в `type.code`; path-заявка подставляется в фильтр. Отдельной проверки существования корня нет. |
| `PUT .../merge` | `Dto[]` → `Dto[]` | DELETE permission, хотя full-replace создаёт, обновляет и физически удаляет строки. Разрешён только для `CONTAINER/NONE`; после операции выполняется scoped read. |

Полный декларативный контракт доступен в [generated endpoint-каталоге](../api/endpoints-generated.md#shippingorderrailwaycarriageqtycontroller).

Отдельных публичных CRUD endpoints create/update/delete нет. `id=null` во входной строке merge означает создание; существующий `id` — обновление; строка текущей заявки, не включённая в список, физически удаляется. ID из другой заявки отклоняется общей реализацией `upsertAndDelete` как отсутствующий в scope.

## DTO и фактическая обязательность

| Поле merge DTO | Bean Validation | SQL | Итоговый контракт |
|---|---|---|---|
| `id` | nullable в `Dto` | PK NOT NULL | `null` для новой строки; UUID существующей строки для update. |
| `quantity` | `@NotNull`, `@Min(0)` | `INT NOT NULL CHECK (quantity > 0)` | Обязательное положительное целое фактически задаёт БД. Значение `0` проходит HTTP Bean Validation, но нарушает CHECK. |
| `type` | nullable, без `@Valid` | nullable FK после KIS-3356 | Разрешено отсутствие типа; не более одной такой строки на заявку. |

Внутренний `CreationDto` содержит `shippingOrder`, `quantity` и `type`, но не объявляет `@NotNull` для первых двух и не задаёт числовой минимум. На публичном merge сначала валидируется `Dto`, затем mapper формирует внутренний `UpdateDto`; его `id @NotNull` не применяется к новым строкам как отдельный controller input.

`quantity` не является суммой или счётчиком фактических вагонов: сервер сохраняет переданное число без вычисления и не сравнивает его с физическими wagon rows.

## SQL contract и история

Таблица создана миграцией [`KIS-3352`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql).

| Колонка | Текущий source contract | История / смысл |
|---|---|---|
| `id` | `UUID PRIMARY KEY` | Генерируется mapper/BaseIdentifier. |
| `shipping_order_id` | `UUID NOT NULL`, FK → `shipping_order(id)` | `@JoinColumn(updatable=false)`; `ON DELETE` не задан. |
| `quantity` | `INT NOT NULL CHECK (quantity > 0)` | Количество вагонов, строго больше нуля. |
| `type_id` | nullable FK → `railway_carriage_type(id)` | Изначально NOT NULL; nullable с [`KIS-3356`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260415_KIS-3356_make_shipping_order_railway_carriage_qty_type_nullable.sql). |

Сущность наследует только `BaseIdentifier`: в таблице нет `deleted`, `created_at/by` и `updated_at/by`. Удаление — физическое, история изменений этой строки не сохраняется.

[`KIS-3663`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260330_KIS-3663_add_unique_constraints_for_numberless_shipping_order.sql) добавил `UNIQUE(shipping_order_id, type_id)`. KIS-3356 затем добавил второй constraint `UNIQUE NULLS NOT DISTINCT(shipping_order_id, type_id)`, не удаляя первый. Первый стал функционально избыточен для ненулевых типов, а второй дополнительно разрешает не более одной строки с `type_id=NULL` на заявку.

Composite UNIQUE создаёт индекс с префиксом `shipping_order_id`; отдельного индекса по одному `type_id` в просмотренных миграциях не найдено. В [`KIS-4321`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260729_KIS-4321_edit_railway_carriage_table.sql) три старых «неопределённых» типа заменяются в qty-строках единым типом `Не определено`. Если одна заявка до миграции содержала две заменяемые строки разных старых типов, их массовое сведение к одному `type_id` могло конфликтовать с UNIQUE; предварительное объединение строк в SQL не выполняется. Успешность на фактических данных не проверялась.

## Уникальность и конкурентность

[`ShippingOrderRailwayCarriageQtyService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyService.java) перед add/update загружает строки заявки и проверяет:

- один и тот же ненулевой `type.id` не должен повторяться;
- строка с `type=null` может быть только одна;
- при update текущая строка исключается из проверки по ID.

В отличие от ранее разобранных wagon/ETRAN application checks, здесь текущая SQL-схема дублирует правило DB constraint и закрывает параллельный конфликт. DB violation общий `BaseService` преобразует в `UniqueViolationException("Already exists")`, поэтому предметный код `TypeAlreadyExists` гарантирован только при успешной предварительной прикладной проверке.

## Merge, удаление и атомарность

Merge является полной синхронизацией всей заявки. Общий `upsertAndDelete` сначала физически удаляет отсутствующие ID, затем последовательно создаёт/обновляет переданные строки.

Метод `ShippingOrderRailwayCarriageQtyService.merge` не имеет `@Transactional` и вызывает `super.upsertAndDelete(...)` внутри того же объекта. Аннотация `@Transactional` на superclass-методе не проходит через Spring proxy при таком self-invocation; DAO/add/update/remove имеют собственные транзакционные границы. Поэтому source-level поведение выглядит **неатомарным**: при ошибке поздней строки ранее удалённые/добавленные строки могут уже сохраниться. Integration tests выполняются внутри test-level `@Transactional` и этот production gap не проверяют.

Перед merge корень загружается прямым `shippingOrderDaoService.getById`, затем проверяются status и filling type. `findAvailableShippingOrder`/явное обогащение корневого access filter не используются. Controller permission — только `SHIPPING_ORDER_RAILWAY_CARRIAGE/DELETE`; достаточность этого для client row-level write scope runtime не подтверждена.

Как и другие дочерние shipping-сервисы, status check использует общий helper с жёстко заданным receiving-правом для состояния `ON_REVIEW`.

```mermaid
flowchart TD
    M[PUT merge: полный желаемый список] --> A{Заявка CONTAINER или NONE?}
    A -->|нет| X[Invalid filling type]
    A -->|да| S{Статус разрешает изменение?}
    S -->|нет| X
    S -->|да| D[Физически удалить отсутствующие ID]
    D --> U[Последовательно add / update]
    U --> Q{quantity > 0 и пара order+type уникальна?}
    Q -->|нет| E[Ошибка; ранние операции могут сохраниться]
    Q -->|да| R[Вернуть scoped list]
```

## Accept, route read и meta-view

[`ShippingOrderAcceptValidator.railwayCarriageChecks`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) для `CONTAINER/NONE` проверяет только наличие хотя бы одной qty-строки. Он не проверяет сумму, наличие типа или согласованность с КТК. Положительность количества обеспечивает SQL CHECK.

`POST /route/{routeId}/shipping-order/railway-carriage` в [`RouteService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java) для `CONTAINER/NONE` читает qty-строки напрямую и возвращает `code/model/liftingCapacity=null`; nullable `type` mapper обрабатывает как `null`. Для `ALL/RAILWAY_CARRIAGE` endpoint вместо этого читает физические вагоны.

Route meta использует SQL [`shipping_route_railway_carriage_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_railway_carriage.sql). Qty-ветка делает обычный `JOIN railway_carriage_type` по nullable `type_id`, поэтому строка без типа **исчезает из meta-view**, хотя list, accept и route direct read её видят. Это расхождение появилось после разрешения nullable type и в текущем view не компенсировано `LEFT JOIN`.

## Route chain package outbound

[`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) собирает все qty-строки всех shipping-заявок рейса и экспортирует:

- `id` строки;
- `quantity`;
- `shippingOrderId`;
- nullable `typeId`.

Nullable type обработан безопасно: `typeId=null`, а null не включается в справочный список `RailwayCarriageType`. Но exporter не фильтрует строки по текущему `fillingType`. Если заявка была переведена из `CONTAINER/NONE` в `ALL/RAILWAY_CARRIAGE` без очистки qty, stale плановые строки всё равно попадут в route chain package, хотя accept и route direct read будут использовать физические вагоны.

## Тесты и пробелы покрытия

[`ShippingOrderRailwayCarriageQtyServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyServiceIntegrationTest.java) содержит два теста: дублирование ненулевого типа и две строки без типа. Оба вызывают merge внутри test-level transaction. В этом подэтапе тесты не запускались.

Не найдены прямые тесты для `quantity=0`, DB CHECK/UNIQUE, успешного create/update/delete/full-replace, пустого списка, rollback после поздней ошибки, запрещённого filling type/status, client write scope, nullable type в list/route/meta/outbound, смены filling type и stale export.

## Влияющие commits

- `d29256da` (`KIS-3352`) — `filling_type` и физические qty-таблицы.
- `0a8c1bb5` (`KIS-3356`) — JPA/service базовой qty-модели.
- `b33f9401` (`KIS-3360`) — публичный API безномерных заявок и full-replace.
- `9ca9eb80` (`KIS-3663`) — первый DB UNIQUE и backend duplicate validation.
- `fc6003c0` (`KIS-3356`) — nullable type, `UNIQUE NULLS NOT DISTINCT` и актуальная проверка uniqueness.
- `1e46c564` (`KIS-4321`) — объединение старых неопределённых типов.
- `49ce562d`/`6557b9e8` (`KIS-4450`) — route meta-view/endpoints и исправление.
- `4ff9eb7c`/`0b2c6b91` (`KIS-3809`) — route chain package и справочник типов вагонов.
- `8691a93e` и `cd8ab542` — исправление filter naming и scoped meta aliases.

## Чек-лист для проверки ТЗ

- Для каких `fillingType` разрешены qty-строки и что происходит со старыми строками при смене типа?
- Должен ли merge быть атомарным и означает ли `[]` полное физическое удаление?
- `quantity` должна быть `> 0` или допустим ноль? DTO и SQL сейчас расходятся.
- Допускается ли строка без типа и должна ли она отображаться в route meta?
- Нужно ли сверять суммарный план с фактическими вагонами/контейнерами?
- Должен ли outbound исключать stale qty для номерной заявки?
- Достаточно ли DELETE permission для create/update/delete и где проверяется client write scope?
- Нужен ли audit/history для физически удаляемых строк?

## Связанные документы

- [Корень заявки на вывоз](shipping-order-root-as-is.md)
- [Физический вагон заявки](shipping-order-railway-carriage-as-is.md)
- [Membership ЭТРАН](shipping-order-etran-invoice-as-is.md)
- [Route: план/факт и meta](../business-rules/route-shipping-plan-fact-as-is.md)
- [Сводная integrity-карта ShippingOrder](shipping-order-integrity-map.md)
