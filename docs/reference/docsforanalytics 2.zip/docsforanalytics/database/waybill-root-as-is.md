# `waybill`: корень накладной ЭТРАН и связь с поставкой, физическая модель AS-IS (часть 9)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java integration/controller/service/JPA, SQL/cumulative migrations и test sources. Это **source-level модель**, не снимок применённой БД. Полное поведение внешнего payload, справочных upserts, пользовательских read endpoints и ошибок уже описано в [Waybill и входящий ЭТРАН: актуальный AS-IS](../business-rules/waybill-etran-as-is.md); здесь фокус на корневой таблице, её ключах/nullable/FK и write paths. Дочерние уровни раскрыты отдельно: [вагон](waybill-railway-carriage-as-is.md), [КТК и ЗПУ](waybill-container-as-is.md), [груз](waybill-product-as-is.md), [специальные и тарифные отметки](waybill-marks-as-is.md). Производная eventually consistent проекция вынесена в [физическую модель `grouped_waybill`](grouped-waybill-as-is.md), а весь контур с ReceivingOrder — в [сводную ER/integrity-карту](receiving-order-waybill-integrity-map.md).

## Как создаётся и обновляется корень

Основной create/update source — `POST /datareon/waybill` в [`DatareonController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java). Он принимает [`WaybillIntegrationDto`](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md) и вызывает transactional [`WaybillDatareonService.handleInboundWaybill`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java).

| Вход | Декларативная обязательность | Фактическая роль |
|---|---|---|
| `waybill` | root `@NotNull`, но без `@Valid` | Nested `@NotNull` не каскадирует из controller validation; service обращается к полям напрямую. |
| `waybill_identifier` | nested `@NotNull`, фактически не каскадирует | `Integer.valueOf` и единственный lookup key; SQL `NOT NULL UNIQUE`. `MessageId` и `Version` не участвуют в дедупликации. |
| `waybill_status`, `waybill_number`, станции | nested annotations + runtime mapping | Status/number и оба station FK обязательны в SQL; станции ищутся/создаются по ESR. |
| Семь дат | DTO nullable | При первом create service вызывает `atZone(Europe/Moscow)` без null-check, хотя SQL разрешает null. |
| `products`, `containers`, остальные child lists | DTO nullable | Validator/mapper вызывает `.size()`/`.stream()` без единой нормализации; фактические требования строже паспорта DTO. |

Алгоритм root upsert имеет две разные ветки:

1. `waybill_identifier` преобразуется в Integer, до lookup разрешаются danger products из входных товаров.
2. Если identifier не найден, service проверяет сочетание products/containers, создаёт станции/плательщика, сохраняет полный Waybill и затем все child rows в одной транзакции.
3. Если identifier найден, изменяется **только `Waybill.status`**. Номер, даты, станции, payer, остальные root поля и весь дочерний состав не сравниваются и не обновляются.
4. После успешного commit публикуется event; [`WaybillService.updateGroupedWaybills`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java) асинхронно refresh materialized `grouped_waybill`. Ошибка refresh логируется и не откатывает импорт.

SQL UNIQUE защищает identifier, но source использует `find-then-insert`, не database upsert/row lock. Два первых конкурентных пакета способны столкнуться на constraint. Повторы существующей накладной меняют status по last-write-wins; optimistic `@Version` нет. Status — произвольный String без enum/CHECK и без проверенной transition map.

## Связь с `receiving_order`: link, relink, unlink и bulk replace

[`Waybill.receivingOrder`](../entities/catalog/entities/waybill/Waybill.md) — nullable N:1: одна накладная может быть связана максимум с одной поставкой, одна поставка — с несколькими накладными. Integration import не задаёт эту связь. Ею управляют scoped endpoints поставки и compatibility [`ReceivingOrderEtranInvoiceController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingorderetraninvoice/ReceivingOrderEtranInvoiceController.java):

| Операция | Request | Изменение таблицы |
|---|---|---|
| Link | [`WaybillLinkRequestDto`](../dto/catalog/waybill/WaybillLinkRequestDto.md) | Загружает Waybill и ReceivingOrder по вложенным IDs, устанавливает `receiving_order_id`. DTO/controller не имеют Bean Validation. |
| Relink | path old Waybill ID + тот же DTO | При разных IDs сначала очищает FK старой накладной, затем присваивает новую указанной заявке. Path сравнивается не с DTO `id`, а с `etranInvoice.id`. |
| Unlink | path Waybill ID | Устанавливает `receiving_order_id=NULL`; Waybill и children не удаляются. |
| Bulk replace | [`WaybillSelectionDto`](../dto/catalog/waybill/WaybillSelectionDto.md) | `waybillIds @NotNull`: выбранным IDs массово присваивается заявка, у остальных ранее связанных с ней FK очищается; пустой список очищает все. |

[`WaybillRepository`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillRepository.java) выполняет bulk JPQL updates без row locks: неизвестные IDs молча пропускаются, а Waybill другой поставки перепривязывается. Link/bulk не проверяют статус/тип ReceivingOrder, статус Waybill или принадлежность клиенту в service; `ReceivingOrderService.reject` отдельно очищает все links отклонённой заявки. `POST /receivingorderetraninvoice/all` в source не имеет `@Secure`; runtime security/gateway не проверены.

Корень Waybill не реализует soft-delete и не содержит `deleted`. Пользовательского endpoint физического удаления корня в просмотренных controllers нет. Generic DAO test физического `remove` существует, а child FK initial SQL используют `ON DELETE CASCADE`; вызов DAO удаления из другого кода потенциально удалит агрегат, но это не опубликованная Waybill business operation.

## SQL source: текущий состав `waybill`

Initial [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql) создаёт table без `IF NOT EXISTS`. [`Waybill`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/Waybill.java) не задаёт `@Table/@Column` names, поэтому snake_case ниже подтверждён Liquibase, а не одной JPA naming convention.

| Группа Java-полей | SQL source contract | Семантика / writer |
|---|---|---|
| `id`, audit | `id UUID PRIMARY KEY`; `created_at TIMESTAMP NOT NULL DEFAULT UTC current timestamp`, `created_by VARCHAR(50) NOT NULL`, update audit nullable | UUID `@PrePersist`; auditing. DB default есть только у created_at. |
| `status`, `number`, `waybillIdentifier` | `status VARCHAR NOT NULL`, `number VARCHAR NOT NULL`, `waybill_identifier INTEGER NOT NULL UNIQUE` | Status/number из inbound; identifier — AS ЭТРАН business key. `number` **не UNIQUE**. |
| `type`, `shipmentType`, `shipmentSpeed`, `formType` | nullable unbounded `VARCHAR` | Inbound snapshot strings, без CHECK/enum. |
| Семь business dates | nullable `TIMESTAMP` | LocalDateTime интерпретируется как Moscow time и преобразуется к Instant; колонка без time zone. |
| `departureCountry/Route`, `destinationCountry/Route` | nullable `VARCHAR` | Snapshot входного сообщения. |
| `departureStation`, `destinationStation` | два UUID `NOT NULL REFERENCES railway_station(id)` | Lookup/create по ESR; в source нет `ON DELETE` и отдельных root indexes. |
| shipper/consignee name/address | nullable `VARCHAR` | Snapshot, не FK на Client. |
| shipper/consignee TGNL/OKPO | nullable `INTEGER` | Парсинг входных strings; диапазон ограничен Integer. |
| `payer` | `payer_id UUID NULL REFERENCES payer(id)` | [`KIS-3482`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3482_add_payer_table.sql) добавил FK; старые `payer VARCHAR`/`payer_code INTEGER` затем удалены. |
| payment/ownership/responsible | nullable `VARCHAR`; `planned_railway_carriages INTEGER NULL` | Snapshot/payment и план вагонов. |
| `receivingOrder` | `receiving_order_id UUID NULL REFERENCES receiving_order(id)` | [`KIS-3631`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_add_receiving_order_id_to_waybill.sql); link API/migration, не inbound create. |

В просмотренной source chain нет UNIQUE для `number`, UNIQUE/CHECK для связи с ReceivingOrder, status transition constraint или явных non-unique indexes по station/payer/receiving_order FK. PostgreSQL автоматически индексирует PK/UNIQUE identifier, но не создаёт индексы на referencing FK columns. Applied indexes/constraints нужно проверять через `pg_catalog`.

## История миграции старой receiving-модели

Порядок v1.34 cumulative:

1. Создаёт `payer`, добавляет nullable `waybill.payer_id`.
2. [`KIS-3481`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3481_migrate_payer_data.sql) создаёт default `Без плательщика`, переносит distinct payer_code и заполняет FK.
3. Удаляет старые Waybill `payer`/`payer_code` после drop materialized view.
4. Добавляет nullable `receiving_order_id`.
5. [`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) связывает active старые `receiving_order_etran_invoice` с Waybill по `etran_invoice.code = waybill.number`, переносит children с ограниченными наборами полей.
6. [`KIS-3631 drop`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_drop_receiving_order_etran_railway_tables.sql) делает `DROP TABLE ... CASCADE` старых receiving ETRAN/railway tables.

Поскольку `waybill.number` не уникален, number-based migration не доказывает однозначность соответствия. Update заполняет только Waybill с null receiving FK; конфликтующие старые связи, duplicate numbers и фактический результат требуют проверки данных до/после changeset. DO-блоки пропускают шаги, если legacy tables уже отсутствуют; это делает скрипт технически терпимым к другому состоянию, но не подтверждает полноту ранее перенесённых данных.

## Read model и источник полей

`GET /waybill/{id}` возвращает [`WaybillDetailedDto`](../dto/catalog/waybill/WaybillDetailedDto.md), а import — [`WaybillShortDto`](../dto/catalog/waybill/WaybillShortDto.md). Detailed DTO раскрывает root snapshot/stations/payer, но не receivingOrder и не children. Grouped tabs читают materialized view, archive — live table; сразу после import они могут временно различаться из-за async refresh. Link/unlink не публикуют refresh event, однако receivingOrder не входит в ключ materialized grouping.

`WaybillDaoService.findByNumber` возвращает `Optional<Waybill>`, хотя SQL разрешает duplicate number; при фактическом дубле single-result repository query способен завершиться non-unique-result error. Для импорта authoritative lookup — identifier, а number применяется в legacy data migration и некоторых compatibility usages; в ТЗ эти ключи нельзя считать взаимозаменяемыми.

```mermaid
flowchart TD
    P[POST /datareon/waybill] --> K[Parse integer waybill_identifier]
    K --> F{Identifier exists?}
    F -->|No| N[Create root plus all child rows in one transaction]
    F -->|Yes| S[Update only status]
    N --> W[(waybill)]
    S --> W
    W --> U[UNIQUE waybill_identifier]
    W --> C[Child FK with ON DELETE CASCADE]
    L[Link/relink/bulk API] --> R[Set nullable receiving_order_id]
    X[Unlink or ReceivingOrder reject] --> Z[Clear receiving_order_id]
    R --> W
    Z --> W
    W --> E[After-commit async grouped view refresh only after inbound]
```

[`WaybillDatareonServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonServiceIntegrationTest.java) source покрывает создание root+основных children, справочные типы/danger classification и повтор с обновлением только status. [`WaybillDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/waybill/WaybillDaoServiceTest.java) покрывает физический DAO CRUD, identifier/number lookup, filters и bulk receiving links. Не найдены прямые tests nested validation/null dates/lists, duplicate number lookup, concurrent same identifier, link status/client ownership, unknown bulk IDs/reassignment, legacy migration conflicts и async read consistency. Тесты **не запускались**.

Influencing commits: `feb37a42` (initial Waybill tables/import, 2026-02), `ce939d57`/`443ae69a` (payer/receiving link, migration and current v1.34 chain, 2026-03/04), `84598b3a` (inbound response, 2026-05), `4ff9dac6` (danger classification, 2026-07), `4e55d447` (source-provided carriage/container classifications, 2026-08). Commit history не доказывает применённость migration chain на среде.
