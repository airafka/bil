# `waybill_product`: груз накладной, физическая модель AS-IS (часть 12)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java controller/service/JPA, Datareon import/export, SQL/cumulative migrations и test sources. Это **source-level модель**, а не снимок применённой БД. Корень описан в [физической модели `waybill`](waybill-root-as-is.md), использование веса в КТК — в [физической модели `waybill_container`](waybill-container-as-is.md).

## Назначение и границы

[`WaybillProduct`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillproduct/WaybillProduct.java) — строка груза конкретной накладной. Она содержит snapshot наименования, упаковки, размеров, масс, количества мест и таможенных реквизитов, но обязательный ЕТСНГ и классификацию опасного продукта хранит ссылками на глобальные справочники.

| Объект | Business key / связь | Поведение в Waybill import |
|---|---|---|
| `waybill_product` | Собственного business key/UNIQUE нет | На первом импорте создаётся отдельная строка для каждого элемента входного списка; повтор Waybill children не обновляет. |
| [`EtsngCode`](../entities/catalog/entities/etsng/EtsngCode.md) | Глобальный `code VARCHAR(100) UNIQUE` | Find-or-create по коду; существующее имя не обновляется, для нового сохраняется входное имя. |
| [`DangerProduct`](../entities/catalog/entities/dangerproduct/DangerProduct.md) | `identifier INTEGER UNIQUE` | Только lookup seeded-классификатора; runtime create/update из Waybill не выполняется. |
| [`DangerClass`](../entities/catalog/entities/dangerclass/DangerClass.md) | `code_danger_class UNIQUE` | Получается через DangerProduct и используется для read/filter; не выводится из строк `signDanger`/`isDangerous`. |

`WaybillProduct.isDangerous` и `signDanger` — исходные строки ЭТРАН. Они не являются FK и не синхронизируются с `DangerProduct.dangerClass`, поэтому эти три представления опасности могут расходиться.

## SQL-контракт

Initial [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql) создаёт все snapshot-поля; KIS-4352 позднее добавляет nullable `danger_product_id` и индексы классификатора.

| Группа Java-полей | SQL source | Ограничения / смысл |
|---|---|---|
| `id`, audit | `UUID PRIMARY KEY`; `created_at TIMESTAMP NOT NULL DEFAULT ...`, `created_by VARCHAR(50) NOT NULL` | Entity наследует `BaseCreatable`: update audit/version/soft-delete отсутствуют. |
| `waybill` | `waybill_id UUID NOT NULL REFERENCES waybill ON DELETE CASCADE` | Явный неуникальный индекс по Waybill. |
| `etsngCode` | `etsng_code_id UUID NOT NULL REFERENCES etsng_code(id)` | Отдельного индекса в просмотренной chain нет. |
| `dangerProduct` | nullable `danger_product_id UUID REFERENCES danger_product(id)` | Поздний индекс есть; старые/migrated rows могут остаться null. Новый importer подставляет sentinel `-1` при пустом входе. |
| `gngCode` | nullable `INTEGER` | Входная строка парсится в Integer; non-numeric/overflow дают ошибку до insert. |
| text snapshot | nullable unbounded `VARCHAR`: `cargo_full_name`, `additional`, `packaging_type`, `marks_stamps_shipper`, `sign_danger`, `is_dangerous`, emergency/customs fields | Нет enum, длины, format/CHECK и связей со справочниками. |
| decimal snapshot | nullable `NUMERIC(16,3)`: `volume`, `weight`, `weight_loaded`, `net_weight`, `gross_weight`, `length`, `width`, `height` | Нет positivity, net≤gross, unit или formula CHECK. |
| counts | nullable `INTEGER`: `packages_count`, `places_count` | Нет проверки неотрицательности. |

Нет `UNIQUE` даже для `(waybill_id, etsng_code_id, cargo_full_name)`: одинаковые строки допустимы. SQL не выражает Datareon-правила «минимум один продукт» и зависимости количества продуктов от количества КТК.

## Datareon create и validation

[`WaybillDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java) до root lookup разрешает DangerProduct для всех входных products, затем только для новой Waybill валидирует состав и создаёт строки:

- products list должен быть non-null: service сразу вызывает `.size()`; пустой список запрещён;
- при двух и более products требуется ровно один container;
- при одном product и хотя бы одном вагоне с положительным `railway_weight_net` требуется минимум один container;
- один product без container допустим, если загруженный вагон по этому критерию не найден;
- поля продукта не имеют Bean Validation annotations; ЕТСНГ фактически обязателен из-за SQL и вызова lookup/create, но пустой/null код приводит к lookup/insert error вне единой declarative validation model.

Все массы товара (`weight`, `weightLoaded`, `cargoNetWeight`, `cargoGrossWeight`) сохраняются as-is; строки volume/length/width/height преобразуются в BigDecimal, GNG — в Integer. Service не пересчитывает одно поле из другого и не проверяет единицы.

### Опасный продукт

KIS-4352 создаёт seeded `danger_product` (9077 source identifiers плюс sentinel `-1`) и классы опасности. Пустой/blank вход разрешается как `identifier=-1`, неизвестный, нечисловой или выходящий за Integer identifier даёт `ValidationException`. Lookup дедуплицирован Map по исходному значению.

Разрешение происходит **до** проверки существования Waybill: пакет с уже известным `waybill_identifier`, который должен был бы изменить только root status, всё равно отклоняется при неизвестном danger identifier. Это подтверждено integration test.

## Legacy migration и другие writers

[`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) переносит active `receiving_order_container_item` в **каждую** Waybill связанной ReceivingOrder. Из всей item-строки сохраняются только `etsng_code_id` и `description → cargo_full_name`; price, gross/net weights, places и остальные поля теряются. `NOT EXISTS` по Waybill+ЕТСНГ+description снижает дубли только во время migration и не создаёт constraint.

До KIS-3631 migration `KIS-2906` снял NOT NULL с `receiving_order_container_item.etsng_code_id`, а target `waybill_product.etsng_code_id` остаётся NOT NULL. Migration не фильтрует null ЕТСНГ; наличие active legacy item без ЕТСНГ способно остановить changeset. Фактические данные не проверены.

Railway Excel parser не создаёт WaybillProduct: он продолжает создавать `ReceivingOrderContainerItem`. Runtime writers, изменяющие или удаляющие уже сохранённую WaybillProduct, не найдены; прямых create/update/delete HTTP endpoints нет.

## Read API и DTO

[`WaybillProductController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybillproduct/WaybillProductController.java) публикует page/meta/get с `Permission.WAYBILL`. Scoped receiving endpoint `POST /receivingorder/{id}/waybill-products/page` сначала проверяет доступность заявки через user restriction, затем возвращает группы по Waybill.

| DTO / read model | Что отдаёт | Что теряется или преобразуется |
|---|---|---|
| [`WaybillProductDto`](../dto/catalog/waybillproduct/WaybillProductDto.md) | ЕТСНГ, weight, volume, dimensions, additional | BigDecimal числовые поля представлены `Double`; не видны Waybill, gross/net/loaded, упаковка, counts, danger/customs. |
| [`WaybillProductDetailedDto`](../dto/catalog/waybillproduct/WaybillProductDetailedDto.md) | Добавляет class danger, GNG, cargo name, flags, customs, packaging/counts и три массы | `gngCode INTEGER` преобразуется в String; BigDecimal массы — в Double; identifier/name DangerProduct не отдаются. |
| [`WaybillProductViewDto`](../dto/catalog/waybill/WaybillProductViewDto.md) | ЕТСНГ code/name, weight/grossWeight, signDanger, class danger, cargo name | Сохраняет BigDecimal, но показывает только подмножество snapshot. |

Фильтры `dangerClass` и backward-compatible `isDangerous` оба сравнивают `DangerClass.codeDangerClass`; сохранённая строка `WaybillProduct.isDangerous` ими **не фильтруется**. Common search охватывает ЕТСНГ, cargo name, gross weight и class danger, но не остальные snapshot-поля.

`ReceivingOrderService` при каждом detailed read безусловно перестраивает `ReceivingOrderDetailedDto.totalWeight` как сумму nullable `WaybillProduct.weight`, начиная с нуля. Это override root stored total: для заявки без связанных WaybillProduct ответ получает `0`, а gross/net/loaded не используются. Вкладка КТК отдельно показывает сумму `WaybillProduct.netWeight` всей накладной как net каждого контейнера — см. [часть 11](waybill-container-as-is.md#read-api-dto-и-вычисляемые-поля).

## Outbound route chain package

[`ReceivingRailwayRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ReceivingRailwayRouteChainPackageExportService.java) преобразует product/cardinality не как прямое 1:1:

| Состав Waybill | Outbound-строки | Поле outbound `weight` |
|---|---|---|
| 0 products | Нет строк | — |
| 1 product, N containers | Один и тот же product дублируется N раз, с ID каждого WC | `WaybillContainer.netWeight`, а не `WaybillProduct.weight`. При N=0 product исчезает из payload. |
| 2+ products | Каждый product отправляется один раз и привязывается к **первому** WC | `WaybillProduct.weight`. При отсутствии WC вызов `containers.get(0)` падает. |

Остальные snapshot-поля копируются из WaybillProduct; `dangerProduct` и вычисленный danger class в outbound DTO не входят. Datareon create validation обеспечивает один WC для нового пакета с 2+ products, но legacy/manual/direct DB data эту предпосылку не гарантируют.

## Удаление и read counts

WaybillProduct не soft-deletable. Прямого delete route нет; удаление Waybill физически каскадирует products. Materialized `grouped_waybill.product_ids` агрегирует IDs всех строк, включая допустимые дубли; refresh асинхронно запускается только после inbound commit.

```mermaid
flowchart TD
    I[Datareon Waybill payload] --> D[Resolve DangerProduct before root lookup]
    D --> V{New Waybill?}
    V -->|No| S[Update only Waybill status; products unchanged]
    V -->|Yes| C[Validate product/container cardinality]
    C --> E[Find/create global ETSNG]
    E --> P[(waybill_product snapshot)]
    DP[(danger_product seeded lookup)] --> P
    P --> R[Grouped and detailed read DTO]
    P --> T[ReceivingOrder totalWeight = SUM product.weight]
    P --> O{Route package cardinality}
    O -->|1 product| A[Duplicate by containers; weight = WC netWeight]
    O -->|2+ products| B[Bind all to first WC; weight = product.weight]
    X[Delete Waybill] -->|ON DELETE CASCADE| P
```

## Проверки, пробелы и история

`WaybillDatareonServiceIntegrationTest` подтверждает создание product, 9078 seeded DangerProduct, known/blank/unknown mapping, один lookup, detailed eager fetch и отклонение unknown danger даже для existing Waybill. Не найдены прямые tests всех field mappings/precision, product-container cardinality branches outbound, null ЕТСНГ migration, duplicate products, ReceivingOrder weight override, HTTP page/meta/get и cascade. Тесты в этом подэтапе **не запускались**.

Основные повлиявшие commits: `feb37a42` (initial WaybillProduct schema/import, 2026-02-13), `ce939d57`/`443ae69a` (legacy migration и read model, 2026-03/04), `935edac2` (ЕТСНГ/net-weight read behavior, 2026-04), `4ff9eb7c` и последующие route-package commits (outbound route-level model, 2026-04/05), `4ff9dac6` (KIS-4352 DangerProduct, 2026-07), `cd8ab542` (scoped meta/filtering, 2026-08). История Git не доказывает applied schema или deployed outbound assumptions.
