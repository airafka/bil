# `shipping_order_container_qty`: плановое количество КТК, физическая модель AS-IS (часть 28)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations, accept-validator, route read/meta/export, route chain package и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Таблица описывает строки КТК без конкретных номеров; физические КТК разобраны в [части 20](shipping-order-container-as-is.md). Дочерний `shipping_order_etsng_code` здесь рассматривается только как граница агрегата и получит отдельный паспорт.

## Назначение и filling type

| `ShippingOrder.fillingType` | Источник КТК в route read/export | Запись через qty-service |
|---|---|---|
| `ALL` | Физические `shipping_order_container` | Запрещена. |
| `CONTAINER` | Физические `shipping_order_container` | Запрещена. |
| `RAILWAY_CARRIAGE` | `shipping_order_container_qty` | Разрешена; номера вагонов заданы, номера КТК — нет. |
| `NONE` | `shipping_order_container_qty` | Разрешена; номера вагонов и КТК не заданы. |
| `NONE_CONTAINER` | `shipping_order_container_qty` | Разрешена только специальная строка: ровно один порожний КТК без ЕТСНГ. Сам filling type допустим только для `CONTAINER + VEHICLE`. |

Найденной автоматической очистки qty-строк при смене `fillingType` корня нет. Поэтому stale плановые строки могут физически сосуществовать с номерными КТК, хотя обычный route read выбирает модель по текущему filling type.

## Endpoint → DTO → service

Контроллер [`ShippingOrderContainerQtyController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontainerqty/ShippingOrderContainerQtyController.java) публикует scoped API. Основной transport DTO — [`ShippingOrderContainerQtyDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyDto.md), внутренние DTO — [`CreationDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyCreationDto.md) и [`UpdateDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyUpdateDto.md).

| Endpoint | DTO / результат | Реализованная логика и ограничения |
|---|---|---|
| `POST /shipping-order/{shippingOrderId}/shipping-order-container-qty/list` | optional filter → `Dto[]` | READ. Path-заявка подставляется в фильтр; service отдельно проверяет доступный пользователю корень. Возвращает вложенные `items[]` ЕТСНГ. |
| `POST .../meta/{fieldName}` | required paged filter → meta values | READ. Кроме полей родителя вручную поддерживает nested `etsngCode` и `weight`. Отдельная проверка существования корня не выполняется. |
| `PUT .../merge` | `Dto[]` → `Dto[]` | DELETE permission, хотя full-replace создаёт, обновляет и физически удаляет parent/items. Разрешён для `RAILWAY_CARRIAGE`, `NONE`, `NONE_CONTAINER`. |

Полный декларативный контракт доступен в [generated endpoint-каталоге](../api/endpoints-generated.md#shippingordercontainerqtycontroller).

Отдельных публичных CRUD endpoints нет. В merge `id=null` означает create, существующий scoped ID — update, отсутствие текущего ID во входе — physical delete. ID строки другой заявки отклоняется общей реализацией `upsertAndDelete`.

## DTO и физические ограничения

| Поле | Bean Validation внешнего `Dto` | SQL | Фактическая семантика |
|---|---|---|---|
| `id` | nullable | UUID PK | `null` для новой строки. |
| `quantity` | `@NotNull`, `@Min(0)` | `INT NOT NULL CHECK (quantity > 0)` | Значение `0` проходит Bean Validation, но нарушает DB CHECK. |
| `type` | `@NotNull` | `VARCHAR(20) NOT NULL` | `ContainerType`: шесть enum-значений; хранится имя enum, не русское `tosType`. |
| `empty` | `@NotNull` | `BOOLEAN NOT NULL DEFAULT false` | `true` — порожний КТК. Явное значение обязательно в API, DB default обычно не используется mapper'ом как бизнес-default. |
| `items` | `@NotNull`, default empty list | отдельная дочерняя таблица | Полная желаемая коллекция ЕТСНГ/веса для строки. |

На `items` отсутствует `@Valid`. Поэтому `@Valid` верхнего DTO не запускает Bean Validation вложенных [`ShippingOrderEtsngCodeDto`](../dto/catalog/shippingorderetsngcode/ShippingOrderEtsngCodeDto.md): их `etsngCode @NotNull`, `weight @NotNull @Min(0)` не гарантированы на HTTP-границе. Null/некорректный item может привести к service/JPA/DB-ошибке вместо аккуратного `400`. Кроме того, вложенный DTO допускает вес `0`, тогда как SQL дочерней таблицы требует `weight > 0`.

## SQL contract

Таблица создана миграцией [`KIS-3352`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql).

| Колонка | Текущий source contract | Смысл |
|---|---|---|
| `id` | `UUID PRIMARY KEY` | ID плановой строки. |
| `shipping_order_id` | `UUID NOT NULL`, FK → `shipping_order(id)` | Родительская заявка; `ON DELETE` не задан. |
| `quantity` | `INT NOT NULL CHECK (quantity > 0)` | Количество одинаково описанных КТК. |
| `type` | `VARCHAR(20) NOT NULL` | Строковое имя `ContainerType`; отдельного DB CHECK по enum нет. |
| `empty` | `BOOLEAN NOT NULL DEFAULT false` | Признак порожнего КТК. |

Сущность наследует только `BaseIdentifier`: `deleted` и audit-полей нет. Parent и дочерние ЕТСНГ удаляются физически application-кодом.

Миграция [`KIS-3663`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260414_KIS-3663_add_unique_constraint_for_shipping_order_container_qty.sql) создаёт partial unique index `(shipping_order_id, type) WHERE empty=true`. Следовательно, для одной заявки допустим только один порожний row каждого типа независимо от `quantity`; для гружёных строк DB-уникальности parent-уровня нет.

Composite partial index помогает запросам по заявке только для `empty=true`. Отдельных обычных индексов `shipping_order_id` и `type` в просмотренных миграциях не найдено. Дочерний FK `shipping_order_etsng_code.shipping_order_container_qty_id` также не имеет `ON DELETE CASCADE`.

## Уникальность строк КТК и ЕТСНГ

После полного merge [`ShippingOrderContainerQtyService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyService.java) строит для каждой строки signature:

`(type, empty, sorted[etsngCode.id + normalized weight])`.

- две гружёные строки с полностью одинаковым непустым набором ЕТСНГ/весов запрещены, даже если их `quantity` различается;
- частично пересекающиеся наборы разрешены;
- строки без items намеренно пропускаются: одинаковые гружёные строки без ЕТСНГ application-check не блокирует;
- порожние строки одного типа блокирует partial DB unique index;
- внутри одного parent SQL UNIQUE дочерней таблицы запрещает точный дубль `(parent, etsngCode, weight)`.

Parent signature защищён только прикладной проверкой после записи. Без DB constraint два конкурентных запроса теоретически способны сохранить одинаковые гружёные signatures.

## Порожний КТК и `NONE_CONTAINER`

Для любой строки с `empty=true` [`ShippingOrderEtsngCodeService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderetsngcode/ShippingOrderEtsngCodeService.java) запрещает add/update дочернего груза ошибкой `ShippingOrderContainerQty.ContainerIsEmpty`. Удаление ранее существующего item разрешено.

Для `fillingType=NONE_CONTAINER` parent-service дополнительно требует:

- ровно одну qty-строку во всём merge;
- `quantity == 1`;
- `empty == true`;
- пустой `items`.

То же условие повторяет accept-validator. Прямых integration tests именно этой ветки container qty не найдено.

## Merge, каскад и транзакция

`merge` помечен `@Transactional`, поэтому full-replace parent rows, вложенные merge ЕТСНГ, проверка duplicate signatures и пересчёт корня входят в одну транзакцию. Ошибка поздней строки или финальной проверки должна откатить весь вызов; это отличается от неатомарного wagon qty merge из [части 27](shipping-order-railway-carriage-qty-as-is.md).

При удалении parent `preRemove` сначала физически удаляет все дочерние ЕТСНГ через application service, затем BaseService удаляет parent. Это не DB cascade. При create/update parent сначала сохраняется, затем дочерняя коллекция полностью синхронизируется по ID.

Merge загружает корень прямым `shippingOrderDaoService.getById`; явного `findAvailableShippingOrder`/client-restricted write lookup нет. Controller требует только container DELETE permission. List, напротив, проверяет корень через user restriction. Runtime-достаточность write permission/client scope не подтверждена.

```mermaid
flowchart TD
    M[PUT merge: полный список qty КТК] --> F{fillingType разрешён?}
    F -->|нет| X[Ошибка]
    F -->|NONE_CONTAINER| N{Одна строка: qty=1, empty=true, items=[]?}
    N -->|нет| X
    F -->|RAILWAY_CARRIAGE / NONE| U[Full-replace parent rows]
    N -->|да| U
    U --> I[Full-replace items ЕТСНГ каждого parent]
    I --> D{Нет дублей parent signature и DB conflicts?}
    D -->|нет| R[Rollback всей транзакции]
    D -->|да| T[SUM quantity → shipping_order.total_container_quantity]
    T --> O[Вернуть scoped list]
```

## Stored total и конкурирующие writers

После add/update/remove parent service выполняет `SUM(shipping_order_container_qty.quantity)` и записывает результат в `shipping_order.total_container_quantity`. Сервис физических КТК записывает в то же поле `count(shipping_order_container)`.

Оба writer'а не выбирают формулу по текущему filling type. Поэтому при сосуществовании stale physical/qty rows значение корня определяется последней выполненной операцией, а не гарантированно активной моделью заявки. [`RouteExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/route/RouteExportService.java), напротив, вычисляет live route total по filling type: count физических строк для `ALL/CONTAINER`, сумму qty для `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER`.

## Accept и отсутствие общей обязательности

Для железнодорожной заявки accept-validator выбирает container qty косвенно: `containerChecks` проверяет только существующие физические КТК и не требует хотя бы одной qty-строки. Поэтому при `RAILWAY_CARRIAGE/NONE` наличие container qty **не является отдельным accept-требованием** в текущем коде.

Для `NONE_CONTAINER` ветка vehicle-validator требует специальную единственную qty-строку. Для других vehicle filling types `missingContainerChecks` требует физические КТК, а не qty. Таким образом, allowed types service и accept-обязательность не эквивалентны.

## Read, filter и meta

List загружает parents одним запросом, затем все дочерние ЕТСНГ по множеству parent IDs и группирует их в `items`. Фильтр поддерживает `quantity`, `type`, `empty`, nested `etsngCode`, `weight` и общий search. Nested фильтры реализованы коррелированным `EXISTS`, то есть условия кода и веса должны выполняться на одной дочерней строке.

Сортировка `etsngCode`/`weight` использует минимальное значение для ASC и максимальное для DESC у каждого parent; строки без items идут первыми при ASC и последними при DESC. Nested meta использует LEFT JOIN и возвращает также группу `code=null` для parents без items, связывая значение с массивом parent IDs.

Route meta основан на [`shipping_route_container_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_containers.sql). Qty-ветка создаёт одну строку view на каждый item и одну null-item строку для parent без груза. При нескольких items один `soc_qty.id` повторяется в нескольких строках, хотя JPA entity объявляет его `@Id`; текущий consumer использует meta projection, но view не является безопасной уникальной entity-проекцией общего назначения.

## Route read и outbound

`POST /route/{routeId}/shipping-order/container` выбирает qty для `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER`, возвращая `container.code=null`, `quantity`, `type`, `empty` и вложенные ЕТСНГ/вес. Для `ALL/CONTAINER` читаются физические КТК.

[`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) без фильтра filling type экспортирует все qty parents и все их ЕТСНГ, а в корне заявки — сохранённый `totalContainerQuantity`. Поэтому stale qty после перехода к номерной модели всё равно может попасть в package, а stored total может быть рассчитан конкурирующим physical writer'ом.

## Тесты и пробелы покрытия

[`ShippingOrderContainerQtyServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyServiceIntegrationTest.java) проверяет успешный parent full-replace и root total, nested item create/update/delete, допустимое частичное пересечение signatures, DB-дубль item, application-дубль строки и partial unique для двух порожних строк. [`RouteExportServiceTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/datareon/service/route/RouteExportServiceTest.java) проверяет выбор count/sum по filling type для `ALL/CONTAINER` и `RAILWAY_CARRIAGE/NONE`. В этом подэтапе тесты не запускались.

Не найдены прямые tests для zero quantity/weight, отсутствующего `@Valid` на items, `NONE_CONTAINER` parent validation, rollback поздней ошибки, client write scope, concurrent duplicate signatures, stale rows после смены filling type, route meta repeated ID и route chain package qty/items/stored total.

## Влияющие commits

- `d29256da` (`KIS-3352`) — физические qty/ETSNG-таблицы и filling type.
- `eeac19c4` (`KIS-3357`) — базовая container qty service/JPA-модель.
- `b33f9401` (`KIS-3360`) — scoped API и full-replace безномерных заявок.
- `19315731` (`KIS-3366`) — обработка интеграционного package и вложенных данных.
- `9ca9eb80`, `4b61d802`, `2f962915` (`KIS-3663`) — DB/item uniqueness, partial unique порожних строк и актуальная signature-validation.
- `3a283b5a` (`KIS-4271`) — специальный `NONE_CONTAINER`.
- `cd8ab542` — scoped nested meta.
- `49ce562d`/`6557b9e8` (`KIS-4450`) — route meta-view/endpoints и исправление.
- `4ff9eb7c`/`0b2c6b91` (`KIS-3809`) — route chain package с qty и ЕТСНГ.

## Чек-лист для проверки ТЗ

- Для какого filling type qty обязателен, а не только разрешён?
- Означает ли `[]` полное физическое удаление parents и всех ЕТСНГ?
- Должны ли `quantity` и `weight` быть строго `> 0` также на DTO-уровне?
- Нужен ли `@Valid` для каждого `items[]` и предметные ошибки вместо DB/NPE?
- Считается ли quantity частью уникальности гружёной строки?
- Разрешены ли одинаковые гружёные строки без ЕТСНГ?
- Нужно ли блокировать concurrent duplicate signatures физическим ключом/нормализованной моделью?
- Как очищаются stale qty при смене filling type и какой writer владеет `total_container_quantity`?
- Должен ли route chain package фильтровать parents/items по текущей модели заявки?
- Достаточно ли DELETE permission для полного create/update/delete и где проверяется client write scope?

## Связанные документы

- [Корень заявки на вывоз](shipping-order-root-as-is.md)
- [Физический КТК заявки](shipping-order-container-as-is.md)
- [Плановое количество вагонов](shipping-order-railway-carriage-qty-as-is.md)
- [Route: план/факт и meta](../business-rules/route-shipping-plan-fact-as-is.md)
- [Сводная integrity-карта ShippingOrder](shipping-order-integrity-map.md)
