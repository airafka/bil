# Модель БД заявок

Постраничные паспорта всех перечисленных ниже классов доступны в [полном каталоге JPA-модели](../entities/catalog/README.md). Там раскрыты все поля, включая наследуемые, имена колонок и cardinality связей. Семантика данных определяется [типами заявок](../business-rules/order-types.md), [правилами поставки](../business-rules/receiving-orders.md), [вывоза](../business-rules/shipping-orders.md) и [услуги](../business-rules/service-orders.md).

Трассировка корневых полей поставки до SQL-типа, nullable/FK, миграции и источника агрегатов вынесена в [физическую модель `receiving_order`](receiving-order-root-as-is.md); она не объявляет исходную cumulative-цепочку состоянием применённой БД.

Связанный транспорт с общим ключом и его отдельные SQL-колонки описаны в [физической модели `receiving_order_transport`](receiving-order-transport-as-is.md); одноимённые `shipper`/`waybill` в корне и транспорте нельзя считать одним полем.

Прямые поля товарной строки, история `good_variant_id` и пересчёт SKU/цены заявки описаны в [физической модели `receiving_order_good`](receiving-order-good-as-is.md).

Колонки грузового места, nullable-переходы количества/размеров и счётчики корня описаны в [физической модели `receiving_order_cargo`](receiving-order-cargo-as-is.md).

Таблица КТК поставки, условная обязательность DTO, SQL array ЗПУ и различие источников веса описаны в [физической модели `receiving_order_container`](receiving-order-container-as-is.md); содержимое КТК остаётся отдельной таблицей.

Строка содержимого КТК, её два независимых FK на корень и parent и конкурирующие расчёты цены/веса описаны в [физической модели `receiving_order_container_item`](receiving-order-container-item-as-is.md).

Услуга поставки, её обязательные request ID, SQL-колонки, расчёт планового количества/цены и отличие direct/required/auto-reprice paths описаны в [физической модели `receiving_order_requested_service`](receiving-order-requested-service-as-is.md).

Грузовое место без товарной детализации, ссылка на глобальный Cargo, direct/Excel/copy write paths и возможное расхождение active rows с корневым счётчиком описаны в [физической модели `receiving_order_blackbox`](receiving-order-blackbox-as-is.md).

Корень накладной ЭТРАН, уникальный identifier, snapshot-поля, nullable FK на поставку и перенос старых receiving ETRAN/railway таблиц описаны в [физической модели `waybill`](waybill-root-as-is.md).

Участие физического вагона в накладной, snapshot-поля, отсутствие unique пары/soft-delete, lifecycle task status и каскады удаления описаны в [физической модели `waybill_railway_carriage`](waybill-railway-carriage-as-is.md).

Участие физического КТК в вагоне накладной, ЗПУ, различие глобального Container/snapshot/операционного владельца и TOS lifecycle описаны в [физической модели `waybill_container`](waybill-container-as-is.md).

Строка груза накладной, ЕТСНГ/опасный классификатор, snapshot масс/размеров/таможни и outbound cardinality описаны в [физической модели `waybill_product`](waybill-product-as-is.md).

Специальные и тарифные отметки накладной, их nullable-поля, преобразование тарифного кода, import/replay и read API описаны в [физической модели отметок Waybill](waybill-marks-as-is.md).

Материализованная группировка накладных по маршруту и плательщику, её агрегаты, refresh lifecycle и eventual consistency описаны в [read-модели `grouped_waybill`](grouped-waybill-as-is.md).

Единая карта всех физических связей поставки и Waybill, каскадов, soft-delete, уникальности и конкурирующих writers собрана в [сводной модели ReceivingOrder ↔ Waybill](receiving-order-waybill-integrity-map.md).

Корневая таблица вывоза, её DTO/service write semantics, nullable/обязательные поля, filling-type CHECK, status writers и сохранённые агрегаты описаны в [физической модели `shipping_order`](shipping-order-root-as-is.md). Дочерние таблицы вывоза остаются отдельными объектами и не являются колонками корня.

Единая карта корня и всех 12 дочерних таблиц вывоза собрана в [сводной модели ShippingOrder](shipping-order-integrity-map.md). Для анализа ТЗ это основной переход к plan/fact-развилкам по `fillingType`, ETRAN membership, FK/UNIQUE/delete, каскадам, владельцам записи, конкурирующим totals и route/outbound-границам; точные поля и методы остаются в 13 детальных паспортах.

## Наследуемые колонки

Каждая конкретная таблица заявки содержит поля mapped-superclass: `id UUID` (PK, генерируется до insert), `created_at`, `created_by`, `updated_at`, `updated_by`; от `Order` — `number`, `client_id`; транспортные заявки также содержат `order_status`, `terminal_area_catalog_id`, `transport_type`.

`Order` и `TransportOrder` собственных таблиц не имеют.

## Основные таблицы и связи

| Таблица / JPA-сущность | Родительская связь | Назначение |
|---|---|---|
| `receiving_order` / `ReceivingOrder` | `client`, `contract`, `currency`, `route`, `shipper`, `payer`, станции | Корень поставки |
| `receiving_order_good` | `receiving_order_id` | Строка товара/партии |
| `receiving_order_cargo` | заявка и товар | Грузовое место и количества |
| `receiving_order_container` | `receiving_order_id` | Контейнер поставки |
| `receiving_order_container_item` | контейнер | Содержимое контейнера |
| `receiving_order_requested_service` | `receiving_order_id` | Дополнительная операция |
| `receiving_order_transport` | PK/FK на заявку | Транспортные реквизиты, связь one-to-one |
| `waybill` | `receiving_order_id` | Накладные поставки; дочерние вагоны/КТК/товары идут через накладную |
| `waybill_railway_carriage` | `waybill_id`, `railway_carriage_id` | Участие глобального вагона в накладной, snapshot и task status |
| `waybill_container`, `waybill_zpu` | `waybill_railway_carriage_id`, `container_id`; дочерний FK ЗПУ | Участие глобального КТК в вагоне, snapshot веса/owner/status и пломбы |
| `waybill_product` | `waybill_id`, `etsng_code_id`, nullable `danger_product_id` | Груз накладной: snapshot характеристик и ссылки на классификаторы |
| `waybill_special_mark`, `waybill_tariff_mark` | `waybill_id` | Независимые snapshot-отметки накладной без business key/unique |
| `grouped_waybill` materialized view | станции + payer; UUID arrays базовых строк | Eventually consistent read-модель групп, counts и dropdowns |
| `shipping_order` / `ShippingOrder` | `client`, `contract`, `currency`, `route`, `consignee` | Корень вывоза |
| `shipping_order_good`, `shipping_order_cargo` | `shipping_order_id` | Товар и грузовые места |
| `shipping_order_container`, `shipping_order_container_item` | заявка / контейнер | КТК и состав |
| [`shipping_order_railway_carriage`](shipping-order-railway-carriage-as-is.md) | `shipping_order_id`; nullable `etran_invoice_id`; global `railway_carriage_id` | Вагоны вывоза, task status и parent для КТК |
| [`shipping_order_etran_invoice`](shipping-order-etran-invoice-as-is.md) | `shipping_order_id`, global `etran_invoice_id` | Membership накладной в заявке; full-replace и application-cascade на вагоны |
| [`shipping_order_railway_carriage_qty`](shipping-order-railway-carriage-qty-as-is.md) | `shipping_order_id`, nullable `type_id` | Плановое количество вагонов для `CONTAINER/NONE` |
| [`shipping_order_container_qty`](shipping-order-container-qty-as-is.md) | `shipping_order_id`; parent для `shipping_order_etsng_code` | Плановое количество КТК для безномерной модели |
| `shipping_order_requested_service` | `shipping_order_id` | Дополнительная операция |
| `shipping_order_transport` | связь one-to-one с заявкой | Транспортные реквизиты |
| [`shipping_order_etsng_code`](shipping-order-etsng-code-as-is.md) | `shipping_order_container_qty_id`, global `etsng_code_id` | Код и масса груза плановой строки КТК |
| `service_order` / `ServiceOrder` | `client_id` | Корень заявки на услугу |
| `service_order_container` | `service_order_id`, `container_id` | Контейнеры услуги |

## Владение и удаление

Большинство дочерних строк транспортных заявок имеют `deleted` и используют мягкое удаление. Нельзя автоматически трактовать отсутствие строки в обычной выборке как физическое удаление. Для DTO и отчётов агрегаты (`totalWeight`, `totalCargoQuantity` и т. п.) могут храниться в корне или вычисляться/переопределяться при построении detailed DTO.

## Источники истины

- JPA-связи и mutability: `db-layer/src/main/java/ru/korusconsulting/alis/model`.
- Физическая схема и история изменений: `db-layer/src/main/resources/db/changelog`.
- Представления: `db-layer/src/main/resources/db/changelog/rerunnable`.

Имена без явного `@Table` в этом документе приведены по фактическому соглашению миграций. При проектировании изменения обязательно проверять актуальную cumulative-цепочку Liquibase, ограничения, индексы и rerunnable views.

## Изменения БД из pull 9 сентября 2026

### Удаление центрального склада

Коммит `22355528e744ffcf1f270453d9a71a5ba297af40` переносит ссылки с площадки «Центральный склад Алабуга» (`fb6bdf47-44e1-4b4b-9fa6-deae0b7774c9`) на «Складской комплекс» (`8c2e7a54-9a1f-41d0-82c4-3c44b3e8e6f2`) в `good_movement`, `good_remain`, `receiving_order`, `route`, `service`, `shipping_order`, `term_of_service`, затем удаляет старую площадку.

Следствие для аналитики: старый UUID площадки больше нельзя использовать в новых требованиях, фильтрах и интеграционных примерах. Исторические ссылки после применения миграции указывают на «Складской комплекс».

### Представление контейнеров маршрута вывоза

Коммит `6557b9e88da7c933ea9a5c892884a8ef9e09f559` заменяет `INNER JOIN` на `LEFT JOIN` к `shipping_order_etsng_code` и `etsng_code` в `view_shipping_route_containers`. Строка `ShippingOrderContainerQty` теперь остаётся в представлении при отсутствии ЕТСНГ; `etsng_code` и `gross_weight` для неё могут быть `null`.

### Настройки пользователей

Коммит `15f90451aba50ee8b552ebed1da2f1b11408bd55` выполняет `DELETE FROM user_setting`, затем вставляет 100 default-настроек для пользователя `49d19fdf-d3ed-4d48-9450-e4b8517a5150`. Это означает полный сброс существующих персональных настроек при применении миграции, а не точечное обновление defaults.

Полный список изменений pull: [журнал сверки](../traceability/repository-change-log.md#pull-от-9-сентября-2026-года).
