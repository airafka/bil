# ShippingOrder: сводная физическая карта AS-IS (части 16–29)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561` и детальные физические модели частей 16–29. Это **source-level карта для проверки ТЗ**, а не снимок применённой БД и не замена паспортам таблиц: здесь сведены FK, уникальность, soft/physical delete, plan/fact-развилки, write ownership, totals и route/outbound-границы — по аналогии с [`ReceivingOrder ↔ Waybill`](receiving-order-waybill-integrity-map.md).

## Охват

Карта покрывает корень и все 12 дочерних таблиц shipping-контура, для которых подготовлены отдельные паспорта:

| Часть | Physical object | Детальная модель |
|---|---|---|
| 16 | `shipping_order` | [корень вывоза](shipping-order-root-as-is.md) |
| 17 | `shipping_order_transport` | [транспорт, shared PK](shipping-order-transport-as-is.md) |
| 18 | `shipping_order_good` | [товарная строка](shipping-order-good-as-is.md) |
| 19 | `shipping_order_cargo` | [грузовое место](shipping-order-cargo-as-is.md) |
| 20 | `shipping_order_container` | [физический КТК](shipping-order-container-as-is.md) |
| 21 | `shipping_order_container_item` | [содержимое физического КТК](shipping-order-container-item-as-is.md) |
| 22 | `shipping_order_requested_service` | [дополнительная услуга](shipping-order-requested-service-as-is.md) |
| 23 | `shipping_order_blackbox` | [груз без товарной детализации](shipping-order-blackbox-as-is.md) |
| 25 | `shipping_order_railway_carriage` | [физический вагон](shipping-order-railway-carriage-as-is.md) |
| 26 | `shipping_order_etran_invoice` | [membership глобальной ЭТРАН](shipping-order-etran-invoice-as-is.md) |
| 27 | `shipping_order_railway_carriage_qty` | [плановое количество вагонов](shipping-order-railway-carriage-qty-as-is.md) |
| 28 | `shipping_order_container_qty` | [плановое количество КТК](shipping-order-container-qty-as-is.md) |
| 29 | `shipping_order_etsng_code` | [груз планового КТК](shipping-order-etsng-code-as-is.md) |

Номер 24 принадлежал первоначальной восьмиузловой версии этой карты. Подэтап 4.30 расширил её ЖД-частями 25–29; отдельный новый файл не создавался.

## ER-карта физического владения

```mermaid
erDiagram
    SHIPPING_ORDER ||--o| SHIPPING_ORDER_TRANSPORT : "shared PK/FK"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_GOOD : "shipping_order_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_CARGO : "shipping_order_id"
    SHIPPING_ORDER_GOOD ||--o{ SHIPPING_ORDER_CARGO : "shipping_order_good_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_CONTAINER : "shipping_order_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_CONTAINER_ITEM : "shipping_order_id"
    SHIPPING_ORDER_CONTAINER ||--o{ SHIPPING_ORDER_CONTAINER_ITEM : "shipping_order_container_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_REQUESTED_SERVICE : "shipping_order_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_BLACKBOX : "shipping_order_id"

    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_ETRAN_INVOICE : "shipping_order_id"
    ETRAN_INVOICE ||--o{ SHIPPING_ORDER_ETRAN_INVOICE : "global etran_invoice_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_RAILWAY_CARRIAGE : "shipping_order_id"
    RAILWAY_CARRIAGE ||--o{ SHIPPING_ORDER_RAILWAY_CARRIAGE : "global railway_carriage_id"
    ETRAN_INVOICE o|--o{ SHIPPING_ORDER_RAILWAY_CARRIAGE : "nullable direct global FK"
    SHIPPING_ORDER_RAILWAY_CARRIAGE o|--o{ SHIPPING_ORDER_CONTAINER : "nullable wagon parent"

    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_RAILWAY_CARRIAGE_QTY : "plan wagon qty"
    RAILWAY_CARRIAGE_TYPE o|--o{ SHIPPING_ORDER_RAILWAY_CARRIAGE_QTY : "nullable type_id"
    SHIPPING_ORDER ||--o{ SHIPPING_ORDER_CONTAINER_QTY : "plan container qty"
    SHIPPING_ORDER_CONTAINER_QTY ||--o{ SHIPPING_ORDER_ETSNG_CODE : "physical child"
    ETSNG_CODE ||--o{ SHIPPING_ORDER_ETSNG_CODE : "global etsng_code_id"

    SHIPPING_ORDER_BLACKBOX }o--|| CARGO : "global cargo_id"
```

На схеме нет связи `shipping_order_etran_invoice → shipping_order_railway_carriage`, потому что её действительно нет: wagon row ссылается прямо на глобальную `etran_invoice`. Membership заявки обеспечивается только сервисами/merge и может расходиться с физическими wagon rows.

`shipping_order_cargo` и `shipping_order_container_item` имеют одновременно root FK и промежуточный parent FK. SQL проверяет существование каждого ID по отдельности, но не равенство их `shipping_order_id`. Аналогично `shipping_order_container.shipping_order_id` физически не обязан совпадать с заявкой выбранного wagon-row.

## Plan/fact-развилка по `fillingType`

| `fillingType` | Вагоны | КТК | ЭТРАН membership | Что читает route API |
|---|---|---|---|---|
| `ALL` | Физические wagon rows; у каждого нужна глобальная ЭТРАН | Физические container/item rows | При accept требуется хотя бы одна строка | Физические вагоны и КТК |
| `RAILWAY_CARRIAGE` | Физические wagon rows; ЭТРАН nullable | `container_qty` + nullable `etsng_code[]` | Не требуется accept-validator'ом | Физические вагоны, плановые КТК |
| `CONTAINER` | `railway_carriage_qty` | Физические container/item rows | Не требуется | Плановые вагоны, физические КТК |
| `NONE` | `railway_carriage_qty` | `container_qty` + nullable `etsng_code[]` | Не требуется | Обе плановые qty-модели |
| `NONE_CONTAINER` | Не применяется; тип разрешён только для `CONTAINER + VEHICLE` | Ровно одна строка `qty=1`, `empty=true`, без ЕТСНГ | Не применяется | Специальная плановая строка КТК |

Эта взаимоисключаемость **не закреплена DB constraints**. Смена `fillingType` не сопровождается найденной очисткой прежней модели, поэтому plan и fact rows могут сосуществовать. Route read выбирает одну ветку по текущему типу, а route chain package собирает все rows обеих моделей без такого фильтра.

## Матрица ключей и ограничений

| Physical object | Parent/reference key | Доказанная business uniqueness | Delete semantics |
|---|---|---|---|
| `shipping_order` | client/contract/terminal area/route/consignee и другие FK | Только PK; `number` заполняет sequence generator, SQL UNIQUE не найден | DELETE endpoint не найден |
| `shipping_order_transport` | `id` одновременно PK и FK → root | PK даёт не более одной строки на заявку | Physical-модель без `deleted`; `ON DELETE` не задан |
| `shipping_order_good` | root, ClientGood, nullable Batch | Не найдена | Soft-delete; FK без cascade |
| `shipping_order_cargo` | root + Good + nullable GoodPackage/Barcode/Cargo | Не найдена; root/Good consistency не защищена | Soft-delete; FK без cascade |
| `shipping_order_container` | root + nullable global Container + nullable wagon-row | `UNIQUE(shipping_order_id, container_id)` без учёта `deleted` | Soft-delete; FK без cascade |
| `shipping_order_container_item` | root + parent Container + nullable ETSNG | Не найдена; root/parent consistency не защищена | Soft-delete; FK без cascade |
| `shipping_order_requested_service` | root + TermOfRequestedService | Не найдена | Soft-delete; FK без cascade |
| `shipping_order_blackbox` | root + global Cargo | Не найдена | Soft-delete; FK без cascade |
| `shipping_order_etran_invoice` | root + global EtranInvoice | Не найдена | Soft-delete; application-cascade на wagon/container/item |
| `shipping_order_railway_carriage` | root + global RailwayCarriage + nullable global EtranInvoice | Не найдена | Soft-delete; application-cascade на container/item |
| `shipping_order_railway_carriage_qty` | root + nullable RailwayCarriageType | `UNIQUE NULLS NOT DISTINCT(shipping_order_id, type_id)`; старый обычный UNIQUE также остаётся | Physical delete; audit/deleted отсутствуют |
| `shipping_order_container_qty` | root + enum type + empty | Partial unique `(shipping_order_id,type) WHERE empty=true`; loaded signature только в приложении | Physical delete; application-delete детей ЕТСНГ |
| `shipping_order_etsng_code` | parent qty + global EtsngCode + weight | `UNIQUE(parent, etsng_code_id, weight)` | Physical delete; FK cascade отсутствует |

Таким образом, в 13-табличном контуре есть четыре физические business-защиты: container pair, wagon qty order/type, empty container qty order/type и exact ETSNG child. Они имеют разную семантику soft/physical delete и не образуют единой модели целостности.

## Cross-table integrity gaps

- Wagon `etran_invoice_id` доказывает только направление глобальной накладной (`isForReceivingOrder=false`), но не наличие membership этой накладной в той же заявке.
- Container может ссылаться на wagon-row другой заявки: composite parent constraint и service-level equality check не найдены.
- Cargo и ContainerItem могут сочетать root одной заявки с intermediate parent другой заявки.
- Container soft-delete не освобождает физический UNIQUE-слот `(shipping_order_id, container_id)`; повторное добавление той же пары может упасть на БД.
- ETRAN membership и wagon rows не имеют DB business UNIQUE; update application-check обоих сервисов допускает конфликт с ровно одной другой строкой.
- Plan/fact rows не взаимоисключаются по filling type; stale qty/ETSNG могут оставаться после перехода к номерной модели и наоборот.
- Parent container qty loaded-signature `(type,empty,full ETSNG+weight set)` не защищена DB constraint и уязвима к concurrency; строки без items из проверки исключаются.
- DTO для qty/weight используют `@Min(0)`, а SQL CHECK требует строго `> 0`; nested ETSNG items не имеют `@Valid` на parent-поле.

## Владельцы записи и write paths

| Объект/поля | Основные writers AS-IS | Особенности |
|---|---|---|
| Root business fields/status | `ShippingOrderService`, review/accept, inbound actions | `client`/`contract`/`terminalArea` immutable после create; production HTTP-вызов `accept(UUID)` в source не найден |
| Root/transport `consignee` и address | Root service и Transport service независимо | Root-версия валидирует роль/owner и используется отчётами/outbound; transport-версия — сырой дублирующий ввод без найденных внешних consumers |
| Good/Cargo/Blackbox | Direct, bulk, Excel и auto-create paths | Разная атомарность; shipping Excel требует существующий Cargo, direct API может создать |
| Container/ContainerItem | Direct/list, full-order merge, copy, inbound TOS | Container merge scope — вся заявка; wagon membership не гарантируется; item меняет parent/root weight |
| RequestedService | Direct, required DAO insert, два CARGO_PLACE reprice path | Required/auto paths не всегда сразу пересчитывают root totals |
| ETRAN membership | Legacy CRUD/full-replace и V2 merge | V2 write path `/shippingorder/...` отличается от read `/shipping-order/...`; merge без явного `@Secure`; ShortDto.id — global ETRAN ID, не row ID |
| Physical wagon | Legacy CRUD/full-replace, V2 grouped/unnumbered merge, inbound actions | Direct global ETRAN FK; nullable owners нельзя безопасно очистить; update membership не каскадирует wagon |
| Wagon qty | Scoped list/meta/merge | Merge source-level неатомарен: outer method без transaction, delete идёт до add/update |
| Container qty | Scoped list/meta/transactional merge | Владеет nested ETSNG, пересчитывает root total; `NONE_CONTAINER` имеет специальную форму |
| ETSNG child | Только nested parent merge | Exact duplicate закрыт DB; самостоятельного HTTP controller нет; старый repository duplicate query не вызывается |
| Общий status helper | Большинство shipping child services | Для `ON_REVIEW` жёстко проверяет receiving permission вместо shipping permission |
| Child outbound | Старые per-entity hooks | Для transport/good/cargo/container/requested-service/ETRAN прямые hooks отключены; актуальные пакеты собираются от root/route |

## Aggregate authority: одного источника нет

```mermaid
flowchart LR
    G[ShippingOrderGood] -->|sum price / SKU| R[(shipping_order stored totals)]
    C[ShippingOrderCargo] -->|count / pallet split / weight| R
    PC[Physical Container] -->|count / tare+gross weight| R
    I[ContainerItem] -->|item price / gross without tare| R
    QC[ContainerQty] -->|SUM quantity| R
    S[RequestedService] -->|count / priceWithoutVAT| R
    B[Blackbox direct] -->|increment / decrement| R
    EX[Blackbox Excel] -. insert without counter update .-> R
    C -->|CARGO_PLACE formula A| S
    PC -->|CARGO_PLACE formula B| S
```

Критичные stored values:

- `total_weight` имеет три Java-writer'а: Cargo, physical Container и ContainerItem — с разными формулами;
- `total_goods_price` пишут Good и ContainerItem;
- `total_container_quantity` пишут physical Container (`count rows`) и ContainerQty (`SUM quantity`) без выбора формулы по текущему filling type;
- `total_cargo_quantity` direct Blackbox меняет инкрементально, а Excel DAO insert способен его не обновить;
- `shipping_order_container.weight` вычисляется из tare + item gross и затем участвует в root weight;
- CARGO_PLACE `plannedQuantity` рассчитывается двумя независимыми методами;
- route live export выбирает count/SUM по filling type, но route chain package отдаёт stored `totalContainerQuantity`, поэтому два интеграционных ответа могут расходиться.

## Удаление и каскады

```mermaid
flowchart TD
    EI[Soft-delete ETRAN membership] --> W[Soft-delete wagons той же order+ETRAN]
    W --> C[Soft-delete связанных physical containers]
    C --> I[Soft-delete physical container items]
    CQ[Physical delete ContainerQty] --> E[Physical delete ETSNG children сначала]
    WQ[WagonQty] -->|merge omission| WD[Physical delete без audit]
    SC[Soft-deleted physical Container] -. остаётся в UNIQUE pair .-> U[Повтор пары может быть заблокирован]
```

- Good/Cargo/Container/ContainerItem/RequestedService/Blackbox/Wagon/ETRAN membership используют soft-delete.
- Transport, обе qty-таблицы и ETSNG child не имеют `deleted`; qty/ETSNG удаляются физически.
- Ни один показанный cascade не является FK `ON DELETE CASCADE`; это порядок service-вызовов.
- Удаление ETRAN membership каскадирует вниз, но **update** order/ETRAN membership не переносит и не удаляет старые wagon rows.
- ContainerQty merge атомарен вместе с ETSNG children; WagonQty merge имеет отдельный transaction gap.

## Route, meta и outbound boundary

Route read выбирает plan или fact по `fillingType`. Две rerunnable view объединяют обе модели для meta:

- `shipping_route_railway_carriage_view` использует inner join к nullable wagon qty type и поэтому скрывает строки без типа;
- `shipping_route_container_view` разворачивает один container qty parent в несколько строк по ETSNG, повторяя один UUID в JPA `@Id`.

Route chain package не применяет filling-type switch: он собирает physical rows, qty rows и ETSNG children одновременно для всех заявок рейса. Поэтому stale plan/fact данные экспортируются вместе. ETRAN membership как отдельная строка не экспортируется; manifest/route packages используют прямые global ETRAN links физических вагонов.

## Что база не проверяет за сервис

- Принадлежность client/contract/consignee/справочников клиенту и договору заявки.
- Composite consistency root/intermediate parent и container/wagon parent.
- Взаимоисключаемость plan/fact по `fillingType` и очистку stale rows при его изменении.
- Принадлежность global ETRAN конкретной заявке через membership.
- Большинство business duplicates, включая wagon, ETRAN membership, goods/cargo/services и loaded container signatures.
- Формулы totals, единицы weight и смысл ETSNG weight на один КТК или всю qty-строку.
- Enum-domain container type на DB-уровне и согласованность DTO `>=0` с SQL `>0`.
- Client row-level write scope прямых UUID/merge paths; `@Secure` проверяет permission, но не доказывает ownership.
- Soft-deleted rows продолжают занимать FK/UNIQUE-слоты и могут проявляться в нестандартных query/view paths.

## Чек-лист проверки будущего ТЗ

1. Указать `terminalArea`, `transportType` и `fillingType`; определить plan/fact physical tables для вагонов и КТК.
2. Для каждого UUID различать root, membership row, global ETRAN, wagon row, global wagon, qty parent и ETSNG child.
3. Явно назвать merge-семантику: полный replace или patch; что означает `[]`; soft или physical delete; какой cascade ожидается.
4. Определить поведение при смене filling type: очистка, миграция либо запрет при существующих rows.
5. Зафиксировать authoritative writer/formula каждого root total и отличие stored total от route live calculation.
6. Проверить composite parent consistency (`good↔cargo`, `container↔item`, `container↔wagon`) и ETRAN membership.
7. Решить, какие application uniqueness должны стать DB constraints с учётом soft-delete/concurrency.
8. Для quantity/weight определить `>0`, precision/scale, единицы и per-row/per-unit смысл; синхронизировать DTO и SQL.
9. Добавить nested `@Valid` там, где HTTP должен возвращать validation error до service/DB.
10. Сверить permission и client write scope merge/read paths, особенно V2 ETRAN merge и direct root IDs.
11. Проверить route meta views на nullable type и повторяющийся ID, а outbound — на stale plan/fact rows.
12. Добавить negative, rollback и concurrency tests для late merge error, cross-parent ID, duplicate signature и повторного create после soft-delete.

## Проверки, история и границы достоверности

Сводка сопоставлена с 13 детальными моделями частей 16–29, их controller/DTO/mapper/service/JPA, cumulative SQL, validators, route/meta/outbound consumers и доступными test sources. Она связывает выводы паспортов, не заменяя их подробности.

Крупные влияющие commits базового контура: `11de1385` (исходные shipping-таблицы), `dd22741c` (KIS-928, shared-key transport), `52d3c09151c0` (KIS-3084, shipper→consignee), `53e847f2` (KIS-1746, nullable package/conversion/total), `c7728e90` (KIS-2441, nullable transport address). ЖД-расширение связано с `b67b2971`, `d29256da`, `0a8c1bb5`, `55be7d74`, `9ca9eb80`, `fc6003c0`, `4b61d802`, `2f962915`, `3a283b5a`, `4ff9eb7c`, `49ce562d`, `6557b9e8` и `cd8ab542`; точная роль каждого commit приведена в частях 25–29.

Тесты в подэтапе 4.30 не запускались. Не проверены applied Liquibase/`pg_catalog`, реальные дубли и stale rows, runtime roles/client restrictions, generated MapStruct, transaction behavior на работающем приложении, внешние Datareon consumers и query plans views. Карта пригодна для анализа и ревью ТЗ, но не является production schema dump.
