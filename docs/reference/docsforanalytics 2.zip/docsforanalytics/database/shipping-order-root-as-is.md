# `shipping_order`: корень вывоза, физическая модель AS-IS (часть 16)

Источник проверки — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java DTO/mapper/service/JPA, SQL и cumulative Liquibase в репозитории. Это **реконструкция по исходникам**, а не инспекция применённой БД. Содержательная валидация и переходы статусов описаны в [правилах вывоза](../business-rules/shipping-orders.md) и [карте валидации](../business-rules/order-validation.md); здесь рассматриваются корневая таблица, происхождение её полей и владельцы сохранённых агрегатов. Дочерние таблицы будут разбираться отдельно.

## Граница агрегата и цепочка записи

[`ShippingOrder`](../entities/catalog/entities/shippingorder/ShippingOrder.md) наследует mapped-superclasses [`TransportOrder`](../entities/catalog/mapped-superclasses/order/TransportOrder.md) → [`Order`](../entities/catalog/mapped-superclasses/order/Order.md) → `BaseEditable`; их поля физически находятся в `shipping_order`, отдельных таблиц superclass нет.

```mermaid
flowchart LR
    HTTP[POST /shippingorder/\nPUT /shippingorder/{id}] --> DTO[CreationDto / UpdateDto]
    DTO --> MAP[ShippingOrderMapper]
    MAP --> SVC[ShippingOrderService]
    SVC --> VAL[OrderCombinationValidator\nconsignee lookup]
    SVC --> DAO[ShippingOrderDaoService]
    DAO --> ROOT[(shipping_order)]
    CHILD[goods / cargo / containers / items\nservices / blackbox / qty] -->|recalculate stored totals| ROOT
    INBOUND[WMS / TOS inbound actions] -->|actual time / statuses| ROOT
    DAO -->|status changed event| ROUTE[route status listener]
```

[`BaseService.add`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) и `update` транзакционны. Mapper создаёт новый UUID, затем [`ShippingOrderService.prepareModelToAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) принудительно ставит `DRAFT`, проверяет сочетание площадки/транспорта/вида вывоза/типа заполнения и подменяет адрес грузополучателя значением справочника. После INSERT тот же внешний transaction вызывает прямую DAO-вставку обязательных услуг договора.

Первоначальный [`CREATE TABLE` ALG-388](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240730_ALG-388_add_table_shipping_order.sql) задаёт `id uuid PRIMARY KEY` и `number SERIAL NOT NULL`. Java [`Order.number`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/order/Order.java) дополнительно использует общий `EntitySequenceGenerator` с типом `ORDER`, поэтому приложение подставляет номер до INSERT, а PostgreSQL `SERIAL` остаётся отдельным default-механизмом для прямого INSERT. `UNIQUE(number)` в просмотренной цепочке не найден.

## DTO → service/JPA → физические колонки

Контракты: [`ShippingOrderCreationDto`](../dto/catalog/shippingorder/ShippingOrderCreationDto.md), [`ShippingOrderUpdateDto`](../dto/catalog/shippingorder/ShippingOrderUpdateDto.md), [`ShippingOrderDto`](../dto/catalog/shippingorder/ShippingOrderDto.md) и [`ShippingOrderDetailedDto`](../dto/catalog/shippingorder/ShippingOrderDetailedDto.md). Декларации HTTP находятся в [`ShippingOrderController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorder/ShippingOrderController.java).

| Request / иное происхождение | Entity → SQL | Подтверждённый source-контракт и write semantics |
|---|---|---|
| Нет request `id`, `number`, audit | `id`, `number`, `createdAt/By`, `updatedAt/By` → одноимённые snake_case колонки | `uuid PK`, `SERIAL NOT NULL`, create audit `NOT NULL`, update audit nullable. UUID, номер и audit заполняет приложение. Unique номера не найден. |
| `client.id` — `@NotNull` | `client` → `client_id` | После цепочки [KIS-1397](../../../db-layer/src/main/resources/db/changelog/v.1.24.0/v1.24.0_KIS-1397_add-field-tables-legal_entity_id.sql) и [KIS-1623](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250918_KIS-1623_RemoveClientTable_RenameLegalEntityTable.sql): `UUID NOT NULL`, FK `shipping_order_client_id_fkey` на текущую таблицу `client`; JPA `optional=false`, `updatable=false`. Update DTO содержит client, но service его не переносит. |
| `contract.id` — `@NotNull` | `contract` → `contract_id` | `UUID NOT NULL REFERENCES contract(id)`. На create mapper ставит reference; update service ищет Contract по ID. Проверки, что договор принадлежит client заявки, в корневом service/SQL не найдено. |
| `terminalArea` — `@NotNull` | `terminalArea` → `terminal_area_catalog_id` | [KIS-1422](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20251111_KIS-1422_edit_terminal_area_catalog_entity.sql): `UUID NOT NULL`, FK `fk_shipping_order_terminal_area_catalog`, backfill по старому `terminal_area` и удаление старой колонки. JPA `updatable=false`; update body не меняет площадку. |
| `transportType` — `@NotNull` | `transportType` → `transport_type` | `VARCHAR(100) NOT NULL`, enum STRING, JPA `updatable=false`; update body не меняет значение. |
| `orderStatus` — `@NotNull` | `orderStatus` → `order_status` | `VARCHAR(100) NOT NULL`. На create присланное значение **игнорируется** и заменяется на `DRAFT`; обычный update его не копирует. Review/accept/reject и inbound actions — отдельные writers. |
| `plannedShippingDateTime` — optional | → `planned_shipping_date_time` | `TIMESTAMP`; [KIS-703](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250311_KIS-703_drop_not_null_in_orders_tables.sql) снял `NOT NULL`. Update прямо присваивает значение, включая `null`. Java `Instant` не доказывает timezone semantics колонки `TIMESTAMP`. |
| WMS inbound, не common DTO | `actualShippingDateTime` → `actual_shipping_date_time` | [KIS-147](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250218_KIS-147_add_vh_departure_action_inbound_event_config.sql): `TIMESTAMP NULL`. Поле ответа не является плановой датой. |
| `currency.id` — optional | `currency` → `currency_id` | FK на `currency(id)`, `NOT NULL` снят KIS-703. Create без валюты подтверждён существующим integration test. При update ветка вызывает `updateModel.getCurrency().getId()` даже когда current currency или новое значение `null`; очистка/повторное сохранение null может завершиться до SQL ошибкой Java. |
| `contact` — optional embedded | → `contact_name`, `contact_phone`, `contact_email` | После ALG-814 все nullable; phone расширен до `VARCHAR(50)`, остальные `VARCHAR(100/255)`. Update заменяет contact только при body `contact != null`; `null` не очищает старые значения. |
| `comment` — optional | → `comment` | `VARCHAR(512) NULL`; update прямо присваивает, поэтому поле можно очистить. |
| `deliveryType` — optional | → `delivery_type` | [KIS-1135](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250606_KIS-1135_add_delivery_type_for_shipping_order.sql): `VARCHAR(64) NULL`, backfill для warehouse. На create обязателен логикой только для warehouse+vehicle и очищается для других сочетаний; обычный update его не переносит. SQL CHECK значений не найден. |
| `route.id/code`, `needTransport` — optional | → `route_id`, `need_transport` | [KIS-1751](../../../db-layer/src/main/resources/db/changelog/v.1.29.0/v.1.29.0_20251008_KIS-1751_add_table_route.sql): nullable FK на `route(id)` и `BOOLEAN NOT NULL DEFAULT false`; [KIS-2332](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251224_KIS-2332_add_index_for_route_in_shipping_and_receiving_orders.sql) добавляет `idx_shipping_order_route_id`. Update service переносит route, но не `needTransport`. |
| `consignee.id`, присланный `consigneeAddress` | → `consignee_id`, `consignee_address` | `consignee_id` появился как `shipper_id` без FK и переименован [KIS-3084](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260204_KIS-3084_rename_column_shipper_to_consignee.sql); source SQL FK не найден. Service требует `isConsignee=true` и того же client, а body-address игнорирует: сохраняет trimmed `ClientRelatedEntity.addressFact`. При отсутствии consignee очищает оба поля. [KIS-4248](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260729_KIS-4248_expand_shipping_order_consignee_address.sql) расширяет snapshot-address до `VARCHAR(1000)`. |
| `fillingType` — optional | → `filling_type` | [KIS-3352](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql): `VARCHAR(16) NOT NULL`, historical backfill `ALL`, CHECK; [KIS-4271](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260716_KIS-4271_add_none_container_filling_type.sql) расширяет CHECK до `ALL/RAILWAY_CARRIAGE/CONTAINER/NONE/NONE_CONTAINER`. Для container+railway create null нормализуется в `ALL`; `@PrePersist` также подставляет `ALL`. Обычный update поле не переносит. |
| Не входит в common request DTO | `ktkNumberUnknown` → `ktk_number_unknown` | `BOOLEAN DEFAULT false`, но без `NOT NULL`; вычисляется `ShippingOrderContainerService` по дочерним строкам. Java default `FALSE` не равен SQL constraint. |
| Только response DTO | `documentConfirmed` | Колонка была добавлена KIS-1717, затем удалена [v1.31](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251202_KIS-1717_drop_column.sql); поля нет в entity и явного mapper source нет. Нельзя считать это значение сохранённым свойством `shipping_order`. |

`PUT /shippingorder/{id}` объявляет path, но метод контроллера не принимает `@PathVariable`: [`BaseService.update(updateDto)`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) ищет цель по `body.id`. В этом endpoint нет сверки path ID с body ID, хотя отдельная перегрузка `BaseService.update(UUID, dto)` такую сверку умеет.

## Обязательность: три разных слоя

| Поля | Create JSON / Bean Validation | SQL source | Дополнительная серверная логика |
|---|---|---|---|
| `orderStatus`, `client`, `contract`, `terminalArea`, `transportType` | `@NotNull` | `NOT NULL` | Статус заменяется на `DRAFT`; три классифицирующих поля после create не меняются обычным update. |
| `currency`, `plannedShippingDateTime` | optional | nullable после KIS-703 | Разрешены при сохранении черновика, но [`ShippingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) требует оба при review/accept. |
| `deliveryType` | optional | nullable | Обязателен логикой для warehouse+vehicle; для других сочетаний обнуляется. |
| `consignee` | optional | nullable, source FK не найден | При review/accept обязателен для container; при наличии проверяются роль и принадлежность client. |
| `fillingType` | optional | `NOT NULL` + CHECK | Null нормализуется только для container+railway, затем `@PrePersist` даёт `ALL`; `NONE_CONTAINER` разрешён только container+vehicle. |
| totals | отсутствуют в request | восемь `NOT NULL`, `total_weight` nullable | Java defaults и дочерние writers; SQL defaults для totals не найдены. |

Эта матрица означает, что «можно создать черновик» не равно «можно отправить на review/accept». Наличие `@NotNull orderStatus` в create DTO также не означает, что клиент выбирает начальный статус.

## Persisted totals и конкурирующие writers

[`ALG-534`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240819_ALG-534_add_columns_for_shipping_order_preview.sql) добавил восемь агрегатов, [`ALG-644`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240903_ALG-644_add_table_shipping_order_container.sql) — `total_container_quantity`. ALG-633 выполнил backfill нулями и `SET NOT NULL`; отдельный SQL закрепил container total. Поздний KIS-1970 снял `NOT NULL` только с `total_weight`. SQL defaults у этих колонок не найдены: builder/field defaults Java действуют лишь на создаваемую ORM-сущность. Quantity-поля Java имеют тип `Long`, тогда как SQL использует `NUMERIC(16,3)`.

| Корневая колонка | Writer и формула |
|---|---|
| `total_sku_quantity`, `total_goods_price` | [`ShippingOrderGoodService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodService.java): distinct items и сумма сохранённых `totalPrice`. |
| `total_weight`, cargo/pallet/not-pallet counts | [`ShippingOrderCargoService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoService.java): полный пересчёт активных cargo. |
| `total_goods_price`, `total_weight` | [`ShippingOrderContainerItemService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerItemService.java): суммы item price/weight. |
| `total_container_quantity`, `total_weight` | [`ShippingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java): число и вес конкретных КТК. |
| `total_container_quantity` | [`ShippingOrderContainerQtyService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyService.java): сумма количественных строк безномерной заявки. |
| `total_cargo_quantity` | [`ShippingOrderBlackboxService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderblackbox/ShippingOrderBlackboxService.java): инкремент/декремент при direct create/delete. |
| service count/price | [`ShippingOrderRequestedServiceService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java): число active строк и сумма цены без НДС. |

`totalWeight`, `totalGoodsPrice`, `totalCargoQuantity` и `totalContainerQuantity` имеют более одного возможного writer в зависимости от варианта заявки. Физическая схема не фиксирует authoritative formula и не запрещает несогласованные значения. Прямая вставка обязательных услуг в `postAdd` не вызывает показанный service-пересчёт root service totals, поэтому начальный ноль и существующие строки услуг могут временно расходиться.

## Статус и побочные эффекты

- `review`, `accept`, `reject` берут pessimistic/application lock через `findAndLock`, проверяют матрицу [`OrderStatus`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/orderstatus/OrderStatus.java), валидируют сохранённый агрегат и обновляют корень в одной transaction.
- В [`ShippingOrderController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorder/ShippingOrderController.java) есть `/review` и `/reject`, но endpoint для реализованного `ShippingOrderService.accept(UUID)` не найден.
- [`ShippingOrderDaoService.postUpdatePublishEvent`](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderDaoService.java) сравнивает сохранённый transient `previousStatus` со статусом после update и публикует `ShippingOrderStatusChangedEvent`, включая nullable `routeId`.
- Inbound [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) пишет `IN_PROGRESS`, а [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) — `DONE` и фактические данные. Эти пути не являются common update DTO.
- Корень не реализует soft-delete, и DELETE endpoint в controller не найден. Физическое удаление нельзя проектировать без проверки всех дочерних FK; в просмотренных create migrations связи обычно не задают `ON DELETE CASCADE`.

## Ограничения и индексы, найденные в source

| Вид | Что подтверждено |
|---|---|
| PK | `shipping_order(id)`. |
| FK | `client_id`, `contract_id`, `currency_id`, `terminal_area_catalog_id`, `route_id`. Для `consignee_id` source FK не найден. |
| CHECK | Только `chk_shipping_order_filling_type` с пятью enum-значениями после KIS-4271. CHECK для status, transport/delivery type, totals и дат не найден. |
| UNIQUE | Business unique для `number` или других корневых полей не найден. |
| Индексы | Явно найден `idx_shipping_order_route_id`; PK создаёт индекс автоматически. Отдельные source indexes на остальные FK не найдены. |
| Defaults | `number SERIAL`, `need_transport=false`, `ktk_number_unknown=false`; fillingType backfill не является SQL default. Totals получили data backfill, но не `DEFAULT 0`. |

## Миграции и влияющие commits

| Изменение | Commit |
|---|---|
| Первичная таблица и preview totals | `11de138554ed6935c9906dd7f5716bef8f8c1889` |
| Actual shipping datetime | `f2734e15e74330c056349da6d301461cf182b97c` |
| Nullable currency/planned datetime | `c4e6bf2cfca845abe9762194f69d11161ad5dff3` |
| Delivery type | `80b4dbb09a11fe2cb071da43b9edea7ee4a6ce37` |
| Финальная client migration | `a90b9076f153c8f9021b30e264bae782850505f1` |
| Route FK/default и route index | `bc3b0253b73e6b29e58200101a9389152c33ed13`, `e58cd9abb9b1ca6f7d3cf605be4ae9fc440a4cdc` |
| Consignee rename | `52d3c09151c0ce47b2c838de7af180131f85d683` |
| TerminalArea catalog | `78cd428f` / `ec84d091` |
| Filling type/check | `d29256dab8e13418f697d76a6f387c4420e3d046`, `3a283b5af12cdde196f78960c60ac9a62c604048` |
| Derived consignee address / length 1000 | `fa27bf5666ab85082aabc51df8978b196d08b7b5` |

## Что подтверждают tests, но не их запуск

- [`ShippingOrderServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderServiceIntegrationTest.java) содержит create с обязательными услугами, create без currency/planned datetime, отказ accept для такого черновика, review/reject, partial/full copy и assertions stored totals после копирования goods/cargo и containers/items.
- [`ShippingOrderServiceTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderServiceTest.java) проверяет derived consignee address, чужого client и отсутствие роли consignee.
- [`ShippingOrderAcceptValidatorTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidatorTest.java) и integration counterpart покрывают часть комбинаций и отсутствующих дочерних данных.

Тесты в этом подэтапе не запускались. Их наличие не подтверждает applied schema, HTTP routing или результат текущей сборки.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные defaults/indexes/FK, дубли номера и допустимые null в развернутой БД.
2. Нужен прямой HTTP test расхождения path/body ID для update и решение, должен ли path быть authoritative.
3. Нужны negative tests update с nullable currency, очистки contact и попытки изменить поля, присутствующие в update DTO, но не переносимые service.
4. Нужен applied-schema ответ, существует ли FK `consignee_id → client_related_entity(id)`; JPA `@ManyToOne` сам по себе этого не доказывает.
5. Нужен последовательный DB/API test всех вариантов заявки, чтобы определить authoritative writers для четырёх конкурирующих totals и момент согласования mandatory services.
6. Нужно решить, зачем `orderStatus` обязателен в create DTO, если сервер всегда сохраняет `DRAFT`, и удалить/объяснить response-only `documentConfirmed`.
7. Нужно подтвердить доступность accept через другой transport/controller либо признать service method недоступным по HTTP.
8. Перед требованием физического удаления нужно построить полную карту дочерних FK и `ON DELETE`; корневой документ этого не доказывает.

## Чек-лист изменения корня

1. Разделить draft-save обязательность, review/accept обязательность и SQL `NOT NULL`.
2. Для update явно перечислить изменяемые поля и проверить path ID против body ID.
3. Для нового enum/value обновить Java enum, DTO/OpenAPI и SQL CHECK одновременно.
4. Для consignee проверять роль, client ownership, snapshot-address и физический FK как разные гарантии.
5. Для нового writer totals определить вариант заявки, формулу, transaction и полный пересчёт после create/update/delete/copy/import.
6. Для status change проверить lock, allowed transition, validator, outbound inserts и route status event.
7. Для удаления/перепривязки проверить все child FK и отсутствие/наличие cascade по applied schema.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [API заявок](../api/order-api.md)
- [Общая модель заявок](orders.md)
- [JPA-паспорт ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md)
