# Модель данных ALIS

Раздел объединяет физическое представление данных и предметное описание сущностей.

- [Каталог физических объектов БД](catalog/README.md) — навигационный реестр уже разобранных таблиц и read-моделей, их паспортов и пробелов в покрытии.
- [Шаблон физического паспорта таблицы](templates/table.md) — единый формат описания источников, колонок, ограничений, индексов, поведения записи и связей с API/DTO/правилами/тестами.
- [Модель заявок](orders.md) — ручное описание таблиц и связей центрального агрегата.
- [Корень заявки на поставку: физическая модель AS-IS, часть 1](receiving-order-root-as-is.md) — DTO → service/JPA → SQL-колонки, FK/NULL/индекс, persisted и computed totals.
- [Транспорт заявки на поставку: физическая модель AS-IS, часть 2](receiving-order-transport-as-is.md) — **DEPRECATED** (KIS-4093, 24.09.2026): таблица удалена, поля перенесены в root-заявку и `route`; документ сохранён как история.
- [Товарная строка поставки: физическая модель AS-IS, часть 3](receiving-order-good-as-is.md) — DTO/сервис → SQL, фактическое и плановое количество, сохранённая цена и два итога корня.
- [Грузовое место поставки: физическая модель AS-IS, часть 4](receiving-order-cargo-as-is.md) — FK заявки/товара/упаковки, SQL NULL/DEFAULT, расчёт quantity и stored cargo/weight totals.
- [КТК поставки: физическая модель AS-IS, часть 5](receiving-order-container-as-is.md) — parent container row, SQL array seals/FK/unknown flag, TOS actual и competing weight writers.
- [Содержимое КТК поставки: физическая модель AS-IS, часть 6](receiving-order-container-item-as-is.md) — child row/FK/ЕТСНГ, price/gross/net/places и порядок пересчёта parent/root.
- [Дополнительная услуга поставки: физическая модель AS-IS, часть 7](receiving-order-requested-service-as-is.md) — DTO, required rows, SQL/FK, план/тариф/НДС/факт и расхождение автоматического пересчёта строк с итогом корня.
- [Blackbox поставки: физическая модель AS-IS, часть 8](receiving-order-blackbox-as-is.md) — минимальная строка Cargo без товарной детализации, direct/Excel/copy writes и инкрементальный root cargo counter.
- [Корень накладной Waybill: физическая модель AS-IS, часть 9](waybill-root-as-is.md) — inbound partial upsert, SQL-колонки/ключи/FK, nullable связь с поставкой и миграция старой receiving-модели.
- [Вагон накладной Waybill: физическая модель AS-IS, часть 10](waybill-railway-carriage-as-is.md) — граница global/snapshot, три write path, nullable task status, read DTO/filter и физическое удаление с каскадами.
- [КТК накладной Waybill: физическая модель AS-IS, часть 11](waybill-container-as-is.md) — global/snapshot/owner boundary, WC/ZPU schema, create paths, TOS status/потеря actual quantity и read-проекции веса.
- [Груз накладной Waybill: физическая модель AS-IS, часть 12](waybill-product-as-is.md) — ЕТСНГ/DangerProduct, все snapshot-поля, cardinality validation, legacy migration, read totals и route-package projection.
- [Отметки накладной Waybill: физическая модель AS-IS, часть 13](waybill-marks-as-is.md) — две snapshot-коллекции, nullable/duplicate semantics, numeric tariff code, import/replay/cascade и риск nested-фильтра.
- [Материализованная read-модель Waybill: физическая модель AS-IS, часть 14](grouped-waybill-as-is.md) — **DEPRECATED** (KIS-4690, 14.09.2026): materialized view удалён, заменён обычной view `waybill_view`; документ сохранён как история, новый source-level паспорт `waybill_view` не написан (открытый пункт).
- [ReceivingOrder ↔ Waybill: сводная физическая карта AS-IS, часть 15](receiving-order-waybill-integrity-map.md) — единая ER-карта, матрица FK/UNIQUE/delete, writers, агрегаты и чек-лист проверки ТЗ.
- [Корень заявки на вывоз: физическая модель AS-IS, часть 16](shipping-order-root-as-is.md) — DTO → service/JPA → SQL, обязательность, FK/CHECK/индекс, статусы и конкурирующие writers stored totals.
- [Транспорт заявки на вывоз: физическая модель AS-IS, часть 17](shipping-order-transport-as-is.md) — **DEPRECATED** (KIS-4093, 24.09.2026): таблица удалена, `consignee`/`consigneeAddress` слиты в root, `carrier`/ТС/водитель — в `route`; документ сохранён как история.
- [Номенклатура заявки на вывоз: физическая модель AS-IS, часть 18](shipping-order-good-as-is.md) — DTO → service/JPA → SQL, асимметрия update `clientGood`/`batch`, разная атомарность трёх bulk-контрактов, stored root totals и dead outbound config.
- [Грузовое место заявки на вывоз: физическая модель AS-IS, часть 19](shipping-order-cargo-as-is.md) — DTO → service/JPA → SQL, мёртвое поле `batch`, require-existing-id `cargo` (в отличие от find-or-create у поставки), четыре bulk/upsert-контракта с разной атомарностью, пересчёт totals и `CARGO_PLACE`-услуг.
- [КТК заявки на вывоз: физическая модель AS-IS, часть 20](shipping-order-container-as-is.md) — DTO → validator/service/JPA → SQL, живой `UNIQUE`-constraint без учёта `deleted` против app-level дубль-чека, NPE-риск `getCargoWeight()` в отчёте ТН, merge-эндпоинты с scope на всю заявку.
- [Содержимое КТК заявки на вывоз: физическая модель AS-IS, часть 21](shipping-order-container-item-as-is.md) — DTO → service/JPA → SQL, неохраняемый NPE-риск в пересчёте веса контейнера (в контрасте с охраняемым read-side мэппером), три конкурирующих writer'а `total_weight`.
- [Дополнительная услуга заявки на вывоз: физическая модель AS-IS, часть 22](shipping-order-requested-service-as-is.md) — DTO → service/JPA → SQL, два независимых пути пересчёта `CARGO_PLACE`-услуг, прямой DAO insert required-строк без пересчёта root, dead outbound config.
- [Грузовое место без товарной детализации заявки на вывоз: физическая модель AS-IS, часть 23](shipping-order-blackbox-as-is.md) — DTO → service/JPA → SQL, расхождение Excel-импорта с receiving (`.orElseThrow()` вместо find-or-create Cargo), root-счётчик как инкремент, не count. Этим документом закрыт выбранный набор частей 16–23; ЖД-ветка разбирается отдельно.
- [ShippingOrder: сводная физическая карта AS-IS, части 16–29](shipping-order-integrity-map.md) — единая ER/integrity-карта корня и 12 дочерних таблиц: FK/UNIQUE/delete, plan/fact-развилки по `fillingType`, ETRAN membership, каскады, конкурирующие totals и route/outbound-границы.
- [Вагон заявки на вывоз: физическая модель AS-IS, часть 25](shipping-order-railway-carriage-as-is.md) — endpoint/DTO → service/JPA → SQL, filling-type matrix, прямая global ETRAN-ссылка, КТК-cascade, inbound/outbound writers, отсутствие business UNIQUE и разрывы membership/composite integrity.
- [ЭТРАН-накладная заявки на вывоз: физическая модель AS-IS, часть 26](shipping-order-etran-invoice-as-is.md) — V1/V2 endpoint/DTO → service/JPA → SQL, неоднозначность ID ShortDto, условная обязательность, full-replace merge, business UNIQUE gap и каскад на вагоны/КТК.
- [Плановое количество вагонов: физическая модель AS-IS, часть 27](shipping-order-railway-carriage-qty-as-is.md) — scoped API/DTO → service/JPA → SQL, `CONTAINER/NONE`, physical-delete merge, DB uniqueness, route read/meta и route chain package.
- [Плановое количество КТК: физическая модель AS-IS, часть 28](shipping-order-container-qty-as-is.md) — scoped API и nested ЕТСНГ, DTO/validation → service/JPA → SQL, `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER`, транзакционный merge, totals, route read/meta/outbound.
- [Груз планового КТК: физическая модель AS-IS, часть 29](shipping-order-etsng-code-as-is.md) — nested DTO/service/JPA → SQL, weight/UNIQUE, empty-parent и filling-type validation, physical cascade, meta/route/outbound; отдельного controller нет.
- [Полный каталог JPA-модели](../entities/catalog/README.md) — 113 сущностей (на 29.09.2026; было 114 на предыдущей сверке — минус `ReceivingOrderTransport`/`ShippingOrderTransport`/`GroupedWaybillView`, плюс `WaybillView`, `ContainerStatus`, `ContainerMovementMetaView` и др.), отдельная страница на класс, все собственные и наследуемые поля, предполагаемые колонки и связи.
- [Mapped superclasses](../entities/catalog/README.md#наследуемые-модели-без-собственной-таблицы) — поля, физически повторяющиеся в таблицах наследников.

## Изменения схемы 26 августа — 14 октября 2026, вне детального разбора выше

Список ниже — все changeset'ы v.1.34.0–v.1.35.0 и два новых rerunnable view за этот период. Часть покрыта детальными AS-IS документами (ссылки в списке ниже и в разделах выше); часть — **нет**, это открытые пункты для будущей сверки, не полный source-level разбор.

| Изменение | Коммит/тикет | Покрытие |
|---|---|---|
| Удаление `receiving_order_transport`/`shipping_order_transport`, перенос полей в root/`route` | KIS-4093, `d30d77ad`, 24.09.2026 | Покрыто — см. части 2 и 17 выше (помечены DEPRECATED) |
| `container_owner`: колонки `status`, `receiving_order_id`, `shipping_order_id`; `container_owner_history`: `new_status`/`old_status` | KIS-4661, `v.1.35.0_20260915` | Покрыто — [регистр остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md) |
| `receiving_order.default_container_owner_id`, `receiving_order_container.owner_container_id_new`, `waybill_container.owner_container_id` (+ ручная data-миграция ID) | KIS-4716, `v.1.35.0_20260921` (два файла) | Покрыто — там же |
| `waybill.creation_source`, `delivery_deadline` → `DATE`, drop `grouped_waybill` | KIS-4626, `v.1.35.0_20260909`/`20260911` | Частично — см. часть 14 (DEPRECATED) и [waybill-etran-as-is.md](../business-rules/waybill-etran-as-is.md); новый `waybill_view` отдельного паспорта не имеет |
| `container.length` reconciliation, `container_type_iso` identity-column repair | KIS-4432, `v.1.35.0_20260901`/`20260908` | **Не покрыто** — forward-only repair changeset'ы, не разобраны |
| `chk_container_container_type` (+ значение `UNKNOWN`) | KIS-4664, `v.1.35.0_20260901` | **Не покрыто** |
| `railway_carriage_model` — добавлена запись `Не определено` (unknown-модель) | KIS-4665, `v.1.35.0_20260901`; 13.10.2026 (`a4e3b5f8`) changeset переписан в Liquibase formatted SQL с новым id `dgribkov:KIS-4665-idempotent-unknown-railway-carriage-model` и вставляет запись только при отсутствии строки с `code='Не определено'` (на PROD запись уже была; `findByCode` ожидает ровно одну) | **Не покрыто** паспортом; на DEV/STAGE старый changeset уже применён, новый id применится повторно, но дубля не создаст |
| `shipping_order_container.owner_container_id`: FK перенесён с `client_related_entity` на `client`, значения перемаплены, отсутствующие в таблице соответствия — `NULL` | KIS-4830, `v.1.35.0_20261006`, `401bbea3`, 08.10.2026 | Покрыто — [часть 20](shipping-order-container-as-is.md), [регистр владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830) |
| `receiving_order_good.batch_unknown`, `shipping_order_good.batch_unknown` (`BOOLEAN NOT NULL`, существующим строкам `false`, default снят) | KIS-4841, `v.1.35.0_20261012`, `8ee1ab68`, 13.10.2026 | Покрыто — [receiving_order_good](receiving-order-good-as-is.md), [shipping_order_good](shipping-order-good-as-is.md) |
| `receiving_order_transport`/`shipping_order_transport` backfill в `receiving_order`/`shipping_order`/`route` | KIS-4093, `v.1.34.0_20260718` | Покрыто — см. DEPRECATED-заметки в частях 2 и 17 |
| View `container_movement_meta_view` (meta-подбор по `container_movement` + LOAD_FINISH/UNLOAD_FINISH заявке + ЕТСНГ) | без тикета, `rerunnable/view_container_movement_meta.sql` | **Не покрыто** — новая `ContainerMovementMetaView`/DaoService не описаны |
| View `waybill_view` (замена `grouped_waybill`) | KIS-4690, `rerunnable/view_waybill.sql` | Частично — см. выше |

## Как читать каталог

Для поля одновременно указаны Java-тип, колонка, JPA-обязательность и отношение. Если `@Table`, `@Column` или `@JoinColumn` не задаёт имя явно, каталог помечает имя как выведенное по стратегии JPA. Это рабочая подсказка, а не замена проверке Liquibase.

## Порядок анализа изменения схемы

1. Найти корневую и дочерние сущности в каталоге.
2. Проверить JPA-аннотации и наследуемые поля.
3. Найти создание таблицы и все последующие `ALTER` в `db-layer/src/main/resources/db/changelog`.
4. Проверить FK, unique/check constraints, индексы и soft-delete.
5. Проверить rerunnable views и отчёты, читающие таблицу.
6. Зафиксировать миграцию существующих данных и совместимость DTO/интеграционных сообщений.

## Ограничение

JPA описывает объектную модель, а окончательную физическую схему определяет применённая цепочка Liquibase. Поэтому значение «не задано аннотацией» в паспорте сущности нельзя трактовать как доказанный `NULL` в БД.
