# ReceivingOrder ↔ Waybill: сводная физическая карта AS-IS (часть 15)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561` и детальные физические модели частей 1–14. Это **source-level карта для проверки ТЗ**, а не снимок применённой БД. Она не заменяет паспорта таблиц: здесь сведены направления FK, уникальность, удаление, write ownership и места, где база не обеспечивает предметную целостность.

## Охват и исправление инвентаризации

Контур содержит `receiving_order`, **14 связанных физических таблиц** и одну materialized read-модель. Ранние строки журнала считали `waybill_container` и `waybill_zpu` одним объектом документа части 11 и поэтому указывали 13 связанных таблиц. Физически это две таблицы; в этой сводке число исправлено.

| Часть | Объект | Детальная модель |
|---|---|---|
| 1 | `receiving_order` | [корень поставки](receiving-order-root-as-is.md) |
| 2 | `receiving_order_transport` | [транспорт, shared PK](receiving-order-transport-as-is.md) |
| 3 | `receiving_order_good` | [товарная строка](receiving-order-good-as-is.md) |
| 4 | `receiving_order_cargo` | [грузовое место](receiving-order-cargo-as-is.md) |
| 5 | `receiving_order_container` | [КТК поставки](receiving-order-container-as-is.md) |
| 6 | `receiving_order_container_item` | [содержимое КТК](receiving-order-container-item-as-is.md) |
| 7 | `receiving_order_requested_service` | [дополнительная услуга](receiving-order-requested-service-as-is.md) |
| 8 | `receiving_order_blackbox` | [груз без товарной детализации](receiving-order-blackbox-as-is.md) |
| 9 | `waybill` | [корень накладной](waybill-root-as-is.md) |
| 10 | `waybill_railway_carriage` | [вагон накладной](waybill-railway-carriage-as-is.md) |
| 11 | `waybill_container`, `waybill_zpu` | [КТК и ЗПУ накладной](waybill-container-as-is.md) |
| 12 | `waybill_product` | [груз накладной](waybill-product-as-is.md) |
| 13 | `waybill_special_mark`, `waybill_tariff_mark` | [отметки накладной](waybill-marks-as-is.md) |
| 14 | `grouped_waybill` | [materialized read-модель](grouped-waybill-as-is.md) |

## ER-карта физического владения

```mermaid
erDiagram
    RECEIVING_ORDER ||--o| RECEIVING_ORDER_TRANSPORT : "shared PK/FK"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_GOOD : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CARGO : "receiving_order_id"
    RECEIVING_ORDER_GOOD ||--o{ RECEIVING_ORDER_CARGO : "receiving_order_good_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CONTAINER : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CONTAINER_ITEM : "receiving_order_id"
    RECEIVING_ORDER_CONTAINER ||--o{ RECEIVING_ORDER_CONTAINER_ITEM : "receiving_order_container_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_REQUESTED_SERVICE : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_BLACKBOX : "receiving_order_id"
    RECEIVING_ORDER o|--o{ WAYBILL : "nullable receiving_order_id"
    WAYBILL ||--o{ WAYBILL_RAILWAY_CARRIAGE : "ON DELETE CASCADE"
    WAYBILL_RAILWAY_CARRIAGE ||--o{ WAYBILL_CONTAINER : "ON DELETE CASCADE"
    WAYBILL_CONTAINER ||--o{ WAYBILL_ZPU : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_PRODUCT : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_SPECIAL_MARK : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_TARIFF_MARK : "ON DELETE CASCADE"
    WAYBILL }o--|| GROUPED_WAYBILL : "materialized membership by UUID array"
```

`receiving_order_cargo` и `receiving_order_container_item` намеренно показаны с двумя parent-ссылками: SQL гарантирует существование каждого ID отдельно, но не совпадение их корневой заявки. `grouped_waybill` не имеет FK на Waybill: membership хранится в `UUID[]` снимка.

## Матрица ключей и ограничений

| Physical object | Parent/reference key | Доказанная уникальность | Soft-delete | Physical delete / cascade |
|---|---|---|---|---|
| `receiving_order` | UUID PK; client/contract/terminal area и другие FK | `id`; `number` source-level не UNIQUE | Нет | Публичная операция физического удаления не описана; children с default FK мешают delete |
| `receiving_order_transport` | `id` одновременно PK и FK → root | PK обеспечивает не более одной строки на заявку | Нет | `ON DELETE` не задан: source default NO ACTION/RESTRICT |
| `receiving_order_good` | root, ClientGood, nullable Batch | Только UUID PK; root+good+batch не UNIQUE | Да | FK без cascade; soft row сохраняет ссылки |
| `receiving_order_cargo` | root + Good + nullable global Cargo/package | Только UUID PK; root и Good не образуют composite guard | Да | FK без cascade; JPA `@OneToOne` root не подтверждён SQL UNIQUE |
| `receiving_order_container` | root + nullable global Container и справочники | Только UUID PK; прежний root+container UNIQUE удалён | Да | FK без cascade; удаление service дополнительно soft-delete items |
| `receiving_order_container_item` | root + parent Container + nullable ETSNG | Только UUID PK; parent/root match и active duplicate не защищены | Да | FK без cascade; row может ссылаться на parent другой заявки |
| `receiving_order_requested_service` | root + TermOfRequestedService | Только UUID PK; root+term не UNIQUE | Да | FK без cascade; system-managed row тоже физически остаётся после soft-delete |
| `receiving_order_blackbox` | root + global Cargo | Только UUID PK; root+cargo не UNIQUE | Да (`deleted` SQL nullable) | FK без cascade; nullable deleted row выпадает из `deleted=false` |
| `waybill` | nullable root; stations/payer; identifier | `waybill_identifier INTEGER UNIQUE`; number и receiving link не UNIQUE | Нет | Root delete operation не опубликована; linked Waybill FK может блокировать physical ReceivingOrder delete |
| `waybill_railway_carriage` | Waybill + global RailwayCarriage | Только UUID PK; Waybill+carriage не UNIQUE | Нет | Delete Waybill каскадирует WRC; delete WRC каскадирует WC/ZPU |
| `waybill_container` | WRC + global Container | Только UUID PK; WRC+container не UNIQUE | Нет | `ON DELETE CASCADE` только от WRC; global Container FK без cascade |
| `waybill_zpu` | WaybillContainer | Только UUID PK; parent+zpu не UNIQUE | Нет | `ON DELETE CASCADE` от WC |
| `waybill_product` | Waybill + ETSNG + nullable DangerProduct | Только UUID PK; содержательная строка не UNIQUE | Нет | `ON DELETE CASCADE` от Waybill; справочные FK без cascade |
| `waybill_special_mark` | Waybill | Только UUID PK; mark/info не UNIQUE и могут быть null | Нет | `ON DELETE CASCADE` от Waybill |
| `waybill_tariff_mark` | Waybill | Только UUID PK; code/name/note не UNIQUE и могут быть null | Нет | `ON DELETE CASCADE` от Waybill |
| `grouped_waybill` MV | route+payer group; UUID arrays | UNIQUE route triple для concurrent refresh; random `id` не constrained | N/A, read-only | Перестраивается refresh; не участвует в FK cascade |

Вывод для ТЗ: кроме `waybill_identifier`, shared transport PK и ключа materialized group, почти все предметные «не должно быть дубля» правила существуют только в service-коде либо отсутствуют. Проверка `find-then-insert` без DB UNIQUE не защищает от конкурентных дублей.

## Два параллельных контейнерных контура

`ReceivingOrderContainer` и `WaybillContainer` — не одна таблица и не parent/child:

| Контур | Physical path | Что хранит |
|---|---|---|
| Legacy/операционный ReceivingOrder | `receiving_order → receiving_order_container → receiving_order_container_item` | Выбранный/неизвестный КТК, массив ЗПУ, товарные строки, цены/веса, soft-delete, TOS actual |
| ЭТРАН/ЖД Waybill | `receiving_order ← waybill → WRC → WC → ZPU` | Накладная, физический вагон/КТК, snapshot, task status, отдельные пломбы; physical delete |

После KIS-3631 у `receiving_order_container` нет прямого FK на вагон. Сопоставление двух контуров выполняется прикладным чтением через общий глобальный `Container.id` и цепочку Waybill, а не constraint. Поэтому нельзя выводить принадлежность ReceivingOrderContainer конкретной WRC только из physical receiving row.

Legacy migration копировала часть старых receiving railway/container/item данных в Waybill tables, но исходные receiving container/item таблицы не удалены. Поля переносятся неполно: например, item price/weights/places не становятся одноимёнными WaybillProduct values.

## Владельцы записи и конкурирующие write paths

| Объект/поля | Основные writers AS-IS | Особенности |
|---|---|---|
| `receiving_order` business fields/status | ReceivingOrderService, lifecycle endpoints, inbound actions, route operations | Часть полей immutable в JPA/service; status меняется отдельными actions, не generic update |
| root stored totals | Good, Cargo, Container, ContainerItem, RequestedService, Blackbox services; отдельные migrations/actions | Одни и те же totals имеют разные формулы и могут зависеть от последнего writer |
| `receiving_order_transport` | Direct create/update transport service | Shared ID; URL/body/root IDs не образуют доказанной тройной сверки |
| Good | Direct/list services; WMS пишет actual quantity | List self-call transaction boundary не подтверждена |
| Cargo | Direct service; auto-create из Good; copy | Пересчитывает часть root totals и cargo-place services |
| ReceivingOrderContainer | Direct service, Excel parser, copy; TOS actual/status | Direct service и Excel используют разные validation/total paths |
| ContainerItem | Direct/list service, Excel/parser paths | Одновременно меняет parent gross и root goods price/weight по другой формуле |
| RequestedService | Direct service, required DAO insert при root create, cargo/container auto-reprice, WMS/TOS actual | Required/auto paths не всегда пересчитывают root stored totals |
| Blackbox | Direct/list service, copy, Excel DAO | Direct меняет counter, Excel его не меняет; repeated delete способен повторить decrement |
| Waybill root/children | Datareon first create; Excel parser и KIS-3631 migration для части модели | Datareon repeat меняет только root status; children не синхронизируются |
| Waybill task statuses | Route/manifest exporters, `CARRIAGE_ARRIVED`, TOS receiving | WRC/WC status lifecycle не является soft-delete |
| ReceivingOrder ↔ Waybill link | Single relink/unlink и bulk replacement endpoints/migration | Не проверяет предметный status/client ownership в найденной source chain |
| `grouped_waybill` | Liquibase create и async Datareon AFTER_COMMIT refresh | Excel/child writers не публикуют refresh event; ошибка refresh только логируется |

## Aggregate authority: одного источника нет

```mermaid
flowchart LR
    G[ReceivingOrderGood] -->|distinct item; sum totalPrice| R[(ReceivingOrder stored totals)]
    C[ReceivingOrderCargo] -->|row counts; sum cargo weight| R
    RC[ReceivingOrderContainer] -->|container count; sum parent gross| R
    I[ContainerItem] -->|sum item price; gross without tare| R
    S[RequestedService] -->|active count; sum price without VAT| R
    B[Blackbox direct] -->|increment or decrement cargo count| R
    EX[Blackbox Excel] -. inserts rows without counter update .-> R
    W[WaybillProduct live read] -->|overrides detailed totalWeight| D[ReceivingOrderDetailedDto]
    R --> D
    MV[grouped_waybill snapshot] --> GD[GroupedWaybillDto]
    WL[Live Waybill and Product lookup] --> GD
```

Критические значения для требований нужно называть полностью:

- `receiving_order.total_weight` — stored колонка с несколькими writers;
- `ReceivingOrderDetailedDto.totalWeight` — может быть заново вычислен по `WaybillProduct.weight`;
- `receiving_order_container.weight` — gross parent = tare + item gross в item path;
- `waybill_container.weight/net_weight` — отдельный snapshot, не те же колонки;
- `grouped_waybill.container_count` — число физических WC rows последнего refresh, не stored root `total_container_quantity`;
- `total_goods_price` — Good path суммирует `good.totalPrice`, Item path суммирует `item.price`.

Без указания endpoint/event, physical column и момента чтения формулировка «общий вес/количество/стоимость заявки» неоднозначна.

## Удаление и каскады

Большинство mutable receiving-коллекций (`Good`, `Cargo`, `Container`, `ContainerItem`, `RequestedService`, `Blackbox`) используют soft-delete, но их FK физически остаются; shared `ReceivingOrderTransport` soft-delete не имеет. В просмотренных CREATE/ALTER для этих parent links `ON DELETE CASCADE` не задан, поэтому physical delete корня/справочника обычно должен встретить FK NO ACTION, пока ссылки не удалены физически. JPA cascade `PERSIST/MERGE` у shared transport не означает database delete cascade.

Waybill-side children, напротив, физические и образуют cascade tree:

`waybill → WRC → WC → ZPU`, а также `waybill → Product/SpecialMark/TariffMark`.

Удаление WRC не удаляет Waybill или глобальный RailwayCarriage, но удаляет его WC/ZPU. Compatibility cleanup затем пытается soft-delete matching ReceivingOrderContainer; результат зависит от ORM flush order и не подтверждён integration test. Удаление глобальных RailwayCarriage/Container/ETSNG/DangerProduct при существующих FK не каскадируется.

## Что база не проверяет за сервис

- Contract, ClientGood, Batch, Cargo, Container и справочники не обязательно принадлежат клиенту/договору заявки только потому, что их FK существуют.
- `receiving_order_cargo.receiving_order_id` может не совпадать с root товарной строки.
- `receiving_order_container_item.receiving_order_id` может не совпадать с root parent container.
- Одна physical Waybill может быть связана только с одной ReceivingOrder, но bulk API способен перепривязать её без проверки прежнего owner/status.
- Duplicate Good/Cargo/Container/Item/Service/Blackbox и WRC/WC/ZPU/Product/marks rows в большинстве случаев допускаются схемой.
- Числовые формулы, положительность, net≤gross, сумма цен и единицы измерения в основном не закреплены CHECK constraints.
- Soft-deleted receiving rows продолжают занимать ID/FK и могут участвовать в нестандартных direct-ID/read/join paths.
- Materialized view не гарантирует транзакционную актуальность и не является доказательством состояния базовых таблиц.

## Чек-лист проверки будущего ТЗ

1. Назвать authoritative physical table/column и response DTO, а не только бизнес-термин.
2. Указать writer: HTTP endpoint, Excel, Datareon action, migration или автоматический пересчёт.
3. Разделить create, update, repeat/idempotency и concurrent create.
4. Проверить parent ownership не только отдельными FK, но и composite business consistency.
5. Явно решить, нужен DB UNIQUE/CHECK/index или достаточно service validation.
6. Указать soft-delete либо physical delete и требуемый cascade для каждого child.
7. Для totals определить формулу, единицы, округление и момент пересчёта всех write paths.
8. Для Waybill children определить snapshot versus live global reference.
9. Для grouped/read views указать допустимую задержку, refresh triggers, retry/monitoring и стабильный ключ пагинации.
10. Добавить negative и concurrency tests на расхождение parent IDs, дубль и позднюю ошибку транзакции.

## Проверки, история и границы достоверности

Сводка сопоставлена со всеми 14 детальными документами, их SQL/JPA/service/test sources и текущей навигацией. Она исправляет только инвентарное число физических таблиц; предметные выводы исходных частей не переопределяет.

Крупные изменения контура: `11de1385` (исходные receiving children), `be2fd261` (delivery/blackbox), `feb37a42` (Waybill aggregate и grouped view), `ce939d57`/`443ae69a` (KIS-3631 migration и новая receiving↔Waybill модель), `19cb1665`/`229c7d86` (refresh lifecycle), `4ff9dac6` (DangerProduct), `4e55d447` (актуальный Waybill input mapping), `42eee4ee` (Waybill filters/meta). Точные commits отдельных полей остаются в паспортах частей 1–14.

Тесты в этом подэтапе не запускались. Не проверены applied Liquibase chain/`pg_catalog`, реальные данные и дубли, runtime roles/client restrictions, generated MapStruct, transaction boundaries, cascade/flush order, async refresh и внешние Datareon/1С/ЭТРАН contracts. До такой проверки карта пригодна для анализа и ревью ТЗ, но не должна выдаваться за production schema dump.
