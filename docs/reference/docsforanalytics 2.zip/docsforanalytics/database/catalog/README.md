# Каталог физических объектов БД

Каталог связывает предметные таблицы и read-модели с исходным кодом и подробными source-level паспортами. Это навигационный слой, а не утверждение о состоянии конкретной production-схемы: применённость Liquibase, фактические данные и `pg_catalog` требуют проверки в целевом окружении.

Для новых паспортов используйте [единый шаблон](../templates/table.md). В качестве первого образца полного табличного паспорта используйте [корень заявки на вывоз `shipping_order`](../shipping-order-root-as-is.md); он уже содержит трассировку DTO → service/JPA → SQL, ограничения, индексы, изменения миграций, тесты и открытые вопросы. Подробная карта всего агрегата доступна в [integrity-карте ShippingOrder](../shipping-order-integrity-map.md).

## Уже описанные объекты

### Заявки на поставку

| Объект | Паспорт |
|---|---|
| `receiving_order` | [Корень заявки](../receiving-order-root-as-is.md) |
| `receiving_order_transport` | [Транспорт](../receiving-order-transport-as-is.md) |
| `receiving_order_good` | [Номенклатура](../receiving-order-good-as-is.md) |
| `receiving_order_cargo` | [Грузовое место](../receiving-order-cargo-as-is.md) |
| `receiving_order_container` | [КТК](../receiving-order-container-as-is.md) |
| `receiving_order_container_item` | [Содержимое КТК](../receiving-order-container-item-as-is.md) |
| `receiving_order_requested_service` | [Дополнительная услуга](../receiving-order-requested-service-as-is.md) |
| `receiving_order_blackbox` | [Blackbox](../receiving-order-blackbox-as-is.md) |
| ReceivingOrder ↔ Waybill | [Сводная integrity-карта](../receiving-order-waybill-integrity-map.md) |

### Накладные Waybill / железнодорожный контур

| Объект | Паспорт |
|---|---|
| `waybill` | [Корень Waybill](../waybill-root-as-is.md) |
| `waybill_railway_carriage` | [Вагон](../waybill-railway-carriage-as-is.md) |
| `waybill_container`, `waybill_zpu` | [КТК и ЗПУ](../waybill-container-as-is.md) |
| `waybill_product` | [Груз](../waybill-product-as-is.md) |
| `waybill_special_mark`, `waybill_tariff_mark` | [Отметки](../waybill-marks-as-is.md) |
| `grouped_waybill` | [Материализованная read-модель](../grouped-waybill-as-is.md) |

### Заявки на вывоз

| Объект | Паспорт |
|---|---|
| `shipping_order` | [Корень заявки](../shipping-order-root-as-is.md) |
| `shipping_order_transport` | [Транспорт](../shipping-order-transport-as-is.md) |
| `shipping_order_good` | [Номенклатура](../shipping-order-good-as-is.md) |
| `shipping_order_cargo` | [Грузовое место](../shipping-order-cargo-as-is.md) |
| `shipping_order_container`, `shipping_order_container_item` | [КТК и содержимое](../shipping-order-container-as-is.md), [позиции](../shipping-order-container-item-as-is.md) |
| `shipping_order_requested_service` | [Дополнительная услуга](../shipping-order-requested-service-as-is.md) |
| `shipping_order_blackbox` | [Blackbox](../shipping-order-blackbox-as-is.md) |
| `shipping_order_railway_carriage` | [Физический вагон](../shipping-order-railway-carriage-as-is.md) |
| `shipping_order_etran_invoice` | [Связь с ЭТРАН](../shipping-order-etran-invoice-as-is.md) |
| `shipping_order_railway_carriage_qty` | [Плановое количество вагонов](../shipping-order-railway-carriage-qty-as-is.md) |
| `shipping_order_container_qty` | [Плановое количество КТК](../shipping-order-container-qty-as-is.md) |
| `shipping_order_etsng_code` | [Груз планового КТК](../shipping-order-etsng-code-as-is.md) |
| ShippingOrder aggregate | [Сводная integrity-карта](../shipping-order-integrity-map.md) |

## Очередь покрытия

Каталог пока не является полным перечнем всех таблиц и представлений ALIS. Следующие приоритеты — `container` и связанные объекты владельца/остатков/движения, затем route-таблицы и все используемые rerunnable views. Для каждого объекта нужно установить точное имя и цепочку изменений по коду и Liquibase, прежде чем фиксировать физические колонки.

Связи правил с endpoint/DTO уже частично описаны в соседних разделах, но полный реестр `правило → API → таблица → интеграция → тест` ещё не собран. См. [матрицу покрытия](../../_meta/coverage-matrix.md) и [открытые вопросы](../../traceability/analyst-open-items-registry.md).
