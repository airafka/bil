# `shipping_order_etsng_code`: груз планового КТК, физическая модель AS-IS (часть 29)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, nested DTO/mapper/service/JPA, cumulative SQL migrations, parent container qty API, accept-validator, meta/route/outbound consumers и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Строка принадлежит [`shipping_order_container_qty`](shipping-order-container-qty-as-is.md) и описывает код ЕТСНГ с массой для плановой строки КТК без конкретного номера.

## HTTP-контракт: только вложенный ресурс

Отдельного controller и самостоятельных HTTP endpoints для `shipping_order_etsng_code` в текущих исходниках нет. Ресурс доступен только через parent-контракт:

| Endpoint parent | Роль `ShippingOrderEtsngCodeDto` |
|---|---|
| `POST /shipping-order/{shippingOrderId}/shipping-order-container-qty/list` | Возвращается как `containerQty.items[]`. |
| `PUT .../shipping-order-container-qty/merge` | Принимается как полный желаемый `items[]` каждой parent-строки. |
| `POST .../shipping-order-container-qty/meta/etsngCode` | Возвращает значения кодов, но IDs в `IdsCodeDto` — ID **parent container qty**, а не child row. |
| `POST .../shipping-order-container-qty/meta/weight` | Аналогично группирует parent IDs по строковому значению веса. |

Основной DTO — [`ShippingOrderEtsngCodeDto`](../dto/catalog/shippingorderetsngcode/ShippingOrderEtsngCodeDto.md). [`CreationDto`](../dto/catalog/shippingorderetsngcode/ShippingOrderEtsngCodeCreationDto.md) и [`UpdateDto`](../dto/catalog/shippingorderetsngcode/ShippingOrderEtsngCodeUpdateDto.md) создаются mapper'ом внутри parent merge; прямого controller input для них нет.

## DTO и фактическая обязательность

| Поле nested DTO | Bean Validation | SQL | Фактическое использование |
|---|---|---|---|
| `id` | nullable | UUID PK | `null` создаёт child; существующий scoped ID обновляет его. |
| `etsngCode` | `@NotNull` | UUID NOT NULL, FK → `etsng_code(id)` | Mapper передаёт ID, service загружает существующий глобальный справочник. |
| `weight` | `@NotNull`, `@Min(0)` | `NUMERIC(16,3) NOT NULL CHECK (weight > 0)` | Масса сохраняется как передана; `0` допустим по DTO, но запрещён БД. |

Parent-поля `ShippingOrderContainerQtyDto.items` и `CreationDto.items` не имеют `@Valid`. Поэтому controller-level `@Valid` проверяет сам parent и `items @NotNull`, но **не каскадирует** `@NotNull/@Min` каждого child DTO. Возможны service/JPA/DB-ошибки для null child, отсутствующего `etsngCode`, null/zero/negative weight вместо предсказуемой Bean Validation ошибки.

`IdCodeNamedDto` также не помечен `@Valid`: ненулевой объект без `id` не блокируется этим DTO-контрактом. На create/change service вызывает `EtsngCodeDaoService.findById`, поэтому неизвестный или отсутствующий ID разрешается уже серверным lookup.

SQL `NUMERIC(16,3)` ограничивает точность и масштаб сильнее DTO: Java не задаёт `@Digits`. Единица измерения и смысл массы — на один КТК или на всю qty-строку — validation/service-кодом не зафиксированы; умножения на `containerQty.quantity` нет.

## SQL contract

Таблица создана миграцией [`KIS-3352`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql).

| Колонка | Текущий source contract | Смысл |
|---|---|---|
| `id` | `UUID PRIMARY KEY` | ID дочерней строки. |
| `shipping_order_container_qty_id` | `UUID NOT NULL`, FK → `shipping_order_container_qty(id)` | Parent qty-КТК; `ON DELETE` не задан. |
| `etsng_code_id` | `UUID NOT NULL`, FK → `etsng_code(id)` | Глобальный справочный код; `ON DELETE` не задан. |
| `weight` | `NUMERIC(16,3) NOT NULL CHECK (weight > 0)` | Положительная масса. |

Сущность наследует только `BaseIdentifier`: нет `deleted` и audit-полей. Удаление физическое.

[`KIS-3663`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260330_KIS-3663_add_unique_constraints_for_numberless_shipping_order.sql) добавил `UNIQUE(shipping_order_container_qty_id, etsng_code_id, weight)`. Он запрещает только точный дубль code+weight внутри одного parent:

- один код с разными весами разрешён;
- разные коды с одинаковым весом разрешены;
- тот же code+weight в другом parent разрешён;
- numeric-значения, равные после приведения к scale БД, конфликтуют.

Unique constraint создаёт индекс с префиксом parent ID. Отдельного индекса по одному `etsng_code_id` в просмотренной цепочке не найдено.

## Merge и принадлежность parent

[`ShippingOrderEtsngCodeService.merge`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderetsngcode/ShippingOrderEtsngCodeService.java) получает parent ID от container qty service, подставляет его во все внутренние UpdateDto и вызывает scoped `upsertAndDelete`:

- `id=null` → create;
- ID существующего child данного parent → update;
- отсутствующий ID → physical delete;
- ID child другого parent → `NotFoundException`, потому что он вне filter scope.

При update parent не меняется: service обновляет только справочник ЕТСНГ при отличии и `weight`. Таким образом, перенос child между parent не является поддержанной операцией merge.

Child merge помечен `@Transactional` и вызывается из транзакционного parent merge. Parent delete сначала вызывает `removeAllForShippingOrderContainerQtyId`, физически удаляет children, затем удаляет parent. FK cascade отсутствует; порядок обеспечивает application service.

```mermaid
flowchart TD
    P[ContainerQty.items полный список] --> M[Map parent ID в каждый child]
    M --> D[Удалить отсутствующие child IDs]
    D --> U[Update scoped IDs]
    D --> A[Create строк с id=null]
    U --> V{Parent не порожний, status разрешён?}
    A --> F{fillingType RAILWAY_CARRIAGE или NONE?}
    F --> V
    V -->|нет| R[Rollback parent merge]
    V -->|да| C{FK, weight > 0, exact UNIQUE соблюдены?}
    C -->|нет| R
    C -->|да| O[Строки доступны list/meta/route/outbound]
```

## Filling type, статус и порожний parent

Create разрешён только когда заявка parent находится в `RAILWAY_CARRIAGE` или `NONE`. Для `NONE_CONTAINER` items должны отсутствовать; для `ALL/CONTAINER` используется физический `shipping_order_container_item`, а не эта таблица.

Перед create service:

1. Загружает parent qty и его заявку.
2. Проверяет статус через общий `OrderServiceUtils.checkOrderStatusForUpdate`.
3. Проверяет allowed filling type.
4. Отклоняет `parent.empty=true` ошибкой `ShippingOrderContainerQty.ContainerIsEmpty`.

Update проверяет статус и порожность **существующего** parent, но повторно не проверяет filling type. Remove проверяет только статус и намеренно позволяет очистить children. Поэтому stale child после смены filling type может быть удалён; при неконсистентном непорожнем parent он также может быть обновлён вне обычного parent merge.

Общий status helper в `ON_REVIEW` использует жёстко заданное receiving-право, несмотря на изменение shipping-объекта.

## Уникальность parent-линий

Child DB UNIQUE не заменяет проверку дубликатов container qty lines. После полного parent merge [`ShippingOrderContainerQtyService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyService.java) сравнивает полный отсортированный набор `etsngCode.id + weight.stripTrailingZeros()` вместе с parent `type` и `empty`.

Ранее созданные `ShippingOrderEtsngCodeRepository.existsDuplicateContainerLine` и соответствующий DAO-метод проверяют лишь наличие одной совпадающей child-комбинации в другом parent. В текущих исходниках вызовов этих методов не найдено: актуальное правило перенесено на уровень полного parent signature. Это важно не принимать за действующую дополнительную validation.

## Read, filter и meta

Самостоятельного child list API нет. Parent list пакетно загружает children для множества parent IDs, группирует по `shippingOrderContainerQty.id` и возвращает их в `items[]`.

Child filter поддерживает parent, `etsngCode`, `weight`, ID/anyOfId и используется внутренними service/DAO. Parent API поднимает nested filtering через коррелированный `EXISTS`: если одновременно заданы код и вес, они должны встретиться в одной child-строке.

Nested parent meta использует LEFT JOIN и группирует по значению кода/веса. В `IdsCodeDto.ids` помещаются parent container qty IDs. Для parent без items формируется meta-группа с `code=null`; weight форматируется через `stripTrailingZeros().toPlainString()`.

[`shipping_route_container_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_shipping_route_containers.sql) разворачивает по одной строке на каждый child. Поэтому один parent UUID повторяется в view для разных ЕТСНГ, хотя JPA `ShippingRouteContainerView.id` объявлен идентификатором. Route meta работает через field projection, но view не даёт уникальный entity ID на физическую строку представления.

## Route read, accept и outbound

Route container read для `RAILWAY_CARRIAGE/NONE/NONE_CONTAINER` возвращает каждый child как `items[].etsngCode` и `grossWeight`; сервер не агрегирует веса и не умножает их на parent quantity.

Accept-validator напрямую читает children только в специальной ветке `NONE_CONTAINER`, где требует их полное отсутствие. Для `RAILWAY_CARRIAGE/NONE` он не проверяет наличие items, суммарный вес или соответствие количеству КТК.

[`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) экспортирует каждую строку как `{id, shippingOrderContainerQtyId, etsngCodeId, weight}` и добавляет глобальные справочники ЕТСНГ. Экспортер собирает все qty parents заявки без фильтра по текущему filling type, поэтому stale children также могут попасть в package.

Inbound writers этой таблицы в production source не найдены: текущий контур является плановым вводом через parent merge.

## Тесты и пробелы покрытия

[`ShippingOrderEtsngCodeServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderetsngcode/ShippingOrderEtsngCodeServiceIntegrationTest.java) содержит один прямой тест: одинаковый код с разным весом в двух parent разрешён. Parent [`ShippingOrderContainerQtyServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyServiceIntegrationTest.java) проверяет nested create/update/delete, exact DB duplicate и partial/full signature; отдельного production-like rollback-теста поздней ошибки нет. В этом подэтапе тесты не запускались.

Не найдены прямые tests для HTTP nested validation, null item/code/weight, zero/negative/oversized weight, порожнего parent, запрещённого filling type, status/permission, cross-parent child ID, parent physical cascade, meta null/group IDs, route flattened view, accept weight semantics, stale export и concurrency.

## Влияющие commits

- `d29256da` (`KIS-3352`) — физические qty/ETSNG-таблицы.
- `55be7d74` (`KIS-3358`) — JPA entity/DAO/service дочернего ЕТСНГ.
- `2f91bc07` (`KIS-3359`) — первоначальный API безномерных данных.
- `b33f9401` (`KIS-3360`) — текущий nested parent API/full-replace.
- `9ca9eb80`, `4b61d802`, `2f962915` (`KIS-3663`) — DB UNIQUE, прежняя child-проверка и перенос актуальной duplicate validation на parent signature.
- `4c7d689b` — предметная ValidationException для груза порожнего КТК.
- `23723581` (`KIS-4015`) — `name` в ответе ЕТСНГ через `IdCodeNamedDto`.
- `cd8ab542` — scoped nested meta.
- `49ce562d`/`6557b9e8` (`KIS-4450`) — route meta-view/endpoints.
- `4ff9eb7c`/`0b2c6b91` (`KIS-3809`) — route chain package.

## Чек-лист для проверки ТЗ

- В каких единицах хранится `weight` и относится ли он к одному КТК или всей qty-строке?
- Должен ли вес умножаться на `containerQty.quantity` в итогах/отчётах?
- Нужны ли `@Valid` на `items` и `@Positive`/`@Digits` вместо `@Min(0)`?
- Допускается ли один ЕТСНГ несколько раз с разными весами внутри parent?
- Должны ли container lines без items быть разрешены для `RAILWAY_CARRIAGE/NONE`?
- Как очищаются stale children при смене filling type?
- Нужна ли DB cascade или audit вместо физического application-delete?
- Какие IDs возвращает nested meta — parent или child — и соответствует ли это UI?
- Должен ли outbound фильтровать qty/items по текущей модели заявки?

## Связанные документы

- [Плановое количество КТК](shipping-order-container-qty-as-is.md)
- [Физический КТК заявки](shipping-order-container-as-is.md)
- [Содержимое физического КТК](shipping-order-container-item-as-is.md)
- [Route: план/факт и meta](../business-rules/route-shipping-plan-fact-as-is.md)
- [Сводная integrity-карта ShippingOrder](shipping-order-integrity-map.md)
