# `shipping_order_etran_invoice`: ЭТРАН-накладная заявки на вывоз, физическая модель AS-IS (часть 26)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations, accept-validator, вагонный каскад, outbound-код и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Таблица хранит не саму накладную, а связь [`shipping_order`](shipping-order-root-as-is.md) с глобальной `etran_invoice`; физические вагоны описаны в [части 25](shipping-order-railway-carriage-as-is.md).

## Endpoint → DTO → service

Основные DTO: [`CreationDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceCreationDto.md), [`UpdateDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceUpdateDto.md), [`MergeDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceMergeDto.md), [`Dto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceDto.md) и [`ShortDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceShortDto.md).

| Endpoint | DTO / результат | Реализованная логика и ограничения |
|---|---|---|
| `POST /shippingorderetraninvoice/all` | optional filter → `ShortDto[]` | Legacy-список без `@Secure` в [`ShippingOrderEtranInvoiceController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderetraninvoice/ShippingOrderEtranInvoiceController.java). Runtime-защита gateway/security chain не проверена. |
| `POST /shippingorderetraninvoice/page` | paged filter → `Page<Dto>` | Требует `ShippingOrder.EtranInvoice/READ`. |
| `POST /shippingorderetraninvoice/meta/{fieldName}` | optional paged filter → meta values | READ; alias-поля переводятся на вложенные поля глобальной накладной. |
| `GET /shippingorderetraninvoice/{id}` | `Dto` | Path ID — идентификатор **строки связи**. |
| `POST /shippingorderetraninvoice/` | `CreationDto` → `Dto` | `shippingOrder` и `etranInvoice` обязательны через `@Valid @NotNull`; CREATE. |
| `PUT /shippingorderetraninvoice/{id}` | `UpdateDto` → `Dto` | Controller не принимает `@PathVariable id`: изменяемая строка определяется по `body.id`, URL и тело не сверяются. |
| `DELETE /shippingorderetraninvoice/{id}` | `Dto` | Soft-delete связи, затем application-cascade на вагоны/КТК/items этой заявки и накладной. |
| `POST /shippingorderetraninvoice/{shippingOrderId}` | `UpdateDto[]` → `Dto[]` | Legacy full-replace по заявке через `upsertAndDelete`; требуется только DELETE, хотя операция создаёт и обновляет строки. |
| `POST /shipping-order/{shippingOrderId}/shipping-order-etran-invoice/page` | optional paged filter → `Page<Dto>` | V2 read; path ID принудительно заменяет `filter.shippingOrder`. |
| `POST .../list` | optional filter → `Dto[]` | V2 read с тем же scope. |
| `POST .../meta/{fieldName}` | optional filter → meta values | V2 read с тем же scope. |
| `POST /shippingorder/{shippingOrderId}/shipping-order-etran-invoice/merge` | `MergeDto[]` → `void` | V2 full-replace, HTTP `200`; путь write-controller использует `/shippingorder` без дефиса, в отличие от `/shipping-order` read API. На методе и классе нет `@Secure`. |

Полный декларативный перечень доступен в [generated endpoint-каталоге](../api/endpoints-generated.md#shippingorderetraninvoicecontroller).

## Идентификаторы DTO: опасная неоднозначность

Detailed `Dto.id`, `UpdateDto.id`, `MergeDto.id` и path ID CRUD обозначают UUID строки `shipping_order_etran_invoice`. Но [`ShippingOrderEtranInvoiceMapper.toShortDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderetraninvoice/ShippingOrderEtranInvoiceMapper.java) явно записывает в `ShortDto.id` значение `etranInvoice.id`, а в `code` — `etranInvoice.code`.

Следовательно, `POST /all` возвращает в верхнеуровневом `id` **UUID глобальной накладной**, который нельзя безопасно передавать в `GET/PUT/DELETE /{id}` как UUID строки связи. В ТЗ и интеграционном контракте следует всегда различать:

- `shippingOrderEtranInvoiceId` — ID строки связи;
- `etranInvoiceId` — ID глобальной накладной;
- `shippingOrderId` — ID заявки.

## SQL contract

Таблица создана миграцией [`ALG-631`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240823_ALG-631_add_table_shipping_order_etran_invoice.sql).

| Колонка | Текущий source contract | Семантика |
|---|---|---|
| `id` | `UUID PRIMARY KEY NOT NULL` | ID строки связи. |
| `shipping_order_id` | `UUID NOT NULL REFERENCES shipping_order(id)` | Родительская заявка; `ON DELETE` не задан. |
| `etran_invoice_id` | `UUID NOT NULL REFERENCES etran_invoice(id)` | Глобальная shipping-накладная; `ON DELETE` не задан. |
| `deleted` | `BOOLEAN NOT NULL DEFAULT false` | Soft-delete. |
| `created_at`, `created_by` | `TIMESTAMP NOT NULL`, `VARCHAR(50) NOT NULL` | Audit из `BaseEditable`. |
| `updated_at`, `updated_by` | nullable | Audit обновления. |

В просмотренной цепочке не найдены `UNIQUE(shipping_order_id, etran_invoice_id)`, отдельные индексы на два FK или последующие ALTER этой таблицы. Поэтому физическая схема допускает несколько активных и удалённых строк одной пары и не защищает конкурентный create.

Миграция [`KIS-1621`](../../../db-layer/src/main/resources/db/changelog/v.1.26.0/v.1.26.0_20250826_KIS-1621_add_consignee_client_in_etran_invoice.sql) не меняет таблицу связи, но использует её как источник для глобальной `etran_invoice`: накладные, отсутствующие в receiving-связях, получают `is_for_receiving_order=false` и `consignee_client_id` из `shipping_order.legal_entity_id`. Это историческая миграция данных, а не runtime-проверка принадлежности.

## Серверная валидация и условная обязательность

[`ShippingOrderEtranInvoiceService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderetraninvoice/ShippingOrderEtranInvoiceService.java) при create:

1. Загружает заявку и вызывает общий `OrderServiceUtils.checkOrderStatusForUpdate`.
2. Загружает глобальную накладную и проверяет только её направление: `isForReceivingOrder` должно быть `false`.
3. Проверяет application-level отсутствие активной пары заявка+накладная.

Проверки того, что `consigneeClient` накладной совпадает с клиентом/грузополучателем конкретной заявки, не найдено. Прямой CRUD/merge также не ограничивает `fillingType`.

При переводе заявки через [`ShippingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) хотя бы одна такая связь обязательна только для `terminalArea=CONTAINER`, `transportType=RAILWAY`, `fillingType=ALL`. Для `RAILWAY_CARRIAGE`, `CONTAINER` и `NONE` эта таблица accept-validator'ом не требуется. Production-вызов `ShippingOrderService.accept(UUID)` в текущих исходниках ранее не найден, поэтому это service-level правило, а не подтверждённый HTTP-сценарий.

Общий status helper разрешает изменение в `DRAFT`, а в `ON_REVIEW` проверяет permission. В нём жёстко указано receiving-право `RECEIVING_ORDER_SEND_TO_ACCEPT`, хотя изменяется дочерняя строка shipping-заявки.

## Уникальность: update пропускает конфликт

`checkIfAlreadyExists` считает активные строки по `(shippingOrder, etranInvoice)`:

- create отклоняется при `count > 0`;
- update отклоняется только при `count > 1`;
- soft-deleted строки обычно не входят в стандартную выборку и не мешают повторному созданию.

Если строку A обновить на пару, уже занятую ровно одной другой строкой B, count будет равен `1`, проверка пройдёт и появится активный дубль. Даже корректный прикладной check не закрыл бы параллельные запросы без DB UNIQUE.

## Update, merge и границы заявки

Обычный update способен изменить одновременно и заявку, и накладную. Проверка статуса выполняется для **старой** заявки; для новой заявки повторная status/access-проверка не выполняется. Path ID controller игнорируется.

V2 merge загружает заявку через прямой `shippingOrderDaoService.getById`, преобразует каждый `MergeDto` в `UpdateDto` с path `shippingOrderId` и вызывает `upsertAndDelete` по всей заявке. Поэтому отсутствующая во входе строка soft-удаляется. Пустой список означает очистку всех связей заявки. Отдельный `findAvailableShippingOrder`/client row-level scope и `@Secure` для merge не найдены.

Legacy bulk также является full-replace по path-заявке, но DTO содержит собственный `shippingOrder`; соответствие body и path зависит от общей реализации `upsertAndDelete` и отдельно controller'ом не валидируется.

## Каскад на вагоны: delete и update несимметричны

`postRemove` вызывает `ShippingOrderRailwayCarriageService.removeAll(softRemovedModel)`. Он soft-удаляет физические вагоны с той же заявкой и той же глобальной накладной, а wagon remove-path далее soft-удаляет связанные КТК и их item-строки. Это application cascade, а не FK `ON DELETE CASCADE`.

Изменение связи работает иначе: при переносе строки в другую заявку или замене `etranInvoice` связанные вагоны не переносятся и не удаляются. Вагоны содержат прямой FK на глобальную `etran_invoice`, а не FK на строку `shipping_order_etran_invoice`. Поэтому update способен оставить вагоны старой пары без membership-строки; grouped wagon read и accept-валидация могут видеть контур иначе, чем физические wagon rows.

```mermaid
flowchart TD
    R[POST merge / create / update] --> V{DTO @NotNull и shipping-направление ETRAN}
    V -->|ошибка| X[Запрос отклонён]
    V -->|успех| U{Активная пара уже есть?}
    U -->|create: count > 0| X
    U -->|update: count > 1| X
    U -->|иначе| S[Сохранить связь]
    M[Строка отсутствует в full-replace или DELETE] --> D[Soft-delete связи]
    D --> W[Soft-delete вагонов той же заявки и ETRAN]
    W --> C[Soft-delete связанных КТК]
    C --> I[Soft-delete container items]
    S -. update пары не каскадирует .-> G[Вагоны старой пары могут остаться]
```

## Outbound

Миграция [`ALG-682`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240905_ALG-682_add_transport_manifest_outbound_config.sql) исторически добавляла DB-конфигурацию `SHIPPING_ORDER_ETRAN_INVOICE`. После перехода конфигурации в код commit `57c7ca6c` не включил этот entity type в текущий `OutboundConfigService.CONFIGURATION`.

Поэтому child `postAdd` и update-outbound закомментированы как dead code. Deprecated `getListOfEntitiesToOutbound` мог бы выбрать активные вагоны этой заявки/накладной для `SHIPMENT_TRANSPORT_MANIFEST`, но текущий child path его не вызывает. Фактическая source-level сборка manifest выполняется от корневой заявки и оперирует вагонами с их прямой ссылкой на глобальную накладную; membership-строка участвует прежде всего в UI/validation/cascade.

## Тесты и пробелы покрытия

[`ShippingOrderEtranInvoiceDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderetraninvoice/ShippingOrderEtranInvoiceDaoServiceTest.java) проверяет DAO add/update/delete/get/page/filter. Accept-validator tests используют связь в положительных и missing-ETRAN сценариях. В этом подэтапе тесты не запускались.

Прямых тестов не найдено для duplicate create/update hole, конкурентности, V2 merge/full-delete, отсутствия `@Secure`, path/body mismatch, переноса связи между заявками, cascade на wagon/container/item, ShortDto identity и child outbound.

## Влияющие commits

- `b67b2971` (`10-09-24`) — исходная таблица, controller/service/mapper и DB outbound-конфигурация.
- `845acb69` (`KIS-1621`) — разделение receiving/shipping глобальных накладных и backfill через эту связь.
- `57c7ca6c` (`KIS-1983`) — перенос outbound configuration из БД в код; child entity в текущую конфигурацию не вошла.
- `18d7e6d5` (`KIS-3644`) и `9d0c3087` — V2 merge и его исправление.
- `443ae69a` — последующие изменения feature-набора controllers/DTO.
- `cd8ab542` (`KIS-4365`) — scoped meta для nested shipping-order fields.

## Чек-лист для проверки ТЗ

- Какой UUID передаётся: строка связи или глобальная `etran_invoice`?
- Для какого `fillingType` связь должна быть обязательна и в какой точке процесса?
- Merge является полной заменой списка? Означает ли `[]` удаление всех накладных и каскадное удаление вагонов/КТК?
- Нужно ли запретить перенос связи между заявками и замену накладной после появления вагонов?
- Нужны ли DB UNIQUE `(shipping_order_id, etran_invoice_id)` и индексы обоих FK?
- Должны ли client/consignee накладной совпадать с конкретной заявкой?
- Какие permission и client row-level checks требуются для V2 merge и legacy `/all`?
- Должен ли update сверять path ID с body ID?

## Связанные документы

- [Корень заявки на вывоз](shipping-order-root-as-is.md)
- [Физический вагон заявки](shipping-order-railway-carriage-as-is.md)
- [Сводная integrity-карта ShippingOrder](shipping-order-integrity-map.md)
- [Бизнес-правила заявок на вывоз](../business-rules/shipping-orders.md)
- [Интеграции заявок](../business-rules/order-integrations.md)
