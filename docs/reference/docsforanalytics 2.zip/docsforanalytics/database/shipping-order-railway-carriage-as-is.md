# `shipping_order_railway_carriage`: вагон заявки на вывоз, физическая модель AS-IS (часть 25)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations, inbound/outbound consumers и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Корень заявки описан в [`shipping_order`](shipping-order-root-as-is.md), связанный КТК — в [`shipping_order_container`](shipping-order-container-as-is.md), а количественная модель без явных номеров вагонов (`shipping_order_railway_carriage_qty`) остаётся отдельным следующим контуром.

Строка связывает заявку с глобальным справочником `railway_carriage` и, опционально, напрямую с глобальной `etran_invoice`. Она одновременно является родителем для КТК заявки, task-объектом inbound-событий и элементом outbound-манифеста/route chain package.

## Endpoint → DTO → service

Основные DTO: [`CreationDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageCreationDto.md), [`UpdateDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageUpdateDto.md), [`Dto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageDto.md), [`MergeDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageMergeDto.md) и [`UnnumberedMergeDto`](../dto/catalog/shippingorderrailwaycarriage/UnnumberedShippingOrderRailwayCarriageMergeDto.md).

| Endpoint | DTO / результат | Реализованная логика и ограничения |
|---|---|---|
| `POST /shippingorderrailwaycarriage/all` | filter → `ShortDto[]` | Legacy-список. В [`ShippingOrderRailwayCarriageController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageController.java) отсутствует `@Secure`; фактическая runtime-защита gateway/security chain не проверена. |
| `POST /shippingorderrailwaycarriage/page` | paged filter → `Page<Dto>` | Требует `SHIPPING_ORDER_RAILWAY_CARRIAGE/READ`. |
| `GET /shippingorderrailwaycarriage/{id}` | `Dto` | Читает строку по path ID. |
| `POST /shippingorderrailwaycarriage/` | `CreationDto` → `Dto` | `railwayCarriage` и `shippingOrder` имеют `@NotNull`; `etranInvoice`, даты и owner-поля опциональны. Filling type заявки здесь не проверяется. |
| `PUT /shippingorderrailwaycarriage/{id}` | `UpdateDto` → `Dto` | Метод controller **не принимает path `id`**: обновляемая строка определяется только по `body.id`; URL и тело не сверяются. |
| `DELETE /shippingorderrailwaycarriage/{id}` | `Dto` | Soft-delete вагона и application-level soft-delete связанных КТК/item-строк. |
| `POST /shippingorderrailwaycarriage/{shippingOrderId}` | `UpdateDto[]` → `Dto[]` | Legacy full-replace по заявке через `upsertAndDelete`; permission — только `DELETE`, хотя операция создаёт и обновляет строки. |
| `POST /shippingorderrailwaycarriage/preview` | optional paged filter → `Page<PreviewDto>` | Body объявлен `required=false`, но [`preview`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageService.java) сразу обращается к `filter.getFilter()`: отсутствующий body должен привести к NPE. Используется permission контейнера `SHIPPING_ORDER_SHIPPING_ORDER_CONTAINER/READ`, а не вагона. |
| `POST /shippingorderrailwaycarriage/list/preview` | filter → nested wagon/container/item list | Требует `shippingOrder.id`, применяет user restriction и нормализует wagon/container IDs в границах заявки. |
| `POST /shipping-order/{shippingOrderId}/shipping-order-railway-carriage/page` | paged filter → `Page<Dto>` | V2 принудительно заменяет `filter.shippingOrder` на path ID. |
| `POST .../list` | filter → `MergeDto[]` | Возвращает группы по строкам `shipping_order_etran_invoice`; вагоны с `etran_invoice_id=null` или с накладной, не включённой в эту заявку, в результат не попадают. |
| `PUT .../merge` | `MergeDto[]` → `MergeDto[]` | Полная замена строк **всей заявки**, сгруппированных во входе по накладной ЭТРАН. |
| `POST .../unnumbered/list` | filter → `UnnumberedMergeDto[]` | Несмотря на имя `unnumbered`, разрешён только `fillingType=RAILWAY_CARRIAGE`; иначе `IllegalArgumentException`. |
| `POST .../meta/{fieldName}` и `/unnumbered/meta/{fieldName}` | paged filter → meta values | Оба пути вызывают один метод и scope-ятся path ID заявки. |
| `PUT .../unnumbered/merge` | `UnnumberedMergeDto[]` → список | Full-replace всей заявки; разрешён только `fillingType=RAILWAY_CARRIAGE`. |

V2 controller — [`ShippingOrderRailwayCarriageControllerV2`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageControllerV2.java). Полный декларативный список также есть в [generated endpoint-каталоге](../api/endpoints-generated.md#shippingorderrailwaycarriagecontroller).

## Когда нужны физические строки вагонов

[`ShippingOrderAcceptValidator.railwayCarriageChecks`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) вызывается для сочетания площадки `CONTAINER` и транспорта `RAILWAY`, но выбирает источник данных по `ShippingOrder.fillingType`:

| `fillingType` | Что требуется при accept | Требование к ЭТРАН |
|---|---|---|
| `ALL` | Хотя бы одна активная строка `shipping_order_railway_carriage` | У каждой строки должен быть `etranInvoice`; отдельно требуется хотя бы одна строка `shipping_order_etran_invoice`. |
| `RAILWAY_CARRIAGE` | Хотя бы одна активная строка `shipping_order_railway_carriage` | `etranInvoice` не требуется. |
| `CONTAINER` | Физические строки не требуются; проверяется `shipping_order_railway_carriage_qty` | Не применяется к этой таблице. В результате TOS физические строки могут быть созданы позже как факт. |
| `NONE` | Проверяется `shipping_order_railway_carriage_qty` | Не применяется к этой таблице. |

Прямой CRUD вагона эту матрицу не применяет и позволяет создать строку для заявки любого filling type. Кроме того, ранее установлено, что production-вызов `ShippingOrderService.accept(UUID)` в текущих исходниках не найден; validator описывает поведение service-level accept, а не подтверждённый HTTP-маршрут.

## SQL contract и история схемы

| Колонка | Текущий source contract | История |
|---|---|---|
| `id` | `UUID PRIMARY KEY NOT NULL` | Создана [`ALG-629`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240829_ALG-629_add_table_shipping_order_railway_carriage.sql). |
| `shipping_order_id` | `UUID NOT NULL REFERENCES shipping_order(id)` | Нет `ON DELETE`; отдельный индекс по этой колонке в просмотренных миграциях не найден. |
| `railway_carriage_id` | `UUID NOT NULL REFERENCES railway_carriage(id)` | [`KIS-2013`](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251201_KIS-2013_add_indexes_for_container_and_railway_carriage_ids.sql) добавил обычный индекс. Глобальные дубли `railway_carriage.code` позднее схлопнуты `KIS-3234`, после чего на справочнике восстановлен `UNIQUE(code)`. |
| `etran_invoice_id` | `UUID NULL REFERENCES etran_invoice(id)` | В ALG-629 был `NOT NULL`; [`ALG-799`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240917_ALG-799_drop_not_null_receiving_order_railway_carriage_etran_invoice.sql) снял ограничение. FK ведёт прямо на глобальную накладную, а не на `shipping_order_etran_invoice`. |
| `deleted` | `BOOLEAN NOT NULL DEFAULT false` | Soft-delete; default также закреплён в entity. |
| `status` | `VARCHAR(20) NULL` | Добавлен [`ALG-856`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240927_ALG-856_add_railway_carriage_status.sql); JPA — `TaskStatus` строкой. |
| `data_time_krugloye_pole` | `TIMESTAMP NULL` | Добавлен [`KIS-2003`](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251112_KIS-2003_refactoring_excel_template.sql). |
| `customer_services_id` | `UUID NULL REFERENCES client_related_entity(id)` | Добавлен KIS-2003. |
| `owner_railway_carriage_id` | `UUID NULL REFERENCES client_related_entity(id)` | Добавлен KIS-2003. |
| audit | `created_at/by` обязательны; `updated_at/by` nullable | Наследуются от `BaseEditable`. |

`railwayCarriageModelCode` — JPA `@Formula`, отдельной колонки в этой таблице нет. `dateDepotRepair` — `@Transient`: входное значение не сохраняется в строке заявки, а [`updateRailwayCarriage`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageService.java) записывает его в **глобальный справочник** `railway_carriage.date_depot_repair`. Таким образом, изменение одного wagon-row имеет побочный эффект для всех заявок и накладных, использующих тот же глобальный вагон.

В просмотренной цепочке нет `UNIQUE` для `(shipping_order_id, railway_carriage_id, etran_invoice_id)` или `(shipping_order_id, railway_carriage_id)`, нет CHECK для `status` и нет composite constraint, связывающего заявку вагона с заявкой дочернего КТК.

## Application-level уникальность не заменяет constraint

[`checkIfAlreadyExists`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageService.java) считает активные строки по заявке, вагону и — если она не `null` — накладной:

- при create одинаковая тройка блокируется `DuplicateEntityException`;
- разные накладные позволяют повторить один вагон в одной заявке;
- при `etranInvoice=null` фильтр накладной отсутствует, поэтому блокируется любой активный дубль пары заявка+вагон;
- soft-deleted строки обычно не входят в подсчёт и не мешают повторному созданию; физического UNIQUE нет;
- при update порог равен `existingCount > 1`. Если строка меняется на комбинацию, уже занятую **одной другой** строкой, count равен `1`, условие ложно и дубль сохраняется. Это application-level дефект, а не только отсутствие защиты от concurrency.

Параллельные create/update также не защищены транзакционным DB constraint.

## Nullable-поля, которые нельзя безопасно очистить

`customer_services_id` и `owner_railway_carriage_id` nullable и в SQL, и в DTO. Однако [`prepareModelToUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageService.java) при отличии значений без null-ветки вызывает `updateModel.getCustomerService().getId()` и `updateModel.getOwnerRailwayCarriage().getId()`. Если существующая ссылка заполнена, а клиент передаст `null`, `isNotEquals(existing, null)` будет истинным и update должен завершиться NPE. Для `etranInvoice` отдельная `else`-ветка очистку поддерживает; для двух owner-полей — нет. Прямого regression test не найдено.

## ЭТРАН: две разные ссылки и разрыв принадлежности

`shipping_order_railway_carriage.etran_invoice_id` ссылается на глобальную `etran_invoice`, тогда как UI merge группируется по строкам связи `shipping_order_etran_invoice`. [`OrderServiceUtils.checkThatEtranInvoiceForShippingOrder`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/OrderServiceUtils.java) проверяет только направление накладной (`isForReceivingOrder=false`), но не её принадлежность данной заявке.

Следствия:

1. Прямой create/update может связать вагон с shipping-накладной, которая не включена в текущую заявку.
2. `GET .../list` строит ответ только по `shipping_order_etran_invoice` этой заявки, поэтому такая строка и строка с `etran_invoice_id=null` будут невидимы в grouped UI-контракте.
3. `PUT .../merge` использует ID строки `shipping_order_etran_invoice` и тем самым обеспечивает membership для своего собственного пути, но неизвестный ID приводит к `orderEtranInvoices.get(...) == null` и последующему NPE на `etranInvoice.getId()`, а не к предметному `NotFoundException`.

## Связь с КТК и удаление

[`ALG-843`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240926_ALG-843_update_railway_carriage_link.sql) заменил у `shipping_order_container` ссылку на глобальный вагон ссылкой `shipping_order_railway_carriage_id → shipping_order_railway_carriage.id`, выполнив backfill по `(railway_carriage_id, shipping_order_id)`.

Физическая схема не гарантирует, что `shipping_order_container.shipping_order_id` совпадает с `shipping_order_railway_carriage.shipping_order_id`. [`ShippingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) загружает wagon-row только по ID и также не выполняет composite-проверку. Поэтому КТК одной заявки можно технически связать с wagon-row другой заявки, если вызывающий путь передаст такой ID.

Удаление wagon-row — soft-delete. `postRemove` вызывает `ShippingOrderContainerService.removeAllForCarriage`, который soft-удаляет связанные КТК, а их remove-path — item-строки. Это application cascade, а не `ON DELETE CASCADE`; integration test подтверждает ожидаемую последовательность на уровне кода, но тест в этом подэтапе не запускался. Удаление `shipping_order_etran_invoice` также вызывает `removeAll` вагонов этой заявки/накладной и далее тот же каскад.

## Merge scope и права

Оба V2 merge являются **full-order replace**: после преобразования вложенного DTO вызывается `super.upsertAndDelete(filterByShippingOrder, updateDtos)`. Строки заявки, отсутствующие во входе, soft-удаляются вместе со связанными КТК/items. Группировка DTO по ЭТРАН не сужает delete scope до одной накладной.

Read-методы `getList`, `getListForUnnumberedOrder` и `listPreview` сначала используют `findAvailableShippingOrder` и `FilterEnrichService`. Merge-методы загружают корень через прямой `shippingOrderDaoService.getById` и отдельно не вызывают `findAvailableShippingOrder`; достаточно ли controller permission для client row-level scope, по просмотренному коду не подтверждено. Все bulk/merge endpoints требуют только permission level `DELETE`, несмотря на одновременные create/update/delete операции.

Add/update/remove вызывают общий [`OrderServiceUtils.checkOrderStatusForUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/OrderServiceUtils.java). Поэтому изменение разрешено в `DRAFT`, а в `ON_REVIEW` зависит от permission check. Как уже отмечено в [модели транспорта вывоза](shipping-order-transport-as-is.md), общий helper жёстко проверяет `RECEIVING_ORDER_SEND_TO_ACCEPT`, даже когда изменяется дочерняя строка shipping-заявки.

## Inbound и outbound writers

- [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) для `fillingType=RAILWAY_CARRIAGE` находит строку по заявке+глобальному вагону и ставит `status=FINISHED`; для `fillingType=CONTAINER` создаёт новую строку с `status=FINISHED` по номеру транспорта из результата и привязывает к ней КТК.
- [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) блокирует wagon-row по inbound `taskId` и идемпотентно переводит его в `FINISHED`.
- Миграция ALG-682 когда-то добавляла DB-конфигурацию outbound для дочерней entity, но после перехода на code-based [`OutboundConfigService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) `SHIPPING_ORDER_RAILWAY_CARRIAGE` закомментирован. Прямой add/update wagon-row outbound не создаёт.
- [`ShippingOrderService.getListOfEntitiesToOutbound`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) при `SHIPMENT_TRANSPORT_MANIFEST` возвращает все активные wagon-rows корня. [`ShippingTransportManifestExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/shipping/transportmanifest/ShippingTransportManifestExportService.java) затем без null-guard читает `wagon.etranInvoice.departureStation/destinationStation`. Но accept-validator разрешает `etranInvoice=null` для `fillingType=RAILWAY_CARRIAGE`: если service-level accept будет вызван для такой заявки, построение манифеста имеет NPE-риск.
- [`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) независимо читает физические wagon-rows всего рейса и количественные строки, формируя два разных списка route chain package.

```mermaid
flowchart TD
    D[Creation / Update / Merge DTO] --> M[Mapper]
    M --> S[ShippingOrderRailwayCarriageService]
    S --> U{application duplicate check}
    U --> W[(shipping_order_railway_carriage)]
    W --> RC[(railway_carriage global)]
    W --> EI[(etran_invoice global, nullable)]
    W --> C[(shipping_order_container)]
    C --> CI[(shipping_order_container_item)]
    TOS[TOS_SHIPMENT_RESULT] -->|create or FINISHED| W
    ARR[CARRIAGE_ARRIVED] -->|FINISHED| W
    W --> TM[Shipment transport manifest via root accept]
    W --> RP[Shipping route chain package]
```

## Влияющие commits

| Commit | Влияние |
|---|---|
| `b67b2971` | Создание таблицы ALG-629. |
| `0e530be7` | `etran_invoice_id` стал nullable. |
| `693c3cbf` | КТК переведён с global wagon FK на `shipping_order_railway_carriage_id`. |
| `0fc7134b` | Добавлен task `status`. |
| `3ea221c0` | Добавлены `data_time_krugloye_pole`, заказчик и собственник; расширен Excel-контур. |
| `b3733c1f` | Добавлен индекс по `railway_carriage_id`. |
| `5318381a` | Добавлены grouped list/merge-контракты. |
| `3d4d34d7` | Добавлены list/merge для `fillingType=RAILWAY_CARRIAGE`. |
| `dfc12682` | Дочерний outbound отключён в пользу root orchestration. |
| `cd8ab542` | Добавлены scoped meta/nested preview paths. |

## Что подтверждают tests, но не их запуск

- [`ShippingOrderRailwayCarriageServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageServiceIntegrationTest.java) покрывает soft-delete wagon-row с cascade на КТК/items и legacy `upsertAndDelete` с add/update/delete.
- [`ShippingOrderRailwayCarriageDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageDaoServiceTest.java) покрывает базовые DAO create/update/delete/page/filter.
- Не найдены прямые тесты: path/body mismatch; optional-body `/preview`; очистка `customerService`/`ownerRailwayCarriage`; update в уже занятую комбинацию; cross-order wagon↔container; global ETRAN без membership; неизвестный ETRAN-group ID в merge; nullable ETRAN в transport manifest; конкурентный дубль.
- Тесты не запускались. Наличие integration test не подтверждает применённую production-схему или runtime security.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные индексы/constraints/дубли и runtime-права.
2. Нужно определить business key: один вагон на заявку или один вагон на накладную в заявке; затем закрепить его DB constraint с учётом `deleted`.
3. Нужно решить, должна ли ссылка вести на `shipping_order_etran_invoice`, а не напрямую на global `etran_invoice`, либо добавить явную membership-проверку.
4. Нужна composite-проверка `container.shippingOrder == wagon.shippingOrder` в service и/или схеме.
5. Нужно согласовать `RAILWAY_CARRIAGE + nullable ETRAN` с exporter, который разыменовывает накладную без null-guard.
6. Нужно определить, должен ли `dateDepotRepair` обновлять глобальный справочник из order-row DTO и какие права для этого требуются.
7. Нужно подтвердить, что merge действительно является full-order replace, и распространить client row-level проверку на write path.
8. Нужны предметные ошибки вместо NPE для пустого preview-body и неизвестной ETRAN-group в merge.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Inbound actions вывоза](../business-rules/shipping-inbound-actions.md)
- [Корень заявки на вывоз](shipping-order-root-as-is.md)
- [КТК заявки на вывоз](shipping-order-container-as-is.md)
- [Сводная карта восьми ранее описанных таблиц](shipping-order-integrity-map.md)
- [JPA-паспорт ShippingOrderRailwayCarriage](../entities/catalog/entities/shippingorderrailwaycarriage/ShippingOrderRailwayCarriage.md)
