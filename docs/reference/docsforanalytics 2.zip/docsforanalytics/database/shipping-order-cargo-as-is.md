# `shipping_order_cargo`: грузовое место вывоза, физическая модель AS-IS (часть 19)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Это **source-level модель**, не проверка применённой БД. Корень и сохранённые итоги — в [модели `shipping_order`](shipping-order-root-as-is.md), товарная строка и её auto-cargo side effect — в [модели `shipping_order_good`](shipping-order-good-as-is.md). Контур зеркален [`receiving_order_cargo`](receiving-order-cargo-as-is.md); ниже — различия и специфика вывоза, включая заметно более широкий набор bulk-контрактов.

## Ключи, HTTP и валидация

[`ShippingOrderCargo`](../entities/catalog/entities/shippingordercargo/ShippingOrderCargo.md) — отдельная таблица с собственным UUID PK. [`ALG-502 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240816_ALG-502_add_table_shipping_order_cargo.sql) задаёт `shipping_order_id`/`shipping_order_good_id UUID NOT NULL` с FK и изначально `good_package_id UUID NOT NULL REFERENCES good_package`. Как и в receiving, JPA `shippingOrder` объявлен `@OneToOne` без `mappedBy` и без unique constraint на `shipping_order_id` — та же неточная cardinality-аннотация, что и у [`ShippingOrderGood`](shipping-order-good-as-is.md#sqljpa-колонки): физически строк на одну заявку может быть много, `@ManyToOne` описал бы связь точнее.

[`ShippingOrderCargoController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercargo/ShippingOrderCargoController.java) объявляет обычный CRUD (`POST /`, `PUT /{id}`, `DELETE /{id}`, `GET /{id}`, `/all`, `/page`, `/meta/{fieldName}`, `/preview`) и **четыре** разных bulk/upsert endpoint — подробнее в отдельном разделе ниже. Все под `@Secure(Permission.SHIPPING_ORDER_SHIPPING_ORDER_CARGO, ...)`.

[`CreationDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoCreationDto.md) требует `shippingOrder`, `shippingOrderGood` и **`cargo`** — все три `@Valid @NotNull IdDto`. Это отличается от receiving: там `cargo` — строка `@NotBlank`, транслируемая в find-or-create по коду; здесь клиент обязан передать **существующий** ID каталожной записи `Cargo`, find-or-create на этом пути не выполняется. `goodPackage`/`barcode` помечены `@Schema(hidden=true)`, но остаются реальными принимаемыми полями; `packageQuantity`/`totalQuantity`/размеры/`weight` — `@PositiveOrZero`, без `@NotNull` (согласовано со снятым SQL `NOT NULL` — см. таблицу ниже). [`UpdateDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoUpdateDto.md) добавляет `UUID id` **без** `@NotNull`.

### Поле `batch` в DTO — принимается, но никуда не сохраняется

`ShippingOrderCargoCreationDto` (и, соответственно, `UpdateDto`) объявляет `@Valid private IdDto batch;`. У сущности `ShippingOrderCargo` **нет** поля `batch` — партия физически относится к `ShippingOrderGood`. [`ShippingOrderCargoMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercargo/ShippingOrderCargoMapper.java) не содержит ни одного `@Mapping` для `batch` в `modelCreation`/`modelUpdate`, а сервисные методы (`processCargoDto`, `buildUpdateDto`, `copy`) нигде не читают `cargoDto.getBatch()`. Итог: `batch`, присланный в теле `POST/PUT /shippingordercargo`, проходит Bean Validation (если непустой — валиден как `IdDto`), но **молча отбрасывается** — не персистится ни в этой, ни в какой другой таблице. Единственный источник партии в ответе — `shippingOrderGood.batch` (виден в `ShippingOrderCargoPreviewDto`/`PackingListReportDto` через отдельный `@Mapping(target="batch", source="shippingOrderGood.batch")`, но не в основном `ShippingOrderCargoDto`).

`PUT /{id}` не принимает `@PathVariable id`: `service.update(updateDto)` ищет строку по **`UpdateDto.id`** без сверки с path — как и у остальных дочерних сущностей заявки.

## Обновление reference-полей: три разных паттерна в одном методе

[`ShippingOrderCargoService.prepareModelToUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoService.java) обрабатывает три ссылки тремя разными способами:

- `shippingOrderGood`, `cargo` — классический паттерн: `isNotEquals(...)` → DAO lookup при отличии. Оба поля `@NotNull` в DTO (`cargo` — обязателен и в update, так как `UpdateDto` наследует `CreationDto`), поэтому `updateModel.getCargo()`/`getShippingOrderGood()` не могут быть `null` на входе — известный по receiving NPE-паттерн («null-clearing при optional-поле») здесь структурно невозможен для этих двух полей.
- `barcode` — единственное поле с явной защитой от null: `if (updateModel.getBarcode() != null && isNotEquals(...)) { DAO lookup } else { existingModel.setBarcode(updateModel.getBarcode()); }`. Если тело не содержит `barcode`, ветка `else` корректно очищает поле в `null` без обращения к `getId()` на null-объекте.
- `packageQuantity`/размеры/`weight` — прямое присваивание из `updateModel`, `totalQuantity` пересчитывается **только** если после присваивания `packageQuantity` и уже сохранённый `conversionQuantity` оба не `null`; иначе у `existingModel.totalQuantity` остаётся прежнее значение (аналогично receiving).

## SQL-колонки и изменения

| Поле/источник | Текущий SQL source contract | Отличие от `receiving_order_cargo` |
|---|---|---|
| `id`, `shipping_order_id`, `shipping_order_good_id` | `UUID PK`; оба FK `NOT NULL` с самого начала | Совпадает по смыслу; собственный PK, не shared. |
| `good_package_id` | `UUID NULL REFERENCES good_package(id)` | Изначально (ALG-502) `NOT NULL`, как и у receiving; [`KIS-1746`](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/V.1.28.0_20251006_KIS-1746_drop_constraints.sql) снял `NOT NULL` **одним и тем же changeset** для обеих `_cargo`-таблиц. |
| `good_package_barcode_id` | `UUID NULL REFERENCES good_package_barcode(id)` | С самого начала nullable (в отличие от `good_package_id`, который сначала был обязателен). |
| `cargo_id` | `UUID NULL REFERENCES cargo(id)` | Добавлен позже: [`KIS-1135`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250606_KIS-1135_add_cargo_id_to_shipping_order_cargo.sql) для shipping (2025-06), у receiving — параллельный `KIS-1134` (2025-05). DTO делает эту ссылку `@NotNull` (в отличие от receiving, где входной `cargo` — строка с find-or-create). |
| `package_quantity` | `NUMERIC(16,3) NULL`, `DEFAULT 0` с `KIS-1135` | `NOT NULL` снят отдельно [`KIS-1567`](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250917_KIS-1567_add_parent_package_id_to_good_package.sql) — тем же changeset, что и у receiving. |
| `conversion_quantity`, `total_quantity` | `NUMERIC(16,3) NULL`, `DEFAULT 0` | `NOT NULL` снят `KIS-1746`; `total_quantity` дополнительно получил `DEFAULT 0` уже в `KIS-1135`. Формула `total = package × conversion` — только Java-логика сервиса, не SQL `CHECK`. |
| `length`, `width`, `height` | `NUMERIC(10,3) NOT NULL DEFAULT 0` | Заданы `NOT NULL`/`DEFAULT 0` сразу в ALG-502 — **без** отдельной «удалить-и-восстановить» цепочки миграций, которую прошла `receiving_order_cargo` (`ALG-559`). |
| `volume` | `NUMERIC(17,6) NOT NULL DEFAULT 0` | Как и выше — сразу `NOT NULL`/`DEFAULT 0`, без промежуточных снятий. |
| `weight` | `NUMERIC(15,3) NOT NULL DEFAULT 0` | Аналогично; участвует в root `total_weight` как поле строки, без умножения на `packageQuantity` — совпадает с receiving. |
| `executor` | `VARCHAR(256) NULL` | [`KIS-928`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250417_KIS-928_add_fields_for_shipping_order_cargo.sql) добавил вместе с `actual_quantity`. **У `receiving_order_cargo` этой колонки нет вообще** — там нет собственного WMS actual на уровне cargo. |
| `actual_quantity` | `NUMERIC(16,3) NULL` | Тот же `KIS-928`. Пишется [`WmsShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsShipmentResultAction.java) кумулятивно (`existing == null/0 ? item.qty : existing.add(item.qty)`), а не перезаписью — см. [inbound actions вывоза](../business-rules/shipping-inbound-actions.md). |
| `deleted`, audit | `deleted BOOLEAN NOT NULL DEFAULT false`; стандартный audit | Задан сразу в ALG-502, без деструктивного `DELETE`-паттерна, который прошла `receiving_order_cargo` через `ALG-311`. |

Отдельных `UNIQUE`, `CHECK(total_quantity = package_quantity × conversion_quantity)` или non-PK индексов для `shipping_order_cargo` в просмотренных SQL references не найдено — как и у receiving-аналога.

**Асимметрия входа для "контейнера/упаковки"**: в receiving-контуре `cargo` — вводимый пользователем текстовый код с автосозданием каталожной записи (`findOrCreateCargo`); в shipping-контуре `cargo` — обязательная ссылка на уже существующую запись `Cargo` по ID. Аналитик, сравнивающий два контура по имени поля, получит разное практическое поведение (создание новой записи каталога vs жёсткая проверка существования).

## Stored root totals и побочный пересчёт услуг

[`ShippingOrderCargoService.calculateAndSetShippingOrderFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoService.java) после add/update/soft-remove читает неудалённые cargo-строки заявки и пишет `total_weight = sum(weight)`, `total_cargo_quantity = count(rows)`, `total_pallet_quantity = count(rows where goodPackage.processingType=PALLET)`, `total_not_pallet_quantity = count − pallet_count` — формулы идентичны receiving-аналогу.

Отдельно, `postAdd`/`postRemove` вызывают [`updateShippingOrderRequestedService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoService.java): для всех активных `ShippingOrderRequestedService` заявки с `calculationMethod = CARGO_PLACE` пересчитывает `plannedQuantity = countByShippingOrder` (число активных cargo), `priceWithoutVAT = plannedQuantity × rate` и `priceWithVAT` через `VATCalculator`. Изменение одной грузовой строки может, таким образом, немедленно изменить сохранённую цену уже существующих строк дополнительных услуг — не только root totals.

```mermaid
flowchart TD
    D[Creation/Update DTO: order/good/cargo refs, batch (unused), quantities, dimensions] --> M[Mapper: new UUID, ignore batch]
    M --> S[Service: status/deliveryType check, package conversion]
    S --> C[(shipping_order_cargo: active and deleted rows)]
    C --> F[Filter by root and deleted=false]
    F --> W[Sum weight, count rows/pallet rows]
    W --> R[(shipping_order.total_weight/cargo/pallet totals)]
    C --> RS[Recalculate CARGO_PLACE requested services]
    WMS[WmsShipmentResultAction] -->|cumulative add| A[executor / actualQuantity]
    A --> C
```

## Четыре bulk/upsert-контракта и разная атомарность

| Endpoint | Метод | Транзакционность и семантика |
|---|---|---|
| `POST /multipleaddition` | `createShippingOrderCargoByList` → `processCargoDto` | **Не** `@Transactional`. Собственная upsert-эвристика: для каждой строки списка — если тот же `shippingOrderGood.id` уже встречался в этом же вызове, сразу `add`; иначе ищет существующую строку по триплету `(shippingOrder, shippingOrderGood, cargo)` и, если найдена, обновляет её; иначе ищет «пустую» строку того же товара без `cargo` (`findEmpty`, обычно — auto-cargo из `ShippingOrderGoodService.postAdd`) и заполняет её; иначе создаёт новую. `add`/`update` вызываются как `this.add(...)`/`this.update(...)` — self-invocation в обход Spring-прокси, отдельной транзакции на весь список нет. |
| `PUT /multipleupdate` | `updateShippingOrderCargoByList`: `list.stream().map(super::update)` | Тот же self-invocation паттерн, без `@Transactional` на весь список. |
| `POST /{shippingOrderId}` | `BaseService.upsertAndDelete(UUID orderId, List<U>)` | Метод помечен и `@Deprecated`, и `@Transactional` одновременно — контроллер продолжает использовать deprecated overload как основной. Синхронизирует полный набор: элементы вне присланного списка ID **удаляются** (soft), присланные с известным ID — обновляются, остальные — создаются. Так как весь метод атомарен, replace-семантика по крайней мере не оставляет частично применённое состояние. |
| `POST /{shippingOrderId}/batch` | `BaseService.applyBatch` | `@Transactional`, явные списки `add`/`update`/`delete` со scope-проверкой (`validateIdsInFilterScope`) — пересечение update/delete ID запрещено. |

Практическое следствие: `multipleaddition`/`multipleupdate` (первые два ряда) не дают атомарности всего списка, а `{shippingOrderId}` и `{shippingOrderId}/batch` — дают, но с разной семантикой (первый — «пришли новое полное состояние, лишнее удали», второй — «пришли явный diff»). UI/интеграция должна явно выбирать endpoint, зная эту разницу, а не считать три «multiple/batch/upsert» варианта взаимозаменяемыми.

## Outbound: тот же dead-code паттерн

`postAdd`/`prepareModelToUpdate` содержат закомментированный `insertRowsForFurtherIntegration` с TODO: `EntityType.SHIPPING_ORDER_CARGO` отсутствует в [`OutboundConfigService.CONFIGURATION`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) — тот же паттерн, что у [транспорта](shipping-order-transport-as-is.md#outbound-transport-становится-мёртвым-отдельным-writer-ом) и [товарных строк](shipping-order-good-as-is.md#outbound-тот-же-dead-code-паттерн-что-у-транспорта). Оставленный без вызова `getListOfEntitiesToOutbound` (`@Deprecated`) для `ITEM_SHIPMENT_TASK`/`CARGO_SHIPMENT_TASK` вернул бы root `ShippingOrder`, а не саму cargo-строку. Актуальная интеграция идёт через `ShippingOrderService.accept()`.

## Что подтверждают tests, но не их запуск

- [`ShippingOrderCargoServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoServiceIntegrationTest.java) покрывает add, пересчёт `CARGO_PLACE`-услуг при add/delete и пересчёт root totals при add/update/remove.
- [`ShippingOrderCargoValidationTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/dto/validation/ShippingOrderCargoValidationTest.java) — восемь Bean Validation кейсов DTO.
- [`ShippingOrderCargoDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoDaoServiceTest.java) — DAO-уровень.
- Не найдено: тест на `batch`, отбрасываемый мимо сохранения; тест атомарности `multipleaddition`/`multipleupdate` при ошибке в середине списка; тест на реальную семантику `POST /{shippingOrderId}` (replace-by-absence-delete) при частично некорректном списке; сравнительный тест четырёх bulk-эндпоинтов на одинаковом входе.
- Тесты не запускались; их наличие не подтверждает применённую схему, HTTP-роутинг или порядок обработки `processCargoDto`.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные ON DELETE/индексы и допустимые null в развернутой БД.
2. Нужно решить судьбу поля `batch` в DTO — удалить как мёртвое или реализовать сохранение, если бизнес ожидает партию на уровне cargo, а не только good.
3. Нужно решить, действительно ли нужны все четыре bulk/upsert контракта, и если да — явно задокументировать разницу семантики (`multipleaddition`/`multipleupdate` vs `{shippingOrderId}` vs `{shippingOrderId}/batch`) для потребителей API; выяснить, почему клиент использует `@Deprecated` `upsertAndDelete(orderId, ...)`, а не сохранённый более новый `upsertAndDelete(filter, ...)`.
4. Нужен прямой тест атомарности `multipleaddition`/`multipleupdate` при ошибке на одном из элементов списка.
5. Нужно подтвердить/опровергнуть корректность связки `executor`/`actualQuantity` при повторных `WmsShipmentResultAction`-вызовах для одной и той же cargo-строки (кумулятивное сложение может задваивать при повторной доставке одного и того же события).
6. Нужно решить судьбу `@Deprecated` `getListOfEntitiesToOutbound` и закомментированного `insertRowsForFurtherIntegration` — то же решение, что и для транспорта/товаров.

## Чек-лист изменения таблицы

1. Для DTO-полей без соответствующего entity-поля (как `batch`) — либо связать через явный `@Mapping`, либо убрать поле из контракта, чтобы не создавать иллюзию сохранения.
2. Для нового bulk-endpoint — явно решать, нужен ли per-item или per-batch `@Transactional`, и избегать `this.method()`/`super::method()` внутри того же bean, если атомарность важна.
3. Для `find-or-create` vs `require-existing-id` по каталожным ссылкам (`cargo`) — сверять семантику с аналогичным полем на противоположной стороне (receiving/shipping), чтобы не удивлять интеграторов одинаковым именем поля с разным поведением.
4. Для totals, разделяемых с пересчётом услуг (`CARGO_PLACE`), — учитывать, что одна строка cargo влияет сразу на два разных агрегата (root totals и requested service price).
5. Для WMS-инкрементных полей (`actualQuantity`) — явно определить идемпотентность повторной доставки одного и того же события перед тем, как полагаться на них в отчётности.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Inbound actions вывоза](../business-rules/shipping-inbound-actions.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Транспорт заявки на вывоз: физическая модель AS-IS](shipping-order-transport-as-is.md)
- [Номенклатура заявки на вывоз: физическая модель AS-IS](shipping-order-good-as-is.md)
- [Грузовое место поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-cargo-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderCargo](../entities/catalog/entities/shippingordercargo/ShippingOrderCargo.md)
