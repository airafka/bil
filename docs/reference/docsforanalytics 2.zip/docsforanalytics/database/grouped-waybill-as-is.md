# `grouped_waybill`: материализованная read-модель накладных AS-IS (часть 14) — DEPRECATED

> **DEPRECATED.** Коммит [`978ba888`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql) (KIS-4690, 14 сентября 2026) удалил materialized view `grouped_waybill`, сущность `GroupedWaybillView` и все три `/waybill/*grouped*` endpoint, описанные ниже. Их заменила обычная (нематериализованная) `waybill_view` — по одной строке на Waybill, с `receiving_order_id`/номером/статусом заявки и агрегатами по вагонам/КТК/товару через `LEFT JOIN`, без отдельного refresh-цикла. Группировку по станциям/плательщику теперь строит `WaybillViewDaoService.getHierarchyPage` в самом запросе (QueryDSL `groupBy`), а не SQL-view. Текущие endpoints — `POST /waybill/incoming/page`, `/outgoing/page`, `/archive/page` с единым `WaybillFilter` и ответом `Page<WaybillStationPairGroupDto>` (см. [бизнес-правила накладных](../business-rules/waybill-etran-as-is.md)). Содержимое ниже сохранено как исторический AS-IS удалённой read-модели; для нового `waybill_view` отдельный source-level документ ещё не написан (открытый пункт, см. [реестр открытых вопросов](../traceability/analyst-open-items-registry.md)).

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561` (устаревший, ветка `dev` уже не содержит этот коммит — см. [журнал сверки](../traceability/repository-change-log.md)), rerunnable SQL, JPA/DAO/service/controller и test sources. Это **source-level модель**, а не снимок применённой БД. Базовые таблицы раскрыты в физических моделях [корня Waybill](waybill-root-as-is.md), [вагона](waybill-railway-carriage-as-is.md), [КТК](waybill-container-as-is.md), [груза](waybill-product-as-is.md) и [отметок](waybill-marks-as-is.md).

## Назначение и ключ группы

`grouped_waybill` (SQL удалён, был в `rerunnable/view_grouped_waybill.sql`) — PostgreSQL materialized view для вкладок накладных. Одна строка объединяет все неархивные Waybill с одинаковой тройкой:

`(departure_station_id, destination_station_id, payer_id)`.

`receiving_order_id`, клиент и номер накладной в ключ не входят. Поэтому в одну группу могут попасть непривязанные накладные и накладные разных заявок/клиентов, если совпадают станции и плательщик. View не является authoritative storage: все данные можно заново получить из базовых таблиц после refresh.

## SQL-состав и источники полей

| Колонка view | SQL-источник | Семантика |
|---|---|---|
| `id UUID` | `gen_random_uuid()` | Синтетический ID строки; меняется при каждом полном/concurrent refresh |
| `departure_station_id` | `waybill.departure_station_id` | Часть ключа группы |
| `destination_station_id` | `waybill.destination_station_id` | Часть ключа и признак входящей/исходящей группы |
| `payer_id` | nullable `waybill.payer_id` | Часть ключа; physical Waybill FK остаётся nullable после migration |
| `waybill_ids UUID[]` | `ARRAY_AGG(waybill.id)` | Все Waybill группы без заданного `ORDER BY` |
| `waybill_count` | `COUNT(*)` по Waybill | Число корневых строк группы |
| `product_ids UUID[]` | correlated `ARRAY_AGG(waybill_product.id)` | Все product rows группы; пустой результат становится `UUID[] {}` |
| `railway_carriage_count` | сумма `COUNT(*)` по `waybill_railway_carriage.waybill_id` | Считает все WRC rows независимо от task status |
| `container_count` | сумма WC rows через `waybill_container → waybill_railway_carriage → waybill` | Считает все WC rows независимо от task status |

Special/tariff marks и ЗПУ в view не входят. Дубли WRC/WC/Product, допустимые базовой схемой, увеличивают счётчики или число элементов; `DISTINCT` не применяется. `COALESCE` даёт нулевые counts и пустой product array для Waybill без children.

Корневой predicate точный и case-sensitive: исключаются только статусы `Работа с документом окончена` и `MIGRATED`. `waybill.status` физически `NOT NULL`; другие статусы, включая неизвестные строки, входят в view.

## Physical constraints и JPA

После создания view строится единственный физический индекс:

`UNIQUE (departure_station_id, destination_station_id, payer_id)`.

Он нужен для `REFRESH MATERIALIZED VIEW CONCURRENTLY` и выражает ключ группы. На synthetic `id`, отдельных `payer_id`/`destination_station_id` и UUID arrays индексов нет. `id` не является SQL primary key/unique, хотя `GroupedWaybillView` (JPA-сущность удалена вместе с view) наследовала JPA `@Id` и дополнительно повторно объявляла поле `id`.

JPA-модель помечена `@Immutable`; прикладных create/update/delete для неё нет. Станции и payer оформлены как `@ManyToOne(optional=false)`, но materialized view не имеет FK constraints, а исходный `waybill.payer_id` nullable. Поэтому обязательность payer в JPA строже physical source.

SQL `COUNT(*)`/`SUM(count)` возвращает `bigint`, тогда как три count-поля JPA/DTO объявлены `Integer`; отдельной проверки диапазона или явного cast в SQL нет.

Rerunnable changeset делает `DROP MATERIALIZED VIEW`, затем `CREATE MATERIALIZED VIEW` с немедленным заполнением и создаёт индекс заново. При изменении SQL synthetic IDs полностью заменяются, а доступность view во время deployment отдельно не гарантируется исходниками приложения.

## Refresh lifecycle и staleness

Единственный найденный runtime-trigger — успешный `WaybillDatareonService.handleInboundWaybill`:

1. Inbound transaction создаёт новую Waybill со всеми children либо меняет только status существующей.
2. Перед возвратом сервис публикует `WaybillIntegrationPacketProcessedEvent`.
3. [`WaybillService.updateGroupedWaybills`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java) принимает событие через `@TransactionalEventListener(AFTER_COMMIT)` и запускается `@Async`.
4. Repository выполняет `REFRESH MATERIALIZED VIEW CONCURRENTLY grouped_waybill`.
5. Ошибка только логируется и не возвращается inbound-клиенту; retry, scheduler, ручной endpoint, last-refresh timestamp и health/status для view не найдены.

Следствия:

- inbound HTTP может завершиться раньше refresh, поэтому сразу после успешного ответа grouped endpoints ещё могут отдавать старый снимок;
- rollback inbound не публикует AFTER_COMMIT refresh;
- status-only replay запускает refresh и удаляет/возвращает Waybill в зависимости от нового статуса;
- Excel parser создаёт Waybill/WRC/WC без этого event; child deletion/addition и иные DAO writers также не найдены среди trigger-источников — такие изменения остаются невидимыми в membership/counts до следующего Datareon refresh;
- link/unlink с ReceivingOrder refresh не требует, потому что эта связь не входит в view, но и не разделяет группы по заявкам;
- комментарий `flushAutomatically=true` в repository описывает старый inline-refresh «в той же транзакции»; текущий listener работает асинхронно после commit, поэтому эта аргументация исторически устарела.

`CONCURRENTLY` позволяет продолжать чтение существующего снимка во время обычного refresh, но приложение не ждёт его завершения и не раскрывает возраст снимка.

## API и построение ответа

Три endpoint возвращали `GroupedWaybillDto` (DTO удалён вместе с view) под `Permission.WAYBILL`:

| Endpoint (удалён) | Направление | Request |
|---|---|---|
| `POST /waybill/grouped/page` | Все группы view | `FilterWithPaging<GroupedWaybillFilter>` |
| `POST /waybill/incoming/grouped/page` | `destinationStation.esrCode IN ('648400','648908')` | `WaybillTabFilter` |
| `POST /waybill/outgoing/grouped/page` | destination ESR не входит в два кода | `WaybillTabFilter` |

После получения страницы materialized rows сервис собирает объединение `waybill_ids` и `product_ids`, отдельными запросами читает **текущие** Waybill и WaybillProduct, затем строит DTO:

| DTO-поле | Фактический источник |
|---|---|
| `id`, станции, три count | Снимок materialized view |
| `payer` | Текущее `payer.name`, доступное через association строки view |
| `waybills[]` | Текущие Waybill по сохранённым IDs → `{id, number}` |
| `products[]` | Текущие WaybillProduct по сохранённым IDs → `{id, etsngCode.code, etsngCode.name}` |

Это не единый database snapshot. Если после refresh базовая строка обновлена, DTO может показать новое имя/номер при старом составе; если удалена, service отбрасывает отсутствующий ID через `filter(Objects::nonNull)`, но stored counts не уменьшаются. Новый Product до refresh, наоборот, отсутствует. Порядок `waybill_ids`/`product_ids` SQL не задаёт, и mapper сохраняет полученный порядок.

DTO не отдаёт receiving orders/clients, статусы/даты Waybill, веса/количество Product, task statuses, marks или время refresh. `products[]` содержит одну строку на WaybillProduct, а не уникальный справочник ЕТСНГ, поэтому одинаковый ЕТСНГ может повторяться.

## Фильтры, сортировка и dropdowns

`GroupedWaybillFilter` объявляет inherited `id`/`anyOfId`, `payerId`, обе station IDs и `incoming`. Predicate применяет только последние четыре поля: inherited ID-фильтры игнорируются.

Backward-compatible `/grouped/page` сохраняет sorting из `GroupedWaybillFilter`. Но преобразование `WaybillTabFilter` для incoming/outgoing копирует только payer/stations/incoming и **не переносит inherited sorting fields**. Поэтому эти две вкладки всегда используют default sort по synthetic `id`. Поскольку ID меняются при refresh, порядок групп и границы страниц не являются стабильными между обновлениями view даже при неизменном составе.

Три dropdown endpoint также читают materialized view и только входящие ESR-коды:

| Endpoint | Результат | Особенность |
|---|---|---|
| `POST /waybill/payers` | distinct Payer; optional departure/destination filter | Pageable JPQL не задаёт `ORDER BY`, поэтому стабильная пагинация не доказана |
| `POST /waybill/departure-stations/page` | distinct departure stations | Station filter применяется, сортировка жёстко `station.code ASC` |
| `POST /waybill/destination-stations/page` | distinct destination stations | Station filter применяется, сортировка жёстко `station.code ASC` |

На всех шести routes есть только permission gate `WAYBILL`; отдельное user/client restriction в grouped цепочке не найдено.

```mermaid
flowchart TD
    B[(waybill + WRC + WC + Product)] --> R[REFRESH grouped_waybill]
    E[Successful Datareon commit] -->|AFTER_COMMIT + Async| R
    X[Excel/other child writers] -. no refresh event found .-> B
    R --> M[(Materialized membership, IDs, counts)]
    M --> P[Grouped page query]
    P --> L1[Live lookup Waybill by stored IDs]
    P --> L2[Live lookup Product by stored IDs]
    L1 --> D[GroupedWaybillDto hybrid snapshot]
    L2 --> D
    M --> DD[Incoming payer/station dropdowns]
    F[Refresh error] -->|log only| ST[Old snapshot remains readable]
```

## Тесты и история изменений

`GroupedWaybillDaoServiceTest` вручную refresh view и подтверждает: две Waybill одной тройки объединяются; WRC/WC counts суммируются; product IDs собираются; Waybill без children получает нули и пустой product array. Тест не проверяет status exclusions, разные группы, nullable payer, duplicate children, filters/sorting/pagination, DTO enrichment, async AFTER_COMMIT, failure/staleness или controller security. Тесты в этом подэтапе не запускались.

Основные влияющие commits:

- `feb37a42` (2026-02-13) — первоначальные view, JPA/DAO, grouped endpoint и async refresh;
- `ba7f5d64` / merge `443ae69a` (2026-03/04) — переход ключа с payer text на `payer_id`, tabs/dropdowns и текущая read-модель;
- `19cb1665` (2026-05-01) — listener переведён с обычного event на async `AFTER_COMMIT`;
- `229c7d86` (2026-05-01) — `flushAutomatically=true` для refresh repository;
- `f52bef29` (2026-05-29) — статус `MIGRATED` исключён из view;
- `5fff5e70`, `169505ec`, `4d6db879`, `826dbd80` (2026-06) — фильтруемые/paged dropdowns и pagination API.

Не подтверждены applied definition/index, план запросов и объём view, фактическая задержка/конкурентность refresh, runtime permission grants, поведение nullable payer и UI-зависимость от synthetic ID/порядка. Для ТЗ эту модель следует трактовать как eventually consistent read projection, а не как транзакционно актуальный реестр накладных.
