# `waybill_container`: КТК в накладной, физическая модель AS-IS (часть 11)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java controller/service/JPA, integration handlers, SQL/cumulative migrations и test sources. Это **source-level модель**, а не снимок применённой БД. Родительский вагон описан в [физической модели `waybill_railway_carriage`](waybill-railway-carriage-as-is.md), корень — в [физической модели `waybill`](waybill-root-as-is.md), источник товарных весов — в [физической модели `waybill_product`](waybill-product-as-is.md).

## Граница данных: глобальный КТК, snapshot накладной и операционный владелец

[`WaybillContainer`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillcontainer/WaybillContainer.java) — участие физического КТК в конкретном вагоне конкретной накладной. Это не тот же объект, что глобальный [`Container`](../entities/catalog/entities/container/Container.md), и не запись текущего операционного владельца.

| Уровень | Основные данные | Кто меняет |
|---|---|---|
| `container` | уникальный номер `code`, тип, ISO-тип, тара `weight`, грузоподъёмность, размер и другие глобальные характеристики | Waybill importer делает find-or-create по номеру и перезаписывает часть полей существующего Container; есть отдельный CRUD/справочные потоки. |
| `waybill_container` | WRC, `owner`, `length`, gross `weight`, `net_weight`, номера подачи/отправки | Snapshot первого импорта накладной; обычного update API нет. |
| `container_owner` | текущий Client-владелец физического Container и история смены | При успешном завершении поставки owner service переводит физические КТК клиенту заявки; строковый `waybill_container.owner` от этого не меняется. |
| `waybill_container.status` | `UPLOADED`, `FINISHED`, потенциально `CANCELED`, либо `NULL` | ALIS outbound и TOS inbound. |

В требованиях нельзя использовать `WaybillContainer.owner`, `Container.owner` и `ContainerOwner.client` как взаимозаменяемые поля: первое — snapshot накладной, второе — строка глобального справочника, третье — операционная связь с Client.

## SQL-контракт `waybill_container`

Initial table создана migration [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql); v1.34 добавила gross weight, status и net weight.

| Java-поле | SQL source | Обязательность / ограничение | Семантика |
|---|---|---|---|
| `id` | `UUID PRIMARY KEY` | NOT NULL через PK | UUID entity lifecycle. |
| `waybillRailwayCarriage` | `waybill_railway_carriage_id UUID` | `NOT NULL REFERENCES waybill_railway_carriage ON DELETE CASCADE` | Родительское участие вагона. |
| `container` | `container_id UUID` | `NOT NULL REFERENCES container(id)`; `ON DELETE` не задан | Глобальный физический КТК. |
| `supplyRequestNumber`, `sendingRequestNumber` | nullable `INTEGER` | Нет CHECK | Номера заявки из ЭТРАН. |
| `owner` | nullable `VARCHAR` | Нет FK/CHECK | Строковый snapshot собственника. |
| `length` | nullable `NUMERIC(16,3)` | Нет CHECK | Длина из накладной. |
| `weight` | nullable `NUMERIC(15,3)` | Нет CHECK | Gross weight `weight_gross`, записывается as-is. Не путать с `container.weight` — тарой. |
| `netWeight` | nullable `NUMERIC(16,3)` | `CHECK (net_weight > 0)` | Net weight snapshot. Ноль и отрицательное значение отклонит БД, DTO/service это заранее не проверяют. |
| `status` | nullable `VARCHAR` | Нет DEFAULT/CHECK | При создании null, затем enum name. |
| audit | `created_at TIMESTAMP NOT NULL DEFAULT ...`, `created_by VARCHAR(50) NOT NULL` | Только create audit | Entity наследует `BaseCreatable`, update audit отсутствует даже при изменении status. |

В просмотренной migration chain нет явных индексов по обоим FK и нет `UNIQUE(waybill_railway_carriage_id, container_id)`. Поэтому один физический КТК можно повторить внутри WRC или нескольких WRC одной поставки. Repository возвращает `Optional` по паре WRC+Container и по паре ReceivingOrder+Container; при дублях такие single-result запросы способны завершиться ошибкой множественного результата.

## Создание и справочный upsert

### Datareon / ЭТРАН

При первом `waybill_identifier` [`WaybillDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java):

1. находит WRC по `carriage_number` среди только что построенных строк; при повторном номере берётся первая;
2. находит или создаёт глобальный Container по `container_number`;
3. для существующего Container перезаписывает грузоподъёмность, тару, тип и ISO-тип;
4. создаёт WaybillContainer со snapshot-полями;
5. отдельным проходом привязывает каждое ЗПУ к первой строке с тем же номером Container.

Грузоподъёмность перед записью в глобальный Container умножается на 1000, глобальная тара берётся из входного `weight`, а gross snapshot — из `weight_gross` без преобразования. Единицы закреплены комментариями DTO/service, но не SQL constraint.

Повтор существующей Waybill меняет только root status и не обновляет Container/WC/ЗПУ. Внутри первого payload нет проверки duplicate pair. `waybill_container` и `waybill_zpu` списки обрабатываются через `.stream()` без нормализации null; nested Bean Validation из root controller не каскадирует, поэтому фактические ошибки могут быть NPE/parse/not-found, а не единым validation response.

### Railway Excel

[`ReceivingOrderRailwayCarriageParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderRailwayCarriageParser.java) берёт уже созданный `ReceivingOrderContainer.container`, ищет WC по WRC+Container и при отсутствии создаёт только две обязательные ссылки. Snapshot-поля и status остаются null; ЗПУ в этот Waybill path не создаются. Find-then-insert не защищён DB UNIQUE/lock.

### Legacy migration

[`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) переносит только active `receiving_order_container` с известным Container, вагоном и накладной. В WC записываются ссылки и create audit; `empty`, customs clearance, danger class и остальные snapshot-поля теряются. `seal_numbers` разворачиваются отдельными строками `waybill_zpu`; пустые значения пропускаются. `NOT EXISTS` используется только внутри миграции и не создаёт постоянную уникальность.

## `waybill_zpu`

[`WaybillZpu`](../entities/catalog/entities/waybillzpu/WaybillZpu.md) хранит обязательный FK на WC, nullable SQL `zpu`, nullable `zpu_type` и create audit. FK имеет `ON DELETE CASCADE`; есть индекс только по `waybill_container_id`. Уникальности `(waybill_container_id, zpu)` и проверки непустого номера нет, поэтому inbound способен сохранить null/дубли, хотя legacy migration их фильтрует.

JPA-коллекция `WaybillContainer.zpu` загружается `EAGER`, но cascade/orphan removal на entity не заданы. Добавление выполняется отдельным DAO после сохранения WC; удаление вместе с WC обеспечивает именно FK БД.

## Status lifecycle и TOS

Найденные writers:

- успешный экспорт receiving railway route chain package ставит всем WRC и WC всех поставок рейса `UPLOADED`;
- `CARRIAGE_ARRIVED`, если `taskId` оказался WC, ставит ему `FINISHED` и может установить первое фактическое время, но не закрывает заявку;
- `TOS_RECEIVING_RESULT` по WC ставит `FINISHED`, обновляет услуги/движения и переводит ReceivingOrder в `DONE`, только если объединённый непустой список WC+ReceivingOrderContainer целиком имеет `FINISHED` и статусный переход разрешён;
- перед `DONE` TOS меняет `ContainerOwner` физических КТК на клиента заявки.

TOS передаёт `qty`, но у WaybillContainer нет `actualQuantity`: handler только логирует значение и теряет его. Integration test явно закрепляет текущее отсутствие поля.

Status transition map для WC отсутствует: route export без проверки способен записать `UPLOADED` поверх другого значения, а inbound — `FINISHED`; optimistic version/update audit нет. Фактический порядок обычно задаётся процессом, но БД и service не предотвращают регрессию или last-write-wins race.

## Read API, DTO и вычисляемые поля

[`WaybillContainerController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybillcontainer/WaybillContainerController.java) публикует только page и meta endpoints с `Permission.WAYBILL`; create/update/get/delete маршрутов нет.

| Ответ | Поля и источники | Ограничения |
|---|---|---|
| [`WaybillContainerDto`](../dto/catalog/waybillcontainer/WaybillContainerDto.md) | id/create audit, полный глобальный `ContainerDto`, snapshot owner, ЗПУ как id+code | Не отдаёт WRC, length, supply/sending numbers, gross/net weight и status. |
| [`WaybillContainerViewDto`](../dto/catalog/waybill/WaybillContainerViewDto.md) через `POST /receivingorder/{id}/waybill-containers/page` | global number/type/tare/lifting capacity; WC gross/owner/status; ЗПУ; ETSNG products Waybill | `netWeight` берётся **не из `wc.netWeight`**, а как сумма `WaybillProduct.netWeight` всей накладной и повторяется для каждого её КТК. `zpuType` — только первый non-null тип, хотя номеров может быть несколько. |
| Legacy carriage preview | global Container, WC gross и ETSNG | Net weight также сумма products всей Waybill; null gross заменяется нулём. |

`WaybillContainerFilter.deleted=false` не действует: WC не реализует soft-delete, а predicate не использует поле. Основной predicate поддерживает global/snapshot/status/ЗПУ/search. Поле `etsngCode` есть в generic filter и специальной meta-логике, но основной predicate его не применяет; grouped request DTO вообще не содержит ETSNG filter. `container_count` materialized view считает физические строки WC, включая допустимые схемой дубли.

## Удаление и каскады

Прямого HTTP DELETE WC нет. Физическое удаление WRC либо Waybill каскадно удаляет WC, затем `waybill_zpu`; глобальный Container, ContainerOwner и ReceivingOrderContainer автоматически не удаляются. Особый post-remove cleanup ReceivingOrderContainer выполняется сервисом только при compatibility DELETE WRC и имеет описанный в [части 10](waybill-railway-carriage-as-is.md#удаление-и-каскады) риск порядка flush/subquery. Удаление Waybill и прямой DAO remove такого callback не гарантируют.

```mermaid
flowchart TD
    I[Datareon first Waybill import] --> G[Find/create and update global Container]
    I --> W[(waybill_container snapshot)]
    G -->|NOT NULL FK| W
    R[(waybill_railway_carriage)] -->|NOT NULL, ON DELETE CASCADE| W
    W --> Z[(waybill_zpu)]
    E[Railway route package export] -->|UPLOADED| W
    A[CARRIAGE_ARRIVED or TOS_RECEIVING_RESULT] -->|FINISHED| W
    A --> Q[TOS qty logged but not persisted]
    A --> D{All WC plus ROC FINISHED?}
    D -->|Yes and transition allowed| O[ReceivingOrder DONE and ContainerOwner changed]
    X[Delete Waybill or WRC] -->|DB cascade| W
    W -->|DB cascade| Z
```

## Проверки, пробелы и история

`WaybillDatareonServiceIntegrationTest` проверяет создание одной WC только по количеству. Inbound integration tests проверяют `FINISHED`, незавершение заявки при второй незавершённой WC, услуги и movement; `ContainerOwnerServiceIntegrationTest` проверяет смену операционного владельца. Не найдены прямые tests для SQL net-weight CHECK, duplicate pair/single-result, справочного overwrite, WC/ZPU cascade, grouped mapper с `wc.netWeight`, status regression, null inbound lists и Excel snapshot loss. Тесты в этом подэтапе **не запускались**.

Основные повлиявшие commits: `feb37a42` (initial Waybill/WC/ZPU schema и import, 2026-02-13), `ce939d57`/`443ae69a` (KIS-3631 migration/status/read compatibility, 2026-03/04), `c4c21382` и `9460879a` (net weight/entity и receiving integration, 2026-04), `00629653` (TOS update fix, 2026-05), `0ee0d12d` (global container ID в grouped response, 2026-05), `cd8ab542` (scoped meta/filtering, 2026-08). История Git не подтверждает применённую схему или deployed порядок событий.
