# `shipping_order_container`: КТК заявки на вывоз, физическая модель AS-IS (часть 20)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561` (устаревший, ветка `dev` уже не содержит этот коммит — см. [журнал сверки](../traceability/repository-change-log.md)), controller/DTO/validator/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Разделы про `owner_container_id`/`ownerRailwayCarriage`/`customerService` и route chain package обновлены и перепроверены на `HEAD` `49576a842e14c9aa01b86ae5ed128b99deb44a55` (29 сентября 2026), раздел про `owner_container_id` и outbound — повторно на `729c9a17` (14 октября 2026, KIS-4830); остальной текст документа с исходного checkout не переверялся. Это **source-level реконструкция**, не проверка применённой БД. Root totals — в [модели `shipping_order`](shipping-order-root-as-is.md). Контур зеркален [`receiving_order_container`](receiving-order-container-as-is.md), но с заметными расхождениями: сохранённый прямой FK на вагонную задачу (у receiving он был удалён), физически всё ещё живой `UNIQUE`-constraint и не отфильтрованный по `deleted` дубль-чек. [`ShippingOrderContainerItem`](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainerItem.md) — соседняя таблица, разбирается отдельно в следующей части.

## Endpoint, условная обязательность и validator

[`ShippingOrderContainerController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontainer/ShippingOrderContainerController.java) объявляет `POST /`, `PUT /{id}`, `DELETE /{id}`, `GET /{id}`, `/all`, `/page`, `/preview` и **явно** помеченный `@Operation(deprecated = true)` `POST /{shippingOrderId}` (`upsertAndDelete`, полная замена набора КТК заявки). [`ShippingOrderContainerControllerV2`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontainer/ShippingOrderContainerControllerV2.java) добавляет `page`/`list`/`list/preview`/`meta/{fieldName}` под `/shipping-order/{shippingOrderId}/shipping-order-container`, а также **два** современных merge-эндпоинта: `PUT /merge` (обычная заявка, группировка по вагону) и `PUT /unnumbered/merge` (для `fillingType=CONTAINER` без явных номеров).

[`ValidShippingOrderContainer`](../../../web-layer/src/main/java/ru/korusconsulting/alis/validator/ValidShippingOrderContainer.java)/[`ValidShippingOrderContainerValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/validator/ValidShippingOrderContainerValidator.java) задают ту же условную схему, что и у receiving: при `ktkNumberUnknown=true` дополнительных полей не требуется; иначе обязательны `container.id` и `customsClearance`, а при `empty≠true` — ещё `dangerClass.id` и `sealType.id`. **Найдено расхождение**: default-сообщение аннотации перечисляет `container, dangerClass, weight, customsClearance, dangerousCargo` как обязательные, но сама проверка **не трогает** ни `weight`, ни `dangerousCargo` (поля `dangerous_cargo` в текущей схеме уже нет — см. ниже) — текст ошибки описывает более старую версию правила, чем реализованный код.

Помимо `IdDto`-полей (`container`, `sealType`, `dangerClass`, `shippingOrderRailwayCarriage`), [`CreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerCreationDto.md) использует **`IdCodeDto`** для `customerService`, `ownerRailwayCarriage`, `ownerContainer` — то есть клиент технически может передать код вместе с id для этих трёх ссылок, хотя lookup всё равно идёт по id (см. ниже). Исключение — `ownerContainer`: с 08.10.2026 (KIS-4830) значение из DTO игнорируется и при create, и при update, а Excel-импорт его не передаёт; сервер записывает снимок из registry (см. таблицу колонок). `random` имеет DTO `@Builder.Default = TRUE`. [`UpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerUpdateDto.md) добавляет `UUID id` без `@NotNull`; `PUT /{id}` не принимает `@PathVariable id`, лукап идёт по body `UpdateDto.id`, как и везде в контуре заявок.

## Дубль-проверка vs физический `UNIQUE`: несовпадающая область видимости

[`ALG-644 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240903_ALG-644_add_table_shipping_order_container.sql) сразу создаёт `ADD CONSTRAINT shipping_order_container_order_container_unique_idx UNIQUE (shipping_order_id, container_id)` — **не** partial index, без `WHERE deleted = false`. В отличие от receiving-контура, где аналогичный constraint был удалён `ALG-670`, этот UNIQUE **не найден удалённым** ни в одной последующей миграции: он действует на все строки, включая soft-deleted.

[`ShippingOrderContainerService.checkIfAlreadyExists`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) — единственная application-level защита от дубля — делает `daoService.count(ShippingOrderContainerFilter.builder().shippingOrder(...).container(...).build())`. [`ShippingOrderContainerFilter.deleted`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordercontainer/ShippingOrderContainerFilter.java) по умолчанию — `SearchBoolean(false)`, то есть подсчёт **не видит** soft-deleted строки. Итог: если КТК был добавлен, затем удалён (soft-delete через `DELETE /{id}`), а после этого тот же `(shippingOrder, container)` создаётся снова — `checkIfAlreadyExists` пропустит проверку (активных строк 0), но физический INSERT столкнётся с живым `UNIQUE`-constraint на уже существующей soft-deleted строке и упадёт с constraint violation, а не с ожидаемым `DuplicateEntityException("ShippingOrderContainer.AlreadyExists")`. Прямого HTTP-теста этого сценария не найдено; вывод сделан по совпадению SQL constraint (не удалён) и Java filter default (`deleted=false`).

## SQL-колонки и изменения

| Поле/источник | Текущий SQL source contract | История и отличие от `receiving_order_container` |
|---|---|---|
| `id`, `shipping_order_id` | `UUID PK`; `shipping_order_id UUID NOT NULL REFERENCES shipping_order` | Обычный собственный PK, много строк на заявку. |
| `container_id` | `UUID NULL REFERENCES container(id)` | ALG-644 изначально `NOT NULL`; [`KIS-1970`](../../../db-layer/src/main/resources/db/changelog/v.1.30.0/v.1.30.0_20251107_KIS-1970_add_column_ktk_number_unknown_on_receiving_order_and_shipping_order_and_removing_restrictions.sql) снял `NOT NULL` для `ktkNumberUnknown`. Тот же changeset существует **продублированным** в `v.1.30.0` и `v.1.30.1` с идентичным содержимым — вероятная случайная копия при переносе между ветками релиза; оба файла идемпотентны (`IF NOT EXISTS`/`DROP NOT NULL`), поэтому повторное применение не ломает схему. [`KIS-2013`](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251201_KIS-2013_add_indexes_for_container_and_railway_carriage_ids.sql) добавил `idx_shipping_order_container_container_id`. |
| `railway_carriage_id` → `shipping_order_railway_carriage_id` | `UUID NULL REFERENCES shipping_order_railway_carriage(id)` | ALG-644 сначала ссылался на глобальный каталог `railway_carriage`; [`ALG-843`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240926_ALG-843_update_railway_carriage_link.sql) перевёл на строку задачи вагона этой же заявки (`shipping_order_railway_carriage`) с backfill по паре `(railway_carriage_id, shipping_order_id)`. **В отличие от receiving**, где аналогичный прямой FK был позже полностью удалён (`KIS-3631`) в пользу связи через `WaybillContainer`, у shipping этот FK остаётся действующим прямым полем сущности. |
| `seal_numbers` | `VARCHAR(50)[] NULL` | `NOT NULL` снят [`KIS-282`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250306_KIS-282_drop_not_null.sql) — тем же changeset, что и у receiving. |
| `seal_type_id` | `UUID NULL REFERENCES seal_type(id)` | Добавлен [`KIS-286`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250206_KIS-286_add_table_seal_type.sql), создавшим и сам справочник; у receiving аналогичная колонка добавлена позже отдельным changeset `KIS-2003`. |
| `danger_class_id` | `UUID NULL REFERENCES danger_class(id)` | [`KIS-167`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250227_KIS-167_add_danger_class_to_order_containers_tables.sql) добавил FK с backfill на класс «Отсутствует» (`code_danger_class='0'`) и `NOT NULL`; `KIS-1970` снял `NOT NULL`. Старая прямая колонка `dangerous_cargo BOOLEAN NOT NULL` (из ALG-644) удалена [`KIS-2003`](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251112_KIS-2003_refactoring_excel_template.sql) — именно её всё ещё упоминает устаревшее сообщение validator'а. |
| `owner_container_id` | `UUID NULL REFERENCES client(id)` (с 08.10.2026, KIS-4830) | Добавлена `KIS-2003` со ссылкой на `client_related_entity`. [`KIS-4830`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql) (коммит `401bbea3`, 08.10.2026) перевёл FK на `client(id)`: существующие значения перемаплены по той же таблице соответствия `client_related_entity → client`, что и в KIS-4716 (`3bcf0113`); **значения, отсутствующие в таблице соответствия, обнулены**. JPA-поле `ShippingOrderContainer.ownerContainer` теперь `Client`. Значение из DTO игнорируется (`modelCreation` и с KIS-4830 также `modelUpdate` — `@Mapping(target = "ownerContainer", ignore = true)`); сервер сам записывает **снимок** владельца из registry `container.containerOwner.client`: при `create` (`prepareModelToAdd`), при смене КТК в `PUT` (`prepareModelToUpdate`, только если изменился `container`) и при создании/замене строки по результату TOS-отгрузки (`TosShipmentResultAction`). Без КТК (`ktkNumberUnknown`) или без записи в registry — `NULL`. Снимок **не обновляется**, если владелец в registry сменился позже (например, заявкой на услугу), пока в строке не сменят КТК. Подробнее — [регистр остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830). |
| `customer_services_id`, `owner_railway_carriage_id` | `UUID NULL REFERENCES client_related_entity(id)` | Добавлены тем же `KIS-2003`. `prepareModelToUpdate` эти поля не трогает — через `PUT` они не изменяются; при create маппятся обычным образом (lookup по `id`, `code` из `IdCodeDto` не используется). На 14.10.2026 по-прежнему `ClientRelatedEntity`, а не `Client`. |
| `empty`, `customs_clearance` | `BOOLEAN NOT NULL` (обе, с самого начала) | Совпадает с receiving. |
| `customs_control` | Колонка существовала (`BOOL NOT NULL DEFAULT FALSE`, добавлена [`KIS-163`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250225_KIS-163_add_customs_control_to_order_containers_tables.sql)), но [`KIS-664`](../../../db-layer/src/main/resources/db/changelog/v.1.30.0/v.1.30.0_20251107_KIS-664_remove_field_custom_control.sql) удалил её | Как и у receiving — не путать с оставшейся `customs_clearance`; в текущей entity этого поля уже нет. |
| `weight` | `NUMERIC(15,3) NULL` | ALG-644 изначально `NOT NULL`; `KIS-1970` снял. Create берёт `Container.weight` (или `null` для unknown КТК); update пересчитывает как tare + сумма `wightGross` неудалённых item-строк — формула идентична receiving. Один и тот же one-off [`KIS-3297`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260223_KIS-3297_recalculate_container_weight_by_order.sql) backfill применён к обеим `_container`-таблицам в одном SQL-файле. |
| `actual_quantity` | `NUMERIC(16,3) NULL` | [`ALG-728`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240910_ALG-728_add_field_shipping_order_container_actual_quantity.sql) — отдельный номер changeset от receiving-аналога (`ALG-727`), но тот же паттерн: JPA-комментарий говорит «WMS», а конкретный inbound writer для shipping-стороны в этом документе не трассировался отдельно (см. [inbound actions вывоза](../business-rules/shipping-inbound-actions.md)). |
| `status` | `VARCHAR(20) NULL` | [`ALG-851`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240930_ALG-851_add_order_container_status.sql) — тем же changeset добавлена и для receiving. JPA `@Enumerated(STRING)` через `HasTaskStatus`/`TaskStatus`. |
| `random` | `BOOLEAN NOT NULL DEFAULT TRUE` | [`KIS-1039`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250514_KIS-1039_add_random_for_shipping_order_container.sql) — поля с таким названием/семантикой у receiving нет вообще; смысл флага («является ли контейнер произвольным») в просмотренных источниках не раскрыт подробно за пределами имени и JPA-комментария. |
| `ktk_number_unknown` | `BOOLEAN NULL DEFAULT false` | `KIS-1970`; service нормализует `null → false` на add/update. Root имеет отдельный флаг того же имени, обновляемый только для `TerminalArea=CONTAINER + TransportType=VEHICLE` — см. ниже. |
| `deleted`, audit | `BOOLEAN NOT NULL DEFAULT false`; стандартный audit | ALG-644; soft-delete через `BaseService.remove`. |

## `getCargoWeight()`: NPE-риск в отчёте ТН

[`ShippingOrderContainer.getCargoWeight()`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingordercontainer/ShippingOrderContainer.java) вычисляется как `weight.subtract(container.getWeight())` — без null-проверок внутри метода. И `weight`, и `container` — nullable поля (для `ktkNumberUnknown=true` оба остаются `null` после `prepareModelToAdd`). [`TNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/TNContainerReportDataCollectorService.java) вызывает этот метод так:

```java
BigDecimal totalWeight = shippingOrderContainer.stream()
        .map(ShippingOrderContainer::getCargoWeight)
        .filter(Objects::nonNull)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .multiply(THOUSAND);
```

`.filter(Objects::nonNull)` стоит **после** `.map(...)`, поэтому защищает только от `null`-результата метода, а не от исключения внутри него. Если хотя бы один `ShippingOrderContainer` заявки имеет `weight == null` или `container == null` (обычный случай для КТК с неизвестным номером), вызов `getCargoWeight()` бросает `NullPointerException` до того, как фильтр успевает его отсечь — то есть построение отчёта ТН для такой заявки должно падать. Единственное другое место, где вычисляется та же разница (`preview()` в сервисе), делает это **inline с явной проверкой** `weight != null && container != null` — то есть паттерн защиты существует в кодовой базе, но не применён внутри самого `getCargoWeight()`. Прямого теста, воспроизводящего этот путь, не найдено.

## Stored totals и `ktkNumberUnknown`-флаг заявки

[`ShippingOrderContainerService.calculateAndSetReceivingOrderFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) (имя метода унаследовано от общего паттерна, несмотря на shipping-контекст) после add/update/remove читает все контейнеры заявки и пишет `total_container_quantity = count(rows)`, `total_weight = sum(row.weight, null skipped)` — те же формулы, что и в receiving.

[`checkFlagKtkNumber`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) обновляет **отдельный** root-флаг `shipping_order.ktk_number_unknown = существует хотя бы один active КТК этой заявки с `ktkNumberUnknown=true``, но **только** если `terminalArea = CONTAINER` и `transportType = VEHICLE`; для остальных комбинаций (включая `CONTAINER + RAILWAY`) метод выходит без изменений — старое значение root-флага в этом случае не трогается ни в какую сторону. `postAdd`/`prepareModelToUpdate`/`postRemove` также вызывают `updateReceivingOrderRequestedService` → `ShippingOrderRequestedServiceService.updateCargoPlaceRequestedServices` — тот же side effect на `CARGO_PLACE`-услуги, что и у [грузового места](shipping-order-cargo-as-is.md#stored-root-totals-и-побочный-пересчёт-услуг).

```mermaid
flowchart TD
    D[Creation/Update DTO: order/container/carriage refs, seal/danger/owner, flags] --> V[ValidShippingOrderContainer: conditional on ktkNumberUnknown/empty]
    V --> M[Mapper: new UUID]
    M --> S[Service: app-level duplicate count deleted=false, catalog tare]
    S --> C[(shipping_order_container: UNIQUE order+container across ALL rows)]
    C --> R[Sum weight, count rows]
    R --> T[(shipping_order.total_container_quantity/total_weight)]
    C --> K[checkFlagKtkNumber: CONTAINER+VEHICLE only]
    K --> KF[(shipping_order.ktk_number_unknown)]
    C --> RS[updateCargoPlaceRequestedServices]
    C --> TN[TNContainerReportDataCollectorService.getCargoWeight]
```

## Outbound: route chain package и `ownerContainerId`

Строку `shipping_order_container` читают **два независимых** outbound-механизма, которые не описаны нигде централизованно:

1. **Старый row-level `outbound_config`** — запись `EntityType.SHIPPING_ORDER_CONTAINER` закомментирована в [`OutboundConfigService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) (`// addConfig(EntityType.SHIPPING_ORDER_CONTAINER, MessageType.CARGO_SHIPMENT_TASK)`) — этот путь мёртв, именно про него открытый вопрос №7 ниже.
2. **Route chain package** — активный, отдельный от (1) механизм. [`ShippingOrderContainerMapper.toChainPackageDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java) строит [`ShippingOrderContainerChainPackageDto`](../dto/catalog/routetocargochainpackage/ShippingOrderContainerChainPackageDto.md), который собирает [`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) в рамках `ShippingRouteChainPackageDto` для рейса и отправляет в Datareon (через `ShippingRouteChainPackageDatareonRestService`/`ScheduledShippingRouteChainPackageExportService`). Включается только когда `OutboundConfigService.isRouteChainPackageEnabled` — то есть площадка рейса `CONTAINER` и feature flag `receivingAndShippingRailwayRouteChainPackageEnabled`; при выключенном флаге экспорта для этой заявки нет вовсе ни через (1), ни через (2).

`toChainPackageDto` маппит `ownerContainerId` из `source = "ownerContainer.id"` — то есть из собственного поля строки `ShippingOrderContainer.ownerContainer`.

**История дефекта (закрыт KIS-4830).** С 22.09.2026 (KIS-4716) по 08.10.2026 это поле у новых строк было всегда `null`, поэтому пакет по вывозу уходил в Datareon с `ownerContainerId = null`, хотя read-DTO показывали владельца из registry. Коммит `401bbea3` (KIS-4830, 08.10.2026) стал заполнять поле снимком владельца из registry (см. таблицу колонок), а read-DTO (`toDto`, `toDetailedDto`, merge-DTO) — читать именно его, а не `container.containerOwner.client`. На 14.10.2026 пакет и API отдают одно значение — владельца **на момент добавления КТК в заявку или смены КТК в строке**. Строки, созданные 22.09–08.10.2026, миграцией не дозаполнены: у них `owner_container_id` остаётся `NULL`, пока КТК в строке не сменят (вывод по исходному коду, данные среды не проверялись). Подробности — в [регистре остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).

## Merge-эндпоинты: замена в границах всей заявки, не вагона

`PUT /merge` группирует вход по вагону (`ShippingOrderContainerMergeDto` на вагон, вложенный список контейнеров), но фактическая замена (`ShippingOrderContainerService.merge` → `super.upsertAndDelete(filterByShippingOrder, updateDtos)`) сканирует **весь** `shipping_order_id`, а не отдельный вагон. Если в запросе перечислены контейнеры не для всех вагонов заявки, контейнеры отсутствующих в запросе вагонов физически совпадают со «спискoм на удаление» диапазона upsert и будут soft-удалены. `mergeForUnnumberedOrder` — аналогичная операция, но дополнительно требует `shippingOrder.fillingType == CONTAINER` (иначе `IllegalArgumentException`). Оба merge-метода используют не-deprecated `BaseService.upsertAndDelete(F filter, List<U> dtos)` (со strict-проверкой: неизвестный non-null `id` вне scope даёт `NotFoundException`), в отличие от deprecated `POST /{shippingOrderId}` на V1-контроллере, который вызывает overload по `UUID orderId` без этой строгой проверки.

## Что подтверждают tests, но не их запуск

- [`ShippingOrderContainerServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerServiceIntegrationTest.java) покрывает delete с каскадным soft-remove item-строк, переход `empty=true` с удалением items, пересчёт root totals при add/update/remove, preview dto и один positive merge-тест.
- [`ShippingOrderContainerDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerDaoServiceTest.java) — DAO-уровень.
- Не найдено: тест на повторное создание после soft-delete (constraint violation vs `DuplicateEntityException`); тест `getCargoWeight()`/ТН-отчёта для заявки с `ktkNumberUnknown`-контейнером; тест `merge` с частичным списком вагонов (удаление контейнеров отсутствующих вагонов); тест сообщения validator'а на предмет несовпадения с фактически проверяемыми полями.
- Тесты не запускались; их наличие не подтверждает применённую схему, порядок constraint enforcement или фактический HTTP response code при violation.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальный порядок constraint enforcement и допустимые null в развернутой БД.
2. Нужен прямой HTTP-тест: soft-delete КТК → повторное создание того же `(shippingOrder, container)` — подтвердить/опровергнуть гипотезу о конфликте app-level check и физического `UNIQUE`.
3. Нужен прямой тест генерации ТН-отчёта для заявки, где хотя бы один КТК имеет `ktkNumberUnknown=true` (или иначе `null` weight/container), чтобы подтвердить/опровергнуть NPE в `getCargoWeight()`.
4. Нужно обновить текст `ValidShippingOrderContainer.message()` до реально проверяемых полей либо реализовать проверку `weight`/`dangerousCargo`, если она задумывалась.
5. Нужно подтвердить бизнес-смысл поля `random` — в источниках есть только имя колонки, JPA-комментарий и default `true`, но не описание, как оно влияет на процесс.
6. Нужно решить, действительно ли `PUT /merge` должен быть full-order-replace, или конечный UI всегда шлёт полный список вагонов заявки — иначе частичный запрос совершит неожиданное удаление.
7. Нужно решить судьбу `@Deprecated` `getListOfEntitiesToOutbound`/закомментированного `insertRowsForFurtherIntegration` — тот же паттерн dead outbound config, что и у транспорта/товаров/cargo. **Не путать** с активным route chain package export (раздел «Outbound» выше) — это два разных механизма для одной таблицы.
8. ~~`ownerContainerId` в route chain package для вывоза всегда `null` с 22 сентября 2026~~ — **закрыто KIS-4830** (`401bbea3`, 08.10.2026). Остаётся вопрос: нужно ли дозаполнить `owner_container_id` у строк, созданных 22.09–08.10.2026, и должен ли снимок владельца обновляться, если владелец в registry сменился до отгрузки.

## Чек-лист изменения таблицы

1. При добавлении/снятии soft-delete-семантики для этой таблицы сверять физический `UNIQUE`/`CHECK` constraint на предмет учёта `deleted` — иначе app-level дубль-чек и физическая схема разойдутся.
2. При вызове методов, вычисляющих производные значения из nullable-полей entity (`getCargoWeight()` и подобные), переносить null-guard внутрь метода, а не полагаться на `filter(Objects::nonNull)` после `map`.
3. При обновлении текста Bean Validation error message синхронизировать его с фактическим состоянием SQL-схемы (удалённые колонки не должны оставаться в тексте ошибки).
4. Для merge/upsert-эндпоинтов, где scope замены шире, чем единица группировки во входном DTO (вагон vs вся заявка), явно документировать это в API-контракте, чтобы клиент не терял данные по невключённым группам.
5. Для нового reference-поля явно решить, `IdDto` или `IdCodeDto` использовать в DTO, и не оставлять `code` неиспользуемым, если lookup всё равно идёт по `id`.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Inbound actions вывоза](../business-rules/shipping-inbound-actions.md)
- [Route shipping plan/fact (meta-контур КТК/вагонов)](../business-rules/route-shipping-plan-fact-as-is.md)
- [Регистр остатков и владельца КТК: `ContainerOwner` AS-IS](../business-rules/container-remains-and-owner-as-is.md)
- [Route chain package export: 4 пакета в Datareon AS-IS](../business-rules/route-chain-package-export-as-is.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](shipping-order-cargo-as-is.md)
- [КТК поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-container-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderContainer](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainer.md)
