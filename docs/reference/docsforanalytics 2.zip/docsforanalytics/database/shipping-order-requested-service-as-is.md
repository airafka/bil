# `shipping_order_requested_service`: дополнительная услуга вывоза, физическая модель AS-IS (часть 22)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Это **source-level реконструкция**, не проверка применённой БД. Root totals — в [модели `shipping_order`](shipping-order-root-as-is.md#persisted-totals-и-конкурирующие-writers); формирование required-строк при создании заявки там же задокументировано отдельно. Контур почти буквально зеркален [`receiving_order_requested_service`](receiving-order-requested-service-as-is.md), с более короткой и однотипной миграционной историей; ниже — только отличия и специфика вывоза.

## Прямой request, required rows и calculation

[`ShippingOrderRequestedServiceController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderrequestedservice/ShippingOrderRequestedServiceController.java) — обычный CRUD (`POST /`, `PUT /{id}`, `DELETE /{id}`, `GET /{id}`, `/all`, `/page`, `/meta/{fieldName}`) плюс `POST /multipleaddition`/`PUT /multipleupdate`. [`CreationDto`](../dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceCreationDto.md) требует только `shippingOrder.id` и `termOfRequestedService.id` (`@NotNull @Valid`); даты/количество/тариф/цены/`systemManaged` не входят в request. [`UpdateDto`](../dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceUpdateDto.md) добавляет обязательный `id`. `PUT /{id}` не принимает `@PathVariable id` — лукап по body `UpdateDto.id`, как и везде в контуре заявок.

[`ShippingOrderRequestedServiceMapper.modelCreation`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingorderrequestedservice/ShippingOrderRequestedServiceMapper.java) задаёт новый UUID, `deleted=false`, `systemManaged=false`, `actualQuantity=ZERO`. [`ShippingOrderRequestedServiceService.calculateAndSetFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java) загружает [`TermOfRequestedService`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/termofrequestedservice/TermOfRequestedService.java) и заполняет `serviceOfMeasure` из связанной Service, `rate` из текущего условия, `plannedQuantity` и обе цены. Отдельной проверки, что переданное условие услуги принадлежит договору/клиенту заявки, в прямом create-пути не найдено — SQL FK проверяет только существование строки условия. Нет и app-level запрета создать несколько строк с одним и тем же `(shippingOrder, termOfRequestedService)`: SQL `UNIQUE` на эту пару не найден.

`plannedQuantity` вычисляется через [`calculatePlannedQuantity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java): `CalculationMethod.REQUEST → 1`; иначе — число active `ShippingOrderCargo` строк заявки, если `terminalArea = WAREHOUSE`, и число active `ShippingOrderContainer` строк — для всех остальных площадок (в том числе `CONTAINER`). Формула симметрична receiving-аналогу (там `CARGO_PLACE` для `WAREHOUSE` считает грузовые места, иначе — контейнеры), но конкретный набор задействованных DAO — свои для вывоза.

## Два независимых пути пересчёта `CARGO_PLACE`-услуг

При изменении дочерних строк заявки на пересчёт стоимости `CARGO_PLACE`-услуг ведут **два разных, не связанных друг с другом метода**:

1. [`ShippingOrderRequestedServiceService.updateCargoPlaceRequestedServices`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java) — вызывается из [`ShippingOrderContainerService.updateReceivingOrderRequestedService`](shipping-order-container-as-is.md#stored-totals-и-ktknumberunknown-флаг-заявки). Пересчитывает `plannedQuantity` через тот же **terminal-area-aware** `calculatePlannedQuantity` (выбор между cargo/container-счётчиком по площадке), затем `priceWithoutVAT = plannedQuantity × сохранённый row.rate`.
2. [`ShippingOrderCargoService.updateShippingOrderRequestedService`](shipping-order-cargo-as-is.md#stored-root-totals-и-побочный-пересчёт-услуг) — отдельная, **собственная** реализация внутри cargo-сервиса. Пересчитывает `plannedQuantity` напрямую как `countByShippingOrder` (число активных cargo-строк), **не** учитывая terminal area и не вызывая общий `calculatePlannedQuantity`.

Обе реализации в итоге приходят к одной и той же величине для `WAREHOUSE`-заявок (единственного сценария, где cargo-строки вообще создаются по бизнес-правилам заявки), поэтому наблюдаемое расхождение маловероятно при штатном использовании. Тем не менее это дублирование одной и той же формулы двумя независимо поддерживаемыми методами в разных сервисах: изменение алгоритма (например, включение qty-таблиц `NONE_CONTAINER`) в одном месте не гарантированно попадёт в другое. Прямого теста, сравнивающего результат обоих путей на одном датасете, не найдено.

## SQL-колонки и изменения

[`ALG-529 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240814_ALG-529_add_table_shipping_order_requested_service.sql) сразу создал таблицу под финальным именем `SHIPPING_ORDER_REQUESTED_SERVICE` (в отличие от receiving, которую пришлось переименовывать отдельным changeset) и сразу с колонками `price_without_vat`/`price_with_vat` (у receiving эти поля были переименованы позже отдельным `ALG-580`). Изначально была `unit_of_measure_id UUID NOT NULL REFERENCES unit_of_measure`; [`KIS-413`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250313_KIS-413_drop_column_and_add_new_column_order_requested_service.sql) удалил её и добавил nullable `service_of_measure VARCHAR(100)` — тем же changeset, что и для receiving-аналога.

| Поле | SQL source contract | Комментарий |
|---|---|---|
| `id`, `shipping_order_id`, `term_of_requested_service_id` | `UUID PK`; оба FK `NOT NULL` с самого начала | Как и у receiving; отдельного `UNIQUE` на пару не найдено. |
| `service_of_measure` | `VARCHAR(100) NULL` | `@Enumerated(STRING)`, берётся из `Service`, не из DTO. |
| `planned_quantity`, `rate` | `NUMERIC(16,3) NOT NULL`, `NUMERIC(10,2) NOT NULL` | Обе `NOT NULL` с ALG-529, без последующих снятий — строже, чем в некоторых других shipping-таблицах того же периода. |
| `price_without_vat`, `price_with_vat` | `NUMERIC(16,2) NOT NULL` | Java multiplication + [`VATCalculator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/VATCalculator.java) (`${config.vat.rate:0.2}` — source fallback, не подтверждённая deployed-ставка). Root суммирует именно **без НДС**. |
| `actual_quantity` | `NUMERIC(16,3) NOT NULL` | Mapper/required-builder ставят `0`; конкретный inbound writer для shipping-услуг в этом документе не трассировался — см. [inbound actions вывоза](../business-rules/shipping-inbound-actions.md). |
| `system_managed`, `deleted` | `BOOLEAN NOT NULL DEFAULT false` (обе) | Direct create → `false`; required root insert → `true` напрямую через DAO, минуя `ShippingOrderRequestedServiceService`. |
| Audit | стандартный `BaseEditable`/`BaseCreatable` | Как обычно. |

[`ALG-764`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240924_ALG-764_update_count_of_requested_services.sql) — one-off backfill `total_requested_service_quantity` по `count(*) WHERE NOT deleted`, той же миграцией и для receiving, и для shipping; не текущий service write path. Отдельного `UNIQUE`/`CHECK`/non-PK индекса для этой таблицы не найдено.

## Root totals, required rows и та же задержка агрегата

[`ShippingOrderRequestedServiceService.calculateAndSetShippingOrderFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java) после direct add/update/remove читает активные строки заявки и пишет `shipping_order.total_requested_service_quantity = count(rows)`, `total_requested_service_price = sum(priceWithoutVAT)` — идентичные формулы receiving-аналогу.

Как и в receiving-контуре, required-строки, вставляемые [`ShippingOrderService.addRequiredServices`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) при создании корня (`REQUEST → planned=1`, иначе `planned=0`, `systemManaged=true`), идут через **прямой DAO insert** (`shippingOrderRequestedServiceDaoService.add(requiredServices)`), минуя `ShippingOrderRequestedServiceService.postAdd` — то есть этот insert **не** вызывает `calculateAndSetShippingOrderFields`. Уже сохранённые в этот момент root-агрегаты (нулевые, установленные при create заявки) могут не отражать только что вставленные required-строки до следующего прямого пересчёта каким-либо другим сервисом. Этот же паттерн уже задокументирован для root в [`shipping-order-root-as-is.md`](shipping-order-root-as-is.md#persisted-totals-и-конкурирующие-writers).

Аналогично `updateCargoPlaceRequestedServices`/`ShippingOrderCargoService.updateShippingOrderRequestedService` (описанные выше) сохраняют **только строки услуг**, не вызывая пересчёт root-агрегатов заявки — та же задержка между row-level price и root `total_requested_service_price`, что и в receiving-контуре.

```mermaid
flowchart TD
    D[Direct DTO: order/term refs] --> S[Service: term lookup, terminal-area-aware planned quantity]
    R[Root creation: required contract terms] --> Q[Direct DAO insert systemManaged=true, no root recalculation]
    S --> E[(shipping_order_requested_service rows)]
    Q --> E
    E --> A[Direct add/update/remove: active-row count and priceWithoutVAT sum]
    A --> T[(shipping_order.total_requested_service_quantity/price)]
    CG[ShippingOrderCargoService: own CARGO_PLACE reprice] --> E
    CT[ShippingOrderContainerService via updateCargoPlaceRequestedServices] --> E
    BULK["multipleaddition/multipleupdate: self-invocation, per-item"] --> S
```

## Bulk-контракты: тот же self-invocation паттерн

`createByListOfServices`/`updateByListOfServices` вызывают `super::add`/`super::update` в цикле — не аннотированы `@Transactional`, то же self-invocation-ограничение атомарности, что и у [товарных строк](shipping-order-good-as-is.md#три-bulk-контракта-разная-атомарность) и [грузовых мест](shipping-order-cargo-as-is.md#четыре-bulkupsert-контракта-и-разная-атомарность). Отдельного `applyBatch`/`upsertAndDelete`-эндпоинта у этой сущности не найдено.

## Outbound: тот же dead-code паттерн

`postAdd`/`prepareModelToUpdate` содержат закомментированный `insertRowsForFurtherIntegration` с TODO: `EntityType.SHIPPING_ORDER_REQUESTED_SERVICE` отсутствует в [`OutboundConfigService.CONFIGURATION`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) — тот же паттерн, что у транспорта/товаров/cargo/контейнеров. Оставленный без вызова `getListOfEntitiesToOutbound` (`@Deprecated`) для `CARGO_SHIPMENT_TASK` вернул бы root `ShippingOrder`. Актуальная интеграция идёт через `ShippingOrderService.accept()`.

## Что подтверждают tests, но не их запуск

- [`ShippingOrderRequestedServiceServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceServiceIntegrationTest.java) проверяет заполнение полей при add и пересчёт root totals при add/update/remove.
- [`ShippingOrderRequestedServiceDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceDaoServiceTest.java) — DAO-уровень.
- Не найдено: тест, сравнивающий результат `ShippingOrderRequestedServiceService.updateCargoPlaceRequestedServices` и `ShippingOrderCargoService.updateShippingOrderRequestedService` на одинаковых входных данных; тест на дубль `(shippingOrder, termOfRequestedService)`; тест на задержку root-агрегата после вставки required-строк; тест атомарности `multipleaddition`/`multipleupdate`.
- Тесты не запускались; их наличие не подтверждает применённую схему или фактическое поведение при расхождении двух cargo-place реализаций.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog` и applied constraints в развернутой БД.
2. Нужно решить, стоит ли объединить `updateCargoPlaceRequestedServices` и `ShippingOrderCargoService.updateShippingOrderRequestedService` в одну реализацию, чтобы исключить риск расхождения при будущих изменениях формулы planned quantity.
3. Нужен тест на актуальность root `total_requested_service_quantity/price` сразу после создания заявки с required-услугами (до первого прямого add/update/remove отдельной строки).
4. Нужно подтвердить/опровергнуть отсутствие ownership-проверки термина услуги при прямом create (принадлежность договору/клиенту заявки).
5. Нужно решить судьбу `@Deprecated` `getListOfEntitiesToOutbound`/закомментированного `insertRowsForFurtherIntegration` — тот же паттерн dead outbound config, что и у остальных дочерних таблиц заявки.

## Чек-лист изменения таблицы

1. При изменении формулы `plannedQuantity` для `CARGO_PLACE` обновлять оба места: `ShippingOrderRequestedServiceService.calculatePlannedQuantity` и `ShippingOrderCargoService.updateShippingOrderRequestedService`.
2. Для прямых DAO-вставок сервисных строк (required services при создании заявки) явно решать, нужен ли немедленный пересчёт root-агрегатов, а не полагаться на следующий несвязанный вызов.
3. Для нового bulk-endpoint явно выбирать атомарность и не полагаться на `super::method()` внутри того же bean, если она важна.
4. Для нового условия услуги проверять owner/contract consistency на уровне сервиса, если целостность важна для ТЗ — SQL FK её не гарантирует.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](shipping-order-cargo-as-is.md)
- [КТК заявки на вывоз: физическая модель AS-IS](shipping-order-container-as-is.md)
- [Дополнительная услуга поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-requested-service-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderRequestedService](../entities/catalog/entities/shippingorderrequestedservice/ShippingOrderRequestedService.md)
