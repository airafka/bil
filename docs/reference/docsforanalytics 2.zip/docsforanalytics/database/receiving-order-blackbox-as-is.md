# `receiving_order_blackbox`: грузовое место без товарной детализации, физическая модель AS-IS (часть 8)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java controller/DTO/mapper/service/JPA, Excel parser, SQL/cumulative migrations и test sources. Это **source-level модель**, а не снимок применённой БД. Термин `blackbox` здесь означает минимальную строку грузового места для `ReceivingOrder.deliveryType=BY_CARGO`: таблица хранит ссылку на глобальный справочник [`Cargo`](../entities/catalog/entities/cargo/Cargo.md), но **не хранит** собственные количество, вес, размеры, товар, партию или упаковку.

## HTTP-контракт и обязательные поля

[`ReceivingOrderBlackboxController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingorderblackbox/ReceivingOrderBlackboxController.java) публикует list/page/meta/read, `POST /receivingorderblackbox/`, `PUT /receivingorderblackbox/{id}`, `DELETE /receivingorderblackbox/{id}` и `POST /receivingorderblackbox/multipleaddition`; полная сигнатура есть в [generated endpoint-каталоге](../api/endpoints-generated.md). В source `POST /all` оставлен без действующего `@Secure` — аннотация закомментирована; остальные просмотренные методы защищены permission `ReceivingOrder` соответствующего уровня. Runtime security chain и доступность маршрутов не проверены.

| Request / response | Поля и валидация | Реальное использование сервером |
|---|---|---|
| [`ReceivingOrderBlackboxCreationDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxCreationDto.md) | `receivingOrder @NotNull @Valid`, вложенный [`IdDto.id`](../dto/catalog/wms/IdDto.md) — `@NotNull`; `cargo @NotBlank @Size(max=100)` | Parent ID определяет заявку; строковый cargo code после Bean Validation обрезается `trim`, затем разрешается в общий каталог Cargo или создаётся. |
| [`ReceivingOrderBlackboxUpdateDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxUpdateDto.md) | Те же поля + body `id @NotNull` | Строка ищется по **body id**. URL `{id}` handler не принимает как Java-параметр и не вызывает overload со сравнением URL/body. `receivingOrder` обязателен в DTO, но существующий FK им не перепривязывается; меняется только Cargo при отличии code. |
| [`ReceivingOrderBlackboxDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxDto.md) | inherited `id` + `cargo: IdCodeDto` | Ответ не содержит `receivingOrder`, `deleted` или audit. Родительскую принадлежность из одного response DTO установить нельзя. |

[`ReceivingOrderBlackboxMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/receivingorderblackbox/ReceivingOrderBlackboxMapper.java) преобразует строку к временному Cargo через [`ObjectMapper.codeToCargo`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/ObjectMapper.java); он использует `StringUtils.trim`. SQL `cargo.code VARCHAR(100)` глобально `UNIQUE`, поэтому одинаковый код в разных заявках ссылается на одну строку справочника. Прямой blackbox service не запрещает несколько active blackbox rows с одним Cargo в одной заявке: unique пары в SQL source нет.

## Direct CRUD, root counter и повторное удаление

При direct create [`ReceivingOrderBlackboxService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorderblackbox/ReceivingOrderBlackboxService.java):

1. Загружает корень и проверяет допустимый для изменения статус через `OrderServiceUtils`.
2. Повторно загружает корень и требует `deliveryType=BY_CARGO`.
3. [`CargoService.findOrCreateCargo`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/cargo/CargoService.java) ищет глобальный Cargo по trimmed code или добавляет его.
4. Сохраняет blackbox row, блокирует корень `findAndLock` и вызывает `ReceivingOrder.increaseTotalCargoQuantity()`, то есть делает `totalCargoQuantity += 1` внутри transactional `BaseService.add`.

Это инкремент, а не `COUNT(active blackbox rows)`. Update проверяет статус **существующего** parent, меняет только Cargo и не меняет counter. Delete — soft-delete, затем lock parent и `totalCargoQuantity -= 1`. [`BaseDaoService.findById`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseDaoService.java) читает row по repository ID без deleted-фильтра, а `preRemove` не запрещает уже deleted row. Поэтому повторный `DELETE` того же ID source-level способен повторно уменьшить counter, в том числе увести его ниже active-row count или ниже нуля. Прямого repeated-delete test не найдено.

`POST /multipleaddition` вызывает `stream().map(super::add)` без собственной `@Transactional`. Аннотация inherited `BaseService.add` находится на self-invoked method, поэтому общая атомарность списка и наличие ожидаемой transaction/lock semantics требуют отдельного integration/HTTP test; source test для endpoint не найден. Каждая успешная direct add операция увеличивает counter отдельно.

Full-copy path [`ReceivingOrderService.createFullCopyOfOrder`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java) вызывает transactional `ReceivingOrderBlackboxService.copy` только для warehouse `BY_CARGO`; copy разрешён для source `TransportType.VEHICLE`, создаёт строки через `this.add` и тем самым проверяет destination delivery type и увеличивает destination counter.

## Второй write path: загрузка Excel

[`ReceivingOrderAutoWarehouseContainerParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseContainerParser.java) обслуживает template `RECEIVING_ORDER_AUTO_WAREHOUSE_CONTAINER`. Общий [`ExcelTemplateCommonFileParsingService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/ExcelTemplateCommonFileParsingService.java) допускает заявку в `DRAFT`/`ON_REVIEW`, а [`AbstractAutoWarehouseContainerParser.save`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/AbstractAutoWarehouseContainerParser.java) для каждой строки:

- ищет совпадение `order ID + cargo code` с `deleted=null`, запрещает найденную active строку, но разрешает повтор после soft-delete;
- создаёт/переиспользует Cargo и вызывает `ReceivingOrderBlackboxDaoService.add` напрямую;
- **не вызывает** `ReceivingOrderBlackboxService.prepareModelToAdd/postAdd`: нет проверки `deliveryType=BY_CARGO`, root lock и `totalCargoQuantity += 1`.

Следовательно, Excel import способен создать active blackbox rows при неизменном root counter; соответствие типа шаблона типу конкретной заявки также не защищено этим parser method. Parser transactional на весь `save`, однако Cargo lookup-then-insert и отсутствие DB unique пары root+Cargo оставляют конкурентный сценарий отдельным вопросом.

## SQL source и ограничения

[`ReceivingOrderBlackbox`](../entities/catalog/entities/receivingorderblackbox/ReceivingOrderBlackbox.md) наследует UUID/audit и реализует soft-delete. Единственная найденная table migration — [`KIS-1134`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250529_KIS-1134_add_receiving_order_blackbox.sql):

| Java поле | SQL source contract | Комментарий |
|---|---|---|
| `id` | `UUID PRIMARY KEY` | Генерируется `BaseIdentifier.@PrePersist`, если не задан. |
| `receivingOrder` | `receiving_order_id UUID NOT NULL REFERENCES receiving_order(id)` | N:1, без объявленного `ON DELETE`; direct update parent не меняет. |
| `cargo` | `cargo_id UUID NOT NULL REFERENCES cargo(id)` | N:1 на глобальный [`cargo`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250318_KIS-742_add_table_cargo.sql), где code `VARCHAR(100) NOT NULL UNIQUE`. |
| `deleted` | `BOOLEAN NULL`, без SQL default | Java builder default false и mapper ignore дают false в обычном create. SQL допускает null; default filter `deleted=false` не включает null-строки. |
| Audit | `created_at/by NOT NULL`, `updated_at/by NULL` | Наследуемое auditing; отсутствует в request/response blackbox DTO. |

В migration source не найдено `UNIQUE(receiving_order_id,cargo_id)`, CHECK, отдельного индекса по parent/cargo/deleted или последующего ALTER этой таблицы. `CREATE TABLE` не содержит `IF NOT EXISTS`. Фактические FK names, indexes, null rows и применённость changeset нужно проверять через `DATABASECHANGELOG`/`pg_catalog`.

## Read-side и downstream-согласованность

Default [`ReceivingOrderBlackboxFilter`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/receivingorderblackbox/ReceivingOrderBlackboxFilter.java) задаёт `deleted=false`; `container` — JSON alias поля `cargo`, meta aliases `container/cargoNumber/cargo` разрешаются в `cargo.code`. Endpoint `/receiving-order/{receivingOrderId}/meta/{fieldName}` принудительно подставляет parent filter. Прямой `GET /{id}` использует ID lookup без default deleted filter и source-level способен вернуть soft-deleted row.

[Accept validator](../business-rules/receiving-orders.md#склад--автомобиль) для `BY_CARGO` проверяет наличие хотя бы одной active blackbox row; он не сверяет `totalCargoQuantity` с их числом. [`ItemReceivingTaskExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/receiving/itemreceivingtask/ItemReceivingTaskExportService.java) одновременно передаёт root `totalCargoQuantity` как `cargoQty`, а active blackbox rows — как items с cargo code и нулевыми `pkgQty/qty`. Поэтому direct duplicate, repeated delete или Excel write могут дать разные `cargoQty` и количество outbound items.

Rerunnable [`analytics.good_remain_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/V1.0.0_KIS-1410_add_view_good_remain.sql) связывает remains с blackbox только по `cargo_id`, без parent/status/deleted predicate. Один глобальный Cargo, связанный с несколькими blackbox rows, способен размножить строки view и дать неоднозначный order/client join; это source-level следствие SQL join, фактические данные/view output не проверялись.

```mermaid
flowchart TD
    H[Direct POST: order ID and cargo code] --> V[Status and deliveryType BY_CARGO]
    V --> C[Find or create global Cargo]
    C --> B[(receiving_order_blackbox)]
    B --> I[Lock root and totalCargoQuantity plus 1]
    X[Excel template upload] --> D[Duplicate check then DAO add]
    D --> B
    D -. no root increment .-> R[(receiving_order.total_cargo_quantity)]
    I --> R
    E[Repeated DELETE by same ID] --> M[Soft-delete and totalCargoQuantity minus 1 again]
    M --> R
    B --> A[Accept: active row exists]
    B --> O[Outbound items by active rows]
    R --> Q[Outbound cargoQty]
```

[`ReceivingOrderBlackboxServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/receivingorderblackbox/ReceivingOrderBlackboxServiceIntegrationTest.java) source покрывает direct create нового Cargo и `+1`, wrong delivery type, Cargo update, soft-delete и `-1`. [`ReceivingOrderAutoWarehouseContainerParserTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseContainerParserTest.java) покрывает empty/duplicate/re-add-after-delete и DAO save; accept test подтверждает, что deleted-only row считается отсутствием. Outbound unit test проверяет blackbox item mapping. Не найдены прямые tests duplicate direct create, повторного DELETE, null deleted, multi-add atomicity/validation, Excel root counter/delivery mismatch, concurrent Cargo/root+Cargo create и remain-view multiplicity. Тесты **не запускались**.

Influencing commits: `1e4f8f22` (глобальный Cargo и UNIQUE code, 2025-03), `be2fd261` (delivery types, blackbox table/CRUD, 2025-05), `b390898a` (multiple addition, 2025-11), `f19442d9` (cargo max length, 2026-02), `52668052` (copy, 2026-05), `978f0601` (meta/search, 2026-08). История commit не доказывает применённость миграций на среде.
