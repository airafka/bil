# `shipping_order_transport`: транспорт заявки на вывоз, физическая модель AS-IS (часть 17) — DEPRECATED

> **DEPRECATED.** Коммит [`d30d77ad`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_remove_order_transport.sql) (KIS-4093, 24 сентября 2026) удалил таблицу/сущность `shipping_order_transport`, её controller/mapper/service/DTO и endpoint'ы `POST/PUT /shippingordertransport/*`, описанные ниже. Backfill-миграция [`v.1.34.0_..._backfill_order_transport_data.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql) перенесла данные так: `consignee_id`/`consignee_address` — `COALESCE`-слиянием в `shipping_order` (это заодно закрывает описанный ниже конфликт «root vs transport» правил для грузополучателя — поле теперь одно); `carrier_id`/`client_driver_id`/`client_vehicle_id` — в новую строку `route` (`route_type='SHIPPING'`), если у заявки ещё не было `route_id`. Содержимое ниже сохранено как исторический AS-IS удалённой таблицы; актуальные правила транспорта заявки на вывоз теперь нужно искать в модели `route` и в корне `shipping_order`, отдельный source-level документ по объединённому полю ещё не написан (открытый пункт).

Проверено по checkout `22fac945e8116d04972ccc87b06b2303acf7a561` (устаревший, ветка `dev` уже не содержит этот коммит — см. [журнал сверки](../traceability/repository-change-log.md)): Java DTO/controller/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Это **source-level реконструкция**, а не проверка применённой БД. Корень заявки и его собственные `consignee`/`consigneeAddress` описаны [отдельно](shipping-order-root-as-is.md): одноимённые поля транспорта физически относились к другой таблице и, как показано ниже, к другому набору бизнес-правил. Текущие правила вывоза — в [процессе вывоза](../business-rules/shipping-orders.md) и [валидации заявок](../business-rules/order-validation.md).

## Общий ключ и HTTP-цепочка

`ShippingOrderTransport` (сущность удалена) — отдельная `@Entity @Table(SHIPPING_ORDER_TRANSPORT)` с наследуемыми audit-полями `BaseEditable`. [`ALG-393 CREATE TABLE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240807_ALG-393_add_table_shipping_order_transport.sql) задаёт `id UUID PRIMARY KEY REFERENCES shipping_order(id) NOT NULL`: shared-key связь, а не отдельная `shipping_order_id` колонка. Владеющая сторона — `ShippingOrderTransport.shippingOrder` с `@OneToOne(optional = false) @JoinColumn(name = "id")`; обратная сторона — [`ShippingOrder.transport`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingorder/ShippingOrder.java) с `@OneToOne(mappedBy = "shippingOrder", cascade = {MERGE, PERSIST})`. Ровно один (или ноль) transport row на заявку и отсутствие transport без root обеспечиваются PK/FK на SQL-уровне; применённость и ON DELETE не проверялись.

В отличие от `receiving_order_transport`, эта строка **не обязательна для каждой заявки**: [`ShippingOrderAcceptValidator.transportChecks`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) требует существования `ShippingOrderTransport` только для `TransportType.VEHICLE` (площадки `WAREHOUSE` и `CONTAINER`); ветка `CONTAINER + RAILWAY` эту проверку не вызывает и опирается на `ShippingOrderRailwayCarriage`/`ShippingOrderEtranInvoice`. Проверка — только существование строки; поля самой строки повторно не проверяются.

`ShippingOrderTransportController` (удалён) объявлял `POST /shippingordertransport/` с `CreationDto` и `PUT /shippingordertransport/{id}` с `UpdateDto`; DELETE endpoint не найден. Create/update защищены `@Secure(..., CREATE/WRITE)` по `ShippingOrder.ShippingOrderTransport`; deployed grants не проверялись. Для пяти `IdDto` полей (`shippingOrder`, `consignee`, `carrier`, `clientVehicle`, `clientDriver`) DTO задаёт `@Valid @NotNull`, а [`IdDto.id`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/IdDto.java) — `@NotNull`. `consigneeAddress` также имеет `@NotNull String` (пустая строка проходит, `null` — нет), хотя SQL `NOT NULL` на этой колонке снят [`KIS-2441`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260115_KIS-2441_remove_not_null_consignee_address.sql). Update наследует поля create и добавляет обязательный UUID `id`.

`PUT /shippingordertransport/{id}` объявляет path, но Java-метод контроллера **не принимает** `@PathVariable id`: `service.update(updateDto)` вызывает overload `BaseService.update(U dto)`, который ищет цель по **`UpdateDto.id`**, а не по пути. Расхождение path ID и body ID не имеет source-level защиты на этом endpoint — как и на корневом `PUT /shippingorder/{id}`.

### Создание: bidirectional shared-key crutch

`ShippingOrderTransportMapper.modelCreation` (удалён) маппил `shippingOrder.id → model.id`. `ShippingOrderTransportService.prepareModelToAdd` (удалён) затем находил root `ShippingOrder` по этому же ID, вызывает `shippingOrder.setTransport(newModel)` и `newModel.setShippingOrder(shippingOrder)`, после чего явно выполняет `shipmentOrderDaoService.update(shippingOrder)` — код помечен комментарием `Crutch, because shippingOrderTransport is PK and FK and in hibernate between shippingOrderTransport and shippingOrder bidirectional association`. Commit `dd22741c` (KIS-928 «fix creating shippingOrderTransport») добавил именно этот вызов — то есть без него создание transport ранее не работало корректно из-за bidirectional `@OneToOne` с общим PK. Поле `ShippingOrder.transport` — обратная (`mappedBy`) сторона без своей колонки, поэтому вызванный `update(shippingOrder)` не пишет отдельную FK-колонку в `shipping_order`; является ли он источником побочного изменения `updated_at/updated_by` root-заявки (Hibernate dirty checking может не сгенерировать реальный SQL UPDATE, если у `shipping_order` нет изменённых физических колонок) — не проверялось.

Отдельной проверки принадлежности `consignee`/`carrier`/`clientVehicle`/`clientDriver` клиенту заявки в source не найдено — ни на create, ни в `prepareModelToUpdate`.

## Колонки и изменение миграциями

| DTO / JPA поле | SQL source contract на текущем checkout | Изменение/обработка |
|---|---|---|
| `shippingOrder.id` → `ShippingOrderTransport.id` | `UUID PK NOT NULL`, FK на `shipping_order(id)` | ALG-393; один shared ID. Create mapper подставляет root ID; update target выбирается отдельно по `UpdateDto.id`. |
| `consignee.id` → `consignee_id` | `UUID NOT NULL REFERENCES client_related_entity(id)` | ALG-393. Update при отличии делает `ClientRelatedEntityDaoService.findById`, затем `setConsignee`; без роли/client-проверки, в отличие от одноимённого поля root (см. ниже). |
| `carrier.id` → `carrier_id` | `UUID NOT NULL REFERENCES client_related_entity(id)` | ALG-393. Update аналогично делает lookup без ownership-проверки. Только на transport; у root `shipping_order` собственного `carrier_id` нет. |
| `clientVehicle.id` → `client_vehicle_id` | `UUID NOT NULL REFERENCES client_vehicle(id)` | ALG-393. Update делает DAO lookup. |
| `clientDriver.id` → `client_driver_id` | `UUID NOT NULL REFERENCES client_driver(id)` | ALG-393. Update делает DAO lookup. |
| `consigneeAddress` → `consignee_address` | `VARCHAR(512)`, `NOT NULL` снят `KIS-2441` (2026-01-15) | Update присваивает напрямую, включая пустую строку из Bean Validation `@NotNull` (без `@NotBlank`). DTO-обязательность (`@NotNull`) теперь строже снятого SQL `NOT NULL`. |
| Audit, не request DTO | `created_at TIMESTAMP NOT NULL`, `created_by VARCHAR(50) NOT NULL`, `updated_at TIMESTAMP NULL`, `updated_by VARCHAR(50) NULL` | ALG-393 и inherited [`BaseEditable`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/base/BaseEditable.java)/`BaseCreatable` auditing. |

Первоначальный ALG-393 хранил текстовые `vehicle_code`, `vehicle_trailer_number`, `vehicle_insurance_number`, `with_trailer`, `driver_code`, `driver_phone_number`, `driver_poa_number` рядом с уже существующими FK на `client_vehicle`/`client_driver`. [`ALG-511`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240919_ALG-511_increase_max_length_of_phone_number_columns.sql) расширил `driver_phone_number` до `VARCHAR(50)`. [`KIS-1106`](../../../db-layer/src/main/resources/db/changelog/v.1.23.0/v.1.23.0_20250723_KIS-1106_remove_driver_and_vehicle_info_from_order_transport.sql) удалил **все семь** этих текстовых snapshot-колонок (той же миграцией и для `receiving_order_transport`). На текущей JPA entity их уже нет; поле `waybill`, которое существует у `receiving_order_transport`, здесь никогда не создавалось — у заявки на вывоз нет накладной на этом уровне.

По просмотренным SQL references к этой таблице отдельные `UNIQUE`, `CHECK` или non-PK index не найдены. PK обеспечивает уникальность `id`; ON DELETE FK и полный набор фактических constraints нужно сверять с `pg_catalog`/`DATABASECHANGELOG`, а не выводить из JPA.

## Дублирующийся грузополучатель: root и transport — разные правила

И [`ShippingOrder`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingorder/ShippingOrder.java) (колонки `consignee_id`/`consignee_address` в `shipping_order`), и `ShippingOrderTransport` (колонки `consignee_id`/`consignee_address` в `shipping_order_transport`) имеют поля с одинаковыми именами, но это **независимые физические колонки в разных таблицах** с разными пишущими правилами:

- Root: [`ShippingOrderService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) требует `consignee.getIsConsignee() == true` и `consignee.getClient().getId() == shippingOrder.getClient().getId()` (иначе `ShippingOrder.InvalidConsigneeRole`/`InvalidConsigneeClient`), а адрес **не берётся из тела запроса** — сервер сам подставляет `StringUtils.trimToNull(consignee.getAddressFact())`. FK колонки `consignee_id` в SQL source не найден.
- Transport: `ShippingOrderTransportService.prepareModelToUpdate` делает обычный `ClientRelatedEntityDaoService.findById` без проверки роли/клиента, а `consigneeAddress` — это то, что прислал клиент в DTO, без замены на `addressFact`. FK `consignee_id → client_related_entity(id)` для этой таблицы, наоборот, объявлен в ALG-393 SQL.

Прочитано (`grep` по бизнес-source) поле `ShippingOrderTransport.consignee`/`consigneeAddress` используется **только** в собственном mapper transport (`toDto`/`toDetailedDto` — эхо того, что сохранено). TN-отчёт ([`TNContainerReportDataCollectorService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/TNContainerReportDataCollectorService.java)), копирование в рейс ([`RouteService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java)) и outbound `TRANSPORT_MANIFEST` ([`ShippingTransportManifestExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/shipping/transportmanifest/ShippingTransportManifestExportService.java), `transportManifestDto.setConsigneeId(shippingOrder.getConsignee().getSyncId())`) читают исключительно **root** `shippingOrder.getConsignee()`/`getConsigneeAddress()`. Других потребителей transport-версии этих двух полей в business source не найдено. Практический вывод: значение, отправленное через `/shippingordertransport/`, может разойтись с валидированным root-значением и, по видимым source-путям, нигде дальше не используется, кроме возврата тем же API.

## Источник полей ответа и риск несогласованного snapshot

`ShippingOrderTransportDto` (удалён) содержал `consigneeAddress`, `consignee`, `carrier`, `vehicleInfo`, `driverInfo`. Mapper `toDto`/`toDetailedDto` строит [`VehicleInfoDto`](../dto/catalog/transport/VehicleInfoDto.md) из **текущих** `clientVehicle.id/code/trailerNumber/insuranceNumber/withTrailer` и [`DriverInfoDto`](../dto/catalog/transport/DriverInfoDto.md) из **текущих** `clientDriver.id/code/phoneNumber/POANumber`, а не из удалённых `KIS-1106` snapshot-колонок; `consignee` строится через `ClientRelatedEntityMapper.toShortDto`, `carrier` — `IdCodeDto`. Как и в receiving-контуре, изменение справочной записи машины/водителя/грузополучателя после создания transport меняет последующий ответ без отдельного UPDATE строки `shipping_order_transport`.

## Outbound: transport становится «мёртвым» отдельным writer-ом

[`ALG-682`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240905_ALG-682_add_transport_manifest_outbound_config.sql) и [`ALG-676`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240910_ALG-676_add_cargo_shipment_task_outbound_config.sql) когда-то добавили в таблицу `outbound_config` строки `SHIPPING_ORDER_TRANSPORT` × `TRANSPORT_MANIFEST`/`CARGO_SHIPMENT_TASK`. Актуальный [`OutboundConfigService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) прямо документирует переход «конфигурация хранится в коде, а не в БД» и держит статическую `CONFIGURATION`, где обе строки для `SHIPPING_ORDER_TRANSPORT` **закомментированы**. Поэтому:

- `ShippingOrderTransportService.postAdd`/`prepareModelToUpdate` — код, вызывающий `insertRowsForFurtherIntegration(newModel)`, тоже закомментирован (с явным TODO «dead code»), а оставленный без вызова `getListOfEntitiesToOutbound` помечен `@Deprecated`: сам transport-сервис никогда не создаёт outbound-строку.
- Фактическая интеграция идёт через **root**: `addConfig(EntityType.SHIPPING_ORDER, MessageType.SHIPMENT_TRANSPORT_MANIFEST)` активен, и [`ShippingOrderService.getListOfEntitiesToOutbound`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) для этого `messageType` сам подгружает sibling `ShippingOrderTransport` по ID заявки и добавляет его как отдельную `CanBeOutbound` строку (наряду с неудалёнными `ShippingOrderRailwayCarriage`).
- Единственная точка вызова — `ShippingOrderService.accept(UUID)` (`insertRowsForFurtherIntegration(shippingOrder)`). Поэтому outbound-строка для transport создаётся **в момент accept заявки**, а не в момент создания/обновления самого transport. Update transport **после** accept не создаёт новую outbound-запись повторно — источник не показывает listener/hook на `ShippingOrderTransportService.update`, который бы форсировал повторную выгрузку.
- [`ShippingTransportManifestExportService.toDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/shipping/transportmanifest/ShippingTransportManifestExportService.java) собирает исходящий `TransportManifestDto` из `ShippingOrderTransport` (carrier/vehicle/driver) **и** root `ShippingOrder` (`consignee`, `contract.company`, `route`, `plannedShippingDateTime`) одновременно — то есть итоговое исходящее сообщение смешивает обе таблицы, при этом `consigneeId` там всегда из root, а не из transport-поля с тем же именем.

```mermaid
flowchart TD
    D[Creation DTO: shippingOrder/consignee/carrier/vehicle/driver IDs] --> M[Mapper: shippingOrder.id to transport.id]
    M --> P[prepareModelToAdd: bidirectional crutch update on shipping_order]
    P --> T[(shipping_order_transport: shared PK/FK + reference FKs)]
    U[Update DTO: id plus inherited fields] --> L[BaseService lookup by body id]
    L --> S[Service: root status check, selective reference lookups, no ownership check]
    S --> T
    T --> R[Response mapper: vehicleInfo/driverInfo from current client_vehicle/client_driver]
    ACC[ShippingOrder.accept] -->|SHIPMENT_TRANSPORT_MANIFEST config on SHIPPING_ORDER| OD[(outbound_data row, entityType=SHIPPING_ORDER_TRANSPORT)]
    T -.sibling lookup by shared id.-> ACC
    OD --> EXP[ShippingTransportManifestExportService: transport carrier/vehicle/driver + root consignee/route/contract]
```

## Ограничения и индексы, найденные в source

| Вид | Что подтверждено |
|---|---|
| PK | `shipping_order_transport(id)`. |
| FK | `id → shipping_order(id)`, `consignee_id/carrier_id → client_related_entity(id)`, `client_vehicle_id → client_vehicle(id)`, `client_driver_id → client_driver(id)`. ON DELETE не указан (по умолчанию `NO ACTION`). |
| CHECK | Не найден. |
| UNIQUE | Business unique кроме PK не найден. |
| Индексы | Отдельные source-индексы на FK-колонки не найдены; PK создаёт индекс автоматически. |
| Bean Validation vs SQL | `consigneeAddress` — DTO `@NotNull`, SQL nullable с `KIS-2441`; остальные четыре reference-поля — DTO `@NotNull` совпадает с SQL `NOT NULL`. |

## Проверка статуса при update: разделяемая (и потенциально неточная) проверка

`ShippingOrderTransportService.preUpdate` вызывает [`OrderServiceUtils.checkOrderStatusForUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/OrderServiceUtils.java): запрещает update, если `orderStatus` не `DRAFT`/`ON_REVIEW`, а для `ON_REVIEW` дополнительно требует permission. Тот же самый метод переиспользуется по меньшей мере в 12 дочерних сервисах и на обеих сторонах (`shippingorder*`, `receivingorder*`), но **жёстко проверяет** `Permission.RECEIVING_ORDER_SEND_TO_ACCEPT`, а не `SHIPPING_ORDER_SEND_TO_ACCEPT`, даже когда вызывающая сторона — заявка на вывоз. Это общий source-level дефект метода, а не специфика транспорта; здесь он подтверждён именно на пути `ShippingOrderTransport.update`, что означает, что update transport заявки в статусе `ON_REVIEW` авторизуется правом, буквально названным «поставка», а не «вывоз».

## Миграции и влияющие commits

| Изменение | Commit |
|---|---|
| Первичная таблица со snapshot-колонками | `11de138554ed6935c9906dd7f5716bef8f8c1889` |
| Outbound config `TRANSPORT_MANIFEST` (ныне не используется кодом) | `b67b2971a…` |
| Outbound config `CARGO_SHIPMENT_TASK` (ныне не используется кодом) | `5de66acd1…` |
| Увеличение длины `driver_phone_number` | `932fbf5b…` |
| Bidirectional shared-key crutch в `prepareModelToAdd` (KIS-928) | `dd22741cdcbd54daa16efd5c4bc7308e8b14158b` |
| Удаление текстовых driver/vehicle snapshot-колонок (KIS-1106) | `c9294b26…` |
| Снятие `NOT NULL` с `consignee_address` (KIS-2441) | `c7728e90…` |

## Что подтверждают tests, но не их запуск

- `ShippingOrderTransportDaoServiceTest` (удалён вместе с сущностью) покрывал add/findById/getPage/filterByShippingOrder/update на Testcontainers через прямое построение entity (`ShippingOrderTestEntityFactory`), минуя HTTP DTO/service-логику.
- Отдельного `ShippingOrderTransportService`/HTTP-integration теста не найдено. Path/body ID mismatch, role/ownership-проверка consignee на transport, отличие DTO `@NotNull` от снятого SQL `NOT NULL` и hardcoded `RECEIVING_ORDER_SEND_TO_ACCEPT`-permission в `checkOrderStatusForUpdate` не покрыты тестами в этом контуре.
- Тесты в этом подэтапе не запускались; их наличие не подтверждает применённую схему, HTTP-роутинг или фактическое поведение permission-проверки.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные ON DELETE/индексы и допустимые null в развернутой БД.
2. Нужно решить, является ли дублирование `consignee`/`consigneeAddress` между `shipping_order` и `shipping_order_transport` осознанным (например, «грузополучатель по документам транспорта» отдельно от «грузополучателя заявки»), либо забытым legacy-полем; на текущий момент transport-версия не читается ни одним найденным потребителем, кроме собственного ответа API.
3. Нужен прямой HTTP-тест расхождения path/body ID для `PUT /shippingordertransport/{id}`.
4. Нужно подтвердить/опровергнуть, действительно ли `checkOrderStatusForUpdate` должен проверять `SHIPPING_ORDER_SEND_TO_ACCEPT` для всех shipping-side вызовов, и оценить последствия текущего hardcoded receiving-права для прод-доступа.
5. Нужен ответ, должен ли update transport после `accept` заявки повторно создавать outbound `TRANSPORT_MANIFEST` строку, и если да — где должен быть этот hook.
6. Нужно решить судьбу двух `@Deprecated`/закомментированных outbound-веток в `ShippingOrderTransportService` — удалить или восстановить конфигурацию.

## Чек-лист изменения таблицы

1. Для нового reference-поля добавить owner-ship/role-проверку по аналогии с root `consignee`, а не полагаться только на факт существования связанной записи.
2. Для DTO-обязательности сверять её с текущим SQL `NOT NULL`/`NULL` каждый раз, когда меняется миграция (`consigneeAddress` — уже пример расхождения).
3. Для нового outbound message-type сверять и код `OutboundConfigService.CONFIGURATION`, и историю `outbound_config` в БД — таблица может быть legacy-источником, не совпадающим с активной конфигурацией.
4. Для проверок статуса переиспользуемых между заявками методов (`OrderServiceUtils`) явно указывать нужный `Permission`, а не полагаться на общий метод с зашитым правом одной из сторон.
5. Для path ID vs body ID на `PUT` явно решить, что авторитетно, и добавить сверку, если это требование ТЗ.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Транспорт заявки на поставку: физическая модель AS-IS (аналогичный контур)](receiving-order-transport-as-is.md)
- [API заявок](../api/order-api.md)
- JPA-паспорт ShippingOrderTransport — удалён вместе с сущностью (KIS-4093)
