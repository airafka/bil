# `shipping_order_good`: номенклатура заявки на вывоз, физическая модель AS-IS (часть 18)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, DTO/controller/mapper/service/JPA, cumulative SQL migrations и исходники тестов. Это **source-level реконструкция**, не инспекция применённой БД. Stored totals корня подробнее разобраны в [физической модели `shipping_order`](shipping-order-root-as-is.md), транспорт — в [отдельном документе](shipping-order-transport-as-is.md), бизнес-правила — в [процессе вывоза](../business-rules/shipping-orders.md). Контур почти зеркален [`receiving_order_good`](receiving-order-good-as-is.md); ниже — только различия и специфика вывоза.

> Дополнение от 15.10.2026: изменения `8ee1ab68` (13.10.2026, KIS-4841, «add batchUnknown») сверены с backend `729c9a17` (14.10.2026): колонка `batch_unknown`, серверная проверка партии, привязка фактической партии в `WmsShipmentResultAction`. Остальной текст — по исходному checkout.

## HTTP → DTO → сохранение

У `shipping_order_good` **три независимых bulk-контракта** с разной атомарностью, плюс обычный CRUD:

- [`ShippingOrderGoodController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordergood/ShippingOrderGoodController.java): `POST /shippingordergood/`, `PUT /shippingordergood/{id}`, `DELETE /shippingordergood/{id}`, `POST /shippingordergood/multipleaddition`, `PUT /shippingordergood/multipleupdate`, `POST /shippingordergood/{shippingOrderId}/batch`. Все защищены `@Secure(Permission.SHIPPING_ORDER_SHIPPING_ORDER_GOOD, ...)`, кроме `/{shippingOrderId}/batch`, который использует `permissionName = "ShippingOrder.ShippingOrderGood"` через отдельный `@Secure(permission=...)` overload — путь строки в `PERMISSION_PATH` совпадает, но конкретный уровень для этого endpoint — `PermissionLevel.DELETE`, хотя он выполняет combined add/update/**и** delete.
- [`ShippingOrderGoodControllerV2`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordergood/ShippingOrderGoodControllerV2.java): read-only `page`/`list`/`meta/{fieldName}` под `/shipping-order/{shippingOrderId}/shipping-order-good`, форсирующий `filter.shippingOrder = ShippingOrderFilter.byId(shippingOrderId)` из path независимо от присланного тела.

[`CreationDto`](../dto/catalog/shippingordergood/ShippingOrderGoodCreationDto.md) требует `shippingOrder`/`clientGood` (`@Valid @NotNull` `IdDto`), `plannedQuantity` (`@NotNull @Positive`), `price`/`totalPrice` (`@NotNull @Min(0)`, ноль разрешён); `batch` — необязательный на уровне DTO `IdDto`, плюс с 13.10.2026 (`8ee1ab68`, KIS-4841) `boolean batchUnknown` (есть и в ответе `ShippingOrderGoodDto`). Раньше партия на сервере не требовалась вовсе; теперь `prepareModelToAdd` и `prepareModelToUpdate` вызывают [`OrderGoodBatchValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/ordergood/validation/OrderGoodBatchValidator.java) (`SOURCE_CONFIRMED`) с теми же правилами и кодами, что у [поставки](receiving-order-good-as-is.md#http--dto--сохранение): при `MANUFACTURE_DATE`/`EXPIRATION_DATE` нужна партия либо `batchUnknown=true` (`OrderGood.MissingBatch`), `batchUnknown` с партией → `OrderGood.BatchUnknownWithBatch`, без партионного учёта → `OrderGood.BatchUnknownNotAllowed`; HTTP 400. `copy()` переносит `batchUnknown`, поэтому копия старой строки с учётом, но без партии, теперь падает `OrderGood.MissingBatch`. [`UpdateDto`](../dto/catalog/shippingordergood/ShippingOrderGoodUpdateDto.md) наследует их и добавляет `@NotNull id`. Как и в receiving-контуре, никакой server-side проверки `totalPrice = plannedQuantity × price` не найдено — оба значения принимаются как есть.

`PUT /{id}` не принимает `@PathVariable id`: `service.update(updateDto)` ищет строку по **`UpdateDto.id`**, без сверки с path.

## Обновление batch: асимметрия с `clientGood`

[`ShippingOrderGoodService.prepareModelToUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodService.java) обрабатывает две reference-связи по-разному:

- `clientGood`: при отличии — `clientGoodDaoService.findById(updateModel.getClientGood().getId())`, то есть в `existingModel` попадает полностью загруженная managed-сущность.
- с 13.10.2026 (`8ee1ab68`, KIS-4841) между ними — `OrderGoodBatchValidator` по `batchAccountingType` текущего (после возможной смены) `clientGood` и body `batch`/`batchUnknown`; после него `batchUnknown` перезаписывается из body.
- `batch`: **безусловно** `existingModel.setBatch(updateModel.getBatch())` — без `isNotEquals`-проверки и без DAO lookup. `updateModel` получен из `mapper.modelUpdate(updateDto)`, а MapStruct для `IdDto batch → Batch batch` (при отсутствии явного `@Mapping`/generated resolver) сопоставляет поля по имени — общее поле только `id` (см. [`IdDto`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/IdDto.java)), поэтому итоговый `Batch`-объект внутри `updateModel` заполнен **только `id`**, остальные поля (включая `code`) — `null`.

Практическое следствие: после update `existingModel.getBatch()` указывает на этот недогруженный объект. `ShippingOrderGoodMapper.toDto` не переопределяет `batch` явным `@Mapping`, то есть MapStruct должен построить `IdCodeDto` из `Batch` по совпадающим `id`/`code` — если это происходит без обращения к БД (прямое copy-by-property из объекта в памяти), ответ на `PUT` может вернуть `batch.code = null` при корректном `batch.id`, даже если у партии есть реальный код. Последующий `GET`/`findById` перечитывает строку из БД и покажет корректный `code`. Это **source-level вывод**, требующий прямого HTTP-теста для подтверждения фактического ответа `PUT`; наличие явной DAO-проверки только для `clientGood` — не случайность, а асимметрия конкретно этого метода. Побочный плюс той же асимметрии: `batch = null` в теле корректно **очищает** партию (если это допускает валидатор: нет учёта или `batchUnknown=true`). У `receiving_order_good` до 13.10.2026 такая очистка падала NPE; с `8ee1ab68` (KIS-4841) она работает и там, так что различие осталось только в DAO lookup.

## SQL/JPA колонки

[`ShippingOrderGood`](../entities/catalog/entities/shippingordergood/ShippingOrderGood.md) — `@Entity` с собственным UUID PK. [`ALG-396 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240807_ALG-396_add_table_shipping_order_good.sql):

| Поле/источник | Текущий SQL source contract | Отличие от `receiving_order_good` |
|---|---|---|
| `id` | `UUID PRIMARY KEY NOT NULL` | Совпадает: собственный PK, не shared с root. |
| `shippingOrder.id` | `shipping_order_id UUID NOT NULL REFERENCES shipping_order(id)` | JPA-поле объявлено как `@OneToOne` **без** `mappedBy` и **без** unique-ограничения на FK-колонке в SQL. Root `ShippingOrder` не содержит обратной коллекции по этой связи. Физически несколько `ShippingOrderGood` могут ссылаться на один `shipping_order_id` (как и должно быть для номенклатурных строк) — аннотация `@OneToOne` называет cardinality неверно, но при отсутствии `mappedBy`/unique constraint это не создаёт функционального ограничения на INSERT. |
| `clientGood.id` | `client_good_id UUID NOT NULL REFERENCES client_good(id)` | Совпадает по смыслу с receiving; update lookup через DAO. |
| `batch.id` | `batch_id UUID NULL REFERENCES batch(id)` | Optional в SQL, но update-семантика отличается — см. выше. С 13.10.2026 (`8ee1ab68`, KIS-4841) service требует партию при партионном учёте и `batch_unknown=false`. |
| `batchUnknown` | `batch_unknown BOOLEAN NOT NULL`, комментарий «Признак неизвестной партии» | Добавлена той же миграцией [`KIS-4841`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261012_KIS-4841_add_order_good_batch_unknown.sql) (13.10.2026, `8ee1ab68`), что и у receiving: backfill `false` через временный default, затем default снят. SQL `CHECK` на сочетание с `batch_id` нет. |
| `plannedQuantity` | `planned_quantity NUMERIC(16,3) NOT NULL` | Совпадает с receiving по типу. |
| `price`, `totalPrice` | `price`, `total_price NUMERIC(15,2) NOT NULL` | **Отличается** от receiving: там `NUMERIC(16,3)` (после отдельной type-миграции из `BIGINT`); здесь `NUMERIC(15,2)` задан сразу в ALG-396 и никогда не менялся. Разное количество знаков после запятой для «одноимённых» денежных полей двух контуров. |
| `actualQuantity` (WMS inbound) | `actual_quantity NUMERIC(16,3) DEFAULT 0`, nullable | Заполняется входящим WMS-результатом вывоза; не входит в create/update DTO. Writer — [`WmsShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/WmsShipmentResultAction.java): ищет строку по `ClientGood.syncId` + `Batch.syncId` (без кода партии), суммирует `actual_quantity`, при отсутствии строки и `deliveryType != BY_CARGO` создаёт новую с `planned_quantity=0`. С 13.10.2026 (`8ee1ab68`, KIS-4841) строка с `batch_unknown=true` сопоставляется с любой партией товара, получает фактическую партию (`resolveUnknownBatch`) и `batch_unknown=false`; >1 совпадения — ошибка `Ambiguous order good…` (раньше — «не найдено» и новая строка). Подробнее — [действия вывоза](../business-rules/shipping-inbound-actions.md). |
| `deleted` | `deleted BOOLEAN NOT NULL DEFAULT false` | Задан сразу в ALG-396 (без деструктивного `DELETE`-паттерна, который receiving-версия прошла отдельным changeset). `BaseService.remove` делает soft delete через `SoftDeletable`. |
| Audit | `created_at/by NOT NULL`, `updated_at/by NULL` | Как обычно, inherited `BaseEditable`/`BaseCreatable`. |

Исторический `good_variant_id`: [`ALG-614`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240821_ALG-614_add_shipping_order_good_variant.sql) добавил nullable FK на `good_variant`, [`ALG-842`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240926_ALG-842_make_good_variant_id_columns_not_null.sql) сделал его `NOT NULL` (после backfill данными по `client_good_id`, одновременно и для `receiving_order_good`), затем более позднее снятие `NOT NULL` в рамках `KIS-1508`/`KIS-1624`-цепочки и итоговое `DROP COLUMN` ([`KIS-1624`](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250921_KIS-1624_remove_good_variant.sql)) убрали `good_variant`/`good_variant_id` полностью вместе со всей моделью `good_variant`. В текущей JPA entity этого поля уже нет.

`used_in_orders` на `client_good` — общий boolean-флаг, добавленный [`ALG-833`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240927_ALG-833_add_used_in_order_column_to_client_good.sql) с backfill по объединению `receiving_order_good`/`shipping_order_good`. `ShippingOrderGoodService.updateClientGoodUsage` при каждом `postAdd` безусловно ставит его в `true`; source path, возвращающий флаг обратно в `false` (например, после удаления последней ссылающейся строки), не найден — это односторонний «когда-либо использовался», а не «сейчас используется».

FK на `shipping_order_good(id)` есть у `shipping_order_cargo.shipping_order_good_id` ([`ALG-502`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240816_ALG-502_add_table_shipping_order_cargo.sql)) — soft-delete строки товара не убирает эту ссылку физически. Отдельный business `UNIQUE` (например, по `shipping_order_id + client_good_id + batch_id`) в просмотренных миграциях не найден.

## Stored root totals

[`ShippingOrderGoodService.calculateAndSetShippingOrderFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodService.java) после add/update/soft-remove перечитывает активные (`deleted=false`) строки этой заявки и пишет два root-поля тем же способом, что и receiving:

- `total_sku_quantity` (root `ShippingOrder.totalSKUQuantity`) = число различных `ClientGood.item` среди активных строк.
- `total_goods_price` = сумма сохранённых `totalPrice` активных строк (null пропускается, старт с нуля).

Как и в receiving, эти два поля разделяют root-таблицу с другими writer-ами: [физическая модель `shipping_order`](shipping-order-root-as-is.md#persisted-totals-и-конкурирующие-writers) фиксирует, что `total_goods_price` также перезаписывается `ShippingOrderContainerItemService` суммой `item.price` в контейнерном сценарии — какой из двух источников итоговый, зависит от `deliveryType`/`fillingType` конкретной заявки, а не от одного authoritative writer.

`postAdd` дополнительно: (1) при `deliveryType == BY_GOOD_WITH_CARGO_WITH_DETAILS` находит первый `GoodPackage` для `clientGood` и создаёт соседний `ShippingOrderCargo` с нулевым `packageQuantity` и размерами из упаковки; (2) ставит `ClientGood.usedInOrders = true`. `postRemove` при soft-delete вызывает `ShippingOrderCargoService.removeAllForShippingOrderGood`, поэтому удаление товарной строки может каскадно затронуть уже созданные cargo-строки.

## Outbound: тот же dead-code паттерн, что у транспорта

`postAdd`/`prepareModelToUpdate` содержат закомментированный вызов `insertRowsForFurtherIntegration` с явным TODO: `EntityType.SHIPPING_ORDER_GOOD` отсутствует в [`OutboundConfigService.CONFIGURATION`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) (как и `SHIPPING_ORDER_TRANSPORT` в [transport-документе](shipping-order-transport-as-is.md#outbound-transport-становится-мёртвым-отдельным-writer-ом)). Оставленный без вызова `getListOfEntitiesToOutbound` — `@Deprecated` мёртвый код, который для `ITEM_SHIPMENT_TASK` вернул бы **сам root `ShippingOrder`**, а не список товарных строк. Актуальная интеграция товаров идёт по активной конфигурации `addConfig(EntityType.SHIPPING_ORDER, MessageType.ITEM_SHIPMENT_TASK)` — то есть тем же паттерном «root как единица outbound», только другим `messageType`, чем у транспорта (`SHIPMENT_TRANSPORT_MANIFEST`). Фактическую сборку `ITEM_SHIPMENT_TASK`-сообщения (какие поля товарных строк туда попадают) этот документ не трассирует — она относится к экспортным сервисам `datareon`, не к физической модели `shipping_order_good`.

## Три bulk-контракта: разная атомарность

| Endpoint | Метод сервиса | Транзакционность |
|---|---|---|
| `POST /multipleaddition` | `createByListOfClientGood`: `list.stream().map(super::add)` | Метод **не** аннотирован `@Transactional`; вызов `super::add` — прямая ссылка на реализацию суперкласса на этом же объекте, минуя Spring CGLIB-прокси. `@Transactional` на `BaseService.add` в этом случае не гарантированно перехватывается AOP — каждый элемент, в лучшем случае, работает в своей отдельной транзакции DAO-уровня, а не как единый батч. |
| `PUT /multipleupdate` | `updateByListOfClientGood`: аналогично `super::update` | Тот же паттерн self-invocation, тот же риск частичного применения списка при ошибке на одном из элементов. |
| `POST /{shippingOrderId}/batch` | `BaseService.applyBatch` | Явно аннотирован `@Transactional` на уровне `BaseService`: проверяет пересечение update/delete ID, проверяет принадлежность ID переданному `filter` (client-controlled `shippingOrderId` из path), затем последовательно `remove`/`update`/`add` — **одна** транзакция на весь батч. |

Это значит, что при одинаковой бизнес-задаче («изменить набор товарных строк заявки одним запросом») два старых bulk-endpoint (`multipleaddition`/`multipleupdate`) и новый `{shippingOrderId}/batch` дают разные гарантии атомарности; UI/интеграция, выбирающая между ними, должна учитывать эту разницу. `remove()` в `BaseService` оборачивает soft-delete в `try/catch DataIntegrityViolationException → UniqueViolationException` (декларированный в OpenAPI `406`) — для `SoftDeletable`-сущности вроде этой (UPDATE `deleted=true`, а не физический `DELETE`) реальный путь для получения такого нарушения ограничения из этого конкретного вызова не установлен; `406` в спецификации контроллера, вероятно, унаследован от общего шаблона, а не проверен для soft-delete строки.

```mermaid
flowchart TD
    D[Creation/Update DTO: refs, plannedQuantity, price, totalPrice] --> M[ShippingOrderGoodMapper]
    M --> S[Service: status check, clientGood DAO lookup, raw batch assignment]
    S --> G[(shipping_order_good: rows with deleted flag)]
    G --> F[Filter by shipping order and deleted=false]
    F --> Q[distinct ClientGood.item count]
    F --> P[sum persisted totalPrice]
    Q --> R[(shipping_order.total_sku_quantity)]
    P --> T[(shipping_order.total_goods_price, shared with container-item writer)]
    S -->|deliveryType=BY_GOOD_WITH_CARGO_WITH_DETAILS| C[ShippingOrderCargo auto-create]
    BULK1[multipleaddition/multipleupdate: self-invocation, per-item] --> S
    BULK2[POST .../batch: BaseService.applyBatch, single @Transactional] --> S
```

## Что подтверждают tests, но не их запуск

- [`ShippingOrderGoodServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodServiceIntegrationTest.java) покрывает пересчёт root totals при add/update/remove и авто-создание cargo для `BY_GOOD_WITH_CARGO_WITH_DETAILS`.
- [`ShippingOrderGoodDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodDaoServiceTest.java) — DAO-уровень (add/find/page/filter/update), в обход HTTP DTO.
- Не найдено: тест на фактический ответ `PUT` с недогруженным `batch` (`code = null` в ответе), тест атомарности `multipleaddition`/`multipleupdate` при ошибке в середине списка, тест `applyBatch` на предмет частичного/полного отката, тест на `total_goods_price` при одновременной активности container-item writer-а.
- Тесты в этом подэтапе не запускались; их наличие не подтверждает применённую схему, HTTP-роутинг или фактическое поведение MapStruct-генерации.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные ON DELETE/индексы и допустимые null в развернутой БД.
2. Нужен прямой HTTP-тест `PUT /shippingordergood/{id}` с изменением `batch`, читающий именно ответ этого запроса (не последующий `GET`), чтобы подтвердить или опровергнуть гипотезу о `batch.code = null`.
3. Нужно решить, действительно ли `@OneToOne` для `shippingOrder` в `ShippingOrderGood` — ошибка именования cardinality, и стоит ли переименовать в `@ManyToOne` для читаемости (функционально, при текущей схеме без unique/mappedBy, эффект на SQL не ожидается, но аннотация вводит в заблуждение).
4. Нужен прямой тест атомарности `multipleaddition`/`multipleupdate` (в частности — что происходит с уже сохранёнными элементами при ошибке валидации/lookup в середине списка).
5. Нужно определить единственный authoritative writer для `total_goods_price`, если в заявке одновременно возможны и товарные, и container-item записи (маловероятно по бизнес-логике площадки, но не запрещено физической схемой).
6. Нужно решить судьбу `@Deprecated` `getListOfEntitiesToOutbound` и закомментированного `insertRowsForFurtherIntegration` — то же решение, что и для транспорта.

## Чек-лист изменения таблицы

1. Для нового reference-поля явно решить: DAO lookup при отличии (как `clientGood`) или прямое присваивание mapper-результата (как `batch`) — и задокументировать, какие вложенные поля будут в ответе после такого update.
2. Для нового bulk-endpoint явно выбрать, нужен ли per-item или per-batch `@Transactional`, и не вызывать `BaseService`-методы через `super::method`/self-invocation, если атомарность важна.
3. Для totals, разделяемых с другими writer-ами (container-item), однозначно определить, какой сценарий/deliveryType какой writer использует, прежде чем добавлять новый источник записи.
4. Для `@OneToOne`/`@ManyToOne` при отсутствии `mappedBy` и unique-ограничения проверять физическую cardinality по SQL, а не по одной JPA-аннотации.
5. Для outbound message-type сверять и `OutboundConfigService.CONFIGURATION`, и историю `outbound_config` в БД, как и в транспортном документе.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Транспорт заявки на вывоз: физическая модель AS-IS](shipping-order-transport-as-is.md)
- [Товарная строка поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-good-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderGood](../entities/catalog/entities/shippingordergood/ShippingOrderGood.md)
