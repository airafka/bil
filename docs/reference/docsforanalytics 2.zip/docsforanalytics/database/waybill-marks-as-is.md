# Отметки накладной Waybill: физическая модель AS-IS (часть 13)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, Java DTO/controller/service/JPA, SQL migration и test sources. Это **source-level модель**, а не снимок применённой БД. Корень и остальные дочерние таблицы описаны в [физической модели `waybill`](waybill-root-as-is.md), [вагона](waybill-railway-carriage-as-is.md), [КТК и ЗПУ](waybill-container-as-is.md) и [груза](waybill-product-as-is.md).

## Назначение и границы

Отметки — две независимые коллекции snapshot-строк накладной:

| Таблица / entity | Назначение | Собственный business key |
|---|---|---|
| `waybill_special_mark` / [`WaybillSpecialMark`](../entities/catalog/entities/waybillspecialmark/WaybillSpecialMark.md) | Произвольная специальная отметка и пояснение | Нет |
| `waybill_tariff_mark` / [`WaybillTariffMark`](../entities/catalog/entities/waybilltariffmark/WaybillTariffMark.md) | Наименование, числовой код и примечание тарифной отметки | Нет |

Обе сущности наследуют только `BaseCreatable`: имеются `id`, `created_at`, `created_by`, но нет update audit, optimistic `@Version` и soft-delete. Таблицы не связаны друг с другом, справочником отметок или тарифов.

## SQL-контракт

Обе таблицы созданы единственным найденным changeset [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql); более поздних `ALTER`/индексов для них в просмотренной migration chain не найдено.

| Поле Java | Колонка SQL | Фактические ограничения |
|---|---|---|
| `WaybillSpecialMark.id` | `waybill_special_mark.id UUID PRIMARY KEY` | Идентификатор строки |
| `WaybillSpecialMark.waybill` | `waybill_id UUID NOT NULL REFERENCES waybill ON DELETE CASCADE` | Обязательный parent; неуникальный индекс `waybill_special_mark_waybill_id_idx` |
| `mark` | `mark VARCHAR` | Nullable, длина/формат/CHECK не заданы |
| `info` | `info VARCHAR` | Nullable, длина/формат/CHECK не заданы |
| `WaybillTariffMark.id` | `waybill_tariff_mark.id UUID PRIMARY KEY` | Идентификатор строки |
| `WaybillTariffMark.waybill` | `waybill_id UUID NOT NULL REFERENCES waybill ON DELETE CASCADE` | Обязательный parent; неуникальный индекс `waybill_tariff_mark_waybill_id_idx` |
| `code` | `code INTEGER` | Nullable; входная строка преобразуется в Java `Integer` |
| `name` | `name VARCHAR` | Nullable, длина/формат/CHECK не заданы |
| `note` | `note VARCHAR` | Nullable, длина/формат/CHECK не заданы |
| audit обеих таблиц | `created_at TIMESTAMP NOT NULL DEFAULT UTC now`, `created_by VARCHAR(50) NOT NULL` | Обеспечивается `BaseCreatable`/инфраструктурой аудита |

Нет `UNIQUE` ни на содержимое, ни на сочетание с `waybill_id`. Поэтому точные дубли, несколько одинаковых кодов и даже строки, у которых все содержательные поля null, схема допускает.

## Inbound DTO, обязательность и преобразование

`POST /datareon/waybill` принимает вложенные списки [`WaybillIntegrationDto.Waybill.specialMarks` и `tariffMarks`](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md):

| JSON list / элемент | Входные поля | Bean Validation | Запись в БД |
|---|---|---|---|
| `waybill_special_marks[]` (`СпециальныеОтметки`) | `mark`, `info`: `String` | Аннотаций нет | Значения копируются без trim/нормализации |
| `waybill_tariff_marks[]` (`ТарифныеОтметкиЗаОтправку`) | `name`, `code`, `note`: `String` | Аннотаций нет | `name`/`note` копируются; `code` проходит `Integer.parseInt`, если не blank |

Сами списки nullable в DTO, но [`WaybillDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java) для **новой** накладной без null-check вызывает `.stream()`. Поэтому фактический контракт первого импорта таков:

- оба списка должны присутствовать хотя бы как `[]`, иначе возникает `NullPointerException` и транзакция откатывается;
- пустые списки допустимы;
- null-элемент внутри списка разыменовывается и также приводит к ошибке;
- поля элемента, включая все поля одновременно, могут быть null/blank;
- blank тарифный `code` сохраняется как null; нечисловой код или значение вне диапазона `Integer` вызывает `NumberFormatException`;
- строка с ведущими нулями теряет формат: например, `"0020"` сохраняется как `20` и read DTO возвращает `"20"`.

Отдельной mark-validation в `validateWaybillDto` нет. Ошибки преобразования не переводятся здесь в предметное сообщение о конкретной отметке.

## Создание, повтор и удаление

При первом импорте Waybill сервис сначала сохраняет корень и остальные children, затем пакетно добавляет специальные и тарифные отметки в той же транзакции. Порядок элементов не хранится отдельной колонкой; запросы должны задавать сортировку явно, если порядок важен потребителю.

При повторе уже существующего `waybill_identifier` сервис изменяет только `Waybill.status`: списки отметок не сравниваются, не добавляются и не заменяются. Таким образом, входной повтор не является синхронизацией отметок. Прямых runtime writers помимо первичного Datareon create в просмотренном Java-коде не найдено.

Прямых HTTP create/update/delete endpoints также нет. Физическое удаление родительской Waybill каскадно удаляет обе коллекции через SQL `ON DELETE CASCADE`; отдельного восстановления или истории значений нет.

## Read API, DTO и фильтрация

Контроллеры публикуют только два защищённых `Permission.WAYBILL` маршрута:

| Endpoint | Request | Response DTO | Поля ответа |
|---|---|---|---|
| `POST /waybill-special-mark/page` | `FilterWithPaging<WaybillSpecialMarkFilter>` | [`WaybillSpecialMarkDto`](../dto/catalog/waybillspecialmark/WaybillSpecialMarkDto.md) | `id`, `mark`, `info` |
| `POST /waybill-tariff-mark/page` | `FilterWithPaging<WaybillTariffMarkFilter>` | [`WaybillTariffMarkDto`](../dto/catalog/waybilltariffmark/WaybillTariffMarkDto.md) | `id`, `name`, `code`, `note` |

Parent `waybill` и audit-поля в DTO не входят. Tariff entity хранит `Integer`, а mapper не задаёт специального правила, поэтому MapStruct выполняет стандартное преобразование `Integer → String`. Оба фильтра содержат только inherited ID-условия и nested `waybill`; фильтрации по `mark`, `info`, `name`, `code`, `note` и общего search нет. `get`, `meta`, `all`, create/update/delete mappings не опубликованы.

### Риск nested Waybill filter

Оба mark-predicate вызывают `waybillPredicate.in(filter.getWaybill())`. Этот overload строит subquery от статического корневого `QWaybill.waybill`, но не связывает его с `WaybillSpecialMark.waybill` или `WaybillTariffMark.waybill`. В соседних predicates `WaybillProduct` и `WaybillContainer` используется path-aware overload с дочерней связью.

Из source следует, что nested Waybill condition не коррелирован с текущей строкой отметки: если подходящая Waybill существует, условие не ограничивает marks этой Waybill; в зависимости от сгенерированного JPQL/provider возможна и ошибка пути. Фактический SQL/HTTP результат не проверен, поэтому это обозначено как **source-level риск**, а не подтверждённый production-дефект.

В остальных просмотренных пользовательских Waybill DTO, grouped view, receiving details и outbound route package отметки не найдены. Следовательно, доказанный read path содержимого — только два page endpoints, причём DTO не сообщает parent ID.

```mermaid
flowchart TD
    I[Datareon Waybill payload] --> N{New waybill_identifier?}
    N -->|No| S[Update only Waybill status]
    S --> U[Existing marks remain unchanged]
    N -->|Yes| L{Both mark lists non-null?}
    L -->|No| E[NullPointerException; transaction rollback]
    L -->|Yes| SM[(waybill_special_mark)]
    L -->|Yes; parse code| TM[(waybill_tariff_mark)]
    W[(waybill)] -->|FK, ON DELETE CASCADE| SM
    W -->|FK, ON DELETE CASCADE| TM
    SM --> P1[POST special-mark/page]
    TM --> P2[POST tariff-mark/page]
    F[Nested Waybill filter] -. uncorrelated source-level risk .-> P1
    F -. uncorrelated source-level risk .-> P2
```

## Проверки, пробелы и история

`WaybillDatareonServiceIntegrationTest` формирует по одному элементу обоих списков, поэтому happy-path import проходит через mapping/save. Однако test проверяет только Waybill, WRC, WC и Product counts: содержимое/count отметок, numeric conversion, null/empty/duplicate lists, repeat semantics, cascade и оба page endpoints прямо не утверждаются. Отдельных tests mark controller/service/predicate не найдено; тесты в этом подэтапе не запускались.

Entity, migration, inbound nested DTO/mapping, controllers, DTO/mappers, filters/predicates и тестовый fixture добавлены commit `feb37a42` (`KIS-2273 add waybills`, 2026-02-13). В просмотренной Git-истории последующих предметных изменений этих mark-классов/таблиц не найдено; более поздние изменения общего `WaybillIntegrationDto` и сервиса не изменили mapping отметок.

Остаются неподтверждёнными applied schema, фактическая длина `VARCHAR` на целевой БД, runtime security/roles, SQL двух nested filters, UI-потребитель и внешний Datareon contract. Для ТЗ нельзя считать порядок, уникальность, непустое содержимое или текстовый формат тарифного кода гарантированными текущей моделью.
