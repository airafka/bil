# `shipping_order_blackbox`: грузовое место без товарной детализации, физическая модель AS-IS (часть 23)

Источник — checkout `22fac945e8116d04972ccc87b06b2303acf7a561`, controller/DTO/mapper/service/JPA, Excel-парсер, cumulative SQL migrations и исходники тестов. Это **source-level реконструкция**, не проверка применённой БД. `blackbox` — минимальная строка грузового места для `ShippingOrder.deliveryType=BY_CARGO`: хранит только ссылку на глобальный справочник [`Cargo`](../entities/catalog/entities/cargo/Cargo.md), без собственного количества/веса/размеров/товара. Контур зеркален [`receiving_order_blackbox`](receiving-order-blackbox-as-is.md); этим документом закрывается дочерняя физическая модель `shipping_order`, начатая в [части 16](shipping-order-root-as-is.md).

## Два независимых write-пути

### Прямой CRUD

[`ShippingOrderBlackboxController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorderblackbox/ShippingOrderBlackboxController.java) — простейший из всех дочерних контроллеров контура: `POST /all`, `POST /page`, `GET /{id}`, `POST /`, `PUT /{id}`, `DELETE /{id}`. Никаких bulk/merge/batch-эндпоинтов не найдено — единственная сущность заявки на вывоз без `multipleaddition`/`multipleupdate`. Все методы защищены **общим** `@Secure(permissionName = "ShippingOrder", ...)`, а не отдельным `ShippingOrder.ShippingOrderBlackbox` path: миграция создания таблицы не вставляет отдельную строку в `PERMISSION_PATH` — то же решение, что и у `receiving_order_blackbox`, то есть это общий паттерн блэкбокс-контура на обеих сторонах, а не отклонение конкретно здесь.

[`ShippingOrderBlackboxCreationDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxCreationDto.md) требует `shippingOrder @NotNull` и `cargo @NotBlank @Size(max=100)` (строка кода, не `IdDto`). `PUT /{id}` не принимает `@PathVariable id` — как и везде, лукап по body `id`.

[`ShippingOrderBlackboxService.prepareModelToAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderblackbox/ShippingOrderBlackboxService.java) требует `deliveryType=BY_CARGO` и вызывает [`CargoService.findOrCreateCargo`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/cargo/CargoService.java) — то есть **создаёт** отсутствующую запись в глобальном каталоге `Cargo`, если код не найден. `postAdd`/`postRemove` **не вызывают `super.postAdd`/`super.postRemove`** (оба base-метода — пустые no-op в `BaseService`, поэтому это не имеет функциональных последствий), а напрямую делают `shippingOrderDaoService.findAndLock(...)` и `shippingOrder.increaseTotalCargoQuantity()`/`decreaseTotalCargoQuantity()` — простой `+1`/`-1` на managed-сущности без явного `daoService.update(shippingOrder)`; сохранение полагается на JPA dirty checking внутри активной транзакции `add()`/`remove()`.

Update меняет только Cargo (по `isNotEqualsByCode`, тоже через `findOrCreateCargo`), не перепривязывает `shippingOrder`, не трогает counter. `BaseService.remove` — обычный soft-delete без проверки, что строка уже не `deleted=true`: повторный `DELETE` того же ID способен ещё раз вызвать `decreaseTotalCargoQuantity()` и увести root-счётчик ниже фактического количества активных строк или в отрицательные значения — тот же вывод, что уже задокументирован для receiving-аналога, здесь не переисследовался отдельным repeated-delete тестом.

### Excel-импорт: другой Cargo-lookup, чем у прямого CRUD и чем у receiving

[`ShippingOrderAutoWarehouseContainerParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ShippingOrderAutoWarehouseContainerParser.java) реализует общий [`AbstractAutoWarehouseContainerParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/AbstractAutoWarehouseContainerParser.java) (тот же базовый класс, что и у receiving) для шаблона `SHIPPING_ORDER_AUTO_WAREHOUSE_CONTAINER`. `save()` для каждой строки: пропускает уже существующую **не-удалённую** дубль-строку `(order, cargo code)` через `UniqueViolationException`, иначе вызывает `getBlackboxDaoService().add(buildBlackbox(order, codeCargo))` — прямой DAO insert, минуя `ShippingOrderBlackboxService.prepareModelToAdd/postAdd`: нет проверки `deliveryType=BY_CARGO` и нет `increaseTotalCargoQuantity()`.

**Найдено конкретное расхождение с receiving-аналогом.** `ShippingOrderAutoWarehouseContainerParser.buildBlackbox`:

```java
var cargo = cargoDaoService.findAll(CargoFilter.builder()
    .code(new SearchString(codeCargo))
    .build()).stream().findFirst().orElseThrow();
```

— требует **уже существующую** запись `Cargo` и бросает непроверяемое исключение (`NoSuchElementException`, без явной обработки), если кода нет в каталоге. У `ReceivingOrderAutoWarehouseContainerParser.buildBlackbox` та же строка выглядит как `.orElseGet(() -> cargoDaoService.add(Cargo.builder().code(codeCargo).build()))` — то есть **создаёт** отсутствующую запись каталога. Обе реализации используют один и тот же общий базовый класс и делают то же самое для остальной логики (deduplication по active-строке, отсутствие root-counter increment), но именно в поведении "код есть в файле, но нет в справочнике Cargo" они расходятся: receiving Excel-импорт успешно создаст новую запись каталога, shipping Excel-импорт упадёт с необработанным исключением на этой строке. Учитывая, что прямой API-путь (`CargoService.findOrCreateCargo`) на обеих сторонах **создаёт** отсутствующий Cargo, для shipping это значит, что Excel-путь и API-путь **одной и той же таблицы** имеют разное поведение при неизвестном коде.

Дополнительно: для этого парсера **не найдено** отдельного unit/integration теста (в отличие от receiving, где есть [`ReceivingOrderAutoWarehouseContainerParserTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseContainerParserTest.java)) — поведение `.orElseThrow()` на неизвестном коде в этом документе не проверено запуском, только по source.

## SQL-колонки

[`KIS-1319 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250605_KIS-1319_add_shipping_order_blackbox.sql) — единственная найденная миграция таблицы:

| Java поле | SQL source contract | Комментарий |
|---|---|---|
| `id` | `UUID PRIMARY KEY` | Заполняется `BaseIdentifier.@PrePersist`, если не задан явно мэппером. |
| `shippingOrder` | `shipping_order_id UUID NOT NULL REFERENCES shipping_order(id)` | `@ManyToOne(optional = false)`; update не перепривязывает. |
| `cargo` | `cargo_id UUID NOT NULL REFERENCES cargo(id)` | N:1 на общий каталог `cargo` (`code VARCHAR(100) UNIQUE`, см. [`KIS-742`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250318_KIS-742_add_table_cargo.sql)). Один и тот же глобальный Cargo может быть привязан к нескольким blackbox-строкам разных заявок. |
| `deleted` | `BOOLEAN NOT NULL` (без `DEFAULT`) | В отличие от `receiving_order_blackbox`, где `deleted` в этой же по смыслу колонке nullable без SQL default, здесь колонка сразу `NOT NULL`; явного `DEFAULT` в CREATE не указано — INSERT без явного значения потребует его от приложения (mapper/builder default `false` его обеспечивает). |
| Audit | стандартный `BaseEditable`/`BaseCreatable` | Как обычно, вне request/response DTO. |

Отдельного `UNIQUE(shipping_order_id, cargo_id)`, `CHECK` или non-PK индекса не найдено — как и у receiving, ничто на SQL-уровне не запрещает несколько active blackbox-строк с одним Cargo в одной заявке.

## Root-счётчик — инкремент, не count

`shipping_order.total_cargo_quantity` — единственный агрегат, на который влияет эта таблица; формула — не `COUNT(active rows)`, а накопленный `+1/-1` при каждом успешном прямом create/soft-delete (см. выше и [физическую модель `shipping_order`](shipping-order-root-as-is.md#persisted-totals-и-конкурирующие-writers), где этот writer уже перечислен). Excel-импорт этот счётчик не трогает вовсе — то есть загрузка через `SHIPPING_ORDER_AUTO_WAREHOUSE_CONTAINER`-шаблон способна создать активные blackbox-строки, которые `total_cargo_quantity` не отражает, пока какой-либо прямой add/remove через API впервые не пересчитает счётчик (а он всё равно не делает full recount — только инкремент/декремент от своей операции). [`ShippingOrderAcceptValidator.blackboxChecks`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) для `BY_CARGO` проверяет только факт существования хотя бы одной active-строки — не сверяет её с `total_cargo_quantity`.

```mermaid
flowchart TD
    H[Direct POST: order ID and cargo code] --> V[Status check, deliveryType BY_CARGO]
    V --> C[CargoService.findOrCreateCargo — creates if missing]
    C --> B[(shipping_order_blackbox)]
    B --> I["findAndLock + increaseTotalCargoQuantity (+1)"]
    X[Excel SHIPPING_ORDER_AUTO_WAREHOUSE_CONTAINER] --> D["Duplicate check (active only), then direct DAO add"]
    D --> B
    D -->|cargo code not found| ORELSETHROW[".orElseThrow() — unhandled exception, unlike receiving's create-on-missing"]
    D -. no root increment .-> R[(shipping_order.total_cargo_quantity)]
    I --> R
    E[Repeated DELETE by same already-deleted ID] --> M["Soft-delete again, decreaseTotalCargoQuantity (-1) again"]
    M --> R
    B --> A["Accept: active row exists (BY_CARGO)"]
```

## Что подтверждают tests, но не их запуск

- [`ShippingOrderBlackboxServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorderblackbox/ShippingOrderBlackboxServiceIntegrationTest.java) покрывает direct add с новым Cargo и `+1`, ошибку при несовпадающем `deliveryType`, update Cargo и soft-delete.
- DAO-уровня и Excel-парсера отдельного теста **не найдено** — расхождение с receiving-контуром, где `ReceivingOrderAutoWarehouseContainerParserTest` существует и покрывает пустой/дублирующий/re-add-after-delete сценарии.
- Не найдено: тест повторного `DELETE` уже удалённой строки; тест Excel-импорта с кодом Cargo, отсутствующим в каталоге (для подтверждения/опровержения `.orElseThrow()`); тест на расхождение `total_cargo_quantity` после Excel-импорта.
- Тесты не запускались; их наличие не подтверждает применённую схему или фактическое исключение при импорте неизвестного кода.

## Неподтверждённое и вопросы для ТЗ

1. Не проверены `DATABASECHANGELOG`, `pg_catalog` и applied constraints в развернутой БД.
2. Нужно решить, должен ли Excel-импорт для вывоза создавать отсутствующий Cargo (как у receiving) или намеренно требовать существующий код (как сейчас) — и в последнем случае обернуть `.orElseThrow()` в понятную ошибку вместо необработанного исключения.
3. Нужен тест повторного `DELETE` того же ID — подтвердить/опровергнуть уход `total_cargo_quantity` в отрицательные значения.
4. Нужно решить, должен ли Excel-импорт увеличивать `total_cargo_quantity`, и если да — где именно это нужно добавить, не дублируя инкремент при последующем прямом redraw через API.
5. Нужен DAO-уровня и Excel-парсера тест для shipping-стороны, аналогичный существующему для receiving.

## Чек-лист изменения таблицы

1. Для любого нового write-пути этой таблицы (Excel, batch, миграция) явно решать, должен ли он инкрементировать/декрементировать `total_cargo_quantity`, и не полагаться на то, что следующий прямой API-вызов «подтянет» счётчик.
2. При переиспользовании общего `AbstractAutoWarehouseContainerParser` между receiving и shipping — явно сверять поведение `buildBlackbox` на обеих сторонах, чтобы избежать незаметного расхождения find-or-create vs require-existing, как в этом документе.
3. Для soft-delete без проверки текущего состояния (`preRemove` не проверяет `deleted` существующей строки) — добавить guard, если повторный вызов должен быть no-op, а не повторным декрементом счётчика.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](shipping-order-cargo-as-is.md)
- [Дополнительная услуга заявки на вывоз: физическая модель AS-IS](shipping-order-requested-service-as-is.md)
- [Грузовое место без товарной детализации поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-blackbox-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderBlackbox](../entities/catalog/entities/shippingorderblackbox/ShippingOrderBlackbox.md)
