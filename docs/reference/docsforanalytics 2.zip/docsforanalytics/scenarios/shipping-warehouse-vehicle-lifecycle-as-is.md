# Вывоз со склада (WAREHOUSE + VEHICLE): сквозной сценарий AS-IS

Проверено по checkout `22fac945e8116d04972ccc87b06b2303acf7a561`. Это **составная source-level трассировка** заявки на вывоз со склада (`terminalArea=WAREHOUSE`, `transportType=VEHICLE`, `deliveryType=BY_GOOD_WITH_CARGO_WITH_DETAILS`) от создания до возможного перехода в `DONE`, построенная поверх уже существующих детальных AS-IS документов. Цепочка не подтверждена как целиком исполнимый production-сценарий: HTTP endpoint и иной production-вызов `ShippingOrderService.accept(UUID)` в исходниках не найдены, поэтому outbound-ветка после `accept()` описывает поведение service-метода, а не доказанный пользовательский маршрут. Сценарий связывает шаги, которые по отдельности уже задокументированы в [корне заявки на вывоз](../database/shipping-order-root-as-is.md), [транспорте](../database/shipping-order-transport-as-is.md), [товарной строке](../database/shipping-order-good-as-is.md), [грузовом месте](../database/shipping-order-cargo-as-is.md), [дополнительной услуге](../database/shipping-order-requested-service-as-is.md), [inbound actions вывоза](../business-rules/shipping-inbound-actions.md) и [реестре eventCode → action](../business-rules/inbound-event-registry-as-is.md) — и добавляет один новый, ранее не задокументированный дефект (шаг 5).

## Участники сценария

- **Клиент/оператор ALIS** — создаёт и наполняет заявку через `/shippingorder*` endpoints.
- **ALIS backend** — хранит агрегат `shipping_order` + дочерние таблицы, считает totals, выполняет outbound-интеграцию.
- **Datareon** — внешняя шина, через которую WMS/TOS отправляют `POST /datareon/event` обратно в ALIS.
- **WMS** — система склада, физически исполняет отгрузку и присылает `WMS_SHIPMENT_RESULT`.

## Шаг 1 — Создание заявки (`DRAFT`)

`POST /shippingorder/` создаёт корень: `orderStatus` из тела **игнорируется**, сервер принудительно ставит `DRAFT`; `client`/`contract`/`terminalArea`/`transportType` фиксируются как `updatable=false` сразу при создании. В той же транзакции [`ShippingOrderService.addRequiredServices`](../database/shipping-order-requested-service-as-is.md#root-totals-required-rows-и-та-же-задержка-агрегата) вставляет обязательные по договору услуги напрямую через DAO, **минуя** пересчёт root-агрегатов услуг — `total_requested_service_quantity/price` в этот момент могут не отражать только что вставленные строки. Подробности — [физическая модель корня](../database/shipping-order-root-as-is.md).

## Шаг 2 — Наполнение: товары, грузовые места, транспорт

Для `deliveryType=BY_GOOD_WITH_CARGO_WITH_DETAILS`:

1. `POST /shippingordergood/` добавляет `ShippingOrderGood`. Если для номенклатуры есть `GoodPackage`, `ShippingOrderGoodService.postAdd` **автоматически** создаёт соседний `ShippingOrderCargo` с нулевым `packageQuantity` — см. [физическую модель товарной строки](../database/shipping-order-good-as-is.md#stored-root-totals).
2. Добавление good/cargo пересчитывает root `total_sku_quantity`/`total_goods_price` (writer — Good) и `total_weight`/cargo-counts (writer — Cargo). `Good` не пишет `total_weight`: три известных writer'а этого поля — Cargo, Container и ContainerItem; в данном `WAREHOUSE + VEHICLE` сценарии задействован Cargo. См. [сводную карту](../database/shipping-order-integrity-map.md#aggregate-authority-одного-источника-нет).
3. `POST /shippingordertransport/` добавляет `ShippingOrderTransport` — для `WAREHOUSE + VEHICLE` это обязательно для будущего accept (см. шаг 3). Создание использует bidirectional shared-key crutch, добавленный `dd22741c` (KIS-928) — подробности в [физической модели транспорта](../database/shipping-order-transport-as-is.md#создание-bidirectional-shared-key-crutch).

## Шаг 3 — `review`/`accept`

[`ShippingOrderAcceptValidator`](../business-rules/shipping-orders.md#склад--автомобиль) для `WAREHOUSE + VEHICLE` последовательно проверяет: наличие `ShippingOrderTransport` (`transportChecks`), хотя бы одну `ShippingOrderGood` (`goodChecks`), корректность `ShippingOrderCargo` (`cargoChecks`) и — для `BY_CARGO` — активный `ShippingOrderBlackbox` (`blackboxChecks`, здесь не задействован при `BY_GOOD_WITH_CARGO_WITH_DETAILS`). `review()` пропускает проверку `ktkNumberUnknown` (она относится только к контейнерной площадке), `accept()` — тоже, поскольку это поле не участвует в матрице `WAREHOUSE`.

**Известный разрыв, задокументированный ранее**: в [`ShippingOrderController`](../database/shipping-order-root-as-is.md#статус-и-побочные-эффекты) есть `/review` и `/reject`, но HTTP endpoint для `ShippingOrderService.accept(UUID)` не найден. Поэтому этот шаг сценария доказан только на уровне service-метода; фактический вызов через HTTP не подтверждён.

## Шаг 4 — Outbound при `accept()`

`accept()` вызывает `insertRowsForFurtherIntegration(shippingOrder)`, которая по активной конфигурации `OutboundConfigService.CONFIGURATION` создаёт исходящие сообщения для **root** `EntityType.SHIPPING_ORDER`:

- `ITEM_SHIPMENT_TASK` — для `WAREHOUSE` возвращает сам root (`List.of(initialEntity)`), см. [`ShippingOrderService.getListOfEntitiesToOutbound`](../database/shipping-order-root-as-is.md#persisted-totals-и-конкурирующие-writers).
- `SHIPMENT_TRANSPORT_MANIFEST` — подбирает **sibling** `ShippingOrderTransport` по общему ID и передаёт его в [`ShippingTransportManifestExportService`](../database/shipping-order-transport-as-is.md#outbound-transport-становится-мёртвым-отдельным-writer-ом), которая строит `TransportManifestDto` из **transport**-полей (carrier/vehicle/driver) и **root**-полей (`consignee`, `route`, `contract.company`, `plannedShippingDateTime`) одновременно — то есть итоговое сообщение физически собирается из двух разных таблиц.

Отдельный `postAdd`/`prepareModelToUpdate` у `ShippingOrderTransport`/`ShippingOrderGood`/`ShippingOrderCargo`/`ShippingOrderRequestedService` **не** создаёт исходящих сообщений сам по себе — это подтверждённый dead outbound config паттерн (`EntityType` этих таблиц закомментирован в `OutboundConfigService.CONFIGURATION`), одинаковый для всех перечисленных сущностей.

## Шаг 5 — Inbound `VH_DEPARTURE`: новый найденный дефект

Datareon присылает `POST /datareon/event` с `eventCode`, для которого в `INBOUND_EVENT_CONFIG` настроен `action_code=VH_DEPARTURE`. Диспетчер [`ActionsProcessor`](../business-rules/inbound-event-registry-as-is.md#диспетчер-actionsprocessor) находит [`VhDepartureAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/VhDepartureAction.java) и выполняет:

```java
if (hasSuitableOrderType(ClientOrderType.SHIPMENT) && (hasSuitableTerminalArea(WAREHOUSE))) {
    shippingOrderDaoService.getById(inboundEventData.getOrderId())
            .ifPresent(shippingOrder -> {
                if (hasSuitableTransportType(shippingOrder.getTransportType())) {
                    shippingOrderDaoService.findAndLock(shippingOrder.getId());
                    shippingOrderDaoService.update(shippingOrder.toBuilder()
                            .actualShippingDateTime(inboundEventData.getEventDateTime())
                            .build());
                }
            });
}
```

**Найденное расхождение.** `hasSuitableTerminalArea(TerminalAreaEnum terminalArea)` проверяет, входит ли переданное значение в список `terminalArea` строки конфига (пустой список — wildcard). Каждый другой action, который фильтрует по площадке, передаёт туда **фактическую площадку конкретной заявки**:

- [`BaseChangeStatusResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/BaseChangeStatusResultAction.java): `hasSuitableTerminalArea(TerminalAreaEnum.valueOf(shippingOrder.getTerminalArea().getCode()))`.
- [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java), [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java), [`TosReceivingResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosReceivingResultAction.java) — та же схема.

`VhDepartureAction` — **единственный** action во всей директории, который вместо этого передаёт **жёстко закодированную константу `WAREHOUSE`**. Это означает, что условие фактически проверяет «разрешает ли конфигурация площадку `WAREHOUSE` вообще» (что для единственной существующей production-строки `VH_DEPARTURE` — `{WAREHOUSE, CONTAINER}`, см. [KIS-147](../business-rules/inbound-event-registry-as-is.md#таблица-конфигурации-inbound_event_config) — всегда истинно), а не «совпадает ли площадка **этой** заявки с тем, что разрешено». Реальная площадь заявки (`shippingOrder.getTerminalArea()`) в этом action **вообще не читается**. Практическое следствие: `actualShippingDateTime` устанавливается по `VH_DEPARTURE` для **любой** заявки на вывоз подходящего `transportType`, независимо от того, `WAREHOUSE` она или `CONTAINER` — вероятно, не то поведение, которое подразумевало имя действия («Выезд транспорта») и общий паттерн остальных actions. Тест на этот путь не найден.

## Шаг 6 — Inbound `WMS_SHIPMENT_RESULT`: факт без завершения заявки

Второе входящее событие (в тестовой конфигурации — `SHIP_FINISH`, production-строка в репозитории не подтверждена, см. [реестр](../business-rules/inbound-event-registry-as-is.md#полный-реестр-eventcode)) диспетчеризуется в [`WmsShipmentResultAction`](../business-rules/shipping-inbound-actions.md). Для каждого элемента `itemsResult`:

- находит `ShippingOrderGood` по `(clientGood.syncId, batch.syncId)` и обновляет `actualQuantity` **кумулятивно** (`existing == null/0 ? qty : existing.add(qty)`);
- если `deliveryType` не `BY_GOOD`, обновляет соответствующий `ShippingOrderCargo.actualQuantity`/`executor` той же кумулятивной формулой — см. [физическую модель грузового места](../database/shipping-order-cargo-as-is.md#stored-root-totals-и-побочный-пересчёт-услуг);
- обновляет `actualQuantity` найденных `ShippingOrderRequestedService` по `extraOperationResultData`.

Этот action **не меняет `orderStatus`** — заявка остаётся `ACCEPTED`/`IN_PROGRESS` до отдельного действия смены статуса.

## Шаг 7 — Inbound `STATUS_COMPLETED`: `DONE` без проверки полноты

Если для того же (или другого) `eventCode` в конфиге настроен `action_code=STATUS_COMPLETED`, [`StatusCompletedResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/StatusCompletedResultAction.java) (приоритет `1`, поэтому выполняется **после** всех actions приоритета `0` в одном dispatch — см. [диспетчер](../business-rules/inbound-event-registry-as-is.md#диспетчер-actionsprocessor)) переводит заявку в `DONE`. Проверка — только `!terminalOrderStatuses.contains(currentStatus)` (не `DONE`/`REJECTED`), **без** обращения к общей таблице переходов `OrderStatus.ALLOWED_TO_USER_TRANSITIONS` — то есть технически возможен прыжок `DRAFT`/`ON_REVIEW → DONE`, минуя `ACCEPTED`/`IN_PROGRESS`, и минуя любую проверку заполненности товаров/грузовых мест/услуг.

Уже задокументированные в [inbound actions вывоза](../business-rules/shipping-inbound-actions.md#конфликты-нескольких-actions-одного-eventcode) конфликтные комбинации применимы и здесь напрямую: `VH_DEPARTURE + STATUS_COMPLETED` на одном `eventCode` записывает и время, и `DONE`, если оба action проходят свои (разные!) фильтры площадки — с учётом дефекта шага 5 это означает, что `VH_DEPARTURE`-часть пройдёт для любой площадки, а `STATUS_COMPLETED`-часть — только для действительно подходящей.

## Итоговое состояние и что остаётся неоднозначным

К моменту `DONE` у заявки одновременно существуют:

- `total_weight`, записанный Cargo в пределах этого сценария; в общей модели у поля три конкурирующих writer'а — Cargo, Container и ContainerItem, но контейнерные writers для выбранной ветки `WAREHOUSE + VEHICLE` не задействованы;
- `total_requested_service_price`, который мог отстать от только что вставленных required-строк (шаг 1) и от `actualQuantity`, обновлённого `WMS_SHIPMENT_RESULT` (шаг 6) — `actualQuantity` не входит в формулу root price;
- `actualShippingDateTime`, установленный `VH_DEPARTURE` независимо от корректности проверки площадки (шаг 5);
- `orderStatus=DONE`, установленный без проверки заполненности агрегата (шаг 7).

```mermaid
sequenceDiagram
    participant U as Клиент/оператор
    participant A as ALIS backend
    participant D as Datareon
    participant W as WMS

    U->>A: POST /shippingorder/ (DRAFT)
    A->>A: addRequiredServices (DAO insert, root totals не пересчитаны)
    U->>A: POST /shippingordergood/, /shippingordercargo/, /shippingordertransport/
    A->>A: root totals recalculated per writer (good/cargo)
    U->>A: review()
    Note over U,A: Production-вызов accept() не найден
    opt Только подтверждённое поведение service-метода accept()
        U->>A: accept()
        A->>D: outbound ITEM_SHIPMENT_TASK + SHIPMENT_TRANSPORT_MANIFEST
        D->>W: внешняя доставка (не подтверждена)
    end
    Note over D,W: Inbound-события ниже обрабатываются независимо от доступности accept()
    W->>D: событие "выезд транспорта"
    D->>A: POST /datareon/event (VH_DEPARTURE)
    A->>A: VhDepartureAction: actualShippingDateTime = event time (terminal area filter не читает заявку — дефект)
    W->>D: событие результата отгрузки
    D->>A: POST /datareon/event (WMS_SHIPMENT_RESULT)
    A->>A: good/cargo/service.actualQuantity += qty (cumulative)
    D->>A: POST /datareon/event (STATUS_COMPLETED, priority 1, выполняется последним)
    A->>A: orderStatus = DONE (без проверки transition map и полноты агрегата)
```

## Что подтверждают тесты

Отдельные звенья этой цепочки покрыты собственными тестами, уже перечисленными в детальных документах: [`ShippingOrderServiceIntegrationTest`](../database/shipping-order-root-as-is.md#что-подтверждают-tests-но-не-их-запуск) (create/accept/copy), [`ShippingOrderGoodServiceIntegrationTest`](../database/shipping-order-good-as-is.md#что-подтверждают-tests-но-не-их-запуск), [`ShippingOrderCargoServiceIntegrationTest`](../database/shipping-order-cargo-as-is.md#что-подтверждают-tests-но-не-их-запуск), [`ActionsProcessorTest`](../business-rules/inbound-event-registry-as-is.md#что-подтверждают-тесты) (приоритет/fail-fast) и `InboundEventDatareonServiceTest` (отдельные actions в изоляции). **Ни один найденный тест не проходит весь сценарий целиком** — от создания заявки до `DONE` через реальную последовательность `POST /shippingorder/*` → `accept()` → `POST /datareon/event` × N. В частности, тест для `VhDepartureAction`, воспроизводящий дефект шага 5, не найден.

## Неподтверждённое и вопросы для ТЗ

1. Нужен end-to-end интеграционный тест, реально проходящий все семь шагов подряд на одной заявке — существующие тесты проверяют шаги по отдельности с собственными fixtures.
2. Нужно решить, является ли жёстко закодированный `WAREHOUSE` в `VhDepartureAction` дефектом (тогда заменить на `TerminalAreaEnum.valueOf(shippingOrder.getTerminalArea().getCode())`, как у всех остальных actions) или намеренным решением («время выезда фиксируем для любой площадки, конфиг здесь ни при чём») — в последнем случае колонки `terminal_area` в конфиге для строки `VH_DEPARTURE` не нужны и вводят в заблуждение.
3. Нужно подтвердить реальную production-последовательность/комбинацию `eventCode → action_code` для этого сценария — репозиторий подтверждает только сам факт существования диспетчера и одну активную строку (`VH_DEPARTURE`), но не то, какие именно events реальный Datareon/WMS шлют для конкретного склада.
4. Нужен ответ, действительно ли `ShippingOrderService.accept(UUID)` недоступен через HTTP, или endpoint существует вне просмотренных контроллеров.
5. Нужно решить порядок согласования между `actualQuantity` (факт) и plan-based root totals — сейчас это две независимые метрики, и сценарий не показывает точки их сверки.

## Связанные документы

- [Корень заявки на вывоз: физическая модель AS-IS](../database/shipping-order-root-as-is.md)
- [Транспорт заявки на вывоз: физическая модель AS-IS](../database/shipping-order-transport-as-is.md)
- [Номенклатура заявки на вывоз: физическая модель AS-IS](../database/shipping-order-good-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](../database/shipping-order-cargo-as-is.md)
- [Дополнительная услуга заявки на вывоз: физическая модель AS-IS](../database/shipping-order-requested-service-as-is.md)
- [ShippingOrder: сводная физическая карта AS-IS](../database/shipping-order-integrity-map.md)
- [Входящие действия вывоза](../business-rules/shipping-inbound-actions.md)
- [Реестр входящих событий Datareon: eventCode → action AS-IS](../business-rules/inbound-event-registry-as-is.md)
- [Правила вывоза](../business-rules/shipping-orders.md)
